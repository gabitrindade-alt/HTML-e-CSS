﻿from pathlib import Path
import re
root=Path('.')
valid={'.php','.css','.js','.sql','.md','.txt','.html','.svg','.json'}
pattern=re.compile(r'[\w\u0080-\uFFFF]+', re.UNICODE)
markers=('Ã','Â','â','ð','Ð')
def fix_token(token):
    if not any(ch in token for ch in markers): return token
    out=token
    for _ in range(3):
        try: candidate=out.encode('cp1252').decode('utf-8')
        except (UnicodeEncodeError,UnicodeDecodeError): break
        if candidate==out: break
        out=candidate
    return out
changed=[]
for p in root.rglob('*'):
    if not p.is_file() or p.suffix.lower() not in valid or any(part in {'.git','node_modules'} for part in p.parts): continue
    try: original=p.read_text(encoding='utf-8-sig')
    except (UnicodeDecodeError,OSError): continue
    updated=pattern.sub(lambda m:fix_token(m.group()),original)
    if updated!=original:
        changed.append((str(p),original.count('\n'),sum(1 for a,b in zip(original,updated) if a!=b)))
print('would change',len(changed),'files')
for p,lines,n in changed: print(f'{p}: chars affected ~{n}')
