-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 24/11/2026 às 20:32
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `velluto`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `areas_entrega`
--

CREATE TABLE `areas_entrega` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(80) NOT NULL,
  `cidade` varchar(80) NOT NULL,
  `uf` char(2) NOT NULL,
  `cep_inicio` char(8) NOT NULL,
  `cep_fim` char(8) NOT NULL,
  `valor_frete` decimal(10,2) NOT NULL DEFAULT 0.00,
  `valor_expresso` decimal(10,2) DEFAULT NULL,
  `frete_gratis_acima` decimal(10,2) DEFAULT NULL,
  `prazo_padrao` varchar(40) NOT NULL DEFAULT 'até 2 dias',
  `prazo_expresso` varchar(40) DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `areas_entrega`
--

INSERT INTO `areas_entrega` (`id`, `nome`, `cidade`, `uf`, `cep_inicio`, `cep_fim`, `valor_frete`, `valor_expresso`, `frete_gratis_acima`, `prazo_padrao`, `prazo_expresso`, `ativo`, `criado_em`) VALUES
(1, 'Centro e Bela Vista', 'São Paulo', 'SP', '01000000', '01599999', 1.00, 2.00, 199.00, 'até 4 horas', 'até 2 horas', 1, '2026-11-24 08:22:22'),
(2, 'Zona Norte', 'São Paulo', 'SP', '02000000', '02999999', 1.00, 2.00, 249.00, 'até 4 horas', 'até 2 horas', 1, '2026-11-24 08:22:22'),
(3, 'Zona Sul', 'São Paulo', 'SP', '04000000', '04999999', 1.00, 2.00, 199.00, 'até 4 horas', 'até 2 horas', 1, '2026-11-24 08:22:22'),
(4, 'Zona Oeste', 'São Paulo', 'SP', '05000000', '05899999', 1.00, 2.00, 199.00, 'até 4 horas', 'até 2 horas', 1, '2026-11-24 08:22:22'),
(5, 'Zona Leste', 'São Paulo', 'SP', '08000000', '08499999', 1.00, 2.00, 249.00, 'até 4 horas', 'até 2 horas', 1, '2026-11-24 08:22:22');

-- --------------------------------------------------------

--
-- Estrutura para tabela `avaliacoes`
--

CREATE TABLE `avaliacoes` (
  `id` int(10) UNSIGNED NOT NULL,
  `produto_id` int(10) UNSIGNED NOT NULL,
  `usuario_id` int(10) UNSIGNED NOT NULL,
  `nota` tinyint(4) NOT NULL,
  `comentario` varchar(500) DEFAULT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ;

--
-- Despejando dados para a tabela `avaliacoes`
--

INSERT INTO `avaliacoes` (`id`, `produto_id`, `usuario_id`, `nota`, `comentario`, `criado_em`) VALUES
(1, 1, 6, 5, 'Grão soltinho, ótimo custo-benefício.', '2026-11-19 08:22:22'),
(2, 5, 6, 4, 'Aroma excelente. Chegou bem embalado.', '2026-11-20 08:22:22'),
(3, 37, 7, 5, 'Corte perfeito, peso bem conferido.', '2026-11-19 08:22:22');

-- --------------------------------------------------------

--
-- Estrutura para tabela `carrossel_banners`
--

CREATE TABLE `carrossel_banners` (
  `chave` varchar(32) NOT NULL,
  `rotulo` varchar(32) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `texto` varchar(220) NOT NULL,
  `botao` varchar(40) NOT NULL,
  `destino` varchar(230) NOT NULL,
  `imagem` varchar(230) NOT NULL,
  `alt` varchar(150) NOT NULL,
  `ordem` smallint(5) UNSIGNED NOT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `categorias`
--

CREATE TABLE `categorias` (
  `id` int(10) UNSIGNED NOT NULL,
  `pai_id` int(10) UNSIGNED DEFAULT NULL,
  `nome` varchar(80) NOT NULL,
  `slug` varchar(90) NOT NULL,
  `icone` varchar(16) DEFAULT NULL,
  `cor` char(7) NOT NULL DEFAULT '#EADFD3',
  `descricao` varchar(255) DEFAULT NULL,
  `ordem` int(11) NOT NULL DEFAULT 0,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `categorias`
--

INSERT INTO `categorias` (`id`, `pai_id`, `nome`, `slug`, `icone`, `cor`, `descricao`, `ordem`, `ativo`, `criado_em`) VALUES
(1, NULL, 'Alimentos', 'alimentos', '🥖', '#EAD2B0', 'Mercearia, laticínios, congelados e enlatados para o dia a dia.', 1, 1, '2026-11-24 08:22:21'),
(2, NULL, 'Bebidas', 'bebidas', '🧃', '#F2BFCB', 'Águas, sucos, refrigerantes, vinhos e cervejas.', 2, 1, '2026-11-24 08:22:21'),
(3, NULL, 'Hortifruti', 'hortifruti', '🥬', '#CFE0BC', 'Frutas, legumes e verduras selecionados.', 3, 1, '2026-11-24 08:22:21'),
(4, NULL, 'Carnes', 'carnes', '🥩', '#E9B0A8', 'Carnes bovinas, suínas, aves e peixes.', 4, 1, '2026-11-24 08:22:21'),
(5, NULL, 'Padaria', 'padaria', '🥐', '#F0D9AE', 'Pães, bolos e torradas.', 5, 1, '2026-11-24 08:22:21'),
(6, NULL, 'Limpeza', 'limpeza', '🧴', '#C5DDD6', 'Tudo para deixar a casa impecável.', 6, 1, '2026-11-24 08:22:21'),
(7, NULL, 'Higiene', 'higiene', '🧼', '#DCCDE8', 'Cuidados pessoais e higiene diária.', 7, 1, '2026-11-24 08:22:21'),
(8, NULL, 'Beleza', 'beleza', '💄', '#F2C6D6', 'Maquiagem, perfumaria e cuidados.', 8, 1, '2026-11-24 08:22:21'),
(9, NULL, 'Eletrônicos', 'eletronicos', '🎧', '#CDD0DC', 'Áudio, acessórios e tecnologia.', 9, 1, '2026-11-24 08:22:21'),
(10, NULL, 'Eletrodomésticos', 'eletrodomesticos', '🍳', '#DDD3C6', 'Praticidade para a cozinha e a casa.', 10, 1, '2026-11-24 08:22:21'),
(11, NULL, 'Roupas', 'roupas', '👕', '#E8C7B6', 'Básicos confortáveis para toda a família.', 11, 1, '2026-11-24 08:22:21'),
(12, NULL, 'Casa & Decoração', 'casa-decoracao', '🕯️', '#E6D9BD', 'Aconchego e estilo para o lar.', 12, 1, '2026-11-24 08:22:21'),
(13, NULL, 'Pet', 'pet', '🐾', '#EAD5AE', 'Alimentação e cuidados para pets.', 13, 1, '2026-11-24 08:22:21'),
(14, NULL, 'Bebês', 'bebes', '🍼', '#F7D9DF', 'Cuidado e carinho para os pequenos.', 14, 1, '2026-11-24 08:22:21'),
(15, 1, 'Mercearia', 'mercearia', '🌾', '#EAD2B0', 'Grãos, massas, óleos e básicos.', 1, 1, '2026-11-24 08:22:21'),
(16, 1, 'Laticínios', 'laticinios', '🧀', '#F3E6C8', 'Leites, queijos, iogurtes e manteigas.', 2, 1, '2026-11-24 08:22:21'),
(17, 1, 'Congelados', 'congelados', '🧊', '#C9DCE6', 'Pratos prontos, sorvetes e congelados.', 3, 1, '2026-11-24 08:22:21'),
(18, 1, 'Enlatados', 'enlatados', '🥫', '#E8C4A8', 'Conservas e enlatados.', 4, 1, '2026-11-24 08:22:21');

-- --------------------------------------------------------

--
-- Estrutura para tabela `configuracoes`
--

CREATE TABLE `configuracoes` (
  `chave` varchar(60) NOT NULL,
  `valor` varchar(500) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `configuracoes`
--

INSERT INTO `configuracoes` (`chave`, `valor`, `descricao`) VALUES
('aviso_topo', 'Frete grátis acima de R$ 199 nas regiões atendidas · Pagamento 100% simulado', 'Faixa de aviso no topo do site'),
('email_contato', 'contato@velluto.com', 'E-mail de atendimento'),
('nome_loja', 'Velluto', 'Nome exibido na loja'),
('slogan', 'Tudo para sua casa, em um só lugar.', 'Frase de destaque da página inicial'),
('telefone_contato', '(11) 4000-1000', 'Telefone de atendimento'),
('tolerancia_ajuste_percent', '10', 'Aumento máximo (%) no total por diferença de peso sem nova aprovação do cliente'),
('valor_minimo_pedido', '20', 'Valor mínimo de produtos para finalizar a compra (R$)');

-- --------------------------------------------------------

--
-- Estrutura para tabela `enderecos`
--

CREATE TABLE `enderecos` (
  `id` int(10) UNSIGNED NOT NULL,
  `usuario_id` int(10) UNSIGNED NOT NULL,
  `apelido` varchar(40) NOT NULL DEFAULT 'Casa',
  `destinatario` varchar(120) NOT NULL,
  `cep` char(8) NOT NULL,
  `logradouro` varchar(160) NOT NULL,
  `numero` varchar(10) NOT NULL,
  `complemento` varchar(80) DEFAULT NULL,
  `bairro` varchar(80) NOT NULL,
  `cidade` varchar(80) NOT NULL,
  `uf` char(2) NOT NULL,
  `referencia` varchar(160) DEFAULT NULL,
  `principal` tinyint(1) NOT NULL DEFAULT 0,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `enderecos`
--

INSERT INTO `enderecos` (`id`, `usuario_id`, `apelido`, `destinatario`, `cep`, `logradouro`, `numero`, `complemento`, `bairro`, `cidade`, `uf`, `referencia`, `principal`, `ativo`, `criado_em`) VALUES
(1, 6, 'Casa', 'Maria Oliveira', '01234567', 'Rua das Flores', '123', 'Apto 42', 'Jardim Bela Vista', 'São Paulo', 'SP', 'Próximo à praça', 1, 1, '2026-11-24 08:22:21'),
(2, 6, 'Trabalho', 'Maria Oliveira', '04538133', 'Avenida das Magnólias', '1500', '8º andar', 'Vila Olímpia', 'São Paulo', 'SP', NULL, 0, 1, '2026-11-24 08:22:21'),
(3, 7, 'Casa', 'João Pereira', '05422010', 'Rua dos Ipês', '77', NULL, 'Pinheiros', 'São Paulo', 'SP', NULL, 1, 1, '2026-11-24 08:22:21'),
(4, 8, 'Casa', 'matheus', '08160450', 'R PARAITINGA', '87', 'Casa', 'VL SIMONE', 'SÃO PAULO', 'SP', NULL, 1, 1, '2026-11-24 09:05:04'),
(5, 12, 'Casa', 'Moises Stain Bademian', '08501100', 'Rua Paraibuna', '432', NULL, 'Sitio Paredão', 'Ferraz de Vasconcelos', 'SP', NULL, 1, 1, '2026-11-24 11:51:17'),
(6, 13, 'Casa', 'Gaby Trindade', '08160450', 'R PARAITINGA', '87', 'Casa', 'VL SIMONE', 'SÃO PAULO', 'SP', NULL, 1, 1, '2026-11-24 15:14:45');

-- --------------------------------------------------------

--
-- Estrutura para tabela `entregas`
--

CREATE TABLE `entregas` (
  `id` int(10) UNSIGNED NOT NULL,
  `pedido_id` int(10) UNSIGNED NOT NULL,
  `entregador_id` int(10) UNSIGNED DEFAULT NULL,
  `status` enum('disponivel','atribuida','em_rota','entregue','cancelada') NOT NULL DEFAULT 'disponivel',
  `tentativas` int(11) NOT NULL DEFAULT 0,
  `assumida_em` datetime DEFAULT NULL,
  `retirada_em` datetime DEFAULT NULL,
  `entregue_em` datetime DEFAULT NULL,
  `recebedor` varchar(120) DEFAULT NULL,
  `observacao` varchar(255) DEFAULT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `entregas`
--

INSERT INTO `entregas` (`id`, `pedido_id`, `entregador_id`, `status`, `tentativas`, `assumida_em`, `retirada_em`, `entregue_em`, `recebedor`, `observacao`, `criado_em`) VALUES
(1, 1, 3, 'entregue', 1, '2026-11-18 07:22:22', '2026-11-18 07:22:22', '2026-11-18 09:22:22', 'Maria', NULL, '2026-11-18 06:22:22'),
(2, 2, 3, 'entregue', 1, '2026-11-18 11:22:22', '2026-11-18 11:22:22', '2026-11-18 13:22:22', 'João', NULL, '2026-11-18 10:22:22'),
(3, 3, 3, 'entregue', 1, '2026-11-19 09:22:22', '2026-11-19 09:22:22', '2026-11-19 11:22:22', 'Maria', NULL, '2026-11-19 08:22:22'),
(4, 4, 3, 'entregue', 1, '2026-11-20 06:22:22', '2026-11-20 06:22:22', '2026-11-20 08:22:22', 'Maria', NULL, '2026-11-20 05:22:22'),
(5, 5, 3, 'entregue', 1, '2026-11-20 10:22:22', '2026-11-20 10:22:22', '2026-11-20 12:22:22', 'João', NULL, '2026-11-20 09:22:22'),
(6, 6, 3, 'entregue', 1, '2026-11-21 08:22:22', '2026-11-21 08:22:22', '2026-11-21 10:22:22', 'Maria', NULL, '2026-11-21 07:22:22'),
(7, 7, 3, 'entregue', 1, '2026-11-22 05:22:22', '2026-11-22 05:22:22', '2026-11-22 07:22:22', 'João', NULL, '2026-11-22 04:22:22'),
(8, 8, 3, 'entregue', 1, '2026-11-22 10:22:22', '2026-11-22 10:22:22', '2026-11-22 12:22:22', 'Maria', NULL, '2026-11-22 09:22:22'),
(9, 10, 3, 'entregue', 1, '2026-11-23 09:22:22', '2026-11-23 09:22:22', '2026-11-23 11:22:22', 'Maria', NULL, '2026-11-23 08:22:22'),
(10, 11, 3, 'entregue', 1, '2026-11-23 11:22:22', '2026-11-23 11:22:22', '2026-11-23 13:22:22', 'João', NULL, '2026-11-23 10:22:22'),
(11, 12, NULL, 'disponivel', 1, NULL, '2026-11-24 16:39:29', NULL, NULL, 'cliente_ausente_primeira_tentativa', '2026-11-23 15:22:22'),
(12, 16, 11, 'entregue', 1, '2026-11-24 10:32:35', '2026-11-24 10:32:38', '2026-11-24 10:33:42', 'Matheus', NULL, '2026-11-24 10:30:37');

-- --------------------------------------------------------

--
-- Estrutura para tabela `favoritos`
--

CREATE TABLE `favoritos` (
  `id` int(10) UNSIGNED NOT NULL,
  `usuario_id` int(10) UNSIGNED NOT NULL,
  `produto_id` int(10) UNSIGNED NOT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `historico_pedidos`
--

CREATE TABLE `historico_pedidos` (
  `id` int(10) UNSIGNED NOT NULL,
  `pedido_id` int(10) UNSIGNED NOT NULL,
  `status_anterior` varchar(30) DEFAULT NULL,
  `status_novo` varchar(30) NOT NULL,
  `usuario_id` int(10) UNSIGNED DEFAULT NULL,
  `perfil` varchar(20) DEFAULT NULL,
  `descricao` varchar(500) NOT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `historico_pedidos`
--

INSERT INTO `historico_pedidos` (`id`, `pedido_id`, `status_anterior`, `status_novo`, `usuario_id`, `perfil`, `descricao`, `criado_em`) VALUES
(1, 1, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', '2026-11-18 03:22:22'),
(2, 1, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', '2026-11-18 03:22:22'),
(3, 1, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', '2026-11-18 05:22:22'),
(4, 1, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', '2026-11-18 06:22:22'),
(5, 1, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', '2026-11-18 07:22:22'),
(6, 1, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: Maria', '2026-11-18 09:22:22'),
(7, 2, 'aguardando_pagamento', 'confirmado', 7, 'cliente', 'Pagamento simulado aprovado.', '2026-11-18 07:22:22'),
(8, 2, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', '2026-11-18 07:22:22'),
(9, 2, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', '2026-11-18 09:22:22'),
(10, 2, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', '2026-11-18 10:22:22'),
(11, 2, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', '2026-11-18 11:22:22'),
(12, 2, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: João', '2026-11-18 13:22:22'),
(13, 3, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', '2026-11-19 05:22:22'),
(14, 3, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', '2026-11-19 05:22:22'),
(15, 3, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', '2026-11-19 07:22:22'),
(16, 3, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', '2026-11-19 08:22:22'),
(17, 3, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', '2026-11-19 09:22:22'),
(18, 3, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: Maria', '2026-11-19 11:22:22'),
(19, 4, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', '2026-11-20 02:22:22'),
(20, 4, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', '2026-11-20 02:22:22'),
(21, 4, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', '2026-11-20 04:22:22'),
(22, 4, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', '2026-11-20 05:22:22'),
(23, 4, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', '2026-11-20 06:22:22'),
(24, 4, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: Maria', '2026-11-20 08:22:22'),
(25, 5, 'aguardando_pagamento', 'confirmado', 7, 'cliente', 'Pagamento simulado aprovado.', '2026-11-20 06:22:22'),
(26, 5, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', '2026-11-20 06:22:22'),
(27, 5, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', '2026-11-20 08:22:22'),
(28, 5, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', '2026-11-20 09:22:22'),
(29, 5, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', '2026-11-20 10:22:22'),
(30, 5, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: João', '2026-11-20 12:22:22'),
(31, 6, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', '2026-11-21 04:22:22'),
(32, 6, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', '2026-11-21 04:22:22'),
(33, 6, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', '2026-11-21 06:22:22'),
(34, 6, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', '2026-11-21 07:22:22'),
(35, 6, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', '2026-11-21 08:22:22'),
(36, 6, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: Maria', '2026-11-21 10:22:22'),
(37, 7, 'aguardando_pagamento', 'confirmado', 7, 'cliente', 'Pagamento simulado aprovado.', '2026-11-22 01:22:22'),
(38, 7, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', '2026-11-22 01:22:22'),
(39, 7, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', '2026-11-22 03:22:22'),
(40, 7, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', '2026-11-22 04:22:22'),
(41, 7, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', '2026-11-22 05:22:22'),
(42, 7, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: João', '2026-11-22 07:22:22'),
(43, 8, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', '2026-11-22 06:22:22'),
(44, 8, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', '2026-11-22 06:22:22'),
(45, 8, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', '2026-11-22 08:22:22'),
(46, 8, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', '2026-11-22 09:22:22'),
(47, 8, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', '2026-11-22 10:22:22'),
(48, 8, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: Maria', '2026-11-22 12:22:22'),
(49, 9, 'aguardando_pagamento', 'confirmado', 7, 'cliente', 'Pagamento simulado aprovado.', '2026-11-23 02:22:22'),
(50, 9, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', '2026-11-23 02:22:22'),
(51, 9, 'aguardando_separacao', 'cancelado', 7, 'cliente', 'Pedido cancelado pelo cliente. Motivo: Desistência da compra', '2026-11-23 03:22:22'),
(52, 10, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', '2026-11-23 05:22:22'),
(53, 10, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', '2026-11-23 05:22:22'),
(54, 10, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', '2026-11-23 07:22:22'),
(55, 10, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', '2026-11-23 08:22:22'),
(56, 10, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', '2026-11-23 09:22:22'),
(57, 10, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: Maria', '2026-11-23 11:22:22'),
(58, 11, 'aguardando_pagamento', 'confirmado', 7, 'cliente', 'Pagamento simulado aprovado.', '2026-11-23 07:22:22'),
(59, 11, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', '2026-11-23 07:22:22'),
(60, 11, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', '2026-11-23 09:22:22'),
(61, 11, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', '2026-11-23 10:22:22'),
(62, 11, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', '2026-11-23 11:22:22'),
(63, 11, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: João', '2026-11-23 13:22:22'),
(64, 12, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', '2026-11-23 12:22:22'),
(65, 12, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', '2026-11-23 12:22:22'),
(66, 12, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', '2026-11-23 14:22:22'),
(67, 12, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', '2026-11-23 15:22:22'),
(68, 13, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', '2026-11-24 05:22:22'),
(69, 13, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', '2026-11-24 05:22:22'),
(70, 14, 'aguardando_pagamento', 'confirmado', 7, 'cliente', 'Pagamento simulado aprovado.', '2026-11-24 06:22:22'),
(71, 14, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', '2026-11-24 06:22:22'),
(72, 15, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', '2026-11-24 07:22:22'),
(73, 15, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', '2026-11-24 07:22:22'),
(74, 16, NULL, 'aguardando_pagamento', 8, 'cliente', 'Pedido criado pelo cliente (2 itens, R$ 134,70).', '2026-11-24 09:09:23'),
(75, 16, 'aguardando_pagamento', 'confirmado', 8, 'cliente', 'Pagamento simulado aprovado via PIX.', '2026-11-24 09:09:23'),
(76, 16, 'confirmado', 'aguardando_separacao', 8, 'cliente', 'Pedido liberado para separação.', '2026-11-24 09:09:23'),
(77, 13, 'aguardando_separacao', 'em_separacao', 10, 'separador', 'Separação iniciada por Igor Alves.', '2026-11-24 09:57:22'),
(78, 16, 'aguardando_separacao', 'em_separacao', 10, 'separador', 'Separação iniciada por Igor Alves.', '2026-11-24 10:30:20'),
(79, 16, 'em_separacao', 'em_separacao', 10, 'separador', '\"Carne Moída de Patinho\" conferido: 1 kg (R$ 39,90). Total atual R$ 134,70.', '2026-11-24 10:30:30'),
(80, 16, 'em_separacao', 'em_separacao', 10, 'separador', '\"Picanha Bovina\" conferido: 1 kg (R$ 79,90). Total atual R$ 134,70.', '2026-11-24 10:30:31'),
(81, 16, 'em_separacao', 'aguardando_entrega', 10, 'separador', 'Separação concluída por Igor Alves — 1 volume(s) embalado(s). Pedido pronto para entrega.', '2026-11-24 10:30:37'),
(82, 16, 'aguardando_entrega', 'aguardando_entrega', 11, 'entregador', 'Entrega assumida por Maria Clara.', '2026-11-24 10:32:35'),
(83, 16, 'aguardando_entrega', 'saiu_para_entrega', 11, 'entregador', 'Pedido retirado por Maria Clara — entrega em andamento.', '2026-11-24 10:32:38'),
(84, 16, 'saiu_para_entrega', 'concluido', 11, 'entregador', 'Entrega concluída por Maria Clara. Recebido por: Matheus.', '2026-11-24 10:33:42'),
(85, 14, 'aguardando_separacao', 'em_separacao', 10, 'separador', 'Separação iniciada por Igor Alves.', '2026-11-24 11:15:13'),
(86, 14, 'em_separacao', 'em_separacao', 10, 'separador', '\"Morango\" conferido: 2 un (R$ 11,80). Total atual R$ 58,50.', '2026-11-24 11:16:28'),
(87, 14, 'em_separacao', 'em_separacao', 10, 'separador', '\"Bolo de Cenoura\" conferido: 1 un (R$ 18,90). Total atual R$ 58,50.', '2026-11-24 11:16:39'),
(88, 14, 'em_separacao', 'em_separacao', 10, 'separador', '\"Suco de Uva Integral\" indisponível no momento da separação.', '2026-11-24 11:16:43'),
(89, 14, 'em_separacao', 'aguardando_aprovacao', 10, 'separador', 'Substituição sugerida: \"Suco de Uva Integral\" → \"Vinho Tinto Seco\" (diferença R$ 29,00). Aguardando resposta do cliente.', '2026-11-24 11:17:21'),
(90, 17, NULL, 'aguardando_pagamento', 8, 'cliente', 'Pedido criado pelo cliente (7 itens, R$ 183,80).', '2026-11-24 14:35:31'),
(91, 17, 'aguardando_pagamento', 'confirmado', 8, 'cliente', 'Pagamento simulado aprovado via PIX.', '2026-11-24 14:35:31'),
(92, 17, 'confirmado', 'aguardando_separacao', 8, 'cliente', 'Pedido liberado para separação.', '2026-11-24 14:35:31'),
(93, 12, 'aguardando_entrega', 'aguardando_entrega', 11, 'entregador', 'Entrega assumida por Maria Clara.', '2026-11-24 14:38:41'),
(94, 12, 'aguardando_entrega', 'saiu_para_entrega', 11, 'entregador', 'Pedido retirado por Maria Clara — entrega em andamento.', '2026-11-24 14:38:47'),
(95, 12, 'saiu_para_entrega', 'aguardando_entrega', 11, 'entregador', 'Tentativa de entrega sem sucesso (ocorrência #4: cliente_ausente). Pedido retornou à loja para nova entrega.', '2026-11-24 14:39:29'),
(96, 18, NULL, 'aguardando_pagamento', 13, 'cliente', 'Pedido criado pelo cliente (1 itens, R$ 401,90).', '2026-11-24 15:15:26'),
(97, 18, 'aguardando_pagamento', 'confirmado', 13, 'cliente', 'Pagamento simulado aprovado via PIX.', '2026-11-24 15:15:26'),
(98, 18, 'confirmado', 'aguardando_separacao', 13, 'cliente', 'Pedido liberado para separação.', '2026-11-24 15:15:26');

-- --------------------------------------------------------

--
-- Estrutura para tabela `itens_pedido`
--

CREATE TABLE `itens_pedido` (
  `id` int(10) UNSIGNED NOT NULL,
  `pedido_id` int(10) UNSIGNED NOT NULL,
  `produto_id` int(10) UNSIGNED NOT NULL,
  `nome_produto` varchar(140) NOT NULL,
  `vendido_por` enum('unidade','peso') NOT NULL DEFAULT 'unidade',
  `quantidade` decimal(10,3) NOT NULL,
  `quantidade_separada` decimal(10,3) DEFAULT NULL,
  `preco_unitario` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `status` enum('pendente','separado','indisponivel','substituido','removido') NOT NULL DEFAULT 'pendente',
  `item_origem_id` int(10) UNSIGNED DEFAULT NULL,
  `observacao` varchar(255) DEFAULT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ;

--
-- Despejando dados para a tabela `itens_pedido`
--

INSERT INTO `itens_pedido` (`id`, `pedido_id`, `produto_id`, `nome_produto`, `vendido_por`, `quantidade`, `quantidade_separada`, `preco_unitario`, `subtotal`, `status`, `item_origem_id`, `observacao`, `criado_em`) VALUES
(1, 1, 1, 'Arroz Tipo 1', 'unidade', 1.000, 1.000, 24.90, 24.90, 'separado', NULL, NULL, '2026-11-18 03:22:22'),
(2, 1, 2, 'Feijão Carioca', 'unidade', 2.000, 2.000, 8.49, 16.98, 'separado', NULL, NULL, '2026-11-18 03:22:22'),
(3, 1, 29, 'Banana Prata', 'peso', 1.000, 1.000, 6.90, 6.90, 'separado', NULL, NULL, '2026-11-18 03:22:22'),
(4, 1, 9, 'Leite Integral', 'unidade', 6.000, 6.000, 5.49, 32.94, 'separado', NULL, NULL, '2026-11-18 03:22:22'),
(5, 2, 37, 'Picanha Bovina', 'peso', 1.200, 1.200, 79.90, 95.88, 'separado', NULL, NULL, '2026-11-18 07:22:22'),
(6, 2, 27, 'Cerveja Artesanal', 'unidade', 6.000, 6.000, 12.90, 77.40, 'separado', NULL, NULL, '2026-11-18 07:22:22'),
(7, 2, 43, 'Pão Francês', 'peso', 0.500, 0.500, 16.90, 8.45, 'separado', NULL, NULL, '2026-11-18 07:22:22'),
(8, 3, 5, 'Café Torrado e Moído', 'unidade', 2.000, 2.000, 16.90, 33.80, 'separado', NULL, NULL, '2026-11-19 05:22:22'),
(9, 3, 46, 'Croissant de Manteiga', 'unidade', 4.000, 4.000, 6.50, 26.00, 'separado', NULL, NULL, '2026-11-19 05:22:22'),
(10, 3, 12, 'Iogurte Natural', 'unidade', 4.000, 4.000, 3.29, 13.16, 'separado', NULL, NULL, '2026-11-19 05:22:22'),
(11, 4, 49, 'Sabão Líquido para Roupas', 'unidade', 1.000, 1.000, 34.90, 34.90, 'separado', NULL, NULL, '2026-11-20 02:22:22'),
(12, 4, 48, 'Detergente Neutro', 'unidade', 3.000, 3.000, 2.79, 8.37, 'separado', NULL, NULL, '2026-11-20 02:22:22'),
(13, 4, 57, 'Papel Higiênico Folha Dupla', 'unidade', 1.000, 1.000, 19.90, 19.90, 'separado', NULL, NULL, '2026-11-20 02:22:22'),
(14, 5, 64, 'Fone de Ouvido Bluetooth', 'unidade', 1.000, 1.000, 159.90, 159.90, 'separado', NULL, NULL, '2026-11-20 06:22:22'),
(15, 5, 65, 'Carregador USB-C 20W', 'unidade', 1.000, 1.000, 79.90, 79.90, 'separado', NULL, NULL, '2026-11-20 06:22:22'),
(16, 6, 15, 'Pizza Margherita', 'unidade', 2.000, 2.000, 16.90, 33.80, 'separado', NULL, NULL, '2026-11-21 04:22:22'),
(17, 6, 25, 'Refrigerante de Cola', 'unidade', 2.000, 2.000, 8.99, 17.98, 'separado', NULL, NULL, '2026-11-21 04:22:22'),
(18, 6, 18, 'Sorvete de Creme', 'unidade', 1.000, 1.000, 22.90, 22.90, 'separado', NULL, NULL, '2026-11-21 04:22:22'),
(19, 7, 30, 'Maçã Gala', 'peso', 1.500, 1.500, 9.90, 14.85, 'separado', NULL, NULL, '2026-11-22 01:22:22'),
(20, 7, 31, 'Tomate', 'peso', 1.000, 1.000, 7.49, 7.49, 'separado', NULL, NULL, '2026-11-22 01:22:22'),
(21, 7, 33, 'Alface Crespa', 'unidade', 2.000, 2.000, 3.49, 6.98, 'separado', NULL, NULL, '2026-11-22 01:22:22'),
(22, 7, 38, 'Filé de Peito de Frango', 'peso', 1.000, 1.000, 22.90, 22.90, 'separado', NULL, NULL, '2026-11-22 01:22:22'),
(23, 8, 62, 'Perfume Floral', 'unidade', 1.000, 1.000, 109.90, 109.90, 'separado', NULL, NULL, '2026-11-22 06:22:22'),
(24, 8, 59, 'Hidratante Corporal', 'unidade', 1.000, 1.000, 29.90, 29.90, 'separado', NULL, NULL, '2026-11-22 06:22:22'),
(25, 9, 84, 'Ração para Gatos', 'unidade', 1.000, NULL, 69.90, 69.90, 'pendente', NULL, NULL, '2026-11-23 02:22:22'),
(26, 9, 86, 'Areia Higiênica', 'unidade', 2.000, NULL, 24.90, 49.80, 'pendente', NULL, NULL, '2026-11-23 02:22:22'),
(27, 10, 26, 'Vinho Tinto Seco', 'unidade', 2.000, 2.000, 42.90, 85.80, 'separado', NULL, NULL, '2026-11-23 05:22:22'),
(28, 10, 11, 'Queijo Muçarela Fatiado', 'unidade', 1.000, 1.000, 11.90, 11.90, 'separado', NULL, NULL, '2026-11-23 05:22:22'),
(29, 10, 8, 'Azeite Extravirgem', 'unidade', 1.000, 1.000, 28.90, 28.90, 'separado', NULL, NULL, '2026-11-23 05:22:22'),
(30, 11, 87, 'Fralda Tamanho M', 'unidade', 2.000, 2.000, 59.90, 119.80, 'separado', NULL, NULL, '2026-11-23 07:22:22'),
(31, 11, 88, 'Lenço Umedecido', 'unidade', 3.000, 3.000, 9.90, 29.70, 'separado', NULL, NULL, '2026-11-23 07:22:22'),
(32, 12, 69, 'Air Fryer 4 L', 'unidade', 1.000, 1.000, 399.90, 399.90, 'separado', NULL, NULL, '2026-11-23 12:22:22'),
(33, 13, 1, 'Arroz Tipo 1', 'unidade', 1.000, NULL, 24.90, 24.90, 'pendente', NULL, NULL, '2026-11-24 05:22:22'),
(34, 13, 10, 'Leite Semidesnatado', 'unidade', 2.000, NULL, 5.29, 10.58, 'pendente', NULL, NULL, '2026-11-24 05:22:22'),
(35, 13, 29, 'Banana Prata', 'peso', 1.500, NULL, 6.90, 10.35, 'pendente', NULL, NULL, '2026-11-24 05:22:22'),
(36, 13, 5, 'Café Torrado e Moído', 'unidade', 1.000, NULL, 16.90, 16.90, 'pendente', NULL, NULL, '2026-11-24 05:22:22'),
(37, 14, 36, 'Morango', 'unidade', 2.000, 2.000, 5.90, 11.80, 'separado', NULL, NULL, '2026-11-24 06:22:22'),
(38, 14, 45, 'Bolo de Cenoura', 'unidade', 1.000, 1.000, 18.90, 18.90, 'separado', NULL, NULL, '2026-11-24 06:22:22'),
(39, 14, 24, 'Suco de Uva Integral', 'unidade', 1.000, 0.000, 13.90, 0.00, 'indisponivel', NULL, NULL, '2026-11-24 06:22:22'),
(40, 15, 78, 'Vela Aromática Baunilha', 'unidade', 2.000, NULL, 39.90, 79.80, 'pendente', NULL, NULL, '2026-11-24 07:22:22'),
(41, 15, 80, 'Caneca de Cerâmica', 'unidade', 2.000, NULL, 34.90, 69.80, 'pendente', NULL, NULL, '2026-11-24 07:22:22'),
(42, 16, 39, 'Carne Moída de Patinho', 'peso', 1.000, 1.000, 39.90, 39.90, 'separado', NULL, 'Peso real: 1,000 kg', '2026-11-24 09:09:23'),
(43, 16, 37, 'Picanha Bovina', 'peso', 1.000, 1.000, 79.90, 79.90, 'separado', NULL, 'Peso real: 1,000 kg', '2026-11-24 09:09:23'),
(44, 17, 99, 'Cerejas Frescas', 'unidade', 1.000, NULL, 26.31, 26.31, 'pendente', NULL, NULL, '2026-11-24 14:35:31'),
(45, 17, 145, 'Almofada com Capa de Linho', 'unidade', 1.000, NULL, 79.90, 79.90, 'pendente', NULL, NULL, '2026-11-24 14:35:31'),
(46, 17, 112, 'Aveia em Flocos', 'unidade', 1.000, NULL, 13.90, 13.90, 'pendente', NULL, NULL, '2026-11-24 14:35:31'),
(47, 17, 100, 'Azeitonas Verdes sem Caroço', 'unidade', 1.000, NULL, 13.41, 13.41, 'pendente', NULL, NULL, '2026-11-24 14:35:31'),
(48, 17, 32, 'Batata Inglesa', 'peso', 1.000, NULL, 5.99, 5.99, 'pendente', NULL, NULL, '2026-11-24 14:35:31'),
(49, 17, 17, 'Batata Pré-frita', 'unidade', 1.000, NULL, 17.49, 17.49, 'pendente', NULL, NULL, '2026-11-24 14:35:31'),
(50, 17, 131, 'Baguete Rústica', 'unidade', 1.000, NULL, 11.90, 11.90, 'pendente', NULL, NULL, '2026-11-24 14:35:31'),
(51, 18, 69, 'Air Fryer 4 L', 'unidade', 1.000, NULL, 399.90, 399.90, 'pendente', NULL, NULL, '2026-11-24 15:15:26');

-- --------------------------------------------------------

--
-- Estrutura para tabela `logs_alteracoes`
--

CREATE TABLE `logs_alteracoes` (
  `id` int(10) UNSIGNED NOT NULL,
  `usuario_id` int(10) UNSIGNED DEFAULT NULL,
  `entidade` varchar(40) NOT NULL,
  `entidade_id` int(10) UNSIGNED DEFAULT NULL,
  `acao` varchar(40) NOT NULL,
  `detalhes` varchar(2000) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `logs_alteracoes`
--

INSERT INTO `logs_alteracoes` (`id`, `usuario_id`, `entidade`, `entidade_id`, `acao`, `detalhes`, `ip`, `criado_em`) VALUES
(1, 1, 'sistema', NULL, 'instalacao', 'Banco de dados criado com dados de demonstração.', NULL, '2026-11-24 08:22:22'),
(2, NULL, 'funcionario', 9, 'criar', 'Administrador inicial', '::1', '2026-11-24 09:11:49'),
(3, 9, 'sessao', 9, 'login', 'Login no painel Administrador', '::1', '2026-11-24 09:11:59'),
(4, 9, 'produto', 4, 'editar', 'Produto \"Açúcar Refinado\" editado.', '::1', '2026-11-24 09:17:26'),
(5, 9, 'produto', 4, 'editar', 'Produto \"Açúcar Refinado\" editado.', '::1', '2026-11-24 09:17:38'),
(6, 9, 'sessao', 9, 'logout', 'Saída do painel Administrador', '::1', '2026-11-24 09:36:25'),
(7, 9, 'sessao', 9, 'login', 'Login no painel Administrador', '::1', '2026-11-24 09:38:13'),
(8, 9, 'cliente', 8, 'bloquear', 'Cliente matheus', '::1', '2026-11-24 09:44:44'),
(9, 9, 'cliente', 8, 'ativar', 'Cliente matheus', '::1', '2026-11-24 09:44:54'),
(10, 9, 'configuracao', NULL, 'editar', 'aviso_topo: \"Frete grátis acima de R$ 199 nas regiões atendidas · Pagamento 100% simulado\" → \"Frete grátis acima de R$ 199 nas regiões atendidas · Pagamento 10% simulado\"; valor_minimo_pedido: \"20.00\" → \"20\"', '::1', '2026-11-24 09:52:09'),
(11, 9, 'configuracao', NULL, 'editar', 'aviso_topo: \"Frete grátis acima de R$ 199 nas regiões atendidas · Pagamento 10% simulado\" → \"Frete grátis acima de R$ 199 nas regiões atendidas · Pagamento 100% simulado\"', '::1', '2026-11-24 09:52:26'),
(12, 9, 'sessao', 9, 'logout', 'Saída do painel Administrador', '::1', '2026-11-24 09:52:30'),
(13, NULL, 'funcionario', 10, 'criar', 'Cadastro local de separador', '::1', '2026-11-24 09:53:15'),
(14, 10, 'sessao', 10, 'login', 'Login no painel Separador', '::1', '2026-11-24 09:53:29'),
(15, 10, 'sessao', 10, 'logout', 'Saída do painel Separador', '::1', '2026-11-24 10:30:41'),
(16, NULL, 'funcionario', 11, 'criar', 'Cadastro local de entregador', '::1', '2026-11-24 10:31:50'),
(17, 11, 'sessao', 11, 'login', 'Login no painel Entregador', '::1', '2026-11-24 10:32:02'),
(18, 11, 'sessao', 11, 'logout', 'Saída do painel Entregador', '::1', '2026-11-24 10:34:06'),
(19, 10, 'sessao', 10, 'login', 'Login no painel Separador', '::1', '2026-11-24 10:44:49'),
(20, 10, 'sessao', 10, 'logout', 'Saída do painel Separador', '::1', '2026-11-24 11:17:40'),
(21, 9, 'sessao', 9, 'login', 'Login no painel Administrador', '::1', '2026-11-24 14:36:03'),
(22, 9, 'sessao', 9, 'logout', 'Saída do painel Administrador', '::1', '2026-11-24 14:38:20'),
(23, 11, 'sessao', 11, 'login', 'Login no painel Entregador', '::1', '2026-11-24 14:38:32'),
(24, 11, 'sessao', 11, 'logout', 'Saída do painel Entregador', '::1', '2026-11-24 14:40:17'),
(25, 9, 'sessao', 9, 'login', 'Login no painel Administrador', '::1', '2026-11-24 14:58:43'),
(26, 9, 'produto', 35, 'editar', 'Produto \"Abacate\" editado: estoque 30 kg -> 3.000 kg', '::1', '2026-11-24 15:01:10'),
(27, 9, 'produto', 35, 'editar', 'Produto \"Abacate\" editado: estoque 3.000 kg -> 30 kg', '::1', '2026-11-24 15:01:30'),
(28, 9, 'sessao', 9, 'logout', 'Saída do painel Administrador', '::1', '2026-11-24 15:13:37'),
(29, 9, 'sessao', 9, 'login', 'Login no painel Administrador', '::1', '2026-11-24 15:15:42'),
(30, 9, 'sessao', 9, 'logout', 'Saída do painel Administrador', '::1', '2026-11-24 15:17:05'),
(31, 10, 'sessao', 10, 'login', 'Login no painel Separador', '::1', '2026-11-24 15:17:13'),
(32, 10, 'sessao', 10, 'logout', 'Saída do painel Separador', '::1', '2026-11-24 15:17:18'),
(33, 9, 'sessao', 9, 'login', 'Login no painel Administrador', '::1', '2026-11-24 15:52:52'),
(34, 9, 'estoque', 10, 'entrada', '\"Leite Semidesnatado\": +10,000 — Necessário.', '::1', '2026-11-24 16:15:54'),
(35, 9, 'sessao', 9, 'logout', 'Saída do painel Administrador', '::1', '2026-11-24 16:19:55'),
(36, 11, 'sessao', 11, 'login', 'Login no painel Entregador', '::1', '2026-11-24 16:20:20'),
(37, 11, 'sessao', 11, 'logout', 'Saída do painel Entregador', '::1', '2026-11-24 16:20:26'),
(38, 10, 'sessao', 10, 'login', 'Login no painel Separador', '::1', '2026-11-24 16:20:53'),
(39, 10, 'sessao', 10, 'logout', 'Saída do painel Separador', '::1', '2026-11-24 16:21:01');

-- --------------------------------------------------------

--
-- Estrutura para tabela `movimentacoes_estoque`
--

CREATE TABLE `movimentacoes_estoque` (
  `id` int(10) UNSIGNED NOT NULL,
  `produto_id` int(10) UNSIGNED NOT NULL,
  `tipo` enum('entrada','saida','venda','estorno','ajuste','substituicao','ajuste_peso') NOT NULL,
  `quantidade` decimal(10,3) NOT NULL,
  `estoque_anterior` decimal(10,3) NOT NULL,
  `estoque_posterior` decimal(10,3) NOT NULL,
  `pedido_id` int(10) UNSIGNED DEFAULT NULL,
  `usuario_id` int(10) UNSIGNED DEFAULT NULL,
  `observacao` varchar(255) DEFAULT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `movimentacoes_estoque`
--

INSERT INTO `movimentacoes_estoque` (`id`, `produto_id`, `tipo`, `quantidade`, `estoque_anterior`, `estoque_posterior`, `pedido_id`, `usuario_id`, `observacao`, `criado_em`) VALUES
(1, 1, 'entrada', 80.000, 0.000, 80.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(2, 2, 'entrada', 120.000, 0.000, 120.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(3, 3, 'entrada', 90.000, 0.000, 90.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(4, 4, 'entrada', 100.000, 0.000, 100.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(5, 5, 'entrada', 60.000, 0.000, 60.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(6, 6, 'entrada', 140.000, 0.000, 140.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(7, 7, 'entrada', 70.000, 0.000, 70.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(8, 8, 'entrada', 35.000, 0.000, 35.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(9, 9, 'entrada', 150.000, 0.000, 150.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(10, 11, 'entrada', 45.000, 0.000, 45.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(11, 12, 'entrada', 80.000, 0.000, 80.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(12, 13, 'entrada', 40.000, 0.000, 40.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(13, 14, 'entrada', 55.000, 0.000, 55.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(14, 15, 'entrada', 30.000, 0.000, 30.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(15, 16, 'entrada', 25.000, 0.000, 25.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(16, 17, 'entrada', 40.000, 0.000, 40.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(17, 18, 'entrada', 20.000, 0.000, 20.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(18, 19, 'entrada', 90.000, 0.000, 90.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(19, 20, 'entrada', 60.000, 0.000, 60.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(20, 21, 'entrada', 75.000, 0.000, 75.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(21, 22, 'entrada', 65.000, 0.000, 65.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(22, 23, 'entrada', 200.000, 0.000, 200.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(23, 24, 'entrada', 50.000, 0.000, 50.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(24, 25, 'entrada', 110.000, 0.000, 110.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(25, 26, 'entrada', 30.000, 0.000, 30.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(26, 27, 'entrada', 70.000, 0.000, 70.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(27, 28, 'entrada', 60.000, 0.000, 60.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(28, 29, 'entrada', 60.000, 0.000, 60.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(29, 30, 'entrada', 50.000, 0.000, 50.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(30, 31, 'entrada', 40.000, 0.000, 40.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(31, 32, 'entrada', 70.000, 0.000, 70.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(32, 33, 'entrada', 40.000, 0.000, 40.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(33, 34, 'entrada', 80.000, 0.000, 80.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(34, 35, 'entrada', 30.000, 0.000, 30.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(35, 36, 'entrada', 35.000, 0.000, 35.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(36, 37, 'entrada', 25.000, 0.000, 25.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(37, 38, 'entrada', 40.000, 0.000, 40.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(38, 39, 'entrada', 30.000, 0.000, 30.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(39, 40, 'entrada', 35.000, 0.000, 35.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(40, 41, 'entrada', 20.000, 0.000, 20.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(41, 42, 'entrada', 25.000, 0.000, 25.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(42, 43, 'entrada', 30.000, 0.000, 30.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(43, 44, 'entrada', 40.000, 0.000, 40.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(44, 45, 'entrada', 15.000, 0.000, 15.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(45, 46, 'entrada', 40.000, 0.000, 40.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(46, 47, 'entrada', 50.000, 0.000, 50.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(47, 48, 'entrada', 150.000, 0.000, 150.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(48, 49, 'entrada', 40.000, 0.000, 40.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(49, 50, 'entrada', 60.000, 0.000, 60.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(50, 51, 'entrada', 90.000, 0.000, 90.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(51, 52, 'entrada', 70.000, 0.000, 70.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(52, 53, 'entrada', 80.000, 0.000, 80.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(53, 54, 'entrada', 200.000, 0.000, 200.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(54, 55, 'entrada', 120.000, 0.000, 120.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(55, 56, 'entrada', 50.000, 0.000, 50.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(56, 57, 'entrada', 60.000, 0.000, 60.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(57, 58, 'entrada', 70.000, 0.000, 70.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(58, 59, 'entrada', 35.000, 0.000, 35.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(59, 60, 'entrada', 40.000, 0.000, 40.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(60, 61, 'entrada', 60.000, 0.000, 60.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(61, 62, 'entrada', 15.000, 0.000, 15.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(62, 63, 'entrada', 30.000, 0.000, 30.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(63, 64, 'entrada', 18.000, 0.000, 18.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(64, 65, 'entrada', 25.000, 0.000, 25.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(65, 66, 'entrada', 12.000, 0.000, 12.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(66, 67, 'entrada', 8.000, 0.000, 8.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(67, 68, 'entrada', 3.000, 0.000, 3.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(68, 69, 'entrada', 10.000, 0.000, 10.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(69, 70, 'entrada', 12.000, 0.000, 12.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(70, 71, 'entrada', 9.000, 0.000, 9.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(71, 72, 'entrada', 11.000, 0.000, 11.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(72, 73, 'entrada', 4.000, 0.000, 4.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(73, 74, 'entrada', 40.000, 0.000, 40.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(74, 75, 'entrada', 20.000, 0.000, 20.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(75, 76, 'entrada', 50.000, 0.000, 50.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(76, 77, 'entrada', 15.000, 0.000, 15.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(77, 78, 'entrada', 25.000, 0.000, 25.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(78, 79, 'entrada', 15.000, 0.000, 15.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(79, 80, 'entrada', 30.000, 0.000, 30.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(80, 81, 'entrada', 10.000, 0.000, 10.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(81, 82, 'entrada', 14.000, 0.000, 14.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(82, 83, 'entrada', 20.000, 0.000, 20.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(83, 84, 'entrada', 25.000, 0.000, 25.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(84, 85, 'entrada', 60.000, 0.000, 60.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(85, 86, 'entrada', 30.000, 0.000, 30.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(86, 87, 'entrada', 30.000, 0.000, 30.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(87, 88, 'entrada', 60.000, 0.000, 60.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(88, 89, 'entrada', 35.000, 0.000, 35.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(89, 90, 'entrada', 20.000, 0.000, 20.000, NULL, 1, 'Carga inicial de estoque', '2026-11-04 08:22:22'),
(90, 39, 'venda', -1.000, 30.000, 29.000, 16, 8, 'Venda — pedido #16', '2026-11-24 09:09:23'),
(91, 37, 'venda', -1.000, 25.000, 24.000, 16, 8, 'Venda — pedido #16', '2026-11-24 09:09:23'),
(92, 99, 'venda', -1.000, 96.000, 95.000, 17, 8, 'Venda — pedido #17', '2026-11-24 14:35:31'),
(93, 145, 'venda', -1.000, 96.000, 95.000, 17, 8, 'Venda — pedido #17', '2026-11-24 14:35:31'),
(94, 112, 'venda', -1.000, 96.000, 95.000, 17, 8, 'Venda — pedido #17', '2026-11-24 14:35:31'),
(95, 100, 'venda', -1.000, 96.000, 95.000, 17, 8, 'Venda — pedido #17', '2026-11-24 14:35:31'),
(96, 32, 'venda', -1.000, 70.000, 69.000, 17, 8, 'Venda — pedido #17', '2026-11-24 14:35:31'),
(97, 17, 'venda', -1.000, 40.000, 39.000, 17, 8, 'Venda — pedido #17', '2026-11-24 14:35:31'),
(98, 131, 'venda', -1.000, 96.000, 95.000, 17, 8, 'Venda — pedido #17', '2026-11-24 14:35:31'),
(99, 35, 'entrada', 2970.000, 30.000, 3000.000, NULL, 9, 'Quantidade atualizada no cadastro do produto', '2026-11-24 15:01:10'),
(100, 35, 'saida', -2970.000, 3000.000, 30.000, NULL, 9, 'Quantidade atualizada no cadastro do produto', '2026-11-24 15:01:30'),
(102, 69, 'venda', -1.000, 10.000, 9.000, 18, 13, 'Venda — pedido #18', '2026-11-24 15:15:26'),
(103, 10, 'entrada', 10.000, 0.000, 10.000, NULL, 9, 'Necessário.', '2026-11-24 16:15:54');

-- --------------------------------------------------------

--
-- Estrutura para tabela `ocorrencias`
--

CREATE TABLE `ocorrencias` (
  `id` int(10) UNSIGNED NOT NULL,
  `pedido_id` int(10) UNSIGNED DEFAULT NULL,
  `entrega_id` int(10) UNSIGNED DEFAULT NULL,
  `usuario_id` int(10) UNSIGNED DEFAULT NULL,
  `tipo` varchar(40) NOT NULL,
  `gravidade` enum('baixa','media','alta') NOT NULL DEFAULT 'media',
  `descricao` varchar(1000) NOT NULL,
  `status` enum('aberta','resolvida') NOT NULL DEFAULT 'aberta',
  `resolucao` varchar(1000) DEFAULT NULL,
  `resolvido_por` int(10) UNSIGNED DEFAULT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `resolvido_em` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `ocorrencias`
--

INSERT INTO `ocorrencias` (`id`, `pedido_id`, `entrega_id`, `usuario_id`, `tipo`, `gravidade`, `descricao`, `status`, `resolucao`, `resolvido_por`, `criado_em`, `resolvido_em`) VALUES
(1, 7, 7, 3, 'cliente_ausente', 'baixa', 'Cliente ausente na primeira tentativa; porteiro orientou retorno em 20 minutos.', 'resolvida', 'Entrega realizada na segunda passagem.', 1, '2026-11-22 05:22:22', '2026-11-22 07:22:22'),
(2, NULL, NULL, 1, 'estoque', 'media', 'Leite Semidesnatado zerado no estoque; reposição solicitada ao fornecedor.', 'aberta', NULL, NULL, '2026-11-23 22:22:22', NULL),
(3, 14, NULL, 10, 'divergencia_estoque', 'media', '\"Suco de Uva Integral\" não encontrado na separação (reserva de 1 un). Conferir inventário.', 'aberta', NULL, NULL, '2026-11-24 11:16:43', NULL),
(4, 12, 11, 11, 'cliente_ausente', 'media', 'Não estava presente.', 'aberta', NULL, NULL, '2026-11-24 14:39:29', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `pagamentos`
--

CREATE TABLE `pagamentos` (
  `id` int(10) UNSIGNED NOT NULL,
  `pedido_id` int(10) UNSIGNED NOT NULL,
  `tipo` enum('cobranca','complemento','estorno') NOT NULL DEFAULT 'cobranca',
  `metodo` enum('pix','cartao','boleto') NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `status` enum('pendente','aprovado','recusado') NOT NULL DEFAULT 'pendente',
  `codigo_transacao` varchar(40) NOT NULL,
  `cartao_final` char(4) DEFAULT NULL,
  `parcelas` int(11) DEFAULT NULL,
  `observacao` varchar(255) DEFAULT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `confirmado_em` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `pagamentos`
--

INSERT INTO `pagamentos` (`id`, `pedido_id`, `tipo`, `metodo`, `valor`, `status`, `codigo_transacao`, `cartao_final`, `parcelas`, `observacao`, `criado_em`, `confirmado_em`) VALUES
(1, 1, 'cobranca', 'cartao', 94.62, 'aprovado', 'SIM-DEMO0001', NULL, NULL, NULL, '2026-11-18 03:22:22', '2026-11-18 03:22:22'),
(2, 2, 'cobranca', 'pix', 195.63, 'aprovado', 'SIM-DEMO0002', NULL, NULL, NULL, '2026-11-18 07:22:22', '2026-11-18 07:22:22'),
(3, 3, 'cobranca', 'cartao', 85.86, 'aprovado', 'SIM-DEMO0003', NULL, NULL, NULL, '2026-11-19 05:22:22', '2026-11-19 05:22:22'),
(4, 4, 'cobranca', 'pix', 76.07, 'aprovado', 'SIM-DEMO0004', NULL, NULL, NULL, '2026-11-20 02:22:22', '2026-11-20 02:22:22'),
(5, 5, 'cobranca', 'pix', 239.80, 'aprovado', 'SIM-DEMO0005', NULL, NULL, NULL, '2026-11-20 06:22:22', '2026-11-20 06:22:22'),
(6, 6, 'cobranca', 'cartao', 87.58, 'aprovado', 'SIM-DEMO0006', NULL, NULL, NULL, '2026-11-21 04:22:22', '2026-11-21 04:22:22'),
(7, 7, 'cobranca', 'pix', 66.12, 'aprovado', 'SIM-DEMO0007', NULL, NULL, NULL, '2026-11-22 01:22:22', '2026-11-22 01:22:22'),
(8, 8, 'cobranca', 'cartao', 152.70, 'aprovado', 'SIM-DEMO0008', NULL, NULL, NULL, '2026-11-22 06:22:22', '2026-11-22 06:22:22'),
(9, 9, 'cobranca', 'pix', 133.60, 'aprovado', 'SIM-DEMO0009', NULL, NULL, NULL, '2026-11-23 02:22:22', '2026-11-23 02:22:22'),
(10, 9, 'estorno', 'pix', 133.60, 'aprovado', 'SIM-EST0009', NULL, NULL, NULL, '2026-11-23 03:22:22', '2026-11-23 03:22:22'),
(11, 10, 'cobranca', 'pix', 139.50, 'aprovado', 'SIM-DEMO0010', NULL, NULL, NULL, '2026-11-23 05:22:22', '2026-11-23 05:22:22'),
(12, 11, 'cobranca', 'cartao', 163.40, 'aprovado', 'SIM-DEMO0011', NULL, NULL, NULL, '2026-11-23 07:22:22', '2026-11-23 07:22:22'),
(13, 12, 'cobranca', 'pix', 399.90, 'aprovado', 'SIM-DEMO0012', NULL, NULL, NULL, '2026-11-23 12:22:22', '2026-11-23 12:22:22'),
(14, 13, 'cobranca', 'cartao', 75.63, 'aprovado', 'SIM-DEMO0013', NULL, NULL, NULL, '2026-11-24 05:22:22', '2026-11-24 05:22:22'),
(15, 14, 'cobranca', 'pix', 58.50, 'aprovado', 'SIM-DEMO0014', NULL, NULL, NULL, '2026-11-24 06:22:22', '2026-11-24 06:22:22'),
(16, 15, 'cobranca', 'pix', 162.50, 'aprovado', 'SIM-DEMO0015', NULL, NULL, NULL, '2026-11-24 07:22:22', '2026-11-24 07:22:22'),
(17, 16, 'cobranca', 'pix', 134.70, 'aprovado', 'SIM-1EB9BA274046', NULL, NULL, 'Pagamento simulado aprovado', '2026-11-24 09:09:23', '2026-11-24 09:09:23'),
(18, 17, 'cobranca', 'pix', 183.80, 'aprovado', 'SIM-0366CF27466D', NULL, NULL, 'Pagamento simulado aprovado', '2026-11-24 14:35:31', '2026-11-24 14:35:31'),
(19, 18, 'cobranca', 'pix', 401.90, 'aprovado', 'SIM-FCB1B8964EA3', NULL, NULL, 'Pagamento simulado aprovado', '2026-11-24 15:15:26', '2026-11-24 15:15:26');

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(10) UNSIGNED NOT NULL,
  `usuario_id` int(10) UNSIGNED NOT NULL,
  `endereco_id` int(10) UNSIGNED NOT NULL,
  `area_entrega_id` int(10) UNSIGNED NOT NULL,
  `endereco_entrega` varchar(400) NOT NULL,
  `cep_entrega` char(8) NOT NULL,
  `tipo_frete` enum('padrao','expresso') NOT NULL DEFAULT 'padrao',
  `prazo_entrega` varchar(40) DEFAULT NULL,
  `valor_frete` decimal(10,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_pago` decimal(10,2) NOT NULL DEFAULT 0.00,
  `metodo_pagamento` enum('pix','cartao','boleto') NOT NULL,
  `status` enum('aguardando_pagamento','confirmado','aguardando_separacao','em_separacao','aguardando_aprovacao','aguardando_entrega','saiu_para_entrega','concluido','cancelado') NOT NULL DEFAULT 'aguardando_pagamento',
  `ajuste_pendente` tinyint(1) NOT NULL DEFAULT 0,
  `separador_id` int(10) UNSIGNED DEFAULT NULL,
  `volumes` int(11) DEFAULT NULL,
  `observacoes` varchar(500) DEFAULT NULL,
  `motivo_cancelamento` varchar(500) DEFAULT NULL,
  `cancelado_por` int(10) UNSIGNED DEFAULT NULL,
  `cancelado_em` datetime DEFAULT NULL,
  `separacao_iniciada_em` datetime DEFAULT NULL,
  `separacao_concluida_em` datetime DEFAULT NULL,
  `concluido_em` datetime DEFAULT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `atualizado_em` datetime DEFAULT NULL
) ;

--
-- Despejando dados para a tabela `pedidos`
--

INSERT INTO `pedidos` (`id`, `usuario_id`, `endereco_id`, `area_entrega_id`, `endereco_entrega`, `cep_entrega`, `tipo_frete`, `prazo_entrega`, `valor_frete`, `subtotal`, `total`, `total_pago`, `metodo_pagamento`, `status`, `ajuste_pendente`, `separador_id`, `volumes`, `observacoes`, `motivo_cancelamento`, `cancelado_por`, `cancelado_em`, `separacao_iniciada_em`, `separacao_concluida_em`, `concluido_em`, `criado_em`, `atualizado_em`) VALUES
(1, 6, 1, 1, 'Rua das Flores, 123, Apto 42 — Jardim Bela Vista, São Paulo/SP', '01234567', 'padrao', 'até 2 dias', 12.90, 81.72, 94.62, 94.62, 'cartao', 'concluido', 0, 2, 2, NULL, NULL, NULL, NULL, '2026-11-18 05:22:22', '2026-11-18 06:22:22', '2026-11-18 09:22:22', '2026-11-18 03:22:22', '2026-11-18 09:22:22'),
(2, 7, 3, 4, 'Rua dos Ipês, 77 — Pinheiros, São Paulo/SP', '05422010', 'padrao', 'até 2 dias', 13.90, 181.73, 195.63, 195.63, 'pix', 'concluido', 0, 2, 2, NULL, NULL, NULL, NULL, '2026-11-18 09:22:22', '2026-11-18 10:22:22', '2026-11-18 13:22:22', '2026-11-18 07:22:22', '2026-11-18 13:22:22'),
(3, 6, 1, 1, 'Rua das Flores, 123, Apto 42 — Jardim Bela Vista, São Paulo/SP', '01234567', 'padrao', 'até 2 dias', 12.90, 72.96, 85.86, 85.86, 'cartao', 'concluido', 0, 2, 2, NULL, NULL, NULL, NULL, '2026-11-19 07:22:22', '2026-11-19 08:22:22', '2026-11-19 11:22:22', '2026-11-19 05:22:22', '2026-11-19 11:22:22'),
(4, 6, 2, 3, 'Avenida das Magnólias, 1500, 8º andar — Vila Olímpia, São Paulo/SP', '04538133', 'padrao', 'até 2 dias', 12.90, 63.17, 76.07, 76.07, 'pix', 'concluido', 0, 2, 2, NULL, NULL, NULL, NULL, '2026-11-20 04:22:22', '2026-11-20 05:22:22', '2026-11-20 08:22:22', '2026-11-20 02:22:22', '2026-11-20 08:22:22'),
(5, 7, 3, 4, 'Rua dos Ipês, 77 — Pinheiros, São Paulo/SP', '05422010', 'padrao', 'até 2 dias', 0.00, 239.80, 239.80, 239.80, 'pix', 'concluido', 0, 2, 2, NULL, NULL, NULL, NULL, '2026-11-20 08:22:22', '2026-11-20 09:22:22', '2026-11-20 12:22:22', '2026-11-20 06:22:22', '2026-11-20 12:22:22'),
(6, 6, 1, 1, 'Rua das Flores, 123, Apto 42 — Jardim Bela Vista, São Paulo/SP', '01234567', 'padrao', 'até 2 dias', 12.90, 74.68, 87.58, 87.58, 'cartao', 'concluido', 0, 2, 2, NULL, NULL, NULL, NULL, '2026-11-21 06:22:22', '2026-11-21 07:22:22', '2026-11-21 10:22:22', '2026-11-21 04:22:22', '2026-11-21 10:22:22'),
(7, 7, 3, 4, 'Rua dos Ipês, 77 — Pinheiros, São Paulo/SP', '05422010', 'padrao', 'até 2 dias', 13.90, 52.22, 66.12, 66.12, 'pix', 'concluido', 0, 2, 2, NULL, NULL, NULL, NULL, '2026-11-22 03:22:22', '2026-11-22 04:22:22', '2026-11-22 07:22:22', '2026-11-22 01:22:22', '2026-11-22 07:22:22'),
(8, 6, 1, 1, 'Rua das Flores, 123, Apto 42 — Jardim Bela Vista, São Paulo/SP', '01234567', 'padrao', 'até 2 dias', 12.90, 139.80, 152.70, 152.70, 'cartao', 'concluido', 0, 2, 2, NULL, NULL, NULL, NULL, '2026-11-22 08:22:22', '2026-11-22 09:22:22', '2026-11-22 12:22:22', '2026-11-22 06:22:22', '2026-11-22 12:22:22'),
(9, 7, 3, 4, 'Rua dos Ipês, 77 — Pinheiros, São Paulo/SP', '05422010', 'padrao', 'até 2 dias', 13.90, 119.70, 133.60, 0.00, 'pix', 'cancelado', 0, NULL, NULL, NULL, 'Desistência da compra', 7, '2026-11-23 03:22:22', NULL, NULL, NULL, '2026-11-23 02:22:22', '2026-11-23 08:22:22'),
(10, 6, 1, 1, 'Rua das Flores, 123, Apto 42 — Jardim Bela Vista, São Paulo/SP', '01234567', 'padrao', 'até 2 dias', 12.90, 126.60, 139.50, 139.50, 'pix', 'concluido', 0, 2, 2, NULL, NULL, NULL, NULL, '2026-11-23 07:22:22', '2026-11-23 08:22:22', '2026-11-23 11:22:22', '2026-11-23 05:22:22', '2026-11-23 11:22:22'),
(11, 7, 3, 4, 'Rua dos Ipês, 77 — Pinheiros, São Paulo/SP', '05422010', 'padrao', 'até 2 dias', 13.90, 149.50, 163.40, 163.40, 'cartao', 'concluido', 0, 2, 2, NULL, NULL, NULL, NULL, '2026-11-23 09:22:22', '2026-11-23 10:22:22', '2026-11-23 13:22:22', '2026-11-23 07:22:22', '2026-11-23 13:22:22'),
(12, 6, 2, 3, 'Avenida das Magnólias, 1500, 8º andar — Vila Olímpia, São Paulo/SP', '04538133', 'padrao', 'até 2 dias', 0.00, 399.90, 399.90, 399.90, 'pix', 'aguardando_entrega', 0, 2, 2, NULL, NULL, NULL, NULL, '2026-11-23 14:22:22', '2026-11-23 15:22:22', NULL, '2026-11-23 12:22:22', '2026-11-24 14:39:29'),
(13, 6, 1, 1, 'Rua das Flores, 123, Apto 42 — Jardim Bela Vista, São Paulo/SP', '01234567', 'padrao', 'até 2 dias', 12.90, 62.73, 75.63, 75.63, 'cartao', 'em_separacao', 0, 10, NULL, NULL, NULL, NULL, NULL, '2026-11-24 09:57:22', NULL, NULL, '2026-11-24 05:22:22', '2026-11-24 09:57:22'),
(14, 7, 3, 4, 'Rua dos Ipês, 77 — Pinheiros, São Paulo/SP', '05422010', 'padrao', 'até 2 dias', 13.90, 30.70, 44.60, 58.50, 'pix', 'aguardando_aprovacao', 0, 10, NULL, NULL, NULL, NULL, NULL, '2026-11-24 11:15:13', NULL, NULL, '2026-11-24 06:22:22', '2026-11-24 11:17:21'),
(15, 6, 1, 1, 'Rua das Flores, 123, Apto 42 — Jardim Bela Vista, São Paulo/SP', '01234567', 'padrao', 'até 2 dias', 12.90, 149.60, 162.50, 162.50, 'pix', 'aguardando_separacao', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-11-24 07:22:22', '2026-11-24 08:22:22'),
(16, 8, 4, 5, 'R PARAITINGA, 87, Casa — VL SIMONE, SÃO PAULO/SP · Destinatário: matheus', '08160450', 'padrao', 'até 2 dias', 14.90, 119.80, 134.70, 134.70, 'pix', 'concluido', 0, 10, 1, NULL, NULL, NULL, NULL, '2026-11-24 10:30:20', '2026-11-24 10:30:37', '2026-11-24 10:33:42', '2026-11-24 09:09:23', '2026-11-24 10:33:42'),
(17, 8, 4, 5, 'R PARAITINGA, 87, Casa — VL SIMONE, SÃO PAULO/SP · Destinatário: matheus', '08160450', 'padrao', 'até 2 dias', 14.90, 168.90, 183.80, 183.80, 'pix', 'aguardando_separacao', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-11-24 14:35:31', '2026-11-24 14:35:31'),
(18, 13, 6, 5, 'R PARAITINGA, 87, Casa — VL SIMONE, SÃO PAULO/SP · Destinatário: Gaby Trindade', '08160450', 'expresso', 'até 2 horas', 2.00, 399.90, 401.90, 401.90, 'pix', 'aguardando_separacao', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-11-24 15:15:26', '2026-11-24 15:15:26');

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` int(10) UNSIGNED NOT NULL,
  `categoria_id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(140) NOT NULL,
  `slug` varchar(160) NOT NULL,
  `marca` varchar(80) DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  `informacoes` text DEFAULT NULL,
  `embalagem` varchar(60) DEFAULT NULL,
  `vendido_por` enum('unidade','peso') NOT NULL DEFAULT 'unidade',
  `preco` decimal(10,2) NOT NULL,
  `preco_promocional` decimal(10,2) DEFAULT NULL,
  `estoque` decimal(10,3) NOT NULL DEFAULT 0.000,
  `estoque_minimo` decimal(10,3) NOT NULL DEFAULT 10.000,
  `imagem` varchar(255) DEFAULT NULL,
  `destaque` tinyint(1) NOT NULL DEFAULT 0,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `atualizado_em` datetime DEFAULT NULL
) ;

--
-- Despejando dados para a tabela `produtos`
--

INSERT INTO `produtos` (`id`, `categoria_id`, `nome`, `slug`, `marca`, `descricao`, `informacoes`, `embalagem`, `vendido_por`, `preco`, `preco_promocional`, `estoque`, `estoque_minimo`, `imagem`, `destaque`, `ativo`, `criado_em`, `atualizado_em`) VALUES
(1, 15, 'Arroz Tipo 1', 'arroz-tipo-1', 'Velluto Seleção', 'Arroz Tipo 1 Velluto Seleção — pacote 5 kg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Velluto Seleção\r\nApresentação: Pacote 5 kg\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote 5 kg', 'unidade', 24.90, NULL, 80.000, 10.000, 'assets/img/produtos/arroz-tipo-1.jpg', 1, 1, '2026-10-16 08:22:21', NULL),
(2, 15, 'Feijão Carioca', 'feijao-carioca', 'Campo Doce', 'Feijão Carioca Campo Doce — pacote 1 kg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Campo Doce\r\nApresentação: Pacote 1 kg\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote 1 kg', 'unidade', 8.49, NULL, 120.000, 10.000, 'assets/img/produtos/feijao-carioca.jpg', 0, 1, '2026-10-17 08:22:21', NULL),
(3, 15, 'Óleo de Soja', 'oleo-de-soja', 'Aurora', 'Óleo de Soja Aurora — garrafa 900 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Aurora\r\nApresentação: Garrafa 900 ml\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Garrafa 900 ml', 'unidade', 6.99, NULL, 90.000, 10.000, 'assets/img/produtos/oleo-de-soja.jpg', 0, 1, '2026-10-18 08:22:21', NULL),
(4, 15, 'Açúcar Refinado', 'ac-ucar-refinado', 'Doce Lar', 'Açúcar Refinado Doce Lar — pacote 1 kg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Doce Lar\r\nApresentação: Pacote 1 kg\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote 1 kg', 'unidade', 4.79, NULL, 100.000, 10.000, 'assets/img/produtos/acucar-refinado.jpg', 0, 1, '2026-10-19 08:22:21', '2026-11-24 09:17:38'),
(5, 15, 'Café Torrado e Moído', 'cafe-torrado-e-moido', 'Grão Nobre', 'Café Torrado e Moído Grão Nobre — pacote 500 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Grão Nobre\r\nApresentação: Pacote 500 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote 500 g', 'unidade', 18.90, 16.90, 60.000, 10.000, 'assets/img/produtos/cafe-torrado-e-moido.jpg', 1, 1, '2026-10-20 08:22:21', NULL),
(6, 15, 'Macarrão Espaguete', 'macarrao-espaguete', 'Bella Pasta', 'Macarrão Espaguete Bella Pasta — pacote 500 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Bella Pasta\r\nApresentação: Pacote 500 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote 500 g', 'unidade', 4.29, NULL, 140.000, 10.000, 'assets/img/produtos/macarrao-espaguete.jpg', 0, 1, '2026-10-21 08:22:21', NULL),
(7, 15, 'Farinha de Trigo', 'farinha-de-trigo', 'Campo Doce', 'Farinha de Trigo Campo Doce — pacote 1 kg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Campo Doce\r\nApresentação: Pacote 1 kg\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote 1 kg', 'unidade', 5.49, NULL, 70.000, 10.000, 'assets/img/produtos/farinha-de-trigo.jpg', 0, 1, '2026-10-22 08:22:21', NULL),
(8, 15, 'Azeite Extravirgem', 'azeite-extravirgem', 'Oliva Rara', 'Azeite Extravirgem Oliva Rara — vidro 500 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Oliva Rara\r\nApresentação: Vidro 500 ml\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Vidro 500 ml', 'unidade', 32.90, 28.90, 35.000, 10.000, 'assets/img/produtos/azeite-extravirgem.jpg', 1, 1, '2026-10-23 08:22:21', NULL),
(9, 16, 'Leite Integral', 'leite-integral', 'Nuvem', 'Leite Integral Nuvem — caixa 1 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Nuvem\r\nApresentação: Caixa 1 L\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Caixa 1 L', 'unidade', 5.49, NULL, 150.000, 10.000, 'assets/img/produtos/leite-integral.jpg', 0, 1, '2026-10-24 08:22:21', NULL),
(10, 16, 'Leite Semidesnatado', 'leite-semidesnatado', 'Nuvem', 'Leite Semidesnatado Nuvem — caixa 1 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Nuvem\r\nApresentação: Caixa 1 L\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Caixa 1 L', 'unidade', 5.29, NULL, 10.000, 10.000, 'assets/img/produtos/leite-semidesnatado.jpg', 0, 1, '2026-10-25 08:22:21', '2026-11-24 16:15:54'),
(11, 16, 'Queijo Muçarela Fatiado', 'queijo-mucarela-fatiado', 'Serra Branca', 'Queijo Muçarela Fatiado Serra Branca — bandeja 200 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Serra Branca\r\nApresentação: Bandeja 200 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Bandeja 200 g', 'unidade', 11.90, NULL, 45.000, 10.000, 'assets/img/produtos/queijo-mucarela-fatiado.jpg', 0, 1, '2026-10-26 08:22:21', NULL),
(12, 16, 'Iogurte Natural', 'iogurte-natural', 'Nuvem', 'Iogurte Natural Nuvem — pote 170 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Nuvem\r\nApresentação: Pote 170 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pote 170 g', 'unidade', 3.29, NULL, 80.000, 10.000, 'assets/img/produtos/iogurte-natural.jpg', 0, 1, '2026-10-27 08:22:21', NULL),
(13, 16, 'Manteiga com Sal', 'manteiga-com-sal', 'Serra Branca', 'Manteiga com Sal Serra Branca — pote 200 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Serra Branca\r\nApresentação: Pote 200 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pote 200 g', 'unidade', 12.49, NULL, 40.000, 10.000, 'assets/img/produtos/manteiga-com-sal.jpg', 0, 1, '2026-10-28 08:22:21', NULL),
(14, 16, 'Requeijão Cremoso', 'requeijao-cremoso', 'Serra Branca', 'Requeijão Cremoso Serra Branca — copo 200 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Serra Branca\r\nApresentação: Copo 200 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Copo 200 g', 'unidade', 7.99, NULL, 55.000, 10.000, 'assets/img/produtos/requeijao-cremoso.jpg', 0, 1, '2026-10-29 08:22:21', NULL),
(15, 17, 'Pizza Margherita', 'pizza-margherita', 'Forno de Pedra', 'Pizza Margherita Forno de Pedra — caixa 460 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Forno de Pedra\r\nApresentação: Caixa 460 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Caixa 460 g', 'unidade', 19.90, 16.90, 30.000, 10.000, 'assets/img/produtos/pizza-margherita.jpg', 1, 1, '2026-10-30 08:22:21', NULL),
(16, 17, 'Lasanha à Bolonhesa', 'lasanha-a-bolonhesa', 'Forno de Pedra', 'Lasanha à Bolonhesa Forno de Pedra — bandeja 600 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Forno de Pedra\r\nApresentação: Bandeja 600 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Bandeja 600 g', 'unidade', 21.90, NULL, 25.000, 10.000, 'assets/img/produtos/lasanha-a-bolonhesa.jpg', 0, 1, '2026-10-31 08:22:21', NULL),
(17, 17, 'Batata Pré-frita', 'batata-pre-frita', 'Campo Doce', 'Batata Pré-frita Campo Doce — pacote 1 kg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Campo Doce\r\nApresentação: Pacote 1 kg\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote 1 kg', 'unidade', 17.49, NULL, 39.000, 10.000, 'assets/img/produtos/batata-pre-frita.jpg', 0, 1, '2026-11-01 08:22:21', '2026-11-24 14:35:31'),
(18, 17, 'Sorvete de Creme', 'sorvete-de-creme', 'Polar Doce', 'Sorvete de Creme Polar Doce — pote 1,5 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Polar Doce\r\nApresentação: Pote 1,5 L\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pote 1,5 L', 'unidade', 22.90, NULL, 20.000, 10.000, 'assets/img/produtos/sorvete-de-creme.jpg', 0, 1, '2026-11-02 08:22:21', NULL),
(19, 18, 'Milho Verde', 'milho-verde', 'Horta Viva', 'Milho Verde Horta Viva — lata 170 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Horta Viva\r\nApresentação: Lata 170 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Lata 170 g', 'unidade', 3.99, NULL, 90.000, 10.000, 'assets/img/produtos/milho-verde.jpg', 0, 1, '2026-11-03 08:22:21', NULL),
(20, 18, 'Atum Sólido', 'atum-solido', 'Mar Azul', 'Atum Sólido Mar Azul — lata 170 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Mar Azul\r\nApresentação: Lata 170 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Lata 170 g', 'unidade', 9.49, NULL, 60.000, 10.000, 'assets/img/produtos/atum-solido.jpg', 0, 1, '2026-11-04 08:22:21', NULL),
(21, 18, 'Extrato de Tomate', 'extrato-de-tomate', 'Horta Viva', 'Extrato de Tomate Horta Viva — lata 340 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Horta Viva\r\nApresentação: Lata 340 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Lata 340 g', 'unidade', 4.59, NULL, 75.000, 10.000, 'assets/img/produtos/extrato-de-tomate.jpg', 0, 1, '2026-11-05 08:22:21', NULL),
(22, 18, 'Ervilha em Conserva', 'ervilha-em-conserva', 'Horta Viva', 'Ervilha em Conserva Horta Viva — lata 170 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Horta Viva\r\nApresentação: Lata 170 g\r\nVenda: por unidade\n\nArmazenamento: conforme orientação da embalagem', 'Lata 170 g', 'unidade', 3.79, NULL, 65.000, 10.000, 'assets/img/produtos/ervilha-em-conserva.jpg', 0, 1, '2026-11-06 08:22:21', NULL),
(23, 2, 'Água Mineral sem Gás', 'agua-mineral-sem-gas', 'Fonte Clara', 'Água Mineral sem Gás Fonte Clara — garrafa 1,5 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Fonte Clara\r\nApresentação: Garrafa 1,5 L\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Garrafa 1,5 L', 'unidade', 2.49, NULL, 200.000, 10.000, 'assets/img/produtos/agua-mineral-sem-gas.jpg', 0, 1, '2026-11-07 08:22:21', NULL),
(24, 2, 'Suco de Uva Integral', 'suco-de-uva-integral', 'Vinha Serena', 'Suco de Uva Integral Vinha Serena — garrafa 1 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Vinha Serena\r\nApresentação: Garrafa 1 L\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Garrafa 1 L', 'unidade', 13.90, NULL, 50.000, 10.000, 'assets/img/produtos/suco-de-uva-integral.jpg', 0, 1, '2026-11-08 08:22:21', NULL),
(25, 2, 'Refrigerante de Cola', 'refrigerante-de-cola', 'Bolha', 'Refrigerante de Cola Bolha — garrafa 2 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Bolha\r\nApresentação: Garrafa 2 L\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Garrafa 2 L', 'unidade', 8.99, NULL, 110.000, 10.000, 'assets/img/produtos/refrigerante-de-cola.jpg', 0, 1, '2026-11-09 08:22:21', NULL),
(26, 2, 'Vinho Tinto Seco', 'vinho-tinto-seco', 'Vinha Serena', 'Vinho Tinto Seco Vinha Serena — garrafa 750 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Vinha Serena\r\nApresentação: Garrafa 750 ml\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Garrafa 750 ml', 'unidade', 49.90, 42.90, 30.000, 10.000, 'assets/img/produtos/vinho-tinto-seco.jpg', 1, 1, '2026-11-10 08:22:21', NULL),
(27, 2, 'Cerveja Artesanal', 'cerveja-artesanal', 'Lúpulo Rosa', 'Cerveja Artesanal Lúpulo Rosa — garrafa 500 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Lúpulo Rosa\r\nApresentação: Garrafa 500 ml\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Garrafa 500 ml', 'unidade', 12.90, NULL, 70.000, 10.000, 'assets/img/produtos/cerveja-artesanal.jpg', 0, 1, '2026-11-11 08:22:21', NULL),
(28, 2, 'Chá Gelado de Pêssego', 'cha-gelado-de-pessego', 'Fonte Clara', 'Chá Gelado de Pêssego Fonte Clara — garrafa 1 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Fonte Clara\r\nApresentação: Garrafa 1 L\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Garrafa 1 L', 'unidade', 6.49, NULL, 60.000, 10.000, 'assets/img/produtos/cha-gelado-de-pessego.jpg', 0, 1, '2026-11-12 08:22:21', NULL),
(29, 3, 'Banana Prata', 'banana-prata', 'Hortifruti Velluto', 'Banana Prata fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Hortifruti Velluto\r\nApresentação: Vendido por kg\r\nVenda: por quilo (peso aproximado; cobrança pelo peso real)\r\nArmazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 6.90, NULL, 60.000, 8.000, 'assets/img/produtos/banana-prata.jpg', 1, 1, '2026-11-13 08:22:21', NULL),
(30, 3, 'Maçã Gala', 'maca-gala', 'Hortifruti Velluto', 'Maçã Gala fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Hortifruti Velluto\r\nApresentação: Vendido por kg\r\nVenda: por quilo (peso aproximado; cobrança pelo peso real)\r\nArmazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 9.90, NULL, 50.000, 8.000, 'assets/img/produtos/maca-gala.jpg', 0, 1, '2026-11-14 08:22:21', NULL),
(31, 3, 'Tomate', 'tomate', 'Hortifruti Velluto', 'Tomate fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Hortifruti Velluto\r\nApresentação: Vendido por kg\r\nVenda: por quilo (peso aproximado; cobrança pelo peso real)\r\nArmazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 7.49, NULL, 40.000, 8.000, 'assets/img/produtos/tomate.jpg', 0, 1, '2026-11-15 08:22:21', NULL),
(32, 3, 'Batata Inglesa', 'batata-inglesa', 'Hortifruti Velluto', 'Batata Inglesa fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Hortifruti Velluto\r\nApresentação: Vendido por kg\r\nVenda: por quilo (peso aproximado; cobrança pelo peso real)\r\nArmazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 5.99, NULL, 69.000, 8.000, 'assets/img/produtos/batata-inglesa.jpg', 0, 1, '2026-11-16 08:22:21', '2026-11-24 14:35:31'),
(33, 3, 'Alface Crespa', 'alface-crespa', 'Hortifruti Velluto', 'Alface Crespa Hortifruti Velluto — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Hortifruti Velluto\r\nApresentação: Unidade\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 3.49, NULL, 40.000, 10.000, 'assets/img/produtos/alface-crespa.jpg', 0, 1, '2026-11-17 08:22:21', NULL),
(34, 3, 'Laranja Pera', 'laranja-pera', 'Hortifruti Velluto', 'Laranja Pera fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Hortifruti Velluto\r\nApresentação: Vendido por kg\r\nVenda: por quilo (peso aproximado; cobrança pelo peso real)\r\nArmazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 4.99, NULL, 80.000, 8.000, 'assets/img/produtos/laranja-pera.jpg', 0, 1, '2026-11-18 08:22:21', NULL),
(35, 3, 'Abacate', 'abacate', 'Hortifruti Velluto', 'Abacate fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Hortifruti Velluto\r\nApresentação: Vendido por kg\r\nVenda: por quilo (peso aproximado; cobrança pelo peso real)\r\nArmazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 8.90, NULL, 30.000, 8.000, 'assets/img/produtos/abacate.jpg', 0, 1, '2026-10-15 08:22:21', '2026-11-24 15:01:30'),
(36, 3, 'Morango', 'morango', 'Hortifruti Velluto', 'Morango Hortifruti Velluto — bandeja 250 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Hortifruti Velluto\r\nApresentação: Bandeja 250 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Bandeja 250 g', 'unidade', 7.90, 5.90, 35.000, 10.000, 'assets/img/produtos/morango.jpg', 1, 1, '2026-10-16 08:22:21', NULL),
(37, 4, 'Picanha Bovina', 'picanha-bovina', 'Açougue Velluto', 'Picanha Bovina fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Açougue Velluto\r\nApresentação: Vendido por kg\r\nVenda: por quilo (peso aproximado; cobrança pelo peso real)\r\nArmazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 79.90, NULL, 24.000, 8.000, 'assets/img/produtos/picanha-bovina.jpg', 1, 1, '2026-10-17 08:22:21', '2026-11-24 09:09:23'),
(38, 4, 'Filé de Peito de Frango', 'file-de-peito-de-frango', 'Açougue Velluto', 'Filé de Peito de Frango fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Açougue Velluto\r\nApresentação: Vendido por kg\r\nVenda: por quilo (peso aproximado; cobrança pelo peso real)\r\nArmazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 22.90, NULL, 40.000, 8.000, 'assets/img/produtos/file-de-peito-de-frango.jpg', 0, 1, '2026-10-18 08:22:21', NULL),
(39, 4, 'Carne Moída de Patinho', 'carne-moida-de-patinho', 'Açougue Velluto', 'Carne Moída de Patinho fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Açougue Velluto\r\nApresentação: Vendido por kg\r\nVenda: por quilo (peso aproximado; cobrança pelo peso real)\r\nArmazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 39.90, NULL, 29.000, 8.000, 'assets/img/produtos/carne-moida-de-patinho.jpg', 0, 1, '2026-10-19 08:22:21', '2026-11-24 09:09:23'),
(40, 4, 'Linguiça Toscana', 'linguica-toscana', 'Açougue Velluto', 'Linguiça Toscana fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Açougue Velluto\r\nApresentação: Vendido por kg\r\nVenda: por quilo (peso aproximado; cobrança pelo peso real)\r\nArmazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 24.90, NULL, 35.000, 8.000, 'assets/img/produtos/linguica-toscana.jpg', 0, 1, '2026-10-20 08:22:21', NULL),
(41, 4, 'Filé de Tilápia', 'file-de-tilapia', 'Peixaria Velluto', 'Filé de Tilápia fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Peixaria Velluto\r\nApresentação: Vendido por kg\r\nVenda: por quilo (peso aproximado; cobrança pelo peso real)\r\nArmazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 44.90, NULL, 20.000, 8.000, 'assets/img/produtos/file-de-tilapia.jpg', 0, 1, '2026-10-21 08:22:21', NULL),
(42, 4, 'Costela Suína', 'costela-suina', 'Açougue Velluto', 'Costela Suína fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Açougue Velluto\r\nApresentação: Vendido por kg\r\nVenda: por quilo (peso aproximado; cobrança pelo peso real)\r\nArmazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 29.90, 26.90, 25.000, 8.000, 'assets/img/produtos/costela-suina.jpg', 0, 1, '2026-10-22 08:22:21', NULL),
(43, 5, 'Pão Francês', 'pao-frances', 'Padaria Velluto', 'Pão Francês fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Padaria Velluto\r\nApresentação: Vendido por kg\r\nVenda: por quilo (peso aproximado; cobrança pelo peso real)\r\nArmazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 16.90, NULL, 30.000, 8.000, 'assets/img/produtos/pao-frances.jpg', 0, 1, '2026-10-23 08:22:21', NULL),
(44, 5, 'Pão de Forma Integral', 'pao-de-forma-integral', 'Trigal', 'Pão de Forma Integral Trigal — pacote 500 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Trigal\r\nApresentação: Pacote 500 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote 500 g', 'unidade', 9.99, NULL, 40.000, 10.000, 'assets/img/produtos/pao-de-forma-integral.jpg', 0, 1, '2026-10-24 08:22:21', NULL),
(45, 5, 'Bolo de Cenoura', 'bolo-de-cenoura', 'Padaria Velluto', 'Bolo de Cenoura Padaria Velluto — unidade 400 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Padaria Velluto\r\nApresentação: Unidade 400 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade 400 g', 'unidade', 18.90, NULL, 15.000, 10.000, 'assets/img/produtos/bolo-de-cenoura.jpg', 0, 1, '2026-10-25 08:22:21', NULL),
(46, 5, 'Croissant de Manteiga', 'croissant-de-manteiga', 'Padaria Velluto', 'Croissant de Manteiga Padaria Velluto — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Padaria Velluto\r\nApresentação: Unidade\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 6.50, NULL, 40.000, 10.000, 'assets/img/produtos/croissant-de-manteiga.jpg', 1, 1, '2026-10-26 08:22:21', NULL),
(47, 5, 'Torrada Tradicional', 'torrada-tradicional', 'Trigal', 'Torrada Tradicional Trigal — pacote 160 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Trigal\r\nApresentação: Pacote 160 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote 160 g', 'unidade', 5.49, NULL, 50.000, 10.000, 'assets/img/produtos/torrada-tradicional.jpg', 0, 1, '2026-10-27 08:22:21', NULL),
(48, 6, 'Detergente Neutro', 'detergente-neutro', 'Pura Casa', 'Detergente Neutro Pura Casa — frasco 500 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pura Casa\r\nApresentação: Frasco 500 ml\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Frasco 500 ml', 'unidade', 2.79, NULL, 150.000, 10.000, 'assets/img/produtos/detergente-neutro.jpg', 0, 1, '2026-10-28 08:22:21', NULL),
(49, 6, 'Sabão Líquido para Roupas', 'sabao-liquido-para-roupas', 'Pura Casa', 'Sabão Líquido para Roupas Pura Casa — galão 3 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pura Casa\r\nApresentação: Galão 3 L\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Galão 3 L', 'unidade', 39.90, 34.90, 40.000, 10.000, 'assets/img/produtos/sabao-liquido-para-roupas.jpg', 1, 1, '2026-10-29 08:22:21', NULL),
(50, 6, 'Desinfetante Lavanda', 'desinfetante-lavanda', 'Pura Casa', 'Desinfetante Lavanda Pura Casa — frasco 2 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pura Casa\r\nApresentação: Frasco 2 L\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Frasco 2 L', 'unidade', 11.90, NULL, 60.000, 10.000, 'assets/img/produtos/desinfetante-lavanda.jpg', 0, 1, '2026-10-30 08:22:21', NULL),
(51, 6, 'Esponja Multiuso', 'esponja-multiuso', 'Pura Casa', 'Esponja Multiuso Pura Casa — pacote com 3. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pura Casa\r\nApresentação: Pacote com 3\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote com 3', 'unidade', 4.99, NULL, 90.000, 10.000, 'assets/img/produtos/esponja-multiuso.jpg', 0, 1, '2026-10-31 08:22:21', NULL),
(52, 6, 'Papel Toalha', 'papel-toalha', 'Suave', 'Papel Toalha Suave — pacote 2 rolos. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Suave\r\nApresentação: Pacote 2 rolos\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote 2 rolos', 'unidade', 7.49, NULL, 70.000, 10.000, 'assets/img/produtos/papel-toalha.jpg', 0, 1, '2026-11-01 08:22:21', NULL),
(53, 6, 'Água Sanitária', 'agua-sanitaria', 'Pura Casa', 'Água Sanitária Pura Casa — frasco 2 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pura Casa\r\nApresentação: Frasco 2 L\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Frasco 2 L', 'unidade', 6.99, NULL, 80.000, 10.000, 'assets/img/produtos/agua-sanitaria.jpg', 0, 1, '2026-11-02 08:22:21', NULL),
(54, 7, 'Sabonete Erva-doce', 'sabonete-erva-doce', 'Flor de Algodão', 'Sabonete Erva-doce Flor de Algodão — barra 90 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Flor de Algodão\r\nApresentação: Barra 90 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Barra 90 g', 'unidade', 2.99, NULL, 200.000, 10.000, 'assets/img/produtos/sabonete-erva-doce.jpg', 0, 1, '2026-11-03 08:22:21', NULL),
(55, 7, 'Creme Dental Menta', 'creme-dental-menta', 'Sorriso', 'Creme Dental Menta Sorriso — tubo 90 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Sorriso\r\nApresentação: Tubo 90 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Tubo 90 g', 'unidade', 5.49, NULL, 120.000, 10.000, 'assets/img/produtos/creme-dental-menta.jpg', 0, 1, '2026-11-04 08:22:21', NULL),
(56, 7, 'Shampoo Nutrição', 'shampoo-nutricao', 'Flor de Algodão', 'Shampoo Nutrição Flor de Algodão — frasco 350 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Flor de Algodão\r\nApresentação: Frasco 350 ml\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Frasco 350 ml', 'unidade', 19.90, NULL, 50.000, 10.000, 'assets/img/produtos/shampoo-nutricao.jpg', 0, 1, '2026-11-05 08:22:21', NULL),
(57, 7, 'Papel Higiênico Folha Dupla', 'papel-higienico-folha-dupla', 'Suave', 'Papel Higiênico Folha Dupla Suave — pacote 12 rolos. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Suave\r\nApresentação: Pacote 12 rolos\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote 12 rolos', 'unidade', 22.90, 19.90, 60.000, 10.000, 'assets/img/produtos/papel-higienico-folha-dupla.jpg', 1, 1, '2026-11-06 08:22:21', NULL),
(58, 7, 'Desodorante Aerossol', 'desodorante-aerossol', 'Brisa', 'Desodorante Aerossol Brisa — frasco 150 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Brisa\r\nApresentação: Frasco 150 ml\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Frasco 150 ml', 'unidade', 14.90, NULL, 70.000, 10.000, 'assets/img/produtos/desodorante-aerossol.jpg', 0, 1, '2026-11-07 08:22:21', NULL),
(59, 8, 'Hidratante Corporal', 'hidratante-corporal', 'Rosé Botânica', 'Hidratante Corporal Rosé Botânica — frasco 400 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Rosé Botânica\r\nApresentação: Frasco 400 ml\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Frasco 400 ml', 'unidade', 29.90, NULL, 35.000, 3.000, 'assets/img/produtos/hidratante-corporal.jpg', 0, 1, '2026-11-08 08:22:21', NULL),
(60, 8, 'Batom Matte Rosé', 'batom-matte-rose', 'Rosé Botânica', 'Batom Matte Rosé Rosé Botânica — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Rosé Botânica\r\nApresentação: Unidade\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 24.90, NULL, 40.000, 3.000, 'assets/img/produtos/batom-matte-rose.jpg', 1, 1, '2026-11-09 08:22:21', NULL),
(61, 8, 'Esmalte Nude', 'esmalte-nude', 'Rosé Botânica', 'Esmalte Nude Rosé Botânica — frasco 8 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Rosé Botânica\r\nApresentação: Frasco 8 ml\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Frasco 8 ml', 'unidade', 7.90, NULL, 60.000, 3.000, 'assets/img/produtos/esmalte-nude.jpg', 0, 1, '2026-11-10 08:22:21', NULL),
(62, 8, 'Perfume Floral', 'perfume-floral', 'Maison Velluto', 'Perfume Floral Maison Velluto — frasco 50 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Maison Velluto\r\nApresentação: Frasco 50 ml\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Frasco 50 ml', 'unidade', 129.90, 109.90, 15.000, 3.000, 'assets/img/produtos/perfume-floral.jpg', 1, 1, '2026-11-11 08:22:21', NULL),
(63, 8, 'Máscara Capilar', 'mascara-capilar', 'Rosé Botânica', 'Máscara Capilar Rosé Botânica — pote 300 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Rosé Botânica\r\nApresentação: Pote 300 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pote 300 g', 'unidade', 34.90, NULL, 30.000, 3.000, 'assets/img/produtos/mascara-capilar.jpg', 0, 1, '2026-11-12 08:22:21', NULL),
(64, 9, 'Fone de Ouvido Bluetooth', 'fone-de-ouvido-bluetooth', 'Sonora', 'Fone de Ouvido Bluetooth Sonora — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Sonora\r\nApresentação: Unidade\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 189.90, 159.90, 18.000, 3.000, 'assets/img/produtos/fone-de-ouvido-bluetooth.jpg', 1, 1, '2026-11-13 08:22:21', NULL),
(65, 9, 'Carregador USB-C 20W', 'carregador-usb-c-20w', 'Volt', 'Carregador USB-C 20W Volt — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Volt\r\nApresentação: Unidade\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 79.90, NULL, 25.000, 3.000, 'assets/img/produtos/carregador-usb-c-20w.jpg', 0, 1, '2026-11-14 08:22:21', NULL),
(66, 9, 'Caixa de Som Portátil', 'caixa-de-som-portatil', 'Sonora', 'Caixa de Som Portátil Sonora — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Sonora\r\nApresentação: Unidade\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 249.90, NULL, 12.000, 3.000, 'assets/img/produtos/caixa-de-som-portatil.jpg', 0, 1, '2026-11-15 08:22:21', NULL),
(67, 9, 'Smartwatch Fit', 'smartwatch-fit', 'Volt', 'Smartwatch Fit Volt — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Volt\r\nApresentação: Unidade\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 399.90, NULL, 8.000, 3.000, 'assets/img/produtos/smartwatch-fit.jpg', 0, 1, '2026-11-16 08:22:21', NULL),
(68, 9, 'Pilhas Alcalinas AA', 'pilhas-alcalinas-aa', 'Volt', 'Pilhas Alcalinas AA Volt — cartela com 4. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Volt\r\nApresentação: Cartela com 4\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Cartela com 4', 'unidade', 18.90, NULL, 3.000, 3.000, 'assets/img/produtos/pilhas-alcalinas-aa.jpg', 0, 1, '2026-11-17 08:22:21', NULL),
(69, 10, 'Air Fryer 4 L', 'air-fryer-4-l', 'Casa Prática', 'Air Fryer 4 L Casa Prática — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Casa Prática\r\nApresentação: Unidade\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 449.90, 399.90, 9.000, 3.000, 'assets/img/produtos/air-fryer-4-l.jpg', 1, 1, '2026-11-18 08:22:21', '2026-11-24 15:15:26'),
(70, 10, 'Liquidificador 3 Velocidades', 'liquidificador-3-velocidades', 'Casa Prática', 'Liquidificador 3 Velocidades Casa Prática — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Casa Prática\r\nApresentação: Unidade\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 189.90, NULL, 12.000, 3.000, 'assets/img/produtos/liquidificador-3-velocidades.jpg', 0, 1, '2026-10-15 08:22:21', NULL),
(71, 10, 'Cafeteira Elétrica', 'cafeteira-eletrica', 'Casa Prática', 'Cafeteira Elétrica Casa Prática — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Casa Prática\r\nApresentação: Unidade\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 159.90, NULL, 9.000, 3.000, 'assets/img/produtos/cafeteira-eletrica.jpg', 0, 1, '2026-10-16 08:22:21', NULL),
(72, 10, 'Ferro a Vapor', 'ferro-a-vapor', 'Casa Prática', 'Ferro a Vapor Casa Prática — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Casa Prática\r\nApresentação: Unidade\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 129.90, NULL, 11.000, 3.000, 'assets/img/produtos/ferro-a-vapor.jpg', 0, 1, '2026-10-17 08:22:21', NULL),
(73, 10, 'Micro-ondas 20 L', 'micro-ondas-20-l', 'Casa Prática', 'Micro-ondas 20 L Casa Prática — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Casa Prática\r\nApresentação: Unidade\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 699.90, NULL, 4.000, 3.000, 'assets/img/produtos/micro-ondas-20-l.jpg', 0, 1, '2026-10-18 08:22:21', NULL),
(74, 11, 'Camiseta Básica de Algodão', 'camiseta-basica-de-algodao', 'Linho & Co.', 'Camiseta Básica de Algodão Linho & Co. — tamanhos p ao gg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Linho & Co.\r\nApresentação: Tamanhos P ao GG\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Tamanhos P ao GG', 'unidade', 49.90, NULL, 40.000, 3.000, 'assets/img/produtos/camiseta-basica-de-algodao.jpg', 0, 1, '2026-10-19 08:22:21', NULL),
(75, 11, 'Pijama Feminino', 'pijama-feminino', 'Linho & Co.', 'Pijama Feminino Linho & Co. — tamanhos p ao g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Linho & Co.\r\nApresentação: Tamanhos P ao G\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Tamanhos P ao G', 'unidade', 89.90, NULL, 20.000, 3.000, 'assets/img/produtos/pijama-feminino.jpg', 0, 1, '2026-10-20 08:22:21', NULL),
(76, 11, 'Kit de Meias', 'kit-de-meias', 'Linho & Co.', 'Kit de Meias Linho & Co. — pacote com 3 pares. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Linho & Co.\r\nApresentação: Pacote com 3 pares\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote com 3 pares', 'unidade', 29.90, NULL, 50.000, 3.000, 'assets/img/produtos/kit-de-meias.jpg', 0, 1, '2026-10-21 08:22:21', NULL),
(77, 11, 'Moletom Confort', 'moletom-confort', 'Linho & Co.', 'Moletom Confort Linho & Co. — tamanhos p ao gg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Linho & Co.\r\nApresentação: Tamanhos P ao GG\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Tamanhos P ao GG', 'unidade', 139.90, 119.90, 15.000, 3.000, 'assets/img/produtos/moletom-confort.jpg', 0, 1, '2026-10-22 08:22:21', NULL),
(78, 12, 'Vela Aromática Baunilha', 'vela-aromatica-baunilha', 'Maison Velluto', 'Vela Aromática Baunilha Maison Velluto — pote 200 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Maison Velluto\r\nApresentação: Pote 200 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pote 200 g', 'unidade', 39.90, NULL, 25.000, 3.000, 'assets/img/produtos/vela-aromatica-baunilha.jpg', 1, 1, '2026-10-23 08:22:21', NULL),
(79, 12, 'Jogo de Toalhas', 'jogo-de-toalhas', 'Maison Velluto', 'Jogo de Toalhas Maison Velluto — 4 peças. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Maison Velluto\r\nApresentação: 4 peças\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', '4 peças', 'unidade', 99.90, NULL, 15.000, 3.000, 'assets/img/produtos/jogo-de-toalhas.jpg', 0, 1, '2026-10-24 08:22:21', NULL),
(80, 12, 'Caneca de Cerâmica', 'caneca-de-ceramica', 'Maison Velluto', 'Caneca de Cerâmica Maison Velluto — unidade 350 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Maison Velluto\r\nApresentação: Unidade 350 ml\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade 350 ml', 'unidade', 34.90, NULL, 30.000, 3.000, 'assets/img/produtos/caneca-de-ceramica.jpg', 0, 1, '2026-10-25 08:22:21', NULL),
(81, 12, 'Manta Decorativa', 'manta-decorativa', 'Maison Velluto', 'Manta Decorativa Maison Velluto — unidade 1,2 x 1,6 m. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Maison Velluto\r\nApresentação: Unidade 1,2 x 1,6 m\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade 1,2 x 1,6 m', 'unidade', 119.90, NULL, 10.000, 3.000, 'assets/img/produtos/manta-decorativa.jpg', 0, 1, '2026-10-26 08:22:21', NULL),
(82, 12, 'Vaso de Cerâmica', 'vaso-de-ceramica', 'Maison Velluto', 'Vaso de Cerâmica Maison Velluto — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Maison Velluto\r\nApresentação: Unidade\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 59.90, NULL, 14.000, 3.000, 'assets/img/produtos/vaso-de-ceramica.jpg', 0, 1, '2026-10-27 08:22:21', NULL),
(83, 13, 'Ração para Cães Adultos', 'racao-para-caes-adultos', 'Patas Felizes', 'Ração para Cães Adultos Patas Felizes — saco 10 kg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Patas Felizes\r\nApresentação: Saco 10 kg\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Saco 10 kg', 'unidade', 149.90, NULL, 20.000, 10.000, 'assets/img/produtos/racao-para-caes-adultos.jpg', 0, 1, '2026-10-28 08:22:21', NULL),
(84, 13, 'Ração para Gatos', 'racao-para-gatos', 'Patas Felizes', 'Ração para Gatos Patas Felizes — saco 3 kg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Patas Felizes\r\nApresentação: Saco 3 kg\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Saco 3 kg', 'unidade', 69.90, NULL, 25.000, 10.000, 'assets/img/produtos/racao-para-gatos.jpg', 0, 1, '2026-10-29 08:22:21', NULL),
(85, 13, 'Petisco Bifinho', 'petisco-bifinho', 'Patas Felizes', 'Petisco Bifinho Patas Felizes — pacote 65 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Patas Felizes\r\nApresentação: Pacote 65 g\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote 65 g', 'unidade', 8.90, NULL, 60.000, 10.000, 'assets/img/produtos/petisco-bifinho.jpg', 0, 1, '2026-10-30 08:22:21', NULL),
(86, 13, 'Areia Higiênica', 'areia-higienica', 'Patas Felizes', 'Areia Higiênica Patas Felizes — pacote 4 kg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Patas Felizes\r\nApresentação: Pacote 4 kg\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote 4 kg', 'unidade', 24.90, NULL, 30.000, 10.000, 'assets/img/produtos/areia-higienica.jpg', 0, 1, '2026-10-31 08:22:21', NULL),
(87, 14, 'Fralda Tamanho M', 'fralda-tamanho-m', 'Pequeno Abraço', 'Fralda Tamanho M Pequeno Abraço — pacote 40 unidades. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pequeno Abraço\r\nApresentação: Pacote 40 unidades\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote 40 unidades', 'unidade', 69.90, 59.90, 30.000, 10.000, 'assets/img/produtos/fralda-tamanho-m.jpg', 1, 1, '2026-11-01 08:22:21', NULL),
(88, 14, 'Lenço Umedecido', 'lenco-umedecido', 'Pequeno Abraço', 'Lenço Umedecido Pequeno Abraço — pacote 50 unidades. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pequeno Abraço\r\nApresentação: Pacote 50 unidades\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Pacote 50 unidades', 'unidade', 9.90, NULL, 60.000, 10.000, 'assets/img/produtos/lenco-umedecido.jpg', 0, 1, '2026-11-02 08:22:21', NULL),
(89, 14, 'Shampoo Infantil', 'shampoo-infantil', 'Pequeno Abraço', 'Shampoo Infantil Pequeno Abraço — frasco 200 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pequeno Abraço\r\nApresentação: Frasco 200 ml\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Frasco 200 ml', 'unidade', 16.90, NULL, 35.000, 10.000, 'assets/img/produtos/shampoo-infantil.jpg', 0, 1, '2026-11-03 08:22:21', NULL),
(90, 14, 'Mamadeira', 'mamadeira', 'Pequeno Abraço', 'Mamadeira Pequeno Abraço — unidade 260 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pequeno Abraço\r\nApresentação: Unidade 260 ml\r\nVenda: por unidade\r\nArmazenamento: conforme orientação da embalagem', 'Unidade 260 ml', 'unidade', 39.90, NULL, 20.000, 10.000, 'assets/img/produtos/mamadeira.jpg', 0, 1, '2026-11-04 08:22:21', NULL),
(91, 5, 'Panetone de Frutas Cristalizadas', 'panetone-frutas', 'Velluto Seleção', 'Panetone de massa macia com frutas cristalizadas e uvas-passas.', NULL, 'Unidade 500 g', 'unidade', 34.90, NULL, 96.000, 10.000, 'assets/img/produtos/panetone-frutas.jpg', 0, 1, '2026-11-24 11:52:46', NULL),
(92, 5, 'Chocotone com Gotas de Chocolate', 'chocotone-gotas', 'Velluto Seleção', 'Panetone de chocolate com gotas na massa.', NULL, 'Unidade 500 g', 'unidade', 39.90, NULL, 96.000, 10.000, 'assets/img/produtos/chocotone-gotas.jpg', 0, 1, '2026-11-24 11:52:46', NULL),
(93, 2, 'Suco de Maçã Gaseificado', 'suco-maca-espumante', 'Velluto Seleção', 'Suco de maçã com gás, sem álcool, para servir bem gelado.', NULL, 'Garrafa 750 ml', 'unidade', 26.90, NULL, 96.000, 10.000, 'assets/img/produtos/suco-maca-espumante.jpg', 0, 1, '2026-11-24 11:52:46', NULL),
(94, 15, 'Mix de Castanhas para Ceia', 'mix-castanhas-ceia', 'Velluto Seleção', 'Mistura de castanhas para servir na ceia ou acrescentar às receitas.', NULL, 'Pacote 250 g', 'unidade', 32.90, NULL, 96.000, 10.000, 'assets/img/produtos/mix-castanhas-ceia.jpg', 0, 1, '2026-11-24 11:52:46', NULL),
(95, 4, 'Peru Temperado para Assar', 'peru-temperado-natal', 'Velluto Seleção', 'Peru inteiro temperado e congelado. Descongele sob refrigeração e asse conforme a embalagem.', NULL, 'Vendido por kg', 'peso', 39.90, NULL, 96.000, 10.000, 'assets/img/produtos/peru-temperado-natal.jpg', 0, 1, '2026-11-24 11:52:46', NULL),
(96, 4, 'Lombo Suíno Temperado', 'lombo-suino-natal', 'Velluto Seleção', 'Lombo temperado para assar e servir fatiado. A imagem apresenta uma sugestão de preparo.', NULL, 'Vendido por kg', 'peso', 36.90, NULL, 96.000, 10.000, 'assets/img/produtos/lombo-suino-natal.jpg', 0, 1, '2026-11-24 11:52:46', NULL),
(97, 15, 'Farofa Natalina com Passas', 'farofa-natalina', 'Velluto Seleção', 'Farofa de mandioca torrada com uvas-passas para servir como acompanhamento.', NULL, 'Pacote 300 g', 'unidade', 15.90, NULL, 96.000, 10.000, 'assets/img/produtos/farofa-natalina.jpg', 0, 1, '2026-11-24 11:52:46', NULL),
(98, 15, 'Ameixa Seca sem Caroço', 'ameixa-seca', 'Velluto Seleção', 'Ameixas secas para molhos, recheios e tábuas.', NULL, 'Pacote 200 g', 'unidade', 15.90, NULL, 96.000, 10.000, 'assets/img/produtos/ameixa-seca.jpg', 0, 1, '2026-11-24 11:52:46', NULL),
(99, 3, 'Cerejas Frescas', 'cerejas-frescas', 'Velluto Seleção', 'Cerejas frescas para servir à mesa ou decorar sobremesas.', NULL, 'Bandeja 200 g', 'unidade', 29.90, NULL, 95.000, 10.000, 'assets/img/produtos/cerejas-frescas.jpg', 0, 1, '2026-11-24 11:52:46', '2026-11-24 14:35:31'),
(100, 18, 'Azeitonas Verdes sem Caroço', 'azeitonas-verdes-ceia', 'Velluto Seleção', 'Azeitonas verdes em salmoura para entradas, assados e recheios.', NULL, 'Vidro 200 g', 'unidade', 14.90, NULL, 95.000, 10.000, 'assets/img/produtos/azeitonas-verdes-ceia.jpg', 0, 1, '2026-11-24 11:52:46', '2026-11-24 14:35:31'),
(101, 12, 'Guirlanda de Natal com Laço', 'guirlanda-natal', 'Velluto Seleção', 'Guirlanda verde com laço bordô para porta ou parede em ambiente protegido.', NULL, 'Unidade 35 cm', 'unidade', 79.90, NULL, 96.000, 10.000, 'assets/img/produtos/guirlanda-natal.jpg', 0, 1, '2026-11-24 11:52:46', NULL),
(102, 12, 'Conjunto de Bolas de Natal', 'bolas-natal', 'Velluto Seleção', 'Bolas decorativas em vermelho e dourado para pendurar na árvore.', NULL, 'Caixa com 6', 'unidade', 24.90, NULL, 96.000, 10.000, 'assets/img/produtos/bolas-natal.jpg', 0, 1, '2026-11-24 11:52:46', NULL),
(103, 12, 'Pisca-pisca de LED Branco Quente', 'pisca-led-natal', 'Velluto Seleção', 'Cordão de luzes em tom quente para decorar ambientes internos.', NULL, 'Cordão 5 m', 'unidade', 39.90, NULL, 96.000, 10.000, 'assets/img/produtos/pisca-led-natal.jpg', 0, 1, '2026-11-24 11:52:46', NULL),
(104, 12, 'Vela Aromática de Canela', 'vela-canela-natal', 'Velluto Seleção', 'Vela aromática em pote de vidro âmbar para decorar a mesa ou a sala.', NULL, 'Pote 150 g', 'unidade', 29.90, NULL, 96.000, 10.000, 'assets/img/produtos/vela-canela-natal.jpg', 0, 1, '2026-11-24 11:52:46', NULL),
(105, 12, 'Toalha de Mesa Natalina Bordô', 'toalha-mesa-natal', 'Velluto Seleção', 'Toalha retangular bordô com detalhes dourados para a mesa da ceia.', NULL, 'Unidade 140 × 180 cm', 'unidade', 64.90, NULL, 96.000, 10.000, 'assets/img/produtos/toalha-mesa-natal.jpg', 0, 1, '2026-11-24 11:52:46', NULL),
(106, 12, 'Miniárvore de Natal', 'mini-arvore-natal', 'Velluto Seleção', 'Árvore decorativa de mesa com base revestida e ramos verdes.', NULL, 'Unidade 40 cm', 'unidade', 69.90, NULL, 96.000, 10.000, 'assets/img/produtos/mini-arvore-natal.jpg', 0, 1, '2026-11-24 11:52:46', NULL),
(107, 3, 'Abacaxi Pérola', 'abacaxi-perola', 'Velluto Seleção', 'Abacaxi de polpa clara, doce e suculenta.', NULL, 'Unidade', 'unidade', 9.49, NULL, 96.000, 10.000, 'assets/img/produtos/abacaxi-perola.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(108, 3, 'Brócolis Ninja', 'brocolis-ninja', 'Velluto Seleção', 'Brócolis fresco de floretes compactos.', NULL, 'Unidade', 'unidade', 7.99, NULL, 96.000, 10.000, 'assets/img/produtos/brocolis-ninja.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(109, 3, 'Mirtilo Fresco', 'mirtilo-fresco', 'Velluto Seleção', 'Mirtilos frescos para lanches, cereais e sobremesas.', NULL, 'Bandeja 125 g', 'unidade', 14.90, NULL, 96.000, 10.000, 'assets/img/produtos/mirtilo-fresco.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(110, 5, 'Pão de Fermentação Natural', 'pao-de-fermentacao-natural', 'Velluto Seleção', 'Pão rústico de crosta firme e miolo macio.', NULL, 'Vendido por kg', 'peso', 39.90, NULL, 96.000, 10.000, 'assets/img/produtos/pao-de-fermentacao-natural.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(111, 5, 'Rolinho de Canela', 'rolinho-de-canela', 'Velluto Seleção', 'Massa macia enrolada com canela e cobertura açucarada.', NULL, 'Unidade', 'unidade', 8.90, NULL, 96.000, 10.000, 'assets/img/produtos/rolinho-de-canela.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(112, 15, 'Aveia em Flocos', 'aveia-em-flocos', 'Velluto Seleção', 'Flocos de aveia para mingaus, vitaminas e receitas.', NULL, 'Pacote 500 g', 'unidade', 13.90, NULL, 95.000, 10.000, 'assets/img/produtos/aveia-em-flocos.jpg', 0, 1, '2026-11-24 13:36:45', '2026-11-24 14:35:31'),
(113, 15, 'Mel Silvestre', 'mel-silvestre', 'Velluto Seleção', 'Mel de flores silvestres para acompanhar frutas, pães e iogurtes.', NULL, 'Pote 300 g', 'unidade', 24.90, NULL, 96.000, 10.000, 'assets/img/produtos/mel-silvestre.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(114, 2, 'Chá de Camomila', 'cha-de-camomila', 'Velluto Seleção', 'Flores secas de camomila para preparo por infusão.', NULL, 'Pacote 40 g', 'unidade', 10.90, NULL, 96.000, 10.000, 'assets/img/produtos/cha-de-camomila.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(115, 17, 'Framboesa Congelada', 'framboesa-congelada', 'Velluto Seleção', 'Framboesas congeladas para caldas, bebidas e sobremesas.', NULL, 'Pacote 300 g', 'unidade', 27.90, NULL, 96.000, 10.000, 'assets/img/produtos/framboesa-congelada.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(116, 15, 'Geleia de Morango', 'geleia-de-morango', 'Velluto Seleção', 'Geleia de morango para torradas, bolos e tábuas de queijos.', NULL, 'Vidro 230 g', 'unidade', 16.50, NULL, 96.000, 10.000, 'assets/img/produtos/geleia-de-morango.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(117, 15, 'Massa Penne', 'massa-penne', 'Velluto Seleção', 'Massa curta e estriada para molhos encorpados e saladas.', NULL, 'Pacote 500 g', 'unidade', 7.90, NULL, 96.000, 10.000, 'assets/img/produtos/massa-penne.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(118, 15, 'Granola com Castanhas', 'granola-castanhas', 'Velluto Seleção', 'Mistura crocante de cereais e castanhas para iogurte e frutas.', NULL, 'Pacote 300 g', 'unidade', 19.90, NULL, 96.000, 10.000, 'assets/img/produtos/granola-castanhas.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(119, 16, 'Queijo Minas Frescal', 'queijo-minas-frescal', 'Velluto Seleção', 'Queijo fresco de textura macia. Manter refrigerado.', NULL, 'Peça 350 g', 'unidade', 23.90, NULL, 96.000, 10.000, 'assets/img/produtos/queijo-minas-frescal.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(120, 16, 'Iogurte Grego de Morango', 'iogurte-grego-morango', 'Velluto Seleção', 'Iogurte cremoso com morango para servir gelado.', NULL, 'Pote 100 g', 'unidade', 4.99, NULL, 96.000, 10.000, 'assets/img/produtos/iogurte-grego-morango.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(121, 17, 'Polpa de Açaí', 'polpa-de-acai', 'Velluto Seleção', 'Polpa congelada para tigelas, vitaminas e sobremesas.', NULL, 'Pacote 400 g', 'unidade', 19.90, NULL, 96.000, 10.000, 'assets/img/produtos/polpa-de-acai.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(122, 17, 'Pão de Queijo Congelado', 'pao-de-queijo-congelado', 'Velluto Seleção', 'Pães de queijo porcionados para assar conforme a embalagem.', NULL, 'Pacote 500 g', 'unidade', 17.90, NULL, 96.000, 10.000, 'assets/img/produtos/pao-de-queijo-congelado.jpg', 0, 1, '2026-11-24 13:36:45', NULL);
INSERT INTO `produtos` (`id`, `categoria_id`, `nome`, `slug`, `marca`, `descricao`, `informacoes`, `embalagem`, `vendido_por`, `preco`, `preco_promocional`, `estoque`, `estoque_minimo`, `imagem`, `destaque`, `ativo`, `criado_em`, `atualizado_em`) VALUES
(123, 18, 'Grão-de-bico em Conserva', 'grao-de-bico-em-conserva', 'Velluto Seleção', 'Grão-de-bico cozido para saladas, pastas e pratos quentes.', NULL, 'Lata 240 g', 'unidade', 9.49, NULL, 96.000, 10.000, 'assets/img/produtos/grao-de-bico-em-conserva.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(124, 18, 'Palmito em Conserva', 'palmito-em-conserva', 'Velluto Seleção', 'Palmito em salmoura para saladas e recheios.', NULL, 'Vidro 300 g', 'unidade', 22.90, NULL, 96.000, 10.000, 'assets/img/produtos/palmito-em-conserva.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(125, 2, 'Água Mineral com Gás', 'agua-com-gas', 'Velluto Seleção', 'Água mineral gaseificada em garrafa individual.', NULL, 'Garrafa 500 ml', 'unidade', 2.99, NULL, 96.000, 10.000, 'assets/img/produtos/agua-com-gas.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(126, 2, 'Suco de Laranja', 'suco-de-laranja', 'Velluto Seleção', 'Suco de laranja para servir gelado.', NULL, 'Garrafa 1 L', 'unidade', 14.90, NULL, 96.000, 10.000, 'assets/img/produtos/suco-de-laranja.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(127, 3, 'Manga Palmer', 'manga-palmer', 'Velluto Seleção', 'Manga de polpa firme, indicada para cortes e vitaminas.', NULL, 'Vendido por kg', 'peso', 8.90, NULL, 96.000, 10.000, 'assets/img/produtos/manga-palmer.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(128, 3, 'Cenoura', 'cenoura', 'Velluto Seleção', 'Cenoura fresca para saladas, sopas e assados.', NULL, 'Vendido por kg', 'peso', 5.49, NULL, 96.000, 10.000, 'assets/img/produtos/cenoura.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(129, 4, 'Coxão Mole em Bifes', 'coxao-mole', 'Velluto Seleção', 'Corte bovino fatiado para grelhar ou preparar à milanesa.', NULL, 'Vendido por kg', 'peso', 46.90, NULL, 96.000, 10.000, 'assets/img/produtos/coxao-mole.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(130, 4, 'Salmão em Posta', 'salmao-em-posta', 'Velluto Seleção', 'Postas de salmão para forno ou grelha. Manter refrigerado.', NULL, 'Vendido por kg', 'peso', 91.90, NULL, 96.000, 10.000, 'assets/img/produtos/salmao-em-posta.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(131, 5, 'Baguete Rústica', 'baguete-rustica', 'Velluto Seleção', 'Baguete de crosta crocante para sanduíches e bruschettas.', NULL, 'Unidade 250 g', 'unidade', 11.90, NULL, 95.000, 10.000, 'assets/img/produtos/baguete-rustica.jpg', 0, 1, '2026-11-24 13:36:45', '2026-11-24 14:35:31'),
(132, 5, 'Bolo de Laranja', 'bolo-de-laranja', 'Velluto Seleção', 'Bolo de laranja de miolo macio para o café.', NULL, 'Unidade 450 g', 'unidade', 21.90, NULL, 96.000, 10.000, 'assets/img/produtos/bolo-de-laranja.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(133, 6, 'Limpador Multiuso Cítrico', 'limpador-multiuso-citrico', 'Velluto Seleção', 'Limpador em spray para as superfícies indicadas no rótulo.', NULL, 'Frasco 500 ml', 'unidade', 8.90, NULL, 96.000, 10.000, 'assets/img/produtos/limpador-multiuso-citrico.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(134, 6, 'Sabão em Pó para Roupas', 'sabao-em-po', 'Velluto Seleção', 'Sabão para lavagem de roupas. Siga a dosagem da embalagem.', NULL, 'Pacote 800 g', 'unidade', 15.90, NULL, 96.000, 10.000, 'assets/img/produtos/sabao-em-po.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(135, 7, 'Fio Dental Encerado', 'fio-dental', 'Velluto Seleção', 'Fio dental encerado em estojo compacto.', NULL, 'Estojo 50 m', 'unidade', 7.90, NULL, 96.000, 10.000, 'assets/img/produtos/fio-dental.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(136, 7, 'Condicionador Hidratante', 'condicionador-hidratante', 'Velluto Seleção', 'Condicionador para usar após a lavagem e enxaguar.', NULL, 'Frasco 300 ml', 'unidade', 18.90, NULL, 96.000, 10.000, 'assets/img/produtos/condicionador-hidratante.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(137, 8, 'Sérum Facial Hidratante', 'serum-facial', 'Velluto Seleção', 'Sérum de textura leve com aplicador conta-gotas.', NULL, 'Frasco 30 ml', 'unidade', 42.90, NULL, 96.000, 10.000, 'assets/img/produtos/serum-facial.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(138, 8, 'Protetor Solar Facial FPS 50', 'protetor-solar-facial', 'Velluto Seleção', 'Protetor solar facial de uso diário. Siga as instruções do rótulo.', NULL, 'Tubo 40 g', 'unidade', 49.90, NULL, 96.000, 10.000, 'assets/img/produtos/protetor-solar-facial.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(139, 9, 'Mouse sem Fio', 'mouse-sem-fio', 'Velluto Seleção', 'Mouse compacto com receptor USB para computadores compatíveis.', NULL, 'Unidade', 'unidade', 69.90, NULL, 96.000, 10.000, 'assets/img/produtos/mouse-sem-fio.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(140, 9, 'Cabo USB-C Trançado', 'cabo-usb-c-trancado', 'Velluto Seleção', 'Cabo de um metro com revestimento trançado e conectores USB-C.', NULL, 'Unidade 1 m', 'unidade', 29.90, NULL, 96.000, 10.000, 'assets/img/produtos/cabo-usb-c-trancado.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(141, 10, 'Sanduicheira Elétrica', 'sanduicheira-eletrica', 'Velluto Seleção', 'Sanduicheira compacta com placas antiaderentes.', NULL, 'Unidade 127 V', 'unidade', 129.90, NULL, 96.000, 10.000, 'assets/img/produtos/sanduicheira-eletrica.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(142, 10, 'Chaleira Elétrica Inox', 'chaleira-eletrica', 'Velluto Seleção', 'Chaleira de aço inox com base removível.', NULL, 'Unidade 1,7 L · 127 V', 'unidade', 139.90, NULL, 96.000, 10.000, 'assets/img/produtos/chaleira-eletrica.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(143, 11, 'Bermuda de Moletom', 'bermuda-moletom', 'Velluto Seleção', 'Bermuda cinza de moletom com cintura ajustável.', NULL, 'Tamanho M', 'unidade', 59.90, NULL, 96.000, 10.000, 'assets/img/produtos/bermuda-moletom.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(144, 11, 'Camiseta Infantil de Algodão', 'camiseta-infantil', 'Velluto Seleção', 'Camiseta amarela de algodão com manga curta.', NULL, 'Tamanho 8', 'unidade', 34.90, NULL, 96.000, 10.000, 'assets/img/produtos/camiseta-infantil.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(145, 12, 'Almofada com Capa de Linho', 'almofada-de-linho', 'Velluto Seleção', 'Almofada em tom areia com capa texturizada.', NULL, 'Unidade 45 × 45 cm', 'unidade', 79.90, NULL, 95.000, 10.000, 'assets/img/produtos/almofada-de-linho.jpg', 0, 1, '2026-11-24 13:36:45', '2026-11-24 14:35:31'),
(146, 12, 'Organizador de Bambu', 'organizador-de-bambu', 'Velluto Seleção', 'Cesto retangular para organizar objetos em prateleiras.', NULL, 'Unidade 30 × 20 cm', 'unidade', 59.90, NULL, 96.000, 10.000, 'assets/img/produtos/organizador-de-bambu.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(147, 13, 'Comedouro Pet de Inox', 'comedouro-inox', 'Velluto Seleção', 'Tigela de aço inox para água ou ração.', NULL, 'Unidade 500 ml', 'unidade', 25.90, NULL, 96.000, 10.000, 'assets/img/produtos/comedouro-inox.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(148, 13, 'Brinquedo de Corda para Cães', 'brinquedo-corda-para-caes', 'Velluto Seleção', 'Corda trançada com nós para brincadeiras supervisionadas.', NULL, 'Unidade 25 cm', 'unidade', 19.90, NULL, 96.000, 10.000, 'assets/img/produtos/brinquedo-corda-para-caes.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(149, 14, 'Sabonete Líquido Infantil', 'sabonete-liquido-infantil', 'Velluto Seleção', 'Sabonete líquido com válvula dosadora para o banho.', NULL, 'Frasco 200 ml', 'unidade', 18.90, NULL, 96.000, 10.000, 'assets/img/produtos/sabonete-liquido-infantil.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(150, 14, 'Copo de Transição Infantil', 'copo-de-transicao', 'Velluto Seleção', 'Copo infantil com duas alças e bico para transição.', NULL, 'Unidade 200 ml', 'unidade', 32.90, NULL, 96.000, 10.000, 'assets/img/produtos/copo-de-transicao.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(151, 15, 'Arroz Integral', 'arroz-integral', 'Velluto Seleção', 'Arroz integral para acompanhamentos e refeições do dia a dia.', NULL, 'Pacote 1 kg', 'unidade', 9.90, NULL, 96.000, 10.000, 'assets/img/produtos/arroz-integral.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(152, 15, 'Lentilha Seca', 'lentilha-seca', 'Velluto Seleção', 'Lentilhas secas para caldos, saladas e acompanhamentos.', NULL, 'Pacote 500 g', 'unidade', 12.90, NULL, 96.000, 10.000, 'assets/img/produtos/lentilha-seca.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(153, 15, 'Ovo de Páscoa ao Leite', 'ovo-pascoa-chocolate', 'Velluto Seleção', 'Ovo de chocolate ao leite com bombons.', NULL, 'Unidade 200 g', 'unidade', 49.90, NULL, 96.000, 10.000, 'assets/img/produtos/ovo-pascoa-chocolate.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(154, 15, 'Paçoca de Amendoim', 'pacoca-junina', 'Velluto Seleção', 'Doce tradicional de amendoim em porções individuais.', NULL, 'Pacote 180 g', 'unidade', 13.90, NULL, 96.000, 10.000, 'assets/img/produtos/pacoca-junina.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(155, 15, 'Milho Branco para Canjica', 'canjica-branca', 'Velluto Seleção', 'Milho branco em grãos para preparo de canjica doce.', NULL, 'Pacote 500 g', 'unidade', 8.90, NULL, 96.000, 10.000, 'assets/img/produtos/canjica-branca.jpg', 0, 1, '2026-11-24 13:36:45', NULL),
(156, 15, 'Gomas Sortidas de Halloween', 'gomas-halloween', 'Velluto Seleção', 'Balas de goma em formatos variados para festas e lembrancinhas.', NULL, 'Pacote 150 g', 'unidade', 15.90, NULL, 96.000, 10.000, 'assets/img/produtos/gomas-halloween.jpg', 0, 1, '2026-11-24 13:36:45', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `recuperacao_senhas`
--

CREATE TABLE `recuperacao_senhas` (
  `id` int(10) UNSIGNED NOT NULL,
  `usuario_id` int(10) UNSIGNED NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expira_em` datetime NOT NULL,
  `usado_em` datetime DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `substituicoes`
--

CREATE TABLE `substituicoes` (
  `id` int(10) UNSIGNED NOT NULL,
  `pedido_id` int(10) UNSIGNED NOT NULL,
  `item_id` int(10) UNSIGNED NOT NULL,
  `produto_original_id` int(10) UNSIGNED NOT NULL,
  `produto_sugerido_id` int(10) UNSIGNED NOT NULL,
  `quantidade` decimal(10,3) NOT NULL,
  `preco_original` decimal(10,2) NOT NULL,
  `preco_sugerido` decimal(10,2) NOT NULL,
  `diferenca` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('pendente','aceita','rejeitada','cancelada') NOT NULL DEFAULT 'pendente',
  `mensagem` varchar(255) DEFAULT NULL,
  `sugerido_por` int(10) UNSIGNED DEFAULT NULL,
  `respondido_por` int(10) UNSIGNED DEFAULT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `respondido_em` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `substituicoes`
--

INSERT INTO `substituicoes` (`id`, `pedido_id`, `item_id`, `produto_original_id`, `produto_sugerido_id`, `quantidade`, `preco_original`, `preco_sugerido`, `diferenca`, `status`, `mensagem`, `sugerido_por`, `respondido_por`, `criado_em`, `respondido_em`) VALUES
(1, 14, 39, 24, 26, 1.000, 13.90, 42.90, 29.00, 'pendente', '.', 10, NULL, '2026-11-24 11:17:21', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(120) NOT NULL,
  `email` varchar(160) NOT NULL,
  `senha_hash` varchar(255) DEFAULT NULL,
  `perfil` enum('cliente','administrador','separador','entregador') NOT NULL DEFAULT 'cliente',
  `cpf` varchar(11) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `ultimo_login` datetime DEFAULT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `atualizado_em` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha_hash`, `perfil`, `cpf`, `telefone`, `ativo`, `ultimo_login`, `criado_em`, `atualizado_em`) VALUES
(1, 'Administrador Velluto', 'admin@velluto.com', NULL, 'administrador', NULL, '(11) 4000-1000', 1, NULL, '2026-10-25 08:22:21', NULL),
(2, 'Separador Velluto', 'separador@velluto.com', NULL, 'separador', NULL, '(11) 4000-1001', 1, NULL, '2026-10-25 08:22:21', NULL),
(3, 'Entregador Velluto', 'entregador@velluto.com', NULL, 'entregador', NULL, '(11) 4000-1002', 1, NULL, '2026-10-25 08:22:21', NULL),
(4, 'Bruno Lima', 'separador2@velluto.com', NULL, 'separador', NULL, '(11) 4000-1003', 1, NULL, '2026-10-25 08:22:21', NULL),
(5, 'Carla Mendes', 'entregador2@velluto.com', NULL, 'entregador', NULL, '(11) 4000-1004', 1, NULL, '2026-10-25 08:22:21', NULL),
(6, 'Maria Oliveira', 'cliente@velluto.com', '$2y$10$VVmbsMRwB4RgTr5rODKTsueOgf2O0Wq6xwNVy5jnFj42yeNhGOITi', 'cliente', '52998224725', '(11) 98888-1234', 1, NULL, '2026-10-25 08:22:21', NULL),
(7, 'João Pereira', 'joao@velluto.com', '$2y$10$VVmbsMRwB4RgTr5rODKTsueOgf2O0Wq6xwNVy5jnFj42yeNhGOITi', 'cliente', '11144477735', '(11) 97777-4321', 1, NULL, '2026-10-25 08:22:21', NULL),
(8, 'matheus', 'teste@gmail.com', '$2y$10$YDjkPqW4NbN0zq2oky9wMOYg88kuscOC./KB6cdg..RL1oNFgc5ru', 'cliente', NULL, '(11) 98975-4968', 1, '2026-11-24 14:31:38', '2026-11-24 09:04:55', '2026-11-24 09:44:54'),
(9, 'Gaby Trindade', 'gaby@velluto.com', '$2y$10$ES8M.gpHxlfA9gtWpOoHCe3lVT1NWLdWriwlFaB1JuyFYyNJT6oBy', 'administrador', NULL, NULL, 1, '2026-11-24 15:52:52', '2026-11-24 09:11:49', NULL),
(10, 'Igor Alves', 'igor@velluto.com', '$2y$10$czGD5Rtfa/EfC1LIKy6sWev1g5p94NPfB97JGgsTi3wNWA/NCHBgW', 'separador', NULL, NULL, 1, '2026-11-24 16:20:53', '2026-11-24 09:53:15', NULL),
(11, 'Maria Clara', 'maria@velluto.com', '$2y$10$lWIKob0BbAQw1Wnc9a4aPu4K6kkGWKMUz2gGaQe9XefuRlVEl.kb.', 'entregador', NULL, NULL, 1, '2026-11-24 16:20:20', '2026-11-24 10:31:50', NULL),
(12, 'Moises Stain Bademian', 'moises@gmail.com', '$2y$10$kvtfRTzjZ//ydw/VqI6vvOUH4fbunatyHBWOu8EBVIjTg2XLOFDI.', 'cliente', NULL, '(11) 97712-3339', 1, '2026-11-24 11:50:53', '2026-11-24 11:50:53', NULL),
(13, 'Gaby Trindade', 'gaby@gmail.com', '$2y$10$hQHbBut0Bj3UmkBeU31j4.ZTqYrwnShMgzehv55fMINc0IhtDsvz.', 'cliente', NULL, '(11) 98975-4968', 1, '2026-11-24 15:17:34', '2026-11-24 15:14:40', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `vendas_demo_mensais`
--

CREATE TABLE `vendas_demo_mensais` (
  `periodo` date NOT NULL,
  `valor` decimal(12,2) NOT NULL CHECK (`valor` >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `vendas_demo_mensais`
--

INSERT INTO `vendas_demo_mensais` (`periodo`, `valor`) VALUES
('2024-01-01', 12800.00),
('2024-02-01', 11950.00),
('2024-03-01', 13520.00),
('2024-04-01', 14280.00),
('2024-05-01', 15750.00),
('2024-06-01', 15120.00),
('2024-07-01', 16980.00),
('2024-08-01', 17540.00),
('2024-09-01', 18360.00),
('2024-10-01', 20120.00),
('2024-11-01', 21980.00),
('2024-12-01', 26800.00),
('2025-01-01', 22150.00),
('2025-02-01', 21480.00),
('2025-03-01', 23900.00),
('2025-04-01', 25120.00),
('2025-05-01', 26750.00),
('2025-06-01', 25900.00),
('2025-07-01', 28350.00),
('2025-08-01', 29600.00),
('2025-09-01', 31200.00),
('2025-10-01', 32950.00),
('2025-11-01', 35100.00),
('2025-12-01', 41750.00),
('2026-01-01', 36200.00),
('2026-02-01', 34980.00),
('2026-03-01', 38450.00),
('2026-04-01', 39600.00),
('2026-05-01', 41950.00),
('2026-06-01', 40780.00),
('2026-07-01', 44200.00),
('2026-08-01', 45750.00),
('2026-09-01', 48300.00),
('2026-10-01', 51120.00),
('2026-11-01', 49680.00);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `areas_entrega`
--
ALTER TABLE `areas_entrega`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_areas_cep` (`cep_inicio`,`cep_fim`);

--
-- Índices de tabela `avaliacoes`
--
ALTER TABLE `avaliacoes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_avaliacoes` (`produto_id`,`usuario_id`),
  ADD KEY `fk_aval_usuario` (`usuario_id`);

--
-- Índices de tabela `carrossel_banners`
--
ALTER TABLE `carrossel_banners`
  ADD PRIMARY KEY (`chave`);

--
-- Índices de tabela `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_categorias_slug` (`slug`),
  ADD KEY `fk_categorias_pai` (`pai_id`);

--
-- Índices de tabela `configuracoes`
--
ALTER TABLE `configuracoes`
  ADD PRIMARY KEY (`chave`);

--
-- Índices de tabela `enderecos`
--
ALTER TABLE `enderecos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_enderecos_usuario` (`usuario_id`),
  ADD KEY `idx_enderecos_cep` (`cep`);

--
-- Índices de tabela `entregas`
--
ALTER TABLE `entregas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_entregas_pedido` (`pedido_id`),
  ADD KEY `fk_entregas_entregador` (`entregador_id`),
  ADD KEY `idx_entregas_status` (`status`);

--
-- Índices de tabela `favoritos`
--
ALTER TABLE `favoritos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_favoritos` (`usuario_id`,`produto_id`),
  ADD KEY `fk_fav_produto` (`produto_id`);

--
-- Índices de tabela `historico_pedidos`
--
ALTER TABLE `historico_pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_hist_usuario` (`usuario_id`),
  ADD KEY `idx_hist_pedido_data` (`pedido_id`,`criado_em`);

--
-- Índices de tabela `itens_pedido`
--
ALTER TABLE `itens_pedido`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_itens_produto` (`produto_id`),
  ADD KEY `fk_itens_origem` (`item_origem_id`),
  ADD KEY `idx_itens_status` (`pedido_id`,`status`);

--
-- Índices de tabela `logs_alteracoes`
--
ALTER TABLE `logs_alteracoes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_logs_usuario` (`usuario_id`),
  ADD KEY `idx_logs_data` (`criado_em`);

--
-- Índices de tabela `movimentacoes_estoque`
--
ALTER TABLE `movimentacoes_estoque`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_mov_pedido` (`pedido_id`),
  ADD KEY `fk_mov_usuario` (`usuario_id`),
  ADD KEY `idx_mov_produto_data` (`produto_id`,`criado_em`);

--
-- Índices de tabela `ocorrencias`
--
ALTER TABLE `ocorrencias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_ocorr_pedido` (`pedido_id`),
  ADD KEY `fk_ocorr_entrega` (`entrega_id`),
  ADD KEY `fk_ocorr_usuario` (`usuario_id`),
  ADD KEY `fk_ocorr_resolvido_por` (`resolvido_por`),
  ADD KEY `idx_ocorr_status` (`status`);

--
-- Índices de tabela `pagamentos`
--
ALTER TABLE `pagamentos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pagamentos_pedido` (`pedido_id`);

--
-- Índices de tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pedidos_usuario` (`usuario_id`),
  ADD KEY `fk_pedidos_endereco` (`endereco_id`),
  ADD KEY `fk_pedidos_area` (`area_entrega_id`),
  ADD KEY `fk_pedidos_separador` (`separador_id`),
  ADD KEY `fk_pedidos_cancelado_por` (`cancelado_por`),
  ADD KEY `idx_pedidos_status` (`status`),
  ADD KEY `idx_pedidos_criado` (`criado_em`);

--
-- Índices de tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_produtos_slug` (`slug`),
  ADD KEY `fk_produtos_categoria` (`categoria_id`),
  ADD KEY `idx_produtos_nome` (`nome`),
  ADD KEY `idx_produtos_ativo_cat` (`ativo`,`categoria_id`),
  ADD KEY `idx_produtos_marca` (`marca`);

--
-- Índices de tabela `recuperacao_senhas`
--
ALTER TABLE `recuperacao_senhas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_recuperacao_token` (`token_hash`),
  ADD KEY `fk_recuperacao_usuario` (`usuario_id`);

--
-- Índices de tabela `substituicoes`
--
ALTER TABLE `substituicoes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_subst_item` (`item_id`),
  ADD KEY `fk_subst_original` (`produto_original_id`),
  ADD KEY `fk_subst_sugerido` (`produto_sugerido_id`),
  ADD KEY `fk_subst_sugerido_por` (`sugerido_por`),
  ADD KEY `fk_subst_respondido_por` (`respondido_por`),
  ADD KEY `idx_subst_status` (`pedido_id`,`status`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_usuarios_email` (`email`),
  ADD KEY `idx_usuarios_perfil` (`perfil`);

--
-- Índices de tabela `vendas_demo_mensais`
--
ALTER TABLE `vendas_demo_mensais`
  ADD PRIMARY KEY (`periodo`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `areas_entrega`
--
ALTER TABLE `areas_entrega`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `avaliacoes`
--
ALTER TABLE `avaliacoes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `enderecos`
--
ALTER TABLE `enderecos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `entregas`
--
ALTER TABLE `entregas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `favoritos`
--
ALTER TABLE `favoritos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `historico_pedidos`
--
ALTER TABLE `historico_pedidos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT de tabela `itens_pedido`
--
ALTER TABLE `itens_pedido`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `logs_alteracoes`
--
ALTER TABLE `logs_alteracoes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT de tabela `movimentacoes_estoque`
--
ALTER TABLE `movimentacoes_estoque`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT de tabela `ocorrencias`
--
ALTER TABLE `ocorrencias`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `pagamentos`
--
ALTER TABLE `pagamentos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de tabela `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `recuperacao_senhas`
--
ALTER TABLE `recuperacao_senhas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `substituicoes`
--
ALTER TABLE `substituicoes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `avaliacoes`
--
ALTER TABLE `avaliacoes`
  ADD CONSTRAINT `fk_aval_produto` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_aval_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `categorias`
--
ALTER TABLE `categorias`
  ADD CONSTRAINT `fk_categorias_pai` FOREIGN KEY (`pai_id`) REFERENCES `categorias` (`id`);

--
-- Restrições para tabelas `enderecos`
--
ALTER TABLE `enderecos`
  ADD CONSTRAINT `fk_enderecos_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `entregas`
--
ALTER TABLE `entregas`
  ADD CONSTRAINT `fk_entregas_entregador` FOREIGN KEY (`entregador_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_entregas_pedido` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `favoritos`
--
ALTER TABLE `favoritos`
  ADD CONSTRAINT `fk_fav_produto` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fav_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `historico_pedidos`
--
ALTER TABLE `historico_pedidos`
  ADD CONSTRAINT `fk_hist_pedido` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_hist_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Restrições para tabelas `itens_pedido`
--
ALTER TABLE `itens_pedido`
  ADD CONSTRAINT `fk_itens_origem` FOREIGN KEY (`item_origem_id`) REFERENCES `itens_pedido` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_itens_pedido` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_itens_produto` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`);

--
-- Restrições para tabelas `logs_alteracoes`
--
ALTER TABLE `logs_alteracoes`
  ADD CONSTRAINT `fk_logs_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Restrições para tabelas `movimentacoes_estoque`
--
ALTER TABLE `movimentacoes_estoque`
  ADD CONSTRAINT `fk_mov_pedido` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_mov_produto` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_mov_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Restrições para tabelas `ocorrencias`
--
ALTER TABLE `ocorrencias`
  ADD CONSTRAINT `fk_ocorr_entrega` FOREIGN KEY (`entrega_id`) REFERENCES `entregas` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_ocorr_pedido` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_ocorr_resolvido_por` FOREIGN KEY (`resolvido_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_ocorr_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Restrições para tabelas `pagamentos`
--
ALTER TABLE `pagamentos`
  ADD CONSTRAINT `fk_pagamentos_pedido` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `fk_pedidos_area` FOREIGN KEY (`area_entrega_id`) REFERENCES `areas_entrega` (`id`),
  ADD CONSTRAINT `fk_pedidos_cancelado_por` FOREIGN KEY (`cancelado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_pedidos_endereco` FOREIGN KEY (`endereco_id`) REFERENCES `enderecos` (`id`),
  ADD CONSTRAINT `fk_pedidos_separador` FOREIGN KEY (`separador_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_pedidos_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `produtos`
--
ALTER TABLE `produtos`
  ADD CONSTRAINT `fk_produtos_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`);

--
-- Restrições para tabelas `recuperacao_senhas`
--
ALTER TABLE `recuperacao_senhas`
  ADD CONSTRAINT `fk_recuperacao_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `substituicoes`
--
ALTER TABLE `substituicoes`
  ADD CONSTRAINT `fk_subst_item` FOREIGN KEY (`item_id`) REFERENCES `itens_pedido` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_subst_original` FOREIGN KEY (`produto_original_id`) REFERENCES `produtos` (`id`),
  ADD CONSTRAINT `fk_subst_pedido` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_subst_respondido_por` FOREIGN KEY (`respondido_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_subst_sugerido` FOREIGN KEY (`produto_sugerido_id`) REFERENCES `produtos` (`id`),
  ADD CONSTRAINT `fk_subst_sugerido_por` FOREIGN KEY (`sugerido_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
