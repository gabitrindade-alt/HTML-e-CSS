<?php
require __DIR__ . '/includes/bootstrap.php';

/* ---------- Leitura e validação dos filtros ---------- */
$q          = mb_substr(get('q'), 0, 80);
$categoria  = (int) get('categoria', 0);
$subs       = array_values(array_filter(array_map('intval', (array) ($_GET['sub'] ?? []))));
$marca      = mb_substr(get('marca'), 0, 80);
$precoMin   = get('preco_min') !== '' ? max(0, paraNumero(get('preco_min'))) : null;
$precoMax   = get('preco_max') !== '' ? max(0, paraNumero(get('preco_max'))) : null;
$emEstoque  = get('estoque') === '1';
$ofertas    = get('ofertas') === '1';
$temporada  = get('temporada') === '1';
$ordensValidas = [
    'relevancia' => 'p.destaque DESC, p.nome ASC',
    'menor'      => 'preco_final ASC',
    'maior'      => 'preco_final DESC',
    'nome'       => 'p.nome ASC',
    'novidades'  => 'p.criado_em DESC, p.id DESC',
];
$ordem = array_key_exists(get('ordem'), $ordensValidas) ? get('ordem') : 'relevancia';
$pagina = max(1, (int) get('pagina', 1));

$catAtual = null;
if ($categoria) {
    $st = db()->prepare('SELECT * FROM categorias WHERE id = ? AND ativo = 1');
    $st->execute([$categoria]);
    $catAtual = $st->fetch() ?: null;
    if (!$catAtual) {
        $categoria = 0;
    }
}
$catPai = null;
if ($catAtual && $catAtual['pai_id']) {
    $st = db()->prepare('SELECT * FROM categorias WHERE id = ?');
    $st->execute([$catAtual['pai_id']]);
    $catPai = $st->fetch();
}

/* Subcategorias exibidas no filtro: filhas da categoria atual, ou categorias principais */
if ($catAtual && !$catAtual['pai_id']) {
    $st = db()->prepare('SELECT c.*, (SELECT COUNT(*) FROM produtos p WHERE p.categoria_id = c.id AND p.ativo = 1) AS total
                         FROM categorias c WHERE c.pai_id = ? AND c.ativo = 1 ORDER BY c.ordem, c.nome');
    $st->execute([$categoria]);
    $opcoesCategoria = $st->fetchAll();
} else {
    $opcoesCategoria = [];
}
// Só aceita subcategorias que pertençam à categoria selecionada.
$subs = array_values(array_intersect($subs, array_map(fn($o) => (int) $o['id'], $opcoesCategoria)));

/* ---------- Monta a consulta (sempre com parâmetros) ---------- */
$where = ['p.ativo = 1', 'c.ativo = 1'];
$params = [];
if ($q !== '') {
    $where[] = '(p.nome LIKE ? OR p.marca LIKE ? OR p.descricao LIKE ? OR c.nome LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like, $like);
}
if ($subs) {
    $where[] = 'p.categoria_id IN (' . implode(',', array_fill(0, count($subs), '?')) . ')';
    array_push($params, ...$subs);
} elseif ($categoria) {
    $ids = idsCategoriaComFilhas($categoria);
    $where[] = 'p.categoria_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')';
    array_push($params, ...$ids);
}
if ($marca !== '') {
    $where[] = 'p.marca = ?';
    $params[] = $marca;
}
$precoFinal = precoAtualSql();
if ($temporada) {
    $slugs = array_keys(temporadaAtual()['descontos']);
    $where[] = 'p.slug IN (' . implode(',', array_fill(0, count($slugs), '?')) . ')';
    array_push($params, ...$slugs);
}
if ($precoMin !== null) {
    $where[] = "$precoFinal >= CAST(? AS DECIMAL(10,2))";
    $params[] = $precoMin;
}
if ($precoMax !== null && $precoMax > 0) {
    $where[] = "$precoFinal <= CAST(? AS DECIMAL(10,2))";
    $params[] = $precoMax;
}
if ($emEstoque) {
    $where[] = 'p.estoque > 0';
}
if ($ofertas) {
    $where[] = "$precoFinal < p.preco";
}
$sqlWhere = implode(' AND ', $where);

$st = db()->prepare("SELECT COUNT(*) FROM produtos p JOIN categorias c ON c.id = p.categoria_id WHERE $sqlWhere");
$st->execute($params);
$total = (int) $st->fetchColumn();

$offset = ($pagina - 1) * ITENS_POR_PAGINA;
$st = db()->prepare("SELECT p.*, $precoFinal AS preco_final FROM produtos p JOIN categorias c ON c.id = p.categoria_id
                     WHERE $sqlWhere ORDER BY {$ordensValidas[$ordem]} LIMIT " . (int) ITENS_POR_PAGINA . ' OFFSET ' . (int) $offset);
$st->execute($params);
$produtos = $st->fetchAll();

/* Marcas disponíveis no contexto atual */
$sqlMarca = 'SELECT DISTINCT p.marca FROM produtos p WHERE p.ativo = 1 AND p.marca IS NOT NULL';
$pm = [];
if ($categoria) {
    $ids = idsCategoriaComFilhas($categoria);
    $sqlMarca .= ' AND p.categoria_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')';
    $pm = $ids;
}
$st = db()->prepare($sqlMarca . ' ORDER BY p.marca');
$st->execute($pm);
$marcas = $st->fetchAll(PDO::FETCH_COLUMN);
$precoTeto = (float) db()->query('SELECT MAX(preco) FROM produtos WHERE ativo = 1')->fetchColumn();
$precoTeto = max(100, (int) ceil($precoTeto / 50) * 50);

$paramsAtuais = array_filter([
    'q' => $q, 'categoria' => $categoria ?: '', 'sub' => $subs, 'marca' => $marca,
    'preco_min' => $precoMin !== null ? $precoMin : '', 'preco_max' => $precoMax !== null ? $precoMax : '',
    'estoque' => $emEstoque ? '1' : '', 'ofertas' => $ofertas ? '1' : '', 'ordem' => $ordem !== 'relevancia' ? $ordem : '',
    'temporada' => $temporada ? '1' : '',
], fn($v) => $v !== '' && $v !== []);

$tituloLista = $temporada ? temporadaAtual()['titulo'] : ($ofertas ? 'Ofertas' : ($catAtual['nome'] ?? ($q !== '' ? 'Resultados para "' . $q . '"' : ($ordem === 'novidades' ? 'Novidades' : 'Todos os produtos'))));
$titulo = $tituloLista;
$ativo = $ofertas ? 'ofertas' : ($ordem === 'novidades' ? 'novidades' : 'categorias');
require APP_ROOT . '/includes/header.php';
?>
<div class="container pagina">
  <nav class="migalhas" aria-label="Você está em">
    <a href="<?= e(url('index.php')) ?>">Home</a> ›
    <a href="<?= e(url('catalogo.php')) ?>">Catálogo</a>
    <?php if ($catPai): ?> › <a href="<?= e(url('catalogo.php?categoria=' . (int) $catPai['id'])) ?>"><?= e($catPai['nome']) ?></a><?php endif; ?>
    <?php if ($catAtual): ?> › <span><?= e($catAtual['nome']) ?></span><?php endif; ?>
  </nav>

  <?php if (!$categoria && $q === '' && !$ofertas): ?>
    <div class="grade-categorias mb-2">
      <?php foreach (categoriasMenu() as $c): ?>
        <a class="categoria-card" href="<?= e(url('catalogo.php?categoria=' . (int) $c['id'])) ?>">
          <?= visualCategoria($c) ?><?= e($c['nome']) ?>
        </a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <div class="catalogo">
    <aside class="filtros cartao" id="filtros">
      <h3>Filtrar</h3>
      <form method="get" action="<?= e(url('catalogo.php')) ?>">
        <?php if ($q !== ''): ?><input type="hidden" name="q" value="<?= e($q) ?>"><?php endif; ?>
        <?php if ($temporada): ?><input type="hidden" name="temporada" value="1"><?php endif; ?>
        <?php if ($ordem !== 'relevancia'): ?><input type="hidden" name="ordem" value="<?= e($ordem) ?>"><?php endif; ?>
        <div class="filtro-bloco">
          <span class="rotulo">Categoria</span>
          <select class="input" name="categoria" data-auto-envio>
            <option value="">Todas</option>
            <?php foreach (categoriasMenu() as $c): ?>
              <option value="<?= (int) $c['id'] ?>" <?= ($categoria === (int) $c['id'] || ($catPai && (int) $catPai['id'] === (int) $c['id'])) ? 'selected' : '' ?>><?= e($c['nome']) ?></option>
            <?php endforeach; ?>
          </select>
          <?php foreach ($opcoesCategoria as $oc): ?>
            <label class="check"><input type="checkbox" name="sub[]" value="<?= (int) $oc['id'] ?>" <?= in_array((int) $oc['id'], $subs, true) ? 'checked' : '' ?>>
              <?= e($oc['nome']) ?> <small>(<?= (int) $oc['total'] ?>)</small></label>
          <?php endforeach; ?>
        </div>
        <div class="filtro-bloco">
          <span class="rotulo">Preço</span>
          <input type="range" min="0" max="<?= $precoTeto ?>" step="5" value="<?= e($precoMax ?: $precoTeto) ?>" data-faixa="#preco-max" aria-label="Preço máximo">
          <div class="faixa-preco">
            <input class="input" type="number" name="preco_min" min="0" step="0.01" placeholder="Mín." value="<?= e($precoMin ?? '') ?>" aria-label="Preço mínimo">
            <span>—</span>
            <input class="input" id="preco-max" type="number" name="preco_max" min="0" step="0.01" placeholder="Máx." value="<?= e($precoMax ?? '') ?>" aria-label="Preço máximo">
          </div>
        </div>
        <div class="filtro-bloco">
          <label class="rotulo" for="f-marca">Marca</label>
          <select class="input" id="f-marca" name="marca">
            <option value="">Todas</option>
            <?php foreach ($marcas as $m): ?><option <?= $m === $marca ? 'selected' : '' ?>><?= e($m) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="filtro-bloco">
          <span class="rotulo">Disponibilidade</span>
          <label class="check"><input type="checkbox" name="estoque" value="1" <?= $emEstoque ? 'checked' : '' ?>> Somente em estoque</label>
          <label class="check"><input type="checkbox" name="ofertas" value="1" <?= $ofertas ? 'checked' : '' ?>> Somente ofertas</label>
        </div>
        <button class="btn btn-primario btn-bloco" type="submit">Aplicar filtros</button>
        <a class="btn btn-link btn-bloco mt-1" href="<?= e(url('catalogo.php')) ?>">Limpar filtros</a>
      </form>
    </aside>

    <section>
      <div class="barra-catalogo">
        <div>
          <h1 class="mb-0"><?= e($tituloLista) ?></h1>
          <small><?= $total ?> produto(s) encontrado(s)</small>
        </div>
        <div class="flex">
          <button class="btn btn-neutro btn-sm btn-filtros-mobile" type="button" data-alternar="#filtros">Filtros</button>
          <form method="get" action="<?= e(url('catalogo.php')) ?>" class="flex">
            <?php foreach ($paramsAtuais as $k => $v): if ($k === 'ordem') continue;
                foreach ((array) $v as $vv): ?>
              <input type="hidden" name="<?= e($k) . (is_array($v) ? '[]' : '') ?>" value="<?= e($vv) ?>">
            <?php endforeach; endforeach; ?>
            <label class="sr-only" for="ordem">Ordenar</label>
            <select class="input" id="ordem" name="ordem" data-auto-envio>
              <option value="relevancia" <?= $ordem === 'relevancia' ? 'selected' : '' ?>>Ordenar por: Relevância</option>
              <option value="menor" <?= $ordem === 'menor' ? 'selected' : '' ?>>Menor preço</option>
              <option value="maior" <?= $ordem === 'maior' ? 'selected' : '' ?>>Maior preço</option>
              <option value="nome" <?= $ordem === 'nome' ? 'selected' : '' ?>>Nome (A–Z)</option>
              <option value="novidades" <?= $ordem === 'novidades' ? 'selected' : '' ?>>Novidades</option>
            </select>
            <noscript><button class="btn btn-neutro btn-sm">Ok</button></noscript>
          </form>
        </div>
      </div>

      <?php if ($marca !== '' || $precoMin !== null || $precoMax || $emEstoque || $subs): ?>
        <div class="filtros-ativos">
          <?php if ($marca !== ''): ?><span class="chip">Marca: <?= e($marca) ?></span><?php endif; ?>
          <?php if ($precoMin !== null || $precoMax): ?><span class="chip">Preço: <?= dinheiro($precoMin ?? 0) ?> – <?= $precoMax ? dinheiro($precoMax) : 'sem limite' ?></span><?php endif; ?>
          <?php if ($emEstoque): ?><span class="chip">Em estoque</span><?php endif; ?>
          <?php if ($subs): ?><span class="chip"><?= count($subs) ?> subcategoria(s)</span><?php endif; ?>
        </div>
      <?php endif; ?>

      <?php if ($produtos): ?>
        <div class="grade-produtos">
          <?php foreach ($produtos as $p) { echo cartaoProduto($p); } ?>
        </div>
        <?= paginacao($total, $pagina, ITENS_POR_PAGINA, $paramsAtuais) ?>
      <?php else: ?>
        <div class="cartao vazio">
          <?= icone('busca', 'ico-lg') ?>
          <h3>Nenhum produto encontrado</h3>
          <p>Tente outros termos ou remova alguns filtros.</p>
          <a class="btn btn-secundario" href="<?= e(url('catalogo.php')) ?>">Ver todos os produtos</a>
        </div>
      <?php endif; ?>
    </section>
  </div>
</div>
<?php require APP_ROOT . '/includes/footer.php'; ?>
