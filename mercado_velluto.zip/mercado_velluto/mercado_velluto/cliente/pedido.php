<?php
/** Acompanhamento do pedido pelo cliente (substituições, ajustes, cancelamento, histórico). */
require __DIR__ . '/../includes/bootstrap.php';
$u = exigirCliente();

$st = db()->prepare('SELECT * FROM pedidos WHERE id = ? AND usuario_id = ?'); // verificação de propriedade
$st->execute([(int) get('id'), $u['id']]);
$pedido = $st->fetch();
if (!$pedido) {
    http_response_code(404);
    flash('erro', 'Pedido não encontrado.');
    redirecionar('cliente/pedidos.php');
}
$id = (int) $pedido['id'];
$itens = itensDoPedido($id);

$st = db()->prepare("SELECT s.*, po.nome AS nome_original, po.imagem AS img_original, po.embalagem AS emb_original,
                     ps.nome AS nome_sugerido, ps.imagem AS img_sugerido, ps.embalagem AS emb_sugerido, ps.vendido_por
                     FROM substituicoes s JOIN produtos po ON po.id = s.produto_original_id JOIN produtos ps ON ps.id = s.produto_sugerido_id
                     WHERE s.pedido_id = ? ORDER BY s.criado_em DESC");
$st->execute([$id]);
$substituicoes = $st->fetchAll();
$pendentes = array_filter($substituicoes, fn($s) => $s['status'] === 'pendente');

$st = db()->prepare('SELECT * FROM historico_pedidos WHERE pedido_id = ? ORDER BY criado_em DESC, id DESC');
$st->execute([$id]);
$historico = $st->fetchAll();
$st = db()->prepare('SELECT * FROM pagamentos WHERE pedido_id = ? ORDER BY id');
$st->execute([$id]);
$pagamentos = $st->fetchAll();
$st = db()->prepare('SELECT e.*, u.nome AS entregador FROM entregas e LEFT JOIN usuarios u ON u.id = e.entregador_id WHERE e.pedido_id = ?');
$st->execute([$id]);
$entrega = $st->fetch();

$etapas = ['Pedido confirmado', 'Em separação', 'Pronto para entrega', 'Em entrega', 'Concluído'];
$icones = ['caixa', 'lista', 'check', 'caminhao', 'casa'];
$posicao = match ($pedido['status']) {
    'confirmado', 'aguardando_separacao' => 0,
    'em_separacao', 'aguardando_aprovacao' => 1,
    'aguardando_entrega' => 2,
    'saiu_para_entrega' => 3,
    'concluido' => 5,
    default => -1,
};
$podeCancelar = in_array($pedido['status'], STATUS_CANCELAVEL_CLIENTE, true);
$boletoPendente = $pedido['status'] === 'aguardando_pagamento';
$tolerancia = (float) config('tolerancia_ajuste_percent', 10);

$titulo = 'Pedido #' . $id;
require APP_ROOT . '/includes/header.php';
?>
<div class="container pagina">
  <nav class="migalhas"><a href="<?= e(url('cliente/pedidos.php')) ?>">Meus pedidos</a> › <span>Pedido #<?= $id ?></span></nav>

  <section class="cartao">
    <div class="flex entre flex-wrap">
      <div>
        <h1 class="mb-0">Pedido #<?= $id ?> <?= statusBadge($pedido['status']) ?></h1>
        <small>Realizado em <?= dataBr($pedido['criado_em']) ?> · Total: <b><?= dinheiro($pedido['total']) ?></b> · <?= e(METODOS_PAGAMENTO[$pedido['metodo_pagamento']]) ?></small>
      </div>
      <a class="btn btn-neutro btn-sm" href="<?= e(url('cliente/pedido.php?id=' . $id)) ?>"><?= icone('historico', 'ico-sm') ?> Atualizar</a>
    </div>

    <?php if ($pedido['status'] === 'cancelado'): ?>
      <div class="aviso aviso-vermelho mt-2"><b>Pedido cancelado</b> em <?= dataBr($pedido['cancelado_em']) ?>. Motivo: <?= e($pedido['motivo_cancelamento']) ?>.
        Valores pagos foram estornados (simulação) e os produtos voltaram ao estoque.</div>
    <?php elseif ($pedido['status'] === 'aguardando_pagamento'): ?>
      <div class="aviso mt-2 flex entre flex-wrap">
        <span><?= icone('boleto', 'ico-sm') ?> Aguardando a compensação do boleto (simulado) de <b><?= dinheiro($pedido['total']) ?></b>.</span>
        <form method="post" action="<?= e(url('acoes/pedido_cliente.php')) ?>"><?= csrfCampo() ?>
          <input type="hidden" name="pedido_id" value="<?= $id ?>"><input type="hidden" name="acao" value="pagar_boleto">
          <button class="btn btn-primario btn-sm" type="submit">Simular pagamento do boleto</button></form>
      </div>
    <?php else: ?>
      <div class="linha-tempo">
        <?php foreach ($etapas as $i => $nome):
            $cls = $i < $posicao ? 'feita' : ($i === $posicao ? 'atual' : ''); ?>
          <div class="etapa <?= $cls ?>"><span class="bola"><?= icone($icones[$i], 'ico-sm') ?></span><?= e($nome) ?></div>
        <?php endforeach; ?>
      </div>
      <?php if ($pedido['status'] !== 'concluido'): ?>
        <p class="texto-centro mb-0"><?= icone('caminhao', 'ico-sm') ?> Previsão de entrega: <b><?= e($pedido['prazo_entrega']) ?></b> (frete <?= $pedido['tipo_frete'] === 'expresso' ? 'expresso' : 'padrão' ?>)</p>
      <?php else: ?>
        <p class="texto-centro mb-0 aviso aviso-verde">Entregue em <?= dataBr($pedido['concluido_em']) ?><?= $entrega && $entrega['recebedor'] ? ' · Recebido por ' . e($entrega['recebedor']) : '' ?>.</p>
      <?php endif; ?>
    <?php endif; ?>
  </section>

  <?php foreach ($pendentes as $s):
      // O total atual já desconsidera o item indisponível; somamos o valor do substituto.
      $novoTotal = round((float) $pedido['total'] + (float) $s['preco_sugerido'] * (float) $s['quantidade'], 2); ?>
    <section class="cartao" style="border-color:var(--rosa-medio)">
      <h2>Substituição de produto</h2>
      <div class="aviso aviso-rosa"><?= icone('ampulheta', 'ico-sm') ?> <b>Aguardando sua aprovação.</b> Um item não está disponível. Veja a sugestão do nosso separador:</div>
      <?php if ($s['mensagem']): ?><p class="mt-1 pequeno">“<?= e($s['mensagem']) ?>”</p><?php endif; ?>
      <div class="substituicao">
        <div class="subst-produto"><img src="<?= e(imagemProduto(['imagem' => $s['img_original']])) ?>" alt="">
          <div><small class="muted">Produto solicitado</small><br><b><?= e($s['nome_original']) ?></b><br><small><?= e($s['emb_original']) ?> · <?= dinheiro($s['preco_original']) ?></small><br><span class="badge badge-erro">Indisponível</span></div></div>
        <?= icone('seta', 'ico-lg') ?>
        <div class="subst-produto"><img src="<?= e(imagemProduto(['imagem' => $s['img_sugerido']])) ?>" alt="">
          <div><small class="muted">Produto sugerido</small><br><b><?= e($s['nome_sugerido']) ?></b><br><small><?= e($s['emb_sugerido']) ?> · Qtd. <?= e(qtdFormatada($s['quantidade'], $s['vendido_por'])) ?></small><br>
            <b class="preco"><?= dinheiro($s['preco_sugerido']) ?></b></div></div>
      </div>
      <p class="mb-1">Diferença em relação ao item original: <b><?= ((float) $s['diferenca'] >= 0 ? '+ ' : '− ') . dinheiro(abs((float) $s['diferenca'])) ?></b> ·
        Novo total do pedido se aceitar: <b><?= dinheiro($novoTotal) ?></b>
        <?php if ((float) $s['diferenca'] > 0): ?><br><small>Ao aceitar, você aprova a cobrança complementar simulada da diferença.</small><?php elseif ((float) $s['diferenca'] < 0): ?><br><small>A diferença será estornada (simulação).</small><?php endif; ?></p>
      <div class="flex flex-wrap">
        <form method="post" action="<?= e(url('acoes/pedido_cliente.php')) ?>"><?= csrfCampo() ?>
          <input type="hidden" name="pedido_id" value="<?= $id ?>"><input type="hidden" name="substituicao_id" value="<?= (int) $s['id'] ?>"><input type="hidden" name="acao" value="aceitar_substituicao">
          <button class="btn btn-primario" type="submit"><?= icone('check', 'ico-sm') ?> Aceitar substituição</button></form>
        <form method="post" action="<?= e(url('acoes/pedido_cliente.php')) ?>" data-confirma="Recusar a substituição? O item será removido e o valor estornado."><?= csrfCampo() ?>
          <input type="hidden" name="pedido_id" value="<?= $id ?>"><input type="hidden" name="substituicao_id" value="<?= (int) $s['id'] ?>"><input type="hidden" name="acao" value="recusar_substituicao">
          <button class="btn btn-perigo" type="submit"><?= icone('x', 'ico-sm') ?> Recusar e remover</button></form>
      </div>
    </section>
  <?php endforeach; ?>

  <?php if ((int) $pedido['ajuste_pendente'] === 1 && $pedido['status'] === 'aguardando_aprovacao'): ?>
    <section class="cartao" style="border-color:var(--rosa-medio)">
      <h2>Aprovação de novo valor</h2>
      <div class="aviso aviso-rosa"><?= icone('balanca', 'ico-sm') ?> Após a pesagem real dos produtos, o total passou de
        <b><?= dinheiro($pedido['total_pago']) ?></b> para <b><?= dinheiro($pedido['total']) ?></b>
        (+<?= numeroBr(((float) $pedido['total'] / max(0.01, (float) $pedido['total_pago']) - 1) * 100, 1) ?>%, acima da tolerância de <?= numeroBr($tolerancia, 0) ?>%).</div>
      <p class="mt-1">Se aprovar, a diferença de <b><?= dinheiro((float) $pedido['total'] - (float) $pedido['total_pago']) ?></b> será cobrada (simulação) e o pedido segue para entrega.</p>
      <div class="flex flex-wrap">
        <form method="post" action="<?= e(url('acoes/pedido_cliente.php')) ?>"><?= csrfCampo() ?>
          <input type="hidden" name="pedido_id" value="<?= $id ?>"><input type="hidden" name="acao" value="aprovar_ajuste">
          <button class="btn btn-primario" type="submit"><?= icone('check', 'ico-sm') ?> Aprovar novo valor</button></form>
        <form method="post" action="<?= e(url('acoes/pedido_cliente.php')) ?>" data-confirma="Recusar o novo valor cancela o pedido. Confirmar?"><?= csrfCampo() ?>
          <input type="hidden" name="pedido_id" value="<?= $id ?>"><input type="hidden" name="acao" value="recusar_ajuste">
          <button class="btn btn-perigo" type="submit">Recusar e cancelar pedido</button></form>
      </div>
    </section>
  <?php endif; ?>

  <div class="layout-resumo mt-2">
    <div>
      <section class="cartao">
        <h2>Itens</h2>
        <div class="tabela-wrap"><table class="tabela">
          <thead><tr><th></th><th>Produto</th><th class="num">Pedido</th><th class="num">Separado</th><th>Situação</th><th class="num">Valor</th></tr></thead>
          <tbody>
          <?php foreach ($itens as $i): ?>
            <tr>
              <td><img class="mini" src="<?= e(imagemProduto($i)) ?>" alt=""></td>
              <td><b><?= e($i['nome_produto']) ?></b><br><small><?= dinheiro($i['preco_unitario']) ?><?= $i['vendido_por'] === 'peso' ? '/kg' : '' ?></small>
                <?php if ($i['item_origem_id']): ?><br><small class="muted">Substituto aprovado por você</small><?php endif; ?></td>
              <td class="num"><?= e(qtdFormatada($i['quantidade'], $i['vendido_por'])) ?></td>
              <td class="num"><?= $i['quantidade_separada'] !== null ? e(qtdFormatada($i['quantidade_separada'], $i['vendido_por'])) : '—' ?></td>
              <td><span class="badge st-<?= e($i['status']) ?>"><?= e(STATUS_ITEM[$i['status']]) ?></span></td>
              <td class="num"><?= in_array($i['status'], ['pendente', 'separado'], true) ? dinheiro($i['subtotal']) : '<s class="muted">' . dinheiro((float) $i['preco_unitario'] * (float) $i['quantidade']) . '</s>' ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table></div>
      </section>

      <section class="cartao">
        <h2>Histórico do pedido</h2>
        <ul class="historico-lista">
          <?php foreach ($historico as $h): ?>
            <li><time><?= dataBr($h['criado_em']) ?></time><?= e($h['descricao']) ?></li>
          <?php endforeach; ?>
        </ul>
      </section>
    </div>

    <aside>
      <section class="cartao">
        <h3>Valores</h3>
        <div class="linha-resumo"><span>Subtotal</span><span><?= dinheiro($pedido['subtotal']) ?></span></div>
        <div class="linha-resumo"><span>Frete</span><span><?= (float) $pedido['valor_frete'] > 0 ? dinheiro($pedido['valor_frete']) : 'Grátis' ?></span></div>
        <div class="linha-resumo total"><span>Total</span><span><?= dinheiro($pedido['total']) ?></span></div>
        <h4 class="mt-2">Pagamentos (simulados)</h4>
        <?php foreach ($pagamentos as $pg): ?>
          <div class="linha-resumo"><span><?= e(ucfirst($pg['tipo'])) ?> · <?= e(METODOS_PAGAMENTO[$pg['metodo']]) ?><?= $pg['cartao_final'] ? ' •••• ' . e($pg['cartao_final']) : '' ?><br>
            <span class="badge st-<?= e($pg['status']) ?>"><?= e(ucfirst($pg['status'])) ?></span></span>
            <span><?= $pg['tipo'] === 'estorno' ? '− ' : '' ?><?= dinheiro($pg['valor']) ?></span></div>
        <?php endforeach; ?>
      </section>
      <section class="cartao">
        <h3>Entrega</h3>
        <p class="pequeno mb-1"><?= icone('local', 'ico-sm') ?> <?= e($pedido['endereco_entrega']) ?> · CEP <?= e(cepFormatado($pedido['cep_entrega'])) ?></p>
        <?php if ($entrega): ?>
          <p class="pequeno mb-0">Situação: <span class="badge st-<?= e($entrega['status']) ?>"><?= e(STATUS_ENTREGA[$entrega['status']]) ?></span>
            <?php if ($entrega['entregador']): ?><br>Entregador: <?= e(explode(' ', $entrega['entregador'])[0]) ?><?php endif; ?></p>
        <?php endif; ?>
      </section>
      <?php if ($podeCancelar): ?>
      <section class="cartao">
        <h3>Cancelar pedido</h3>
        <form method="post" action="<?= e(url('acoes/pedido_cliente.php')) ?>" data-confirma="Tem certeza que deseja cancelar o pedido #<?= $id ?>?">
          <?= csrfCampo() ?><input type="hidden" name="pedido_id" value="<?= $id ?>"><input type="hidden" name="acao" value="cancelar">
          <div class="campo"><label for="motivo">Motivo *</label>
            <select id="motivo" name="motivo" required>
              <option value="">Selecione…</option>
              <option>Desisti da compra</option><option>Comprei produtos errados</option><option>Prazo de entrega não atende</option>
              <option>Não concordo com as substituições</option><option>Outro motivo</option>
            </select></div>
          <div class="campo"><label for="detalhe">Detalhes (opcional)</label><input id="detalhe" name="detalhe" maxlength="200"></div>
          <button class="btn btn-perigo btn-bloco" type="submit">Cancelar pedido</button>
        </form>
      </section>
      <?php elseif (!in_array($pedido['status'], ['concluido', 'cancelado'], true)): ?>
        <p class="pequeno">Este pedido já está em separação ou entrega e não pode ser cancelado pelo site. Fale com o atendimento: <?= e(config('telefone_contato')) ?>.</p>
      <?php endif; ?>
    </aside>
  </div>
</div>
<?php require APP_ROOT . '/includes/footer.php'; ?>
