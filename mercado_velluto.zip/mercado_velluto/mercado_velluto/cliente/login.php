<?php
require __DIR__ . '/../includes/bootstrap.php';

$voltar = destinoSeguro(get('voltar', post('voltar')), 'index.php');
if (clienteLogado()) {
    redirecionar($voltar);
}
$erro = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = mb_strtolower(post('email'));
    $senha = (string) ($_POST['senha'] ?? '');
    if (loginBloqueado()) {
        $erro = 'Muitas tentativas. Aguarde 1 minuto e tente novamente.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || $senha === '') {
        $erro = 'Informe e-mail e senha válidos.';
    } else {
        $u = autenticar($email, $senha);
        if (!$u) {
            registrarFalhaLogin();
            $erro = 'E-mail ou senha incorretos.';
        } elseif ($u['perfil'] !== 'cliente') {
            $erro = 'Esta conta utiliza o acesso de funcionários.';
        } else {
            limparFalhasLogin();
            iniciarSessaoUsuario($u);
            flash('sucesso', 'Bem-vinda(o) de volta, ' . explode(' ', $u['nome'])[0] . '!');
            redirecionar($voltar);
        }
    }
}

$aba = 'login';
$titulo = 'Entrar';
require APP_ROOT . '/includes/header.php';
require APP_ROOT . '/includes/auth_inicio.php';
?>
<h1>Acesse sua conta</h1>
<?php if ($erro): ?><div class="aviso aviso-vermelho mb-2"><?= e($erro) ?></div><?php endif; ?>
<form method="post" action="<?= e(url('cliente/login.php')) ?>" novalidate>
  <?= csrfCampo() ?>
  <input type="hidden" name="voltar" value="<?= e($voltar) ?>">
  <div class="campo"><label for="email">E-mail</label>
    <input id="email" type="email" name="email" value="<?= e($email) ?>" required autocomplete="email" placeholder="voce@velluto.com"></div>
  <div class="campo"><label for="senha">Senha</label>
    <div class="senha-wrap"><input id="senha" type="password" name="senha" required autocomplete="current-password">
      <button type="button" data-ver-senha aria-label="Mostrar senha"><?= icone('olho', 'ico-sm') ?></button></div></div>
  <div class="flex entre mb-2">
    <span></span>
    <a href="<?= e(url('cliente/recuperar.php')) ?>" class="pequeno">Esqueci minha senha</a>
  </div>
  <button class="btn btn-primario btn-bloco" type="submit">Entrar</button>
</form>
<p class="texto-centro pequeno mt-2">Não tem uma conta? <a href="<?= e(url('cliente/cadastro.php?voltar=' . urlencode($voltar))) ?>">Cadastre-se</a></p>
<?php require APP_ROOT . '/includes/auth_fim.php'; require APP_ROOT . '/includes/footer.php'; ?>
