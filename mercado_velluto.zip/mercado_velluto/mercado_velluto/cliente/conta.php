<?php
require __DIR__ . '/../includes/bootstrap.php';
$u = exigirCliente();

$st = db()->prepare('SELECT nome, email, telefone, senha_hash FROM usuarios WHERE id = ?');
$st->execute([$u['id']]);
$dados = $st->fetch();
$erros = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = post('acao');
    if ($acao === 'dados') {
        $nome = mb_substr(post('nome'), 0, 120);
        $tel = mb_substr(post('telefone'), 0, 20);
        if (mb_strlen($nome) < 3) $erros[] = 'Informe seu nome completo.';
        if (!$erros) {
            db()->prepare('UPDATE usuarios SET nome = ?, telefone = ?, atualizado_em = ? WHERE id = ?')
                ->execute([$nome, $tel ?: null, agora(), $u['id']]);
            $_SESSION['usuario']['nome'] = $nome;
            flash('sucesso', 'Dados atualizados.');
            redirecionar('cliente/conta.php');
        }
    } elseif ($acao === 'senha') {
        $atual = (string) ($_POST['senha_atual'] ?? '');
        $nova = (string) ($_POST['senha_nova'] ?? '');
        if (!password_verify($atual, (string) $dados['senha_hash'])) $erros[] = 'Senha atual incorreta.';
        elseif (strlen($nova) < 8 || !preg_match('/[A-Za-z]/', $nova) || !preg_match('/\d/', $nova)) $erros[] = 'A nova senha deve ter 8+ caracteres, com letras e números.';
        elseif ($nova !== ($_POST['senha_conf'] ?? '')) $erros[] = 'A confirmação não confere.';
        if (!$erros) {
            db()->prepare('UPDATE usuarios SET senha_hash = ?, atualizado_em = ? WHERE id = ?')->execute([password_hash($nova, PASSWORD_DEFAULT), agora(), $u['id']]);
            session_regenerate_id(true);
            flash('sucesso', 'Senha alterada com sucesso.');
            redirecionar('cliente/conta.php');
        }
    }
}

$st = db()->prepare("SELECT COUNT(CASE WHEN status NOT IN ('concluido', 'cancelado') THEN 1 END) AS abertos,
    COUNT(CASE WHEN status = 'concluido' THEN 1 END) AS concluidos FROM pedidos WHERE usuario_id = ?");
$st->execute([$u['id']]);
$resumo = $st->fetch();
$st = db()->prepare('SELECT id, total, status, criado_em FROM pedidos WHERE usuario_id = ? ORDER BY criado_em DESC, id DESC LIMIT 1');
$st->execute([$u['id']]);
$ultimo = $st->fetch();

$titulo = 'Meus dados';
require APP_ROOT . '/includes/header.php';
?>
<div class="container pagina">
  <h1>Meus dados</h1>
  <?php if ($erros): ?><div class="aviso aviso-vermelho mb-2"><?= e(implode(' ', $erros)) ?></div><?php endif; ?>
  <div class="grid-2">
    <form class="cartao" method="post">
      <?= csrfCampo() ?><input type="hidden" name="acao" value="dados">
      <h2>Dados pessoais</h2>
      <div class="campo"><label for="nome">Nome</label><input id="nome" name="nome" value="<?= e($dados['nome']) ?>" required></div>
      <div class="campo"><label>E-mail</label><input value="<?= e($dados['email']) ?>" disabled></div>
      <div class="campo"><label for="telefone">Celular (opcional)</label><input id="telefone" type="tel" name="telefone" value="<?= e($dados['telefone']) ?>" data-mascara="telefone" autocomplete="tel"></div>
      <button class="btn btn-primario" type="submit">Salvar dados</button>
    </form>
    <form class="cartao" method="post">
      <?= csrfCampo() ?><input type="hidden" name="acao" value="senha">
      <h2>Alterar senha</h2>
      <div class="campo"><label for="senha_atual">Senha atual</label><input id="senha_atual" type="password" name="senha_atual" required autocomplete="current-password"></div>
      <div class="campo"><label for="senha_nova">Nova senha</label><input id="senha_nova" type="password" name="senha_nova" required minlength="8" autocomplete="new-password"></div>
      <div class="campo"><label for="senha_conf">Confirmar nova senha</label><input id="senha_conf" type="password" name="senha_conf" required autocomplete="new-password"></div>
      <button class="btn btn-primario" type="submit">Alterar senha</button>
    </form>
  </div>
  <section class="cartao mt-2">
    <div class="cartao-titulo"><h2>Resumo de compras</h2><a href="<?= e(url('cliente/pedidos.php')) ?>">Meus pedidos</a></div>
    <div class="linha-resumo"><span>Em andamento</span><b><?= (int) $resumo['abertos'] ?></b></div>
    <div class="linha-resumo"><span>Concluídos</span><b><?= (int) $resumo['concluidos'] ?></b></div>
    <?php if ($ultimo): ?>
      <div class="linha-resumo">
        <a href="<?= e(url('cliente/pedido.php?id=' . (int) $ultimo['id'])) ?>">Último pedido #<?= (int) $ultimo['id'] ?></a>
        <span><?= statusBadge($ultimo['status']) ?> · <?= dinheiro($ultimo['total']) ?> · <?= e(dataBr($ultimo['criado_em'])) ?></span>
      </div>
    <?php else: ?>
      <p class="muted mb-0">Seus pedidos aparecerão aqui após a primeira compra.</p>
    <?php endif; ?>
  </section>
  <div class="flex flex-wrap mt-2">
    <a class="btn btn-secundario" href="<?= e(url('cliente/enderecos.php')) ?>"><?= icone('local', 'ico-sm') ?> Gerenciar endereços</a>
  </div>
</div>
<?php require APP_ROOT . '/includes/footer.php'; ?>
