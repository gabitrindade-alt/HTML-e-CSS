<?php
/** Etapa 2 — Endereço de entrega, verificação da área atendida e cálculo do frete. */
require __DIR__ . '/../includes/bootstrap.php';
$u = exigirCliente();

$c = carrinhoDetalhado();
if (!$c['itens']) {
    flash('info', 'Seu carrinho está vazio.');
    redirecionar('cliente/carrinho.php');
}
if ($c['problemas']) {
    flash('erro', 'Há itens sem estoque suficiente no carrinho. Ajuste antes de continuar.');
    redirecionar('cliente/carrinho.php');
}
$minimo = (float) config('valor_minimo_pedido', 0);
if ($c['subtotal'] < $minimo) {
    flash('aviso', 'O valor mínimo do pedido é ' . dinheiro($minimo) . '.');
    redirecionar('cliente/carrinho.php');
}

$st = db()->prepare('SELECT * FROM enderecos WHERE usuario_id = ? AND ativo = 1 ORDER BY principal DESC, id');
$st->execute([$u['id']]);
$enderecos = $st->fetchAll();
if (!$enderecos) {
    flash('info', 'Cadastre um endereço de entrega para continuar.');
    redirecionar('cliente/enderecos.php?novo=1&voltar=checkout');
}
$porId = array_column($enderecos, null, 'id');

$selId = (int) (post('endereco_id') ?: get('endereco') ?: ($_SESSION['checkout']['endereco_id'] ?? 0));
if (!isset($porId[$selId])) {
    $selId = (int) $enderecos[0]['id'];
}
$sel = $porId[$selId];
$area = areaPorCep($sel['cep']);
$fretes = $area ? opcoesFrete($area, $c['subtotal']) : [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo = post('tipo_frete');
    if (!$area) {
        flash('erro', 'O endereço selecionado está fora da área de entrega. Escolha ou cadastre outro endereço.');
    } elseif (!isset($fretes[$tipo])) {
        flash('erro', 'Selecione uma opção de frete válida.');
    } else {
        $_SESSION['checkout'] = ['endereco_id' => $selId, 'tipo_frete' => $tipo];
        redirecionar('cliente/pagamento.php');
    }
    redirecionar('cliente/checkout.php?endereco=' . $selId);
}

$tipoSel = $_SESSION['checkout']['tipo_frete'] ?? 'padrao';
if (!isset($fretes[$tipoSel])) {
    $tipoSel = 'padrao';
}
$titulo = 'Endereço e frete';
require APP_ROOT . '/includes/header.php';
?>
<div class="container pagina">
  <?= passosCheckout(2) ?>
  <form method="post" action="<?= e(url('cliente/checkout.php')) ?>" class="layout-resumo">
    <?= csrfCampo() ?>
    <div>
      <section class="cartao">
        <div class="cartao-titulo"><h2>Endereço de entrega</h2>
          <a class="btn btn-secundario btn-sm" href="<?= e(url('cliente/enderecos.php?novo=1&voltar=checkout')) ?>"><?= icone('mais', 'ico-sm') ?> Adicionar novo endereço</a></div>
        <?php foreach ($enderecos as $end): $atende = areaPorCep($end['cep']); ?>
          <label class="opcao">
            <input type="radio" name="endereco_id" value="<?= (int) $end['id'] ?>" <?= (int) $end['id'] === $selId ? 'checked' : '' ?>
                   onchange="window.location='?endereco=' + this.value">
            <span class="opcao-corpo">
              <b><?= e($end['apelido']) ?></b> — <?= e($end['logradouro']) ?>, <?= e($end['numero']) ?><?= $end['complemento'] ? ', ' . e($end['complemento']) : '' ?><br>
              <small><?= e($end['bairro']) ?> — <?= e($end['cidade']) ?>/<?= e($end['uf']) ?> · CEP <?= e(cepFormatado($end['cep'])) ?></small>
            </span>
            <?= $atende ? '<span class="badge badge-ok">Atendido</span>' : '<span class="badge badge-erro">Fora da área</span>' ?>
          </label>
        <?php endforeach; ?>
        <a class="pequeno" href="<?= e(url('cliente/enderecos.php?voltar=checkout')) ?>">Gerenciar endereços</a>
      </section>

      <section class="cartao">
        <h2>Frete</h2>
        <?php if (!$area): ?>
          <div class="aviso aviso-vermelho"><?= icone('alerta', 'ico-sm') ?>
            Ainda não entregamos no CEP <b><?= e(cepFormatado($sel['cep'])) ?></b>. Não é possível finalizar o pedido para este endereço.
            <a href="<?= e(url('ajuda.php#area')) ?>">Ver regiões atendidas</a>.</div>
        <?php else: ?>
          <p class="pequeno">Região: <b><?= e($area['nome']) ?></b></p>
          <?php foreach ($fretes as $chave => $f): ?>
            <label class="opcao">
              <input type="radio" name="tipo_frete" value="<?= e($chave) ?>" <?= $chave === $tipoSel ? 'checked' : '' ?>>
              <span class="opcao-corpo"><b><?= e($f['rotulo']) ?></b> — <?= e($f['prazo']) ?><?php if ($f['obs']): ?><br><small><?= e($f['obs']) ?></small><?php endif; ?></span>
              <span class="valor"><?= $f['valor'] > 0 ? dinheiro($f['valor']) : 'Grátis' ?></span>
            </label>
          <?php endforeach; ?>
        <?php endif; ?>
      </section>
    </div>

    <aside class="cartao resumo">
      <h3>Resumo</h3>
      <div class="linha-resumo"><span>Subtotal (<?= count($c['itens']) ?> itens)</span><span><?= dinheiro($c['subtotal']) ?></span></div>
      <div class="linha-resumo"><span>Frete</span><span><?= $area ? dinheiro($fretes[$tipoSel]['valor']) : '—' ?></span></div>
      <div class="linha-resumo total"><span>Total</span><span><?= dinheiro($c['subtotal'] + ($area ? $fretes[$tipoSel]['valor'] : 0)) ?></span></div>
      <button class="btn btn-primario btn-bloco mt-2" type="submit" <?= $area ? '' : 'disabled' ?>>Continuar <?= icone('seta', 'ico-sm') ?></button>
      <p class="texto-centro mt-1 mb-0"><a class="pequeno" href="<?= e(url('cliente/carrinho.php')) ?>">← Voltar ao carrinho</a></p>
    </aside>
  </form>
</div>
<?php require APP_ROOT . '/includes/footer.php'; ?>
