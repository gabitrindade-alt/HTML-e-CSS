<?php
/** Etapa 3 — Revisão do pedido e pagamento simulado. */
require __DIR__ . '/../includes/bootstrap.php';
$u = exigirCliente();

$c = carrinhoDetalhado();
$ck = $_SESSION['checkout'] ?? null;
if (!$c['itens']) {
    redirecionar('cliente/carrinho.php');
}
if (!$ck) {
    redirecionar('cliente/checkout.php');
}
$st = db()->prepare('SELECT * FROM enderecos WHERE id = ? AND usuario_id = ? AND ativo = 1');
$st->execute([$ck['endereco_id'], $u['id']]);
$end = $st->fetch();
$area = $end ? areaPorCep($end['cep']) : null;
if (!$end || !$area) {
    flash('erro', 'Selecione um endereço dentro da área de entrega.');
    redirecionar('cliente/checkout.php');
}
$fretes = opcoesFrete($area, $c['subtotal']);
$frete = $fretes[$ck['tipo_frete']] ?? $fretes['padrao'];
$total = round($c['subtotal'] + $frete['valor'], 2);
$temPeso = (bool) array_filter($c['itens'], fn($i) => $i['produto']['vendido_por'] === 'peso');

$titulo = 'Revisão e pagamento';
require APP_ROOT . '/includes/header.php';
?>
<div class="container pagina">
  <?= passosCheckout(3) ?>
  <form method="post" action="<?= e(url('acoes/finalizar_pedido.php')) ?>" class="layout-resumo" autocomplete="off">
    <?= csrfCampo() ?>
    <div>
      <section class="cartao">
        <div class="cartao-titulo"><h2>Resumo do pedido</h2><a class="pequeno" href="<?= e(url('cliente/carrinho.php')) ?>">Editar carrinho</a></div>
        <?php if ($c['problemas']): ?>
          <div class="aviso aviso-vermelho mb-2">Alguns itens ficaram sem estoque enquanto você navegava. <a href="<?= e(url('cliente/carrinho.php')) ?>">Revise o carrinho</a>.</div>
        <?php endif; ?>
        <div class="tabela-wrap"><table class="tabela">
          <thead><tr><th></th><th>Produto</th><th class="num">Qtd.</th><th class="num">Valor</th></tr></thead>
          <tbody>
          <?php foreach ($c['itens'] as $it): $p = $it['produto']; ?>
            <tr>
              <td><img class="mini" src="<?= e(imagemProduto($p)) ?>" alt=""></td>
              <td><b><?= e($p['nome']) ?></b><br><small><?= e($p['embalagem']) ?></small>
                <?php if (!$it['disponivel']): ?><div class="erro-campo"><?= e($it['aviso']) ?></div><?php endif; ?></td>
              <td class="num">×<?= e(qtdFormatada($it['qtd'], $p['vendido_por'])) ?></td>
              <td class="num"><?= dinheiro($it['subtotal']) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table></div>
        <?php if ($temPeso): ?>
          <p class="aviso aviso-rosa mt-1"><?= icone('balanca', 'ico-sm') ?> Itens vendidos por peso têm valor estimado. Cobraremos pelo peso real; se o total subir mais de <?= e(config('tolerancia_ajuste_percent', '10')) ?>%, pediremos sua aprovação.</p>
        <?php endif; ?>
      </section>

      <section class="cartao">
        <div class="cartao-titulo"><h2>Entrega</h2><a class="pequeno" href="<?= e(url('cliente/checkout.php')) ?>">Alterar</a></div>
        <p class="mb-0"><?= icone('local', 'ico-sm') ?> <b><?= e($end['apelido']) ?></b> — <?= e($end['logradouro']) ?>, <?= e($end['numero']) ?><?= $end['complemento'] ? ', ' . e($end['complemento']) : '' ?>,
          <?= e($end['bairro']) ?> — <?= e($end['cidade']) ?>/<?= e($end['uf']) ?> · CEP <?= e(cepFormatado($end['cep'])) ?><br>
          <?= icone('caminhao', 'ico-sm') ?> Frete <?= e($frete['rotulo']) ?> (<?= e($frete['prazo']) ?>): <b><?= $frete['valor'] > 0 ? dinheiro($frete['valor']) : 'Grátis' ?></b></p>
      </section>

      <section class="cartao">
        <h2>Pagamento</h2>
        <p class="aviso mb-2"><?= icone('cadeado', 'ico-sm') ?> Ambiente de demonstração: <b>nenhuma cobrança real é feita</b>. Não use dados reais de cartão.</p>

        <label class="opcao"><input type="radio" name="metodo" value="pix" checked><span class="opcao-corpo"><b><?= icone('pix', 'ico-sm') ?> PIX</b><br><small>Aprovação imediata (simulada)</small></span></label>
        <div class="pagamento-detalhe" data-metodo="pix">
          <div class="flex flex-wrap"><div class="qr-simulado" aria-label="QR Code simulado"></div>
            <p class="pequeno" style="max-width:300px">Ao finalizar, o pagamento PIX será <b>aprovado automaticamente</b> nesta simulação.</p></div>
        </div>

        <label class="opcao"><input type="radio" name="metodo" value="cartao"><span class="opcao-corpo"><b><?= icone('cartao', 'ico-sm') ?> Cartão de crédito</b><br><small>Use o cartão de teste 4111 1111 1111 1111</small></span></label>
        <div class="pagamento-detalhe" data-metodo="cartao">
          <div class="grid-form">
            <div class="campo col-12"><label for="cartao_numero">Número do cartão</label><input id="cartao_numero" name="cartao_numero" data-mascara="cartao" inputmode="numeric" placeholder="4111 1111 1111 1111" autocomplete="off"></div>
            <div class="campo col-12"><label for="cartao_nome">Nome impresso</label><input id="cartao_nome" name="cartao_nome" placeholder="MARIA OLIVEIRA" autocomplete="off"></div>
            <div class="campo col-4"><label for="cartao_validade">Validade</label><input id="cartao_validade" name="cartao_validade" data-mascara="validade" placeholder="MM/AA" autocomplete="off"></div>
            <div class="campo col-4"><label for="cartao_cvv">CVV</label><input id="cartao_cvv" name="cartao_cvv" inputmode="numeric" maxlength="4" placeholder="123" autocomplete="off"></div>
            <div class="campo col-4"><label for="parcelas">Parcelas</label><select id="parcelas" name="parcelas">
              <?php for ($n = 1; $n <= 6; $n++): ?><option value="<?= $n ?>"><?= $n ?>x de <?= dinheiro($total / $n) ?></option><?php endfor; ?></select></div>
          </div>
          <p class="pequeno mb-0">Somente os 4 últimos dígitos são armazenados.</p>
        </div>

        <label class="opcao"><input type="radio" name="metodo" value="boleto"><span class="opcao-corpo"><b><?= icone('boleto', 'ico-sm') ?> Boleto bancário</b><br><small>O pedido fica aguardando pagamento até a compensação (simulada)</small></span></label>
        <div class="pagamento-detalhe" data-metodo="boleto">
          <p class="pequeno mb-0">Após finalizar, use o botão <b>“Simular pagamento do boleto”</b> na tela do pedido. Os produtos ficam reservados até lá.</p>
        </div>

        <div class="campo mt-2"><label for="observacoes">Observações para a entrega (opcional)</label>
          <textarea id="observacoes" name="observacoes" maxlength="500" placeholder="Ex.: interfone 42, deixar na portaria"></textarea></div>
      </section>
    </div>

    <aside class="cartao resumo">
      <h3>Total</h3>
      <div class="linha-resumo"><span>Subtotal</span><span><?= dinheiro($c['subtotal']) ?></span></div>
      <div class="linha-resumo"><span>Frete</span><span><?= $frete['valor'] > 0 ? dinheiro($frete['valor']) : 'Grátis' ?></span></div>
      <div class="linha-resumo total"><span>Total</span><span><?= dinheiro($total) ?></span></div>
      <input type="hidden" name="total_exibido" value="<?= e(number_format($total, 2, '.', '')) ?>">
      <button class="btn btn-primario btn-bloco mt-2" type="submit" <?= $c['problemas'] ? 'disabled' : '' ?>>Finalizar pedido <?= icone('seta', 'ico-sm') ?></button>
      <p class="texto-centro mt-1 mb-0"><a class="pequeno" href="<?= e(url('cliente/checkout.php')) ?>">← Voltar</a></p>
    </aside>
  </form>
</div>
<?php require APP_ROOT . '/includes/footer.php'; ?>
