<?php
require __DIR__ . '/../includes/bootstrap.php';

encerrarSessao();
iniciarSessao();
flash('info', 'Você saiu da sua conta com segurança.');
redirecionar('index.php');
