<?php
require __DIR__ . '/../includes/bootstrap.php';
$u = exigirCliente();

$st = db()->prepare('SELECT p.* FROM favoritos f JOIN produtos p ON p.id = f.produto_id WHERE f.usuario_id = ? AND p.ativo = 1 ORDER BY f.criado_em DESC');
$st->execute([$u['id']]);
$produtos = $st->fetchAll();

$titulo = 'Favoritos';
require APP_ROOT . '/includes/header.php';
?>
<div class="container pagina">
  <h1>Meus favoritos</h1>
  <?php if ($produtos): ?>
    <div class="grade-produtos"><?php foreach ($produtos as $p) { echo cartaoProduto($p); } ?></div>
  <?php else: ?>
    <div class="cartao vazio"><?= icone('coracao', 'ico-lg') ?><h3>Nenhum favorito ainda</h3>
      <p>Toque no coração dos produtos para guardá-los aqui.</p>
      <a class="btn btn-primario" href="<?= e(url('catalogo.php')) ?>">Explorar produtos</a></div>
  <?php endif; ?>
</div>
<?php require APP_ROOT . '/includes/footer.php'; ?>
