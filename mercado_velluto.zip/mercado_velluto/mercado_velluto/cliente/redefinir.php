<?php
require __DIR__ . '/../includes/bootstrap.php';

$token = (string) get('token', post('token'));
$registro = null;
if (preg_match('/^[a-f0-9]{64}$/', $token)) {
    $st = db()->prepare('SELECT * FROM recuperacao_senhas WHERE token_hash = ? AND usado_em IS NULL AND expira_em > ?');
    $st->execute([hash('sha256', $token), agora()]);
    $registro = $st->fetch() ?: null;
}
$erro = '';

if ($registro && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $senha = (string) ($_POST['senha'] ?? '');
    if (strlen($senha) < 8 || !preg_match('/[A-Za-z]/', $senha) || !preg_match('/\d/', $senha)) {
        $erro = 'A senha deve ter ao menos 8 caracteres, com letras e números.';
    } elseif ($senha !== ($_POST['senha2'] ?? '')) {
        $erro = 'As senhas não conferem.';
    } else {
        transacao(function () use ($registro, $senha) {
            db()->prepare('UPDATE usuarios SET senha_hash = ?, atualizado_em = ? WHERE id = ?')
                ->execute([password_hash($senha, PASSWORD_DEFAULT), agora(), $registro['usuario_id']]);
            db()->prepare('UPDATE recuperacao_senhas SET usado_em = ? WHERE usuario_id = ? AND usado_em IS NULL')
                ->execute([agora(), $registro['usuario_id']]);
        });
        flash('sucesso', 'Senha alterada! Entre com a nova senha.');
        redirecionar('cliente/login.php');
    }
}

$aba = 'recuperar';
$titulo = 'Nova senha';
require APP_ROOT . '/includes/header.php';
require APP_ROOT . '/includes/auth_inicio.php';
?>
<h1>Criar nova senha</h1>
<?php if (!$registro): ?>
  <div class="aviso aviso-vermelho">Link inválido, expirado ou já utilizado.</div>
  <p class="mt-2"><a class="btn btn-secundario" href="<?= e(url('cliente/recuperar.php')) ?>">Solicitar novo link</a></p>
<?php else: ?>
  <?php if ($erro): ?><div class="aviso aviso-vermelho mb-2"><?= e($erro) ?></div><?php endif; ?>
  <form method="post" action="<?= e(url('cliente/redefinir.php')) ?>">
    <?= csrfCampo() ?><input type="hidden" name="token" value="<?= e($token) ?>">
    <div class="campo"><label for="senha">Nova senha</label><input id="senha" type="password" name="senha" required minlength="8" autocomplete="new-password"></div>
    <div class="campo"><label for="senha2">Confirmar nova senha</label><input id="senha2" type="password" name="senha2" required autocomplete="new-password"></div>
    <button class="btn btn-primario btn-bloco" type="submit">Salvar nova senha</button>
  </form>
<?php endif; ?>
<?php require APP_ROOT . '/includes/auth_fim.php'; require APP_ROOT . '/includes/footer.php'; ?>
