<?php
require __DIR__ . '/../includes/bootstrap.php';
$u = exigirCliente();
$voltar = get('voltar', post('voltar')) === 'checkout' ? 'checkout' : '';

function meuEndereco(int $id, int $uid): ?array
{
    $st = db()->prepare('SELECT * FROM enderecos WHERE id = ? AND usuario_id = ? AND ativo = 1');
    $st->execute([$id, $uid]);
    return $st->fetch() ?: null;
}

$campos = ['apelido', 'destinatario', 'cep', 'logradouro', 'numero', 'complemento', 'bairro', 'cidade', 'uf', 'referencia'];
$form = array_fill_keys($campos, '');
$form['destinatario'] = $u['nome'];
$erros = [];
$editando = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = post('acao');
    $id = (int) post('id');

    if ($acao === 'excluir' || $acao === 'principal') {
        $end = meuEndereco($id, $u['id']);
        if (!$end) {
            flash('erro', 'Endereço não encontrado.');
            redirecionar('cliente/enderecos.php');
        }
        if ($acao === 'excluir') {
            // exclusão lógica: pedidos antigos continuam referenciando o endereço
            db()->prepare('UPDATE enderecos SET ativo = 0, principal = 0 WHERE id = ? AND usuario_id = ?')->execute([$id, $u['id']]);
            flash('info', 'Endereço removido.');
        } else {
            transacao(function () use ($id, $u) {
                db()->prepare('UPDATE enderecos SET principal = 0 WHERE usuario_id = ?')->execute([$u['id']]);
                db()->prepare('UPDATE enderecos SET principal = 1 WHERE id = ? AND usuario_id = ?')->execute([$id, $u['id']]);
            });
            flash('sucesso', 'Endereço principal atualizado.');
        }
        redirecionar('cliente/enderecos.php' . ($voltar ? '?voltar=checkout' : ''));
    }

    if ($acao === 'salvar') {
        $limites = ['apelido' => 40, 'destinatario' => 120, 'cep' => 9, 'logradouro' => 160, 'numero' => 10, 'complemento' => 80,
            'bairro' => 80, 'cidade' => 80, 'uf' => 2, 'referencia' => 160];
        foreach ($campos as $c) {
            $form[$c] = mb_substr(post($c), 0, $limites[$c]);
        }
        $form['cep'] = apenasDigitos($form['cep']);
        $form['uf'] = strtoupper($form['uf']);
        if ($form['apelido'] === '') {
            $form['apelido'] = 'Casa';
        }
        if (mb_strlen($form['destinatario']) < 3) $erros['destinatario'] = 'Informe quem vai receber.';
        if (strlen($form['cep']) !== 8) $erros['cep'] = 'CEP deve ter 8 dígitos.';
        if (mb_strlen($form['logradouro']) < 3) $erros['logradouro'] = 'Informe a rua/avenida.';
        if ($form['numero'] === '' || mb_strlen($form['numero']) > 10) $erros['numero'] = 'Informe o número (ou "s/n").';
        if (mb_strlen($form['bairro']) < 2) $erros['bairro'] = 'Informe o bairro.';
        if (mb_strlen($form['cidade']) < 2) $erros['cidade'] = 'Informe a cidade.';
        if (!preg_match('/^[A-Z]{2}$/', $form['uf'])) $erros['uf'] = 'UF inválida.';

        if ($id) {
            $editando = meuEndereco($id, $u['id']);
            if (!$editando) {
                flash('erro', 'Endereço não encontrado.');
                redirecionar('cliente/enderecos.php');
            }
        }
        if (!$erros) {
            $valores = [$form['apelido'], $form['destinatario'], $form['cep'], $form['logradouro'], $form['numero'], $form['complemento'] ?: null,
                $form['bairro'], $form['cidade'], $form['uf'], $form['referencia'] ?: null];
            if ($editando) {
                $valores[] = $id;
                $valores[] = $u['id'];
                db()->prepare('UPDATE enderecos SET apelido=?, destinatario=?, cep=?, logradouro=?, numero=?, complemento=?, bairro=?, cidade=?, uf=?, referencia=?
                               WHERE id = ? AND usuario_id = ?')->execute($valores);
                $novoId = $id;
            } else {
                $st = db()->prepare('SELECT COUNT(*) FROM enderecos WHERE usuario_id = ? AND ativo = 1');
                $st->execute([$u['id']]);
                $principal = (int) $st->fetchColumn() === 0 ? 1 : 0;
                array_unshift($valores, $u['id']);
                $valores[] = $principal;
                $valores[] = agora();
                db()->prepare('INSERT INTO enderecos (usuario_id, apelido, destinatario, cep, logradouro, numero, complemento, bairro, cidade, uf, referencia, principal, criado_em)
                               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute($valores);
                $novoId = (int) db()->lastInsertId();
            }
            $area = areaPorCep($form['cep']);
            if ($area) {
                flash('sucesso', 'Endereço salvo. Atendemos este CEP (' . $area['nome'] . ').');
            } else {
                flash('aviso', 'Endereço salvo, mas o CEP ' . cepFormatado($form['cep']) . ' está fora da nossa área de entrega. Pedidos para ele não poderão ser finalizados.');
            }
            if ($voltar === 'checkout') {
                redirecionar('cliente/checkout.php?endereco=' . $novoId);
            }
            redirecionar('cliente/enderecos.php');
        }
    }
}

if (!$editando && get('editar')) {
    $editando = meuEndereco((int) get('editar'), $u['id']);
    if ($editando) {
        foreach ($campos as $c) {
            $form[$c] = (string) $editando[$c];
        }
    }
}
$mostrarForm = $editando || get('novo') || $erros;

$st = db()->prepare('SELECT * FROM enderecos WHERE usuario_id = ? AND ativo = 1 ORDER BY principal DESC, id');
$st->execute([$u['id']]);
$enderecos = $st->fetchAll();
if (!$enderecos) {
    $mostrarForm = true;
}

$titulo = 'Meus endereços';
require APP_ROOT . '/includes/header.php';
$err = fn($c) => isset($erros[$c]) ? '<div class="erro-campo">' . e($erros[$c]) . '</div>' : '';
?>
<div class="container pagina">
  <div class="flex entre flex-wrap mb-2">
    <h1 class="mb-0">Meus endereços</h1>
    <?php if (!$mostrarForm): ?><a class="btn btn-primario" href="?novo=1<?= $voltar ? '&voltar=checkout' : '' ?>"><?= icone('mais', 'ico-sm') ?> Adicionar novo endereço</a><?php endif; ?>
  </div>

  <?php if ($mostrarForm): ?>
  <form class="cartao mb-2" method="post" action="<?= e(url('cliente/enderecos.php')) ?>">
    <?= csrfCampo() ?>
    <input type="hidden" name="acao" value="salvar">
    <input type="hidden" name="id" value="<?= (int) ($editando['id'] ?? 0) ?>">
    <input type="hidden" name="voltar" value="<?= e($voltar) ?>">
    <h2><?= $editando ? 'Editar endereço' : 'Novo endereço' ?></h2>
    <div class="grid-form">
      <div class="campo col-3"><label for="cep">CEP *</label><input id="cep" name="cep" value="<?= e(cepFormatado($form['cep'])) ?>" data-mascara="cep" data-busca-cep required inputmode="numeric"><?= $err('cep') ?></div>
      <div class="campo col-3"><label for="apelido">Identificação</label><input id="apelido" name="apelido" value="<?= e($form['apelido']) ?>" placeholder="Casa, Trabalho…" maxlength="40"></div>
      <div class="campo col-6"><label for="destinatario">Destinatário *</label><input id="destinatario" name="destinatario" value="<?= e($form['destinatario']) ?>" required><?= $err('destinatario') ?></div>
      <div class="campo col-8"><label for="logradouro">Rua / Avenida *</label><input id="logradouro" name="logradouro" value="<?= e($form['logradouro']) ?>" required><?= $err('logradouro') ?></div>
      <div class="campo col-4"><label for="numero">Número *</label><input id="numero" name="numero" value="<?= e($form['numero']) ?>" required maxlength="10"><?= $err('numero') ?></div>
      <div class="campo col-6"><label for="complemento">Complemento</label><input id="complemento" name="complemento" value="<?= e($form['complemento']) ?>" maxlength="80"></div>
      <div class="campo col-6"><label for="bairro">Bairro *</label><input id="bairro" name="bairro" value="<?= e($form['bairro']) ?>" required><?= $err('bairro') ?></div>
      <div class="campo col-8"><label for="cidade">Cidade *</label><input id="cidade" name="cidade" value="<?= e($form['cidade']) ?>" required><?= $err('cidade') ?></div>
      <div class="campo col-4"><label for="uf">UF *</label><input id="uf" name="uf" value="<?= e($form['uf']) ?>" required maxlength="2" style="text-transform:uppercase"><?= $err('uf') ?></div>
      <div class="campo col-12"><label for="referencia">Ponto de referência</label><input id="referencia" name="referencia" value="<?= e($form['referencia']) ?>" maxlength="160"></div>
    </div>
    <div class="flex">
      <button class="btn btn-primario" type="submit">Salvar endereço</button>
      <?php if ($enderecos): ?><a class="btn btn-neutro" href="<?= e(url('cliente/enderecos.php' . ($voltar ? '?voltar=checkout' : ''))) ?>">Cancelar</a><?php endif; ?>
    </div>
  </form>
  <?php endif; ?>

  <div class="grid-2">
    <?php foreach ($enderecos as $end): $area = areaPorCep($end['cep']); ?>
      <div class="cartao">
        <div class="flex entre">
          <b><?= icone('local', 'ico-sm') ?> <?= e($end['apelido']) ?></b>
          <span class="flex">
            <?php if ($end['principal']): ?><span class="badge">Principal</span><?php endif; ?>
            <?= $area ? '<span class="badge badge-ok">Área atendida</span>' : '<span class="badge badge-erro">Fora da área</span>' ?>
          </span>
        </div>
        <p class="mt-1 mb-1"><?= e($end['logradouro']) ?>, <?= e($end['numero']) ?><?= $end['complemento'] ? ' — ' . e($end['complemento']) : '' ?><br>
          <?= e($end['bairro']) ?> — <?= e($end['cidade']) ?>/<?= e($end['uf']) ?><br>CEP <?= e(cepFormatado($end['cep'])) ?> · <?= e($end['destinatario']) ?></p>
        <div class="acoes-linha">
          <a class="btn btn-neutro btn-sm" href="?editar=<?= (int) $end['id'] ?><?= $voltar ? '&voltar=checkout' : '' ?>"><?= icone('editar', 'ico-sm') ?> Editar</a>
          <?php if (!$end['principal']): ?>
            <form method="post"><?= csrfCampo() ?><input type="hidden" name="acao" value="principal"><input type="hidden" name="id" value="<?= (int) $end['id'] ?>"><input type="hidden" name="voltar" value="<?= e($voltar) ?>">
              <button class="btn btn-neutro btn-sm" type="submit">Tornar principal</button></form>
          <?php endif; ?>
          <form method="post" data-confirma="Remover este endereço?"><?= csrfCampo() ?><input type="hidden" name="acao" value="excluir"><input type="hidden" name="id" value="<?= (int) $end['id'] ?>"><input type="hidden" name="voltar" value="<?= e($voltar) ?>">
            <button class="btn btn-perigo btn-sm" type="submit"><?= icone('lixeira', 'ico-sm') ?> Remover</button></form>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <?php if ($voltar === 'checkout' && $enderecos): ?>
    <p class="mt-2"><a class="btn btn-secundario" href="<?= e(url('cliente/checkout.php')) ?>">← Voltar para endereço e frete</a></p>
  <?php endif; ?>
</div>
<?php require APP_ROOT . '/includes/footer.php'; ?>
