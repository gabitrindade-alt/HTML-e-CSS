<?php
require __DIR__ . '/../includes/bootstrap.php';

$c = carrinhoDetalhado();
$minimo = (float) config('valor_minimo_pedido', 0);
$titulo = 'Meu carrinho';
require APP_ROOT . '/includes/header.php';
?>
<div class="container pagina">
  <h1>Meu carrinho <small class="muted">(<?= count($c['itens']) ?> <?= count($c['itens']) === 1 ? 'item' : 'itens' ?>)</small></h1>

  <?php if (!$c['itens']): ?>
    <div class="cartao vazio">
      <?= icone('carrinho', 'ico-lg') ?>
      <h3>Seu carrinho está vazio</h3>
      <p>Explore nossas categorias e encontre tudo para sua casa.</p>
      <a class="btn btn-primario" href="<?= e(url('catalogo.php')) ?>">Começar a comprar</a>
    </div>
  <?php else: ?>
  <div class="layout-resumo">
    <div class="cartao">
      <?php foreach ($c['itens'] as $it): $p = $it['produto']; $passo = passoQtd($p); ?>
        <div class="item-carrinho <?= $it['disponivel'] ? '' : 'indisponivel' ?>">
          <a href="<?= e(url('produto.php?id=' . (int) $p['id'])) ?>"><img src="<?= e(imagemProduto($p)) ?>" alt=""></a>
          <div>
            <a class="nome" href="<?= e(url('produto.php?id=' . (int) $p['id'])) ?>" style="color:inherit"><?= e($p['nome']) ?></a><br>
            <small><?= e($p['embalagem']) ?> · <?= dinheiro($it['preco']) ?><?= unidadePreco($p) ?></small>
            <?php if ($p['vendido_por'] === 'peso'): ?><br><small class="muted">Valor estimado — cobrado pelo peso real</small><?php endif; ?>
            <?php if ($it['aviso']): ?><div class="erro-campo"><?= icone('alerta', 'ico-sm') ?> <?= e($it['aviso']) ?></div><?php endif; ?>
          </div>
          <form method="post" action="<?= e(url('acoes/carrinho.php')) ?>" class="flex">
            <?= csrfCampo() ?>
            <input type="hidden" name="acao" value="atualizar">
            <input type="hidden" name="produto_id" value="<?= (int) $p['id'] ?>">
            <div class="qtd">
              <button type="button" data-qtd="-1" aria-label="Diminuir"><?= icone('menos', 'ico-sm') ?></button>
              <input type="number" name="qtd" value="<?= e($p['vendido_por'] === 'peso' ? number_format($it['qtd'], 2, '.', '') : (int) $it['qtd']) ?>" min="0" max="<?= e((float) $p['estoque']) ?>" step="<?= e($passo['passo']) ?>" data-auto-envio aria-label="Quantidade">
              <button type="button" data-qtd="1" aria-label="Aumentar"><?= icone('mais', 'ico-sm') ?></button>
            </div>
            <noscript><button class="btn btn-neutro btn-sm" type="submit">Atualizar</button></noscript>
          </form>
          <div class="flex">
            <b><?= dinheiro($it['subtotal']) ?></b>
            <form method="post" action="<?= e(url('acoes/carrinho.php')) ?>">
              <?= csrfCampo() ?><input type="hidden" name="acao" value="remover"><input type="hidden" name="produto_id" value="<?= (int) $p['id'] ?>">
              <button class="btn-icone" type="submit" aria-label="Remover <?= e($p['nome']) ?>" title="Remover"><?= icone('lixeira') ?></button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
      <form method="post" action="<?= e(url('acoes/carrinho.php')) ?>" class="mt-2" data-confirma="Esvaziar o carrinho?">
        <?= csrfCampo() ?><input type="hidden" name="acao" value="limpar">
        <button class="btn btn-link" type="submit">Esvaziar carrinho</button>
      </form>
    </div>

    <aside class="cartao resumo">
      <h3>Resumo</h3>
      <div class="linha-resumo"><span>Subtotal</span><span><?= dinheiro($c['subtotal']) ?></span></div>
      <div class="linha-resumo"><span>Frete</span><span class="muted">calculado no próximo passo</span></div>
      <div class="linha-resumo total"><span>Total</span><span><?= dinheiro($c['subtotal']) ?></span></div>
      <?php if ($c['problemas']): ?>
        <p class="aviso aviso-vermelho mt-1">Há <?= $c['problemas'] ?> item(ns) sem estoque suficiente. Ajuste ou remova para continuar.</p>
      <?php elseif ($c['subtotal'] < $minimo): ?>
        <p class="aviso mt-1">Pedido mínimo: <?= dinheiro($minimo) ?>.</p>
      <?php endif; ?>
      <a class="btn btn-primario btn-bloco mt-2 <?= ($c['problemas'] || $c['subtotal'] < $minimo) ? 'desabilitado' : '' ?>" href="<?= e(url('cliente/checkout.php')) ?>">Finalizar compra <?= icone('seta', 'ico-sm') ?></a>
      <p class="texto-centro mt-1 mb-0"><a class="pequeno" href="<?= e(url('catalogo.php')) ?>">Continuar comprando</a></p>
      <?php if (!clienteLogado()): ?><p class="pequeno texto-centro mt-1 mb-0">Você precisará entrar ou se cadastrar para finalizar.</p><?php endif; ?>
    </aside>
  </div>
  <?php endif; ?>
</div>
<?php require APP_ROOT . '/includes/footer.php'; ?>
