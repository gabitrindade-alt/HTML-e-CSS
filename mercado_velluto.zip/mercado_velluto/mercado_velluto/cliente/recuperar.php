<?php
require __DIR__ . '/../includes/bootstrap.php';

$enviado = false;
$linkDemo = null;
$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = mb_strtolower(post('email'));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'Informe um e-mail válido.';
    } else {
        // Recuperação por e-mail apenas para clientes; senhas de funcionários são redefinidas pelo administrador.
        $st = db()->prepare("SELECT id FROM usuarios WHERE email = ? AND perfil = 'cliente' AND ativo = 1");
        $st->execute([$email]);
        $uid = $st->fetchColumn();
        if ($uid) {
            $token = bin2hex(random_bytes(32));
            db()->prepare('UPDATE recuperacao_senhas SET usado_em = ? WHERE usuario_id = ? AND usado_em IS NULL')->execute([agora(), $uid]);
            db()->prepare('INSERT INTO recuperacao_senhas (usuario_id, token_hash, expira_em, ip, criado_em) VALUES (?, ?, ?, ?, ?)')
                ->execute([$uid, hash('sha256', $token), date('Y-m-d H:i:s', time() + 1800), $_SERVER['REMOTE_ADDR'] ?? null, agora()]);
            // Sem servidor de e-mail no XAMPP: o link é exibido apenas para acessos feitos do próprio computador.
            if (ehRequisicaoLocal()) {
                $linkDemo = url('cliente/redefinir.php?token=' . $token);
            }
        }
        $enviado = true; // mesma resposta para e-mails existentes ou não
    }
}

$aba = 'recuperar';
$titulo = 'Recuperar senha';
require APP_ROOT . '/includes/header.php';
require APP_ROOT . '/includes/auth_inicio.php';
?>
<h1>Recuperar senha</h1>
<?php if ($enviado): ?>
  <div class="aviso aviso-verde mb-2">Se o e-mail estiver cadastrado, você receberá um link para criar uma nova senha. O link vale por 30 minutos.</div>
  <?php if ($linkDemo): ?>
    <div class="cartao mb-2" style="background:var(--rosa-suave)">
      <b>Link de redefinição para o ambiente local</b>
      <p class="mt-1 mb-1">Olá! Recebemos um pedido para redefinir sua senha no Velluto.</p>
      <a class="btn btn-primario btn-sm" href="<?= e($linkDemo) ?>">Criar nova senha</a>
    </div>
  <?php endif; ?>
<?php else: ?>
  <p class="muted">Informe o e-mail da sua conta para receber o link de redefinição.</p>
  <?php if ($erro): ?><div class="aviso aviso-vermelho mb-2"><?= e($erro) ?></div><?php endif; ?>
  <form method="post" action="<?= e(url('cliente/recuperar.php')) ?>">
    <?= csrfCampo() ?>
    <div class="campo"><label for="email">E-mail</label><input id="email" type="email" name="email" required autocomplete="email"></div>
    <button class="btn btn-primario btn-bloco" type="submit">Enviar link</button>
  </form>
<?php endif; ?>
<p class="texto-centro pequeno mt-2"><a href="<?= e(url('cliente/login.php')) ?>">← Voltar ao login</a></p>
<?php require APP_ROOT . '/includes/auth_fim.php'; require APP_ROOT . '/includes/footer.php'; ?>
