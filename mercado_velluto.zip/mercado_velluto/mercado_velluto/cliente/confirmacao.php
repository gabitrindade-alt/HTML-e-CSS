<?php
require __DIR__ . '/../includes/bootstrap.php';
$u = exigirCliente();

$st = db()->prepare('SELECT * FROM pedidos WHERE id = ? AND usuario_id = ?');
$st->execute([(int) get('id'), $u['id']]);
$pedido = $st->fetch();
if (!$pedido) {
    flash('erro', 'Pedido não encontrado.');
    redirecionar('cliente/pedidos.php');
}
$titulo = 'Pedido confirmado';
require APP_ROOT . '/includes/header.php';
?>
<div class="container-estreito pagina">
  <?= passosCheckout(4) ?>
  <div class="cartao texto-centro">
    <div class="vazio" style="padding:20px">
      <span class="categoria-icone" style="background:var(--verde-claro);color:var(--verde);margin:0 auto 12px"><?= icone('check', 'ico-lg') ?></span>
      <h1>Obrigado pela compra!</h1>
      <p>Seu pedido <b>#<?= (int) $pedido['id'] ?></b> foi registrado em <?= dataBr($pedido['criado_em']) ?>.</p>
      <p><?= statusBadge($pedido['status']) ?></p>
      <?php if ($pedido['status'] === 'aguardando_pagamento'): ?>
        <p class="aviso">Pagamento por boleto: os produtos ficam reservados até a compensação. Simule o pagamento na tela do pedido.</p>
      <?php else: ?>
        <p class="muted">Pagamento aprovado (simulação). Agora nossa equipe vai separar seus produtos com cuidado.</p>
      <?php endif; ?>
      <p class="negrito">Total: <?= dinheiro($pedido['total']) ?> · Previsão: <?= e($pedido['prazo_entrega']) ?></p>
      <div class="flex" style="justify-content:center">
        <a class="btn btn-primario" href="<?= e(url('cliente/pedido.php?id=' . (int) $pedido['id'])) ?>">Acompanhar pedido</a>
        <a class="btn btn-secundario" href="<?= e(url('catalogo.php')) ?>">Continuar comprando</a>
      </div>
    </div>
  </div>
</div>
<?php require APP_ROOT . '/includes/footer.php'; ?>
