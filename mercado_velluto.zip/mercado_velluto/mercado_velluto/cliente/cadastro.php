<?php
require __DIR__ . '/../includes/bootstrap.php';

$voltar = destinoSeguro(get('voltar', post('voltar')), 'index.php');
if (clienteLogado()) {
    redirecionar($voltar);
}
$d = ['nome' => '', 'email' => '', 'telefone' => ''];
$erros = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($d as $k => $_) {
        $d[$k] = post($k);
    }
    $d['email'] = mb_strtolower($d['email']);
    $d['telefone'] = mb_substr($d['telefone'], 0, 20);
    $senha = (string) ($_POST['senha'] ?? '');
    $senha2 = (string) ($_POST['senha2'] ?? '');

    if (mb_strlen($d['nome']) < 3 || mb_strlen($d['nome']) > 120) {
        $erros['nome'] = 'Informe seu nome completo.';
    }
    if (!filter_var($d['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($d['email']) > 160) {
        $erros['email'] = 'E-mail inválido.';
    }
    $tel = apenasDigitos($d['telefone']);
    if ($tel !== '' && (strlen($tel) < 10 || strlen($tel) > 11)) {
        $erros['telefone'] = 'Telefone inválido.';
    }
    if (strlen($senha) < 8 || !preg_match('/[A-Za-z]/', $senha) || !preg_match('/\d/', $senha)) {
        $erros['senha'] = 'A senha deve ter ao menos 8 caracteres, com letras e números.';
    } elseif ($senha !== $senha2) {
        $erros['senha2'] = 'As senhas não conferem.';
    }
    if (empty($_POST['termos'])) {
        $erros['termos'] = 'É preciso aceitar os termos de uso.';
    }
    if (!$erros) {
        $st = db()->prepare('SELECT COUNT(*) FROM usuarios WHERE email = ?');
        $st->execute([$d['email']]);
        if ($st->fetchColumn()) {
            $erros['email'] = 'Já existe uma conta com este e-mail.';
        }
    }
    if (!$erros) {
        $st = db()->prepare("INSERT INTO usuarios (nome, email, senha_hash, perfil, telefone, criado_em) VALUES (?, ?, ?, 'cliente', ?, ?)");
        $st->execute([$d['nome'], $d['email'], password_hash($senha, PASSWORD_DEFAULT), $d['telefone'] ?: null, agora()]);
        $id = (int) db()->lastInsertId();
        $u = db()->prepare('SELECT * FROM usuarios WHERE id = ?');
        $u->execute([$id]);
        iniciarSessaoUsuario($u->fetch());
        flash('sucesso', 'Conta criada com sucesso! Cadastre um endereço para receber suas compras.');
        redirecionar($voltar === 'index.php' ? 'cliente/enderecos.php?novo=1' : $voltar);
    }
}

function erroCampo(array $erros, string $c): string
{
    return isset($erros[$c]) ? '<div class="erro-campo">' . e($erros[$c]) . '</div>' : '';
}

$aba = 'cadastro';
$titulo = 'Criar conta';
require APP_ROOT . '/includes/header.php';
require APP_ROOT . '/includes/auth_inicio.php';
?>
<h1>Crie sua conta</h1>
<?php if ($erros): ?><div class="aviso aviso-vermelho mb-2">Revise os campos destacados.</div><?php endif; ?>
<form method="post" action="<?= e(url('cliente/cadastro.php')) ?>" novalidate>
  <?= csrfCampo() ?>
  <input type="hidden" name="voltar" value="<?= e($voltar) ?>">
  <div class="campo <?= isset($erros['nome']) ? 'campo-erro' : '' ?>"><label for="nome">Nome completo *</label>
    <input id="nome" name="nome" value="<?= e($d['nome']) ?>" required maxlength="120" autocomplete="name"><?= erroCampo($erros, 'nome') ?></div>
  <div class="campo <?= isset($erros['email']) ? 'campo-erro' : '' ?>"><label for="email">E-mail *</label>
    <input id="email" type="email" name="email" value="<?= e($d['email']) ?>" required maxlength="160" autocomplete="email"><?= erroCampo($erros, 'email') ?></div>
  <div class="campo <?= isset($erros['telefone']) ? 'campo-erro' : '' ?>"><label for="telefone">Celular (opcional)</label>
    <input id="telefone" type="tel" name="telefone" value="<?= e($d['telefone']) ?>" data-mascara="telefone" autocomplete="tel"><?= erroCampo($erros, 'telefone') ?></div>
  <div class="grid-2">
    <div class="campo <?= isset($erros['senha']) ? 'campo-erro' : '' ?>"><label for="senha">Senha *</label>
      <input id="senha" type="password" name="senha" required minlength="8" autocomplete="new-password"><?= erroCampo($erros, 'senha') ?></div>
    <div class="campo <?= isset($erros['senha2']) ? 'campo-erro' : '' ?>"><label for="senha2">Confirmar senha *</label>
      <input id="senha2" type="password" name="senha2" required autocomplete="new-password"><?= erroCampo($erros, 'senha2') ?></div>
  </div>
  <label class="check"><input type="checkbox" name="termos" value="1" <?= !empty($_POST['termos']) ? 'checked' : '' ?>> Li e aceito os termos de uso.</label>
  <?= erroCampo($erros, 'termos') ?>
  <button class="btn btn-primario btn-bloco mt-2" type="submit">Criar conta</button>
</form>
<p class="texto-centro pequeno mt-2">Já tem conta? <a href="<?= e(url('cliente/login.php')) ?>">Entrar</a></p>
<?php require APP_ROOT . '/includes/auth_fim.php'; require APP_ROOT . '/includes/footer.php'; ?>
