<?php
require __DIR__ . '/../includes/bootstrap.php';
$u = exigirCliente();

// Cada cliente vê somente os próprios pedidos.
$st = db()->prepare('SELECT p.*, (SELECT COUNT(*) FROM itens_pedido i WHERE i.pedido_id = p.id AND i.status <> \'substituido\') AS qtd_itens
                     FROM pedidos p WHERE p.usuario_id = ? ORDER BY p.criado_em DESC, p.id DESC');
$st->execute([$u['id']]);
$pedidos = $st->fetchAll();

$titulo = 'Meus pedidos';
require APP_ROOT . '/includes/header.php';
?>
<div class="container pagina">
  <h1>Meus pedidos</h1>
  <?php if (!$pedidos): ?>
    <div class="cartao vazio"><?= icone('caixa', 'ico-lg') ?><h3>Você ainda não fez pedidos</h3>
      <a class="btn btn-primario" href="<?= e(url('catalogo.php')) ?>">Começar a comprar</a></div>
  <?php else: ?>
    <?php foreach ($pedidos as $p): ?>
      <a class="cartao flex entre flex-wrap" href="<?= e(url('cliente/pedido.php?id=' . (int) $p['id'])) ?>" style="color:inherit;text-decoration:none;margin-top:12px">
        <div>
          <h3 class="mb-0">Pedido #<?= (int) $p['id'] ?></h3>
          <small>Realizado em <?= dataBr($p['criado_em']) ?> · <?= (int) $p['qtd_itens'] ?> itens · <?= e(METODOS_PAGAMENTO[$p['metodo_pagamento']]) ?></small>
        </div>
        <div class="flex flex-wrap">
          <?php if ($p['status'] === 'aguardando_aprovacao'): ?><span class="badge st-aguardando_aprovacao">Ação necessária</span><?php endif; ?>
          <?= statusBadge($p['status']) ?>
          <b><?= dinheiro($p['total']) ?></b>
          <span class="btn btn-secundario btn-sm">Ver detalhes</span>
        </div>
      </a>
    <?php endforeach; ?>
  <?php endif; ?>
</div>
<?php require APP_ROOT . '/includes/footer.php'; ?>
