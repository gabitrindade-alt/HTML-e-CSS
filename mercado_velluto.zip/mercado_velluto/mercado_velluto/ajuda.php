<?php
require __DIR__ . '/includes/bootstrap.php';

$cepConsulta = apenasDigitos(get('cep'));
$resultado = null;
if ($cepConsulta !== '') {
    $resultado = strlen($cepConsulta) === 8 ? (areaPorCep($cepConsulta) ?: false) : 'invalido';
}
$areas = db()->query('SELECT * FROM areas_entrega WHERE ativo = 1 ORDER BY nome')->fetchAll();

$titulo = 'Central de ajuda';
$ativo = 'ajuda';
require APP_ROOT . '/includes/header.php';
?>
<div class="container pagina">
  <h1>Central de ajuda</h1>
  <div class="grid-2">
    <section class="cartao" id="area">
      <h2><?= icone('local') ?> Entregamos no seu endereço?</h2>
      <form method="get" class="flex flex-wrap" action="<?= e(url('ajuda.php')) ?>#area">
        <input class="input" style="max-width:200px" name="cep" placeholder="00000-000" data-mascara="cep" value="<?= e(cepFormatado($cepConsulta)) ?>" required aria-label="CEP">
        <button class="btn btn-primario" type="submit">Consultar</button>
      </form>
      <?php if ($resultado === 'invalido'): ?>
        <p class="aviso aviso-vermelho mt-2">Informe um CEP com 8 dígitos.</p>
      <?php elseif ($resultado === false): ?>
        <p class="aviso aviso-vermelho mt-2">Ainda não atendemos o CEP <?= e(cepFormatado($cepConsulta)) ?>. Pedidos para este endereço não podem ser finalizados.</p>
      <?php elseif (is_array($resultado)): ?>
        <div class="aviso aviso-verde mt-2">
          <b>Atendemos sua região: <?= e($resultado['nome']) ?> (<?= e($resultado['cidade']) ?>/<?= e($resultado['uf']) ?>)</b><br>
          Padrão: <?= dinheiro($resultado['valor_frete']) ?> (<?= e($resultado['prazo_padrao']) ?>)
          <?php if ($resultado['valor_expresso']): ?> · Expresso: <?= dinheiro($resultado['valor_expresso']) ?> (<?= e($resultado['prazo_expresso']) ?>)<?php endif; ?>
          <?php if ($resultado['frete_gratis_acima']): ?><br>Frete padrão grátis acima de <?= dinheiro($resultado['frete_gratis_acima']) ?>.<?php endif; ?>
        </div>
      <?php endif; ?>
      <h3 class="mt-3">Regiões atendidas</h3>
      <div class="tabela-wrap"><table class="tabela">
        <thead><tr><th>Região</th><th>CEPs</th><th class="num">Frete</th></tr></thead>
        <tbody><?php foreach ($areas as $a): ?>
          <tr><td><?= e($a['nome']) ?> <small>(<?= e($a['cidade']) ?>/<?= e($a['uf']) ?>)</small></td>
              <td><?= e(cepFormatado($a['cep_inicio'])) ?> a <?= e(cepFormatado($a['cep_fim'])) ?></td>
              <td class="num"><?= dinheiro($a['valor_frete']) ?></td></tr>
        <?php endforeach; ?></tbody>
      </table></div>
    </section>

    <section class="cartao">
      <h2>Perguntas frequentes</h2>
      <h3>Como funciona a cobrança de produtos por peso?</h3>
      <p>Frutas, legumes, carnes e pães vendidos por kg são cobrados pelo <b>peso real</b> conferido pelo separador. Se o total subir mais de <?= e(config('tolerancia_ajuste_percent', '10')) ?>%, pedimos sua aprovação antes de enviar.</p>
      <h3>E se um produto estiver em falta?</h3>
      <p>O separador sugere um substituto. Você recebe a solicitação em <b>Meus pedidos</b> e escolhe aceitar ou recusar. Nada é trocado sem a sua resposta.</p>
      <h3>Posso cancelar meu pedido?</h3>
      <p>Sim, enquanto ele estiver aguardando pagamento, aguardando separação ou aguardando sua aprovação. Depois que a separação começa, fale com o atendimento.</p>
    </section>
  </div>
</div>
<?php require APP_ROOT . '/includes/footer.php'; ?>
