<?php
/** Fila de pedidos aguardando separação. */
require __DIR__ . '/../../includes/bootstrap.php';
$eu = exigirPerfil('separador');

$fila = db()->query("SELECT p.id, p.total, p.criado_em, p.tipo_frete, p.prazo_entrega, a.nome AS area,
                     (SELECT COUNT(*) FROM itens_pedido i WHERE i.pedido_id = p.id) AS itens,
                     (SELECT COUNT(*) FROM itens_pedido i WHERE i.pedido_id = p.id AND i.vendido_por = 'peso') AS itens_peso
                     FROM pedidos p JOIN areas_entrega a ON a.id = p.area_entrega_id
                     WHERE p.status = 'aguardando_separacao' AND p.separador_id IS NULL
                     ORDER BY p.tipo_frete = 'expresso' DESC, p.criado_em ASC")->fetchAll();
$st = db()->prepare("SELECT
    COUNT(CASE WHEN status = 'em_separacao' THEN 1 END) AS em_separacao,
    COUNT(CASE WHEN status = 'aguardando_aprovacao' THEN 1 END) AS aguardando_cliente,
    COUNT(CASE WHEN separacao_concluida_em >= ? THEN 1 END) AS concluidos_hoje
    FROM pedidos WHERE separador_id = ?");
$st->execute([date('Y-m-d') . ' 00:00:00', $eu['id']]);
$resumo = $st->fetch();
$expressos = count(array_filter($fila, static fn ($pedido) => $pedido['tipo_frete'] === 'expresso'));

$titulo = 'Pedidos para separação';
$menuAtivo = 'fila';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Pedidos para separação (<?= count($fila) ?>)</h1>
<div class="kpis">
  <div class="kpi"><div class="kpi-topo">Expressos na fila</div><div class="kpi-valor"><?= $expressos ?></div></div>
  <div class="kpi"><div class="kpi-topo">Em separação comigo</div><div class="kpi-valor"><?= (int) $resumo['em_separacao'] ?></div><a href="<?= e(url('interno/separador/meus.php')) ?>">Meus pedidos</a></div>
  <div class="kpi"><div class="kpi-topo">Aguardando cliente</div><div class="kpi-valor"><?= (int) $resumo['aguardando_cliente'] ?></div></div>
  <div class="kpi"><div class="kpi-topo">Concluídos por mim hoje</div><div class="kpi-valor"><?= (int) $resumo['concluidos_hoje'] ?></div><a href="<?= e(url('interno/separador/historico.php')) ?>">Meu histórico</a></div>
</div>
<p class="muted">Ordem de prioridade: entregas expressas primeiro, depois os pedidos mais antigos.</p>
<div class="cartao">
  <?php if (!$fila): ?><div class="vazio"><?= icone('check', 'ico-lg') ?><h3>Fila vazia</h3><p>Nenhum pedido aguardando separação.</p></div><?php endif; ?>
  <?php foreach ($fila as $p): ?>
    <div class="flex entre flex-wrap" style="padding:14px 0;border-bottom:1px solid var(--linha)">
      <div class="flex"><?= icone('caixa') ?> <div><b>#<?= (int) $p['id'] ?></b> <?= $p['tipo_frete'] === 'expresso' ? '<span class="badge badge-erro">Expresso</span>' : '' ?><br>
        <small><?= dataBr($p['criado_em']) ?> · <?= e($p['area']) ?> · prazo <?= e($p['prazo_entrega']) ?></small></div></div>
      <div class="flex flex-wrap">
        <span><?= (int) $p['itens'] ?> itens<?= $p['itens_peso'] ? ' (' . (int) $p['itens_peso'] . ' por peso)' : '' ?></span>
        <b><?= dinheiro($p['total']) ?></b>
        <form method="post" action="<?= e(url('acoes/separador.php')) ?>"><?= csrfCampo() ?>
          <input type="hidden" name="acao" value="assumir"><input type="hidden" name="pedido_id" value="<?= (int) $p['id'] ?>">
          <button class="btn btn-primario btn-sm" type="submit">Separar <?= icone('seta', 'ico-sm') ?></button></form>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
