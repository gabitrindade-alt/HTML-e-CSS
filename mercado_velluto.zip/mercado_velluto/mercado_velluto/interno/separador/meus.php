<?php
/** Pedidos assumidos pelo separador logado. */
require __DIR__ . '/../../includes/bootstrap.php';
$eu = exigirPerfil('separador');

$status = get('status') === 'aguardando_aprovacao' ? ['aguardando_aprovacao'] : ['em_separacao', 'aguardando_aprovacao'];
$marc = implode(',', array_fill(0, count($status), '?'));
$st = db()->prepare("SELECT p.*, (SELECT COUNT(*) FROM itens_pedido i WHERE i.pedido_id = p.id AND i.status = 'pendente') AS pendentes,
                     (SELECT COUNT(*) FROM itens_pedido i WHERE i.pedido_id = p.id) AS itens,
                     (SELECT COUNT(*) FROM substituicoes s WHERE s.pedido_id = p.id AND s.status = 'pendente') AS subs
                     FROM pedidos p WHERE p.separador_id = ? AND p.status IN ($marc) ORDER BY p.separacao_iniciada_em");
$st->execute(array_merge([$eu['id']], $status));
$pedidos = $st->fetchAll();

$titulo = count($status) === 1 ? 'Aguardando resposta do cliente' : 'Em separação';
$menuAtivo = count($status) === 1 ? 'aguardando' : 'meus';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1><?= e($titulo) ?></h1>
<div class="cartao">
  <?php if (!$pedidos): ?><div class="vazio"><?= icone('caixa', 'ico-lg') ?><h3>Nenhum pedido aqui</h3>
    <a class="btn btn-primario" href="<?= e(url('interno/separador/index.php')) ?>">Ver fila de separação</a></div><?php endif; ?>
  <?php foreach ($pedidos as $p): ?>
    <div class="flex entre flex-wrap" style="padding:14px 0;border-bottom:1px solid var(--linha)">
      <div><b>#<?= (int) $p['id'] ?></b> <?= statusBadge($p['status']) ?><br><small>Iniciado em <?= dataBr($p['separacao_iniciada_em']) ?> · <?= (int) $p['pendentes'] ?> de <?= (int) $p['itens'] ?> itens pendentes
        <?= $p['subs'] ? ' · ' . (int) $p['subs'] . ' substituição(ões) aguardando cliente' : '' ?><?= (int) $p['ajuste_pendente'] ? ' · ajuste de valor aguardando cliente' : '' ?></small></div>
      <a class="btn btn-primario btn-sm" href="<?= e(url('interno/separador/pedido.php?id=' . (int) $p['id'])) ?>">Abrir <?= icone('seta', 'ico-sm') ?></a>
    </div>
  <?php endforeach; ?>
</div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
