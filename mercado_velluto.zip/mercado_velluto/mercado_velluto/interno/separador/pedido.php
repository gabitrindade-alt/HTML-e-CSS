<?php
/** Tela de separação de um pedido. */
require __DIR__ . '/../../includes/bootstrap.php';
$eu = exigirPerfil('separador');

$id = (int) get('id');
$st = db()->prepare('SELECT p.*, u.nome AS cliente FROM pedidos p JOIN usuarios u ON u.id = p.usuario_id WHERE p.id = ? AND p.separador_id = ?');
$st->execute([$id, $eu['id']]);
$pedido = $st->fetch();
if (!$pedido) {
    flash('erro', 'Pedido não encontrado ou atribuído a outro separador.');
    redirecionar('interno/separador/index.php');
}
$editavel = in_array($pedido['status'], ['em_separacao', 'aguardando_aprovacao'], true);
$itens = itensDoPedido($id);
$st = db()->prepare("SELECT s.*, p.nome AS sugerido FROM substituicoes s JOIN produtos p ON p.id = s.produto_sugerido_id WHERE s.pedido_id = ? ORDER BY s.id DESC");
$st->execute([$id]);
$subsPorItem = [];
foreach ($st as $s) {
    $subsPorItem[(int) $s['item_id']][] = $s;
}
$pend = pendenciasSeparacao($id);

/** Candidatos a substituto: mesma categoria (ou mesmo grupo), com estoque. */
function candidatos(array $item): array
{
    $st = db()->prepare('SELECT c.id, c.pai_id FROM categorias c WHERE c.id = ?');
    $st->execute([$item['categoria_id']]);
    $c = $st->fetch();
    $grupo = idsCategoriaComFilhas((int) ($c['pai_id'] ?: $c['id']));
    $marc = implode(',', array_fill(0, count($grupo), '?'));
    $st = db()->prepare("SELECT * FROM produtos WHERE ativo = 1 AND estoque > 0 AND id <> ? AND categoria_id IN ($marc)
                         ORDER BY categoria_id = ? DESC, ABS(preco - ?) ASC LIMIT 25");
    $st->execute(array_merge([(int) $item['produto_id']], $grupo, [(int) $item['categoria_id'], (float) $item['preco_unitario']]));
    return $st->fetchAll();
}

$titulo = 'Separação #' . $id;
$menuAtivo = $pedido['status'] === 'aguardando_aprovacao' ? 'aguardando' : 'meus';
require APP_ROOT . '/includes/header_interno.php';
?>
<div class="flex entre flex-wrap mb-2">
  <div><h1 class="mb-0">Pedido #<?= $id ?> <?= statusBadge($pedido['status']) ?></h1>
    <small>Cliente: <?= e(explode(' ', $pedido['cliente'])[0]) ?> · <?= count($itens) ?> itens · frete <?= e(freteRotulo($pedido['tipo_frete'])) ?> · total atual <b><?= dinheiro($pedido['total']) ?></b> (pago <?= dinheiro($pedido['total_pago']) ?>)</small></div>
  <?php if ($pedido['status'] === 'em_separacao' && $pend['pendentes'] === count($itens)): ?>
    <form method="post" action="<?= e(url('acoes/separador.php')) ?>" data-confirma="Devolver o pedido à fila?"><?= csrfCampo() ?>
      <input type="hidden" name="acao" value="devolver"><input type="hidden" name="pedido_id" value="<?= $id ?>">
      <button class="btn btn-neutro btn-sm" type="submit">Devolver à fila</button></form>
  <?php endif; ?>
</div>
<?php if ($pedido['observacoes']): ?><p class="aviso aviso-rosa">Observação do cliente: <?= e($pedido['observacoes']) ?></p><?php endif; ?>
<?php if ($pedido['status'] === 'aguardando_aprovacao'): ?>
  <p class="aviso"><?= icone('ampulheta', 'ico-sm') ?> Aguardando resposta do cliente<?= (int) $pedido['ajuste_pendente'] ? ' sobre o novo valor do pedido' : ' sobre substituição' ?>. Você pode continuar conferindo os demais itens; a finalização fica bloqueada até a resposta.</p>
<?php endif; ?>

<section class="cartao">
  <div class="cartao-titulo"><h3>Itens do pedido</h3><span class="pequeno"><?= $pend['pendentes'] ?> pendente(s) · <?= $pend['indisponiveis'] ?> indisponível(is) · <?= $pend['substituicoes'] ?> substituição(ões) aguardando</span></div>
  <?php foreach ($itens as $i):
      $subs = $subsPorItem[(int) $i['id']] ?? [];
      $subPend = array_values(array_filter($subs, fn($s) => $s['status'] === 'pendente'));
      $fin = in_array($i['status'], ['separado', 'substituido', 'removido'], true); ?>
    <div class="item-separacao <?= $fin ? 'finalizado' : '' ?>">
      <img src="<?= e(imagemProduto($i)) ?>" alt="">
      <div>
        <b><?= e($i['nome_produto']) ?></b> <span class="badge st-<?= e($i['status']) ?>"><?= e(STATUS_ITEM[$i['status']]) ?></span><br>
        <small><?= e($i['embalagem']) ?> · Solicitado: <b><?= e(qtdFormatada($i['quantidade'], $i['vendido_por'])) ?></b> · <?= dinheiro($i['preco_unitario']) ?><?= $i['vendido_por'] === 'peso' ? '/kg' : '' ?>
          <?= $i['quantidade_separada'] !== null ? ' · Separado: <b>' . e(qtdFormatada($i['quantidade_separada'], $i['vendido_por'])) . '</b>' : '' ?>
          · Subtotal <?= dinheiro($i['subtotal']) ?></small>
        <?php if ($i['observacao']): ?><br><small class="muted"><?= e($i['observacao']) ?></small><?php endif; ?>
        <?php foreach ($subs as $s): ?><br><small>↳ Sugestão: <?= e($s['sugerido']) ?> — <span class="badge st-<?= e($s['status']) ?>"><?= e($s['status']) ?></span></small><?php endforeach; ?>
      </div>
      <div class="acoes-item">
        <?php if ($editavel && $i['status'] === 'pendente'): ?>
          <form method="post" action="<?= e(url('acoes/separador.php')) ?>"><?= csrfCampo() ?>
            <input type="hidden" name="acao" value="separar"><input type="hidden" name="pedido_id" value="<?= $id ?>"><input type="hidden" name="item_id" value="<?= (int) $i['id'] ?>">
            <label class="pequeno" for="q<?= (int) $i['id'] ?>"><?= $i['vendido_por'] === 'peso' ? 'Peso real (kg)' : 'Qtd. separada' ?></label>
            <input class="input" id="q<?= (int) $i['id'] ?>" name="quantidade_real" type="number" required
                   step="<?= $i['vendido_por'] === 'peso' ? '0.005' : '1' ?>" min="<?= $i['vendido_por'] === 'peso' ? '0.005' : '1' ?>"
                   <?= $i['vendido_por'] === 'peso' ? '' : 'max="' . (int) $i['quantidade'] . '"' ?>
                   value="<?= $i['vendido_por'] === 'peso' ? e(number_format((float) $i['quantidade'], 3, '.', '')) : (int) $i['quantidade'] ?>">
            <button class="btn btn-sucesso btn-sm" type="submit"><?= icone('check', 'ico-sm') ?> Conferido</button>
          </form>
          <form method="post" action="<?= e(url('acoes/separador.php')) ?>" data-confirma="Marcar &quot;<?= e($i['nome_produto']) ?>&quot; como indisponível?"><?= csrfCampo() ?>
            <input type="hidden" name="acao" value="indisponivel"><input type="hidden" name="pedido_id" value="<?= $id ?>"><input type="hidden" name="item_id" value="<?= (int) $i['id'] ?>">
            <button class="btn btn-perigo btn-sm" type="submit">Indisponível</button>
          </form>
        <?php elseif ($editavel && $i['status'] === 'indisponivel' && $subPend): ?>
          <span class="badge st-aguardando_aprovacao">Aguardando cliente</span>
        <?php elseif ($editavel && $i['status'] === 'indisponivel'): $cands = candidatos($i); ?>
          <form method="post" action="<?= e(url('acoes/separador.php')) ?>" style="display:grid;gap:6px;justify-items:end"><?= csrfCampo() ?>
            <input type="hidden" name="acao" value="sugerir"><input type="hidden" name="pedido_id" value="<?= $id ?>"><input type="hidden" name="item_id" value="<?= (int) $i['id'] ?>">
            <select class="input" name="produto_sugerido_id" required style="width:260px">
              <option value="">Sugerir substituto…</option>
              <?php foreach ($cands as $c): ?><option value="<?= (int) $c['id'] ?>"><?= e($c['nome']) ?> — <?= dinheiro(precoAtual($c)) ?><?= unidadePreco($c) ?> (est. <?= e(qtdFormatada($c['estoque'], $c['vendido_por'])) ?>)</option><?php endforeach; ?>
            </select>
            <div class="flex"><label class="pequeno">Qtd.</label><input class="input" name="quantidade" type="number" step="<?= $i['vendido_por'] === 'peso' ? '0.25' : '1' ?>" min="<?= $i['vendido_por'] === 'peso' ? '0.25' : '1' ?>" value="<?= $i['vendido_por'] === 'peso' ? e(number_format((float) $i['quantidade'], 2, '.', '')) : (int) $i['quantidade'] ?>" style="width:90px"></div>
            <input class="input" name="mensagem" maxlength="255" placeholder="Mensagem ao cliente (opcional)" style="width:260px">
            <button class="btn btn-primario btn-sm" type="submit"><?= icone('troca', 'ico-sm') ?> Enviar sugestão</button>
          </form>
          <form method="post" action="<?= e(url('acoes/separador.php')) ?>" data-confirma="Remover o item sem substituto? O valor será estornado ao cliente."><?= csrfCampo() ?>
            <input type="hidden" name="acao" value="remover"><input type="hidden" name="pedido_id" value="<?= $id ?>"><input type="hidden" name="item_id" value="<?= (int) $i['id'] ?>">
            <button class="btn btn-link" type="submit">Remover sem substituto</button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>
</section>

<?php if ($pedido['status'] === 'em_separacao'): $pode = !$pend['pendentes'] && !$pend['indisponiveis'] && !$pend['substituicoes']; ?>
<section class="cartao">
  <h3>Finalizar separação e encaminhar para embalagem/entrega</h3>
  <?php if (!$pode): ?><p class="aviso">Confira todos os itens e resolva os indisponíveis antes de finalizar.</p><?php endif; ?>
  <form method="post" action="<?= e(url('acoes/separador.php')) ?>" class="flex flex-wrap" data-confirma="Finalizar a separação do pedido #<?= $id ?>?"><?= csrfCampo() ?>
    <input type="hidden" name="acao" value="finalizar"><input type="hidden" name="pedido_id" value="<?= $id ?>">
    <label for="volumes">Volumes embalados</label><input class="input" id="volumes" type="number" name="volumes" min="1" max="50" value="<?= max(1, (int) ceil(count($itens) / 6)) ?>" style="width:90px">
    <button class="btn btn-primario" type="submit" <?= $pode ? '' : 'disabled' ?>><?= icone('caixa', 'ico-sm') ?> Finalizar e encaminhar</button>
  </form>
  <p class="pequeno mt-1 mb-0">Se o total final superar o valor pago em mais de <?= e(config('tolerancia_ajuste_percent', '10')) ?>% (ex.: pesos), o cliente precisará aprovar antes da entrega.</p>
</section>
<?php endif; ?>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
