<?php
/** Histórico de pedidos separados pelo separador logado. */
require __DIR__ . '/../../includes/bootstrap.php';
$eu = exigirPerfil('separador');

$st = db()->prepare("SELECT p.*, (SELECT COUNT(*) FROM itens_pedido i WHERE i.pedido_id = p.id AND i.status = 'separado') AS separados,
                     (SELECT COUNT(*) FROM substituicoes s WHERE s.pedido_id = p.id) AS subs
                     FROM pedidos p WHERE p.separador_id = ? AND (p.separacao_concluida_em IS NOT NULL OR p.status = 'cancelado')
                     ORDER BY COALESCE(p.separacao_concluida_em, p.atualizado_em) DESC LIMIT 200");
$st->execute([$eu['id']]);
$pedidos = $st->fetchAll();
$tempos = [];
foreach ($pedidos as $p) {
    if ($p['separacao_iniciada_em'] && $p['separacao_concluida_em']) {
        $tempos[] = (strtotime($p['separacao_concluida_em']) - strtotime($p['separacao_iniciada_em'])) / 60;
    }
}

$titulo = 'Histórico de separação';
$menuAtivo = 'historico';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Histórico de separação</h1>
<div class="kpis">
  <div class="kpi"><div class="kpi-topo">Pedidos separados</div><div class="kpi-valor"><?= count($tempos) ?></div></div>
  <div class="kpi"><div class="kpi-topo">Tempo médio</div><div class="kpi-valor"><?= $tempos ? numeroBr(array_sum($tempos) / count($tempos), 0) : 0 ?> min</div></div>
</div>
<div class="cartao"><div class="tabela-wrap"><table class="tabela">
  <thead><tr><th>Pedido</th><th>Início</th><th>Conclusão</th><th class="num">Itens separados</th><th class="num">Substituições</th><th class="num">Volumes</th><th>Status atual</th><th></th></tr></thead>
  <tbody><?php foreach ($pedidos as $p): ?>
    <tr><td>#<?= (int) $p['id'] ?></td><td><small><?= dataBr($p['separacao_iniciada_em']) ?></small></td><td><small><?= dataBr($p['separacao_concluida_em']) ?></small></td>
      <td class="num"><?= (int) $p['separados'] ?></td><td class="num"><?= (int) $p['subs'] ?></td><td class="num"><?= $p['volumes'] ? (int) $p['volumes'] : '—' ?></td>
      <td><?= statusBadge($p['status']) ?></td><td><a class="btn btn-neutro btn-sm" href="<?= e(url('interno/separador/pedido.php?id=' . (int) $p['id'])) ?>">Ver</a></td></tr>
  <?php endforeach; ?>
  <?php if (!$pedidos): ?><tr><td colspan="8" class="muted texto-centro">Nenhuma separação concluída ainda.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
