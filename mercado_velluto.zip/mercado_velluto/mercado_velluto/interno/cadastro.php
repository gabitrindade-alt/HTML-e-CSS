<?php
require __DIR__ . '/../includes/bootstrap.php';

$perfil = get('perfil');
if (!is_string($perfil) || !permiteCadastroInternoLocal($perfil)) {
    http_response_code(403);
    exit('Cadastro indisponível para este perfil.');
}

$login = 'interno/login.php?perfil=' . $perfil;
$rotulo = mb_strtolower(PERFIL_ROTULO[$perfil]);
$nome = $email = '';
$erros = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = is_string(post('nome')) ? post('nome') : '';
    $email = is_string(post('email')) ? mb_strtolower(post('email')) : '';
    $senha = is_string($_POST['senha'] ?? null) ? $_POST['senha'] : '';

    if (mb_strlen($nome) < 3 || mb_strlen($nome) > 120) $erros[] = 'Informe o nome completo.';
    if (strlen($email) > 160 || !filter_var($email, FILTER_VALIDATE_EMAIL) || !str_ends_with($email, '@velluto.com')) {
        $erros[] = 'Escolha um e-mail com final @velluto.com.';
    }
    if (strlen($senha) < 8 || strlen($senha) > 72 || str_contains($senha, "\0") || !preg_match('/[A-Za-z]/', $senha) || !preg_match('/\d/', $senha)) {
        $erros[] = 'Escolha uma senha de 8 a 72 bytes, com letras e números.';
    }
    if ($senha !== ($_POST['confirmar_senha'] ?? '')) $erros[] = 'A confirmação da senha não confere.';

    if (!$erros) {
        $conexao = db();
        $conexao->beginTransaction();
        try {
            $st = $conexao->prepare('INSERT INTO usuarios (nome, email, senha_hash, perfil, criado_em) VALUES (?, ?, ?, ?, ?)');
            $st->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT), $perfil, agora()]);
            registrarAlteracao('funcionario', (int) $conexao->lastInsertId(), 'criar', "Cadastro local de $rotulo");
            $conexao->commit();
            flash('sucesso', 'Conta criada. Entre com o e-mail e a senha que você cadastrou.');
            redirecionar($login);
        } catch (Throwable $ex) {
            if ($conexao->inTransaction()) $conexao->rollBack();
            if (!$ex instanceof PDOException || (int) ($ex->errorInfo[1] ?? 0) !== 1062) throw $ex;
            $erros[] = 'Esse e-mail já está em uso. Escolha outro para esta conta.';
        }
    }
}
?><!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex">
  <title>Cadastro de <?= e($rotulo) ?> · Velluto</title>
  <link rel="icon" href="<?= e(asset('img/marca-velluto.svg')) ?>" type="image/svg+xml">
  <link rel="stylesheet" href="<?= e(asset('css/velluto.css')) ?>">
</head>
<body>
<main class="container-estreito pagina">
  <div class="cartao">
    <h1>Criar conta de <?= e($rotulo) ?></h1>
    <p class="muted">Escolha um e-mail com final @velluto.com. Use pelo menos 8 caracteres, com letras e números, na senha.</p>
    <?php if ($erros): ?>
      <div class="aviso aviso-vermelho mb-2" role="alert"><?= implode('<br>', array_map('e', $erros)) ?></div>
    <?php endif; ?>
    <form method="post">
      <?= csrfCampo() ?>
      <div class="campo"><label for="nome">Nome completo</label><input id="nome" name="nome" value="<?= e($nome) ?>" maxlength="120" autocomplete="name" required></div>
      <div class="campo"><label for="email">E-mail corporativo</label><input id="email" name="email" type="email" value="<?= e($email) ?>" maxlength="160" placeholder="nome@velluto.com" autocomplete="username" required></div>
      <div class="campo"><label for="senha">Senha</label><input id="senha" name="senha" type="password" minlength="8" maxlength="72" autocomplete="new-password" required></div>
      <div class="campo"><label for="confirmar-senha">Confirme a senha</label><input id="confirmar-senha" name="confirmar_senha" type="password" minlength="8" maxlength="72" autocomplete="new-password" required></div>
      <button class="btn btn-primario btn-bloco" type="submit">Criar conta</button>
    </form>
    <p class="texto-centro mt-2 mb-0"><a href="<?= e(url($login)) ?>">Voltar para entrar</a></p>
  </div>
</main>
</body>
</html>
