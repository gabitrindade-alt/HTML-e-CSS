<?php
/** Cadastro inicial do administrador e ativação das contas internas preexistentes. */
require __DIR__ . '/../includes/bootstrap.php';

if (!ehRequisicaoLocal()) {
    http_response_code(403);
    exit('Configuração inicial disponível somente no próprio computador que executa o site.');
}

$contas = db()->query("SELECT id, nome, email, perfil FROM usuarios
                       WHERE perfil IN ('administrador','separador','entregador') AND senha_hash IS NULL ORDER BY id")->fetchAll();
$erros = [];
$sqlAdmin = "SELECT COUNT(*) FROM usuarios WHERE perfil = 'administrador' AND ativo = 1 AND senha_hash IS NOT NULL";
$podeCriarAdministrador = !(int) db()->query($sqlAdmin)->fetchColumn();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conexao = db();
    if (!(int) $conexao->query("SELECT GET_LOCK(CONCAT(DATABASE(), ':configurar-admin'), 5)")->fetchColumn()) {
        http_response_code(503);
        exit('Configuração em andamento. Tente novamente.');
    }
    try {
        $podeCriarAdministrador = !(int) $conexao->query($sqlAdmin)->fetchColumn();
        $usuario = usuarioLogado();
        if (!$podeCriarAdministrador && ($usuario['perfil'] ?? '') !== 'administrador') {
            http_response_code(403);
            exit('Entre como administrador para configurar as contas internas.');
        }
        if (post('acao') === 'criar-administrador') {
            if (!$podeCriarAdministrador) {
                redirecionar('interno/administrador/funcionarios.php');
            }
            $nome = mb_substr(is_string(post('nome')) ? post('nome') : '', 0, 120);
            $email = mb_strtolower(is_string(post('email')) ? post('email') : '');
            $senha = is_string($_POST['nova_senha'] ?? null) ? $_POST['nova_senha'] : '';
            if (mb_strlen($nome) < 3) $erros[] = 'Informe o nome completo.';
            if (strlen($email) > 160 || !filter_var($email, FILTER_VALIDATE_EMAIL) || !str_ends_with($email, '@velluto.com')) {
                $erros[] = 'Informe um e-mail corporativo válido (@velluto.com).';
            }
            if (strlen($senha) < 8 || strlen($senha) > 72 || str_contains($senha, "\0") || !preg_match('/[A-Za-z]/', $senha) || !preg_match('/\d/', $senha)) {
                $erros[] = 'A senha deve ter de 8 a 72 bytes, com letras e números.';
            }
            if ($senha !== ($_POST['confirmar_senha'] ?? '')) $erros[] = 'A confirmação da senha não confere.';
            if (!$erros) {
                $st = $conexao->prepare("INSERT INTO usuarios (nome, email, senha_hash, perfil, criado_em) VALUES (?, ?, ?, 'administrador', ?)");
                try {
                    $st->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT), agora()]);
                } catch (PDOException $ex) {
                    if ((int) ($ex->errorInfo[1] ?? 0) !== 1062) throw $ex;
                    $erros[] = 'E-mail já cadastrado. Para usar uma conta da lista abaixo, defina a senha dela.';
                }
                if (!$erros) {
                    registrarAlteracao('funcionario', (int) $conexao->lastInsertId(), 'criar', 'Administrador inicial');
                    flash('sucesso', 'Administrador cadastrado. Entre com sua nova conta para cadastrar funcionários.');
                    redirecionar('interno/login.php?perfil=administrador');
                }
            }
        } elseif ($contas) {

            $definidas = 0;
            foreach ($contas as $c) {
                $s = (string) ($_POST['senha'][$c['id']] ?? '');
                $s2 = (string) ($_POST['confirma'][$c['id']] ?? '');
                if ($s === '') {
                    continue; // pode ser definida depois
                }
                if (strlen($s) < 8 || !preg_match('/[A-Za-z]/', $s) || !preg_match('/\d/', $s)) {
                    $erros[] = $c['email'] . ': a senha deve ter ao menos 8 caracteres, com letras e números.';
                    continue;
                }
                if ($s !== $s2) {
                    $erros[] = $c['email'] . ': a confirmação não confere.';
                    continue;
                }
                $st = db()->prepare('UPDATE usuarios SET senha_hash = ?, atualizado_em = ? WHERE id = ? AND senha_hash IS NULL');
                $st->execute([password_hash($s, PASSWORD_DEFAULT), agora(), $c['id']]);
                if ($st->rowCount()) {
                    $definidas++;
                    registrarAlteracao('usuario', (int) $c['id'], 'senha_inicial', 'Senha inicial definida para ' . $c['email']);
                }
            }
            if ($definidas) {
                flash('sucesso', $definidas . ' senha(s) definida(s) com segurança.');
            }
            if (!$erros) {
                redirecionar('interno/index.php');
            }
        }
    } finally {
        $conexao->query("SELECT RELEASE_LOCK(CONCAT(DATABASE(), ':configurar-admin'))");
    }
}
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>Configuração inicial · Velluto</title>
<script>try{document.documentElement.dataset.theme=localStorage.getItem("velluto-theme")||"light";}catch(e){}</script>
<link rel="stylesheet" href="<?= e(asset('css/velluto.css')) ?>">
</head>
<body data-url-interno="<?= e(url('interno/index.php')) ?>">
<?= mostrarFlash() ?>
<div class="container-estreito pagina">
  <div class="cartao mt-3">
    <h1>Configuração do acesso interno</h1>
    <?php if ($erros): ?><div class="aviso aviso-vermelho mb-2"><?= implode('<br>', array_map('e', $erros)) ?></div><?php endif; ?>
    <?php if ($podeCriarAdministrador): ?>
      <form class="cartao mb-2" method="post">
        <?= csrfCampo() ?><input type="hidden" name="acao" value="criar-administrador">
        <h2>Cadastrar primeiro administrador</h2>
        <p class="muted">Depois de entrar no painel, use Funcionários para cadastrar administradores, separadores e entregadores.</p>
        <div class="campo"><label for="nome">Nome completo</label><input id="nome" name="nome" maxlength="120" value="<?= e($nome ?? '') ?>" autocomplete="name" required></div>
        <div class="campo"><label for="email">E-mail corporativo</label><input id="email" name="email" type="email" maxlength="160" value="<?= e($email ?? '') ?>" placeholder="nome@velluto.com" autocomplete="username" required></div>
        <div class="grid-2">
          <div class="campo"><label for="nova-senha">Senha</label><input id="nova-senha" name="nova_senha" type="password" minlength="8" maxlength="72" autocomplete="new-password" required></div>
          <div class="campo"><label for="confirmar-senha">Confirme a senha</label><input id="confirmar-senha" name="confirmar_senha" type="password" minlength="8" maxlength="72" autocomplete="new-password" required></div>
        </div>
        <button class="btn btn-primario" type="submit">Cadastrar administrador</button>
      </form>
    <?php endif; ?>
    <?php if (!$podeCriarAdministrador && (usuarioLogado()['perfil'] ?? '') !== 'administrador'): ?>
      <p><a class="btn btn-primario" href="<?= e(url('interno/login.php?perfil=administrador')) ?>">Entrar como administrador</a></p>
    <?php elseif (!$contas): ?>
      <div class="aviso aviso-verde">Todas as contas internas já possuem senha. Esta página está desativada.</div>
      <p class="mt-2"><a class="btn btn-primario" href="<?= e(url('interno/index.php')) ?>">Ir para o acesso interno</a></p>
    <?php else: ?>
      <p class="muted">Defina as senhas das contas internas já cadastradas.
        Deixe em branco as que quiser configurar depois. Requisitos: 8+ caracteres, com letras e números.</p>
      <form method="post" autocomplete="off">
        <?= csrfCampo() ?>
        <?php foreach ($contas as $c): ?>
          <fieldset class="cartao" style="margin-top:12px">
            <legend class="negrito"><?= e($c['email']) ?> <span class="badge"><?= e(PERFIL_ROTULO[$c['perfil']]) ?></span></legend>
            <div class="grid-2">
              <div class="campo"><label>Nova senha</label><input type="password" name="senha[<?= (int) $c['id'] ?>]" autocomplete="new-password"></div>
              <div class="campo"><label>Confirmar</label><input type="password" name="confirma[<?= (int) $c['id'] ?>]" autocomplete="new-password"></div>
            </div>
          </fieldset>
        <?php endforeach; ?>
        <button class="btn btn-primario mt-2" type="submit">Salvar senhas</button>
      </form>
    <?php endif; ?>
  </div>
</div>
<script src="<?= e(asset('js/preferencias.js')) ?>"></script>
</body>
</html>
