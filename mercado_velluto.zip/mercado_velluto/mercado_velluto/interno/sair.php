<?php
require __DIR__ . '/../includes/bootstrap.php';

if ($u = usuarioLogado()) {
    registrarAlteracao('sessao', (int) $u['id'], 'logout', 'Saída do painel ' . (PERFIL_ROTULO[$u['perfil']] ?? ''));
}
encerrarSessao();
iniciarSessao();
flash('info', 'Sessão encerrada com segurança.');
redirecionar('interno/index.php');
