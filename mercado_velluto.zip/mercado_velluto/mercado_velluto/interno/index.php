<?php
/** Seleção de perfil interno — aberta pelo atalho Ctrl + A. */
require __DIR__ . '/../includes/bootstrap.php';

$u = usuarioLogado();
$semSenha = (int) db()->query("SELECT COUNT(*) FROM usuarios WHERE perfil IN ('administrador','separador','entregador') AND senha_hash IS NULL")->fetchColumn();
$perfis = [
    'administrador' => ['engrenagem', 'Gerencia produtos, pedidos, estoque, clientes, funcionários, frete e relatórios.', '#F2C6D6'],
    'separador'     => ['caixa', 'Assume pedidos, confere itens, informa pesos reais e sugere substituições.', '#EAD2B0'],
    'entregador'    => ['caminhao', 'Assume entregas, confirma retirada, conclui entregas e registra ocorrências.', '#CFE0BC'],
];
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>Acesso interno · Velluto</title>
<link rel="icon" href="<?= e(asset('img/marca-velluto.svg')) ?>" type="image/svg+xml">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<script>try{document.documentElement.dataset.theme=localStorage.getItem("velluto-theme")||"light";}catch(e){}</script>
<link rel="stylesheet" href="<?= e(asset('css/velluto.css')) ?>">
</head>
<body data-url-interno="<?= e(url('interno/index.php')) ?>" style="background:linear-gradient(140deg,#FFF8F2,#F8E9E2 60%,#F7DCE4)">
<?= mostrarFlash() ?>
<div class="container pagina" style="max-width:1000px">
  <div class="texto-centro">
    <a class="logo" href="<?= e(url('index.php')) ?>" style="justify-content:center"><img src="<?= e(asset('img/marca-velluto.svg')) ?>" alt=""><span class="logo-texto">VELLUTO</span></a>
    <h1 class="mt-2">Acesso interno</h1>
    <p class="muted">Escolha o seu perfil. Cada painel exige login próprio e as permissões são verificadas no servidor.</p>
    <?php if ($u && $u['perfil'] !== 'cliente'): ?>
      <p class="aviso aviso-rosa">Você está conectado como <b><?= e(PERFIL_ROTULO[$u['perfil']]) ?></b>.
        <a href="<?= e(url(painelDoPerfil($u['perfil']))) ?>">Ir para o meu painel</a> · <a href="<?= e(url('interno/sair.php')) ?>">Sair</a></p>
    <?php endif; ?>
  </div>
  <div class="texto-centro mt-3">
    <?php if (($u['perfil'] ?? '') === 'administrador'): ?>
      <a class="btn btn-secundario" href="<?= e(url('interno/administrador/funcionarios.php#cadastro-funcionario')) ?>">Cadastrar funcionário</a>
    <?php else: ?>
      <a class="btn btn-secundario" href="<?= e(url('interno/login.php?perfil=administrador&cadastro=1')) ?>">Cadastrar funcionário</a>
    <?php endif; ?>
    <?php if (ehRequisicaoLocal() && $semSenha && ($u['perfil'] ?? '') === 'administrador'): ?>
      <a class="btn btn-link" href="<?= e(url('interno/instalar.php')) ?>">Configurar senhas iniciais</a>
    <?php endif; ?>
  </div>
  <div class="perfis-internos">
    <?php foreach ($perfis as $chave => [$ic, $desc, $cor]): ?>
      <a class="perfil-card" href="<?= e(url('interno/login.php?perfil=' . $chave)) ?>">
        <span class="categoria-icone" style="background:<?= $cor ?>"><?= icone($ic) ?></span>
        <h2><?= e(PERFIL_ROTULO[$chave]) ?></h2>
        <p class="pequeno"><?= e($desc) ?></p>
        <span class="btn btn-primario btn-sm">Entrar <?= icone('seta', 'ico-sm') ?></span>
      </a>
    <?php endforeach; ?>
  </div>
  <p class="texto-centro mt-3"><a href="<?= e(url('index.php')) ?>">← Voltar à loja</a></p>
</div>
<script src="<?= e(asset('js/velluto.js')) ?>"></script>
<script src="<?= e(asset('js/preferencias.js')) ?>"></script>
</body>
</html>
