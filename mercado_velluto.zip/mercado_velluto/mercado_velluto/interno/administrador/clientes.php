<?php
/** Gestão de clientes. */
require __DIR__ . '/../../includes/bootstrap.php';
exigirPerfil('administrador');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && post('acao') === 'alternar') {
    $id = (int) post('id');
    $st = db()->prepare("SELECT nome, ativo FROM usuarios WHERE id = ? AND perfil = 'cliente'");
    $st->execute([$id]);
    if ($c = $st->fetch()) {
        $novo = (int) $c['ativo'] ? 0 : 1;
        db()->prepare('UPDATE usuarios SET ativo = ?, atualizado_em = ? WHERE id = ?')->execute([$novo, agora(), $id]);
        registrarAlteracao('cliente', $id, $novo ? 'ativar' : 'bloquear', 'Cliente ' . $c['nome']);
        flash('sucesso', 'Cliente ' . ($novo ? 'reativado' : 'bloqueado') . '.');
    }
    redirecionar('interno/administrador/clientes.php' . (get('id') ? '?id=' . (int) get('id') : ''));
}

$q = get('q');
$params = [];
$sql = "SELECT u.*, COUNT(p.id) AS pedidos, COALESCE(SUM(CASE WHEN p.status = 'concluido' THEN p.total ELSE 0 END), 0) AS gasto, MAX(p.criado_em) AS ultimo
        FROM usuarios u LEFT JOIN pedidos p ON p.usuario_id = u.id WHERE u.perfil = 'cliente'";
if ($q !== '') {
    $sql .= ' AND (u.nome LIKE ? OR u.email LIKE ?)';
    $params = ["%$q%", "%$q%"];
}
$sql .= ' GROUP BY u.id, u.nome, u.email, u.senha_hash, u.perfil, u.cpf, u.telefone, u.ativo, u.ultimo_login, u.criado_em, u.atualizado_em ORDER BY u.nome';
$st = db()->prepare($sql);
$st->execute($params);
$clientes = $st->fetchAll();

$detalhe = null;
if (get('id')) {
    $st = db()->prepare("SELECT * FROM usuarios WHERE id = ? AND perfil = 'cliente'");
    $st->execute([(int) get('id')]);
    $detalhe = $st->fetch() ?: null;
    if ($detalhe) {
        $st = db()->prepare('SELECT * FROM pedidos WHERE usuario_id = ? ORDER BY criado_em DESC');
        $st->execute([$detalhe['id']]);
        $pedidosCliente = $st->fetchAll();
        $st = db()->prepare('SELECT * FROM enderecos WHERE usuario_id = ? AND ativo = 1');
        $st->execute([$detalhe['id']]);
        $enderecosCliente = $st->fetchAll();
    }
}

$titulo = 'Clientes';
$menuAtivo = 'clientes';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Clientes <small class="muted">(<?= count($clientes) ?>)</small></h1>
<?php if ($detalhe): ?>
  <section class="cartao mb-2">
    <div class="cartao-titulo"><h2><?= e($detalhe['nome']) ?></h2><a href="<?= e(url('interno/administrador/clientes.php')) ?>">Fechar</a></div>
    <div class="grid-3">
      <dl class="info-lista"><dt>E-mail</dt><dd><?= e($detalhe['email']) ?></dd><dt>Telefone</dt><dd><?= e($detalhe['telefone'] ?? '—') ?></dd>
        <dt>CPF</dt><dd><?= $detalhe['cpf'] ? e(substr($detalhe['cpf'], 0, 3) . '.***.***-' . substr($detalhe['cpf'], -2)) : '—' ?></dd>
        <dt>Cadastro</dt><dd><?= dataBr($detalhe['criado_em'], false) ?></dd><dt>Último login</dt><dd><?= dataBr($detalhe['ultimo_login']) ?></dd></dl>
      <div><b>Endereços</b><?php foreach ($enderecosCliente as $en): ?><p class="pequeno mb-1"><?= e($en['apelido']) ?>: <?= e($en['logradouro']) ?>, <?= e($en['numero']) ?> — <?= e($en['bairro']) ?> · CEP <?= e(cepFormatado($en['cep'])) ?></p><?php endforeach; ?></div>
      <div><b>Pedidos</b><?php foreach (array_slice($pedidosCliente, 0, 8) as $pc): ?>
        <p class="pequeno mb-1"><a href="<?= e(url('interno/administrador/pedido.php?id=' . (int) $pc['id'])) ?>">#<?= (int) $pc['id'] ?></a> · <?= dataBr($pc['criado_em'], false) ?> · <?= dinheiro($pc['total']) ?> <?= statusBadge($pc['status']) ?></p><?php endforeach; ?></div>
    </div>
  </section>
<?php endif; ?>
<form class="filtros-linha cartao" method="get">
  <div class="campo"><label for="q">Buscar</label><input class="input" id="q" name="q" value="<?= e($q) ?>" placeholder="Nome ou e-mail"></div>
  <button class="btn btn-neutro" type="submit">Buscar</button>
</form>
<div class="cartao mt-2"><div class="tabela-wrap"><table class="tabela">
  <thead><tr><th>Cliente</th><th>Contato</th><th class="num">Pedidos</th><th class="num">Total concluído</th><th>Último pedido</th><th>Situação</th><th></th></tr></thead>
  <tbody><?php foreach ($clientes as $c): ?>
    <tr><td><b><?= e($c['nome']) ?></b><br><small>desde <?= dataBr($c['criado_em'], false) ?></small></td>
      <td><?= e($c['email']) ?><br><small><?= e($c['telefone'] ?? '') ?></small></td>
      <td class="num"><?= (int) $c['pedidos'] ?></td><td class="num"><?= dinheiro($c['gasto']) ?></td>
      <td><?= dataBr($c['ultimo']) ?></td>
      <td><?= (int) $c['ativo'] ? '<span class="badge badge-ok">Ativo</span>' : '<span class="badge badge-erro">Bloqueado</span>' ?></td>
      <td><div class="acoes-linha"><a class="btn btn-neutro btn-sm" href="?id=<?= (int) $c['id'] ?>">Ver</a>
        <form method="post" action="?id=<?= (int) $c['id'] ?>" data-confirma="<?= (int) $c['ativo'] ? 'Bloquear o acesso deste cliente?' : 'Reativar este cliente?' ?>"><?= csrfCampo() ?><input type="hidden" name="acao" value="alternar"><input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
          <button class="btn btn-<?= (int) $c['ativo'] ? 'perigo' : 'neutro' ?> btn-sm" type="submit"><?= (int) $c['ativo'] ? 'Bloquear' : 'Reativar' ?></button></form></div></td></tr>
  <?php endforeach; ?></tbody>
</table></div></div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
