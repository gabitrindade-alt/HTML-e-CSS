<?php
require __DIR__ . '/../../includes/bootstrap.php';
exigirPerfil('administrador');

$pagina = 'interno/administrador/carrossel.php';
$padrao = bannersPadrao();
$banners = bannersCarrossel();
$opcoes = opcoesCarrossel();
$efeitos = ['deslizar' => 'Deslizar', 'dissolver' => 'Dissolver', 'nenhum' => 'Sem animação'];
$limites = ['rotulo' => 32, 'titulo' => 100, 'texto' => 220, 'botao' => 40, 'destino' => 230, 'alt' => 150];
$campos = ['rotulo' => 'Nome na aba', 'titulo' => 'Título', 'texto' => 'Texto', 'botao' => 'Texto do botão',
    'destino' => 'Link interno', 'alt' => 'Descrição da imagem'];
$vazio = array_fill_keys(array_keys($limites), '') + ['chave' => '', 'ordem' => 60, 'ativo' => 1, 'imagem' => ''];
$selecionado = get('banner');
$banner = is_string($selecionado) ? ($banners[$selecionado] ?? $vazio) : $vazio;
$erros = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = post('acao');
    $chave = post('chave');
    if (!is_string($chave)) $chave = '';
    if ($acao === 'opcoes') {
        $segundos = filter_var(post('segundos'), FILTER_VALIDATE_INT, ['options' => ['min_range' => 3, 'max_range' => 30]]);
        $efeito = post('efeito');
        if (!$segundos || !is_string($efeito) || !isset($efeitos[$efeito])) {
            $erros[] = 'Escolha um efeito e um intervalo de 3 a 30 segundos.';
        } else {
            transacao(function () use ($segundos, $efeito) {
                $st = db()->prepare('INSERT INTO configuracoes (chave, valor) VALUES (?, ?)
                    ON DUPLICATE KEY UPDATE valor = VALUES(valor)');
                $st->execute(['carrossel_auto', post('automatico') === '1' ? '1' : '0']);
                $st->execute(['carrossel_segundos', (string) $segundos]);
                $st->execute(['carrossel_efeito', $efeito]);
                registrarAlteracao('carrossel', null, 'editar', 'Reprodução e transição do carrossel.');
            });
            flash('sucesso', 'Configurações do carrossel salvas.');
            redirecionar($pagina);
        }
    } elseif ($acao === 'restaurar' && isset($banners[$chave])) {
        db()->prepare('DELETE FROM carrossel_banners WHERE chave = ?')->execute([$chave]);
        registrarAlteracao('carrossel', null, 'editar', (isset($padrao[$chave]) ? 'Restaurou ' : 'Removeu ') . $banners[$chave]['rotulo']);
        flash('sucesso', isset($padrao[$chave]) ? 'Banner padrão restaurado.' : 'Banner removido.');
        redirecionar($pagina);
    } elseif ($acao === 'salvar' && ($chave === '' || isset($banners[$chave]))) {
        $banner = $banners[$chave] ?? $vazio;
        foreach ($limites as $campo => $limite) {
            $valor = post($campo);
            $banner[$campo] = is_string($valor) ? $valor : '';
            if (mb_strlen($banner[$campo]) > $limite || ($campo !== 'alt' && $banner[$campo] === '')) {
                $erros[] = "Revise o campo «{$campos[$campo]}».";
            }
        }
        if (!preg_match('~^(?:#[a-z0-9_-]+|[a-z0-9][a-z0-9/_-]*\.php(?:[?#][^\s\\\\]*)?)$~iD', $banner['destino'])) {
            $erros[] = 'Use um link do site, como catalogo.php?ofertas=1 ou #ofertas-temporada.';
        }
        $ordem = filter_var(post('ordem'), FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 999]]);
        if (!$ordem) $erros[] = 'A posição deve ficar entre 1 e 999.';
        $banner['ordem'] = $ordem ?: 60;
        $banner['ativo'] = post('ativo') === '1' ? 1 : 0;

        $arquivo = $_FILES['imagem'] ?? [];
        $enviou = ($arquivo['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
        $tipos = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
        $info = $enviou && $arquivo['error'] === UPLOAD_ERR_OK ? @getimagesize($arquivo['tmp_name']) : false;
        if ($enviou && (!$info || !isset($tipos[$info[2]]) || $arquivo['size'] > UPLOAD_MAX_BYTES)) {
            $erros[] = 'Envie uma imagem JPG, PNG ou WebP de até 2 MB.';
        } elseif (!$enviou && !$banner['imagem']) {
            $erros[] = 'Selecione uma imagem para o novo banner.';
        }
        $novoArquivo = null;
        if (!$erros && $enviou) {
            $dir = APP_ROOT . '/uploads/carrossel';
            if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
                $erros[] = 'A pasta do carrossel não está disponível.';
            } else {
                $nome = bin2hex(random_bytes(12)) . '.' . $tipos[$info[2]];
                if (move_uploaded_file($arquivo['tmp_name'], "$dir/$nome")) {
                    $banner['imagem'] = 'uploads/carrossel/' . $nome;
                    $novoArquivo = "$dir/$nome";
                } else {
                    $erros[] = 'Não foi possível salvar a imagem.';
                }
            }
        }
        if (!$erros) {
            try {
                transacao(function () use ($chave, $banner) {
                    $st = db()->prepare('INSERT INTO carrossel_banners (chave, rotulo, titulo, texto, botao, destino, imagem, alt, ordem, ativo)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE rotulo = VALUES(rotulo),
                        titulo = VALUES(titulo), texto = VALUES(texto), botao = VALUES(botao), destino = VALUES(destino),
                        imagem = VALUES(imagem), alt = VALUES(alt), ordem = VALUES(ordem), ativo = VALUES(ativo)');
                    $st->execute([$chave ?: bin2hex(random_bytes(12)), $banner['rotulo'], $banner['titulo'], $banner['texto'],
                        $banner['botao'], $banner['destino'], $banner['imagem'], $banner['alt'], $banner['ordem'], $banner['ativo']]);
                    registrarAlteracao('carrossel', null, $chave ? 'editar' : 'criar', $banner['rotulo']);
                });
            } catch (Throwable $ex) {
                if ($novoArquivo) unlink($novoArquivo);
                throw $ex;
            }
            flash('sucesso', 'Banner salvo.');
            redirecionar($pagina);
        }
    }
}

$titulo = 'Carrossel';
$menuAtivo = 'carrossel';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Carrossel da página inicial</h1>
<?php if ($erros): ?><p class="aviso aviso-vermelho" role="alert"><?= e(implode(' ', $erros)) ?></p><?php endif; ?>
<form class="cartao filtros-linha mb-2" method="post">
  <?= csrfCampo() ?><input type="hidden" name="acao" value="opcoes">
  <label class="check"><input type="checkbox" name="automatico" value="1" <?= $opcoes['automatico'] ? 'checked' : '' ?>> Troca automática</label>
  <div class="campo"><label for="segundos">Segundos por imagem</label><input id="segundos" name="segundos" type="number" min="3" max="30" value="<?= $opcoes['segundos'] ?>" required></div>
  <div class="campo"><label for="efeito">Transição</label><select id="efeito" name="efeito">
    <?php foreach ($efeitos as $id => $rotulo): ?><option value="<?= e($id) ?>" <?= $id === $opcoes['efeito'] ? 'selected' : '' ?>><?= e($rotulo) ?></option><?php endforeach; ?>
  </select></div>
  <button class="btn btn-primario" type="submit">Salvar reprodução</button>
</form>
<div class="layout-resumo">
  <section class="cartao">
    <div class="cartao-titulo"><h2>Banners</h2><a class="btn btn-neutro btn-sm" href="<?= e(url($pagina . '#editor-banner')) ?>">Novo banner</a></div>
    <div class="tabela-wrap"><table class="tabela">
      <thead><tr><th>Posição</th><th>Destaque</th><th>Visibilidade</th><th>Ações</th></tr></thead>
      <tbody><?php foreach ($banners as $item): ?>
        <tr>
          <td><?= (int) $item['ordem'] ?></td>
          <td><img class="mini" src="<?= e(fotoBanner($item['imagem'])) ?>" alt=""> <?= e($item['rotulo']) ?></td>
          <td><?= $item['ativo'] ? 'Visível' : 'Oculto' ?></td>
          <td><a href="<?= e(url($pagina . '?banner=' . $item['chave'] . '#editor-banner')) ?>">Editar</a></td>
        </tr>
      <?php endforeach; ?></tbody>
    </table></div>
  </section>
  <section class="cartao" id="editor-banner">
    <h2><?= $banner['chave'] ? 'Editar banner' : 'Novo banner' ?></h2>
    <form method="post" enctype="multipart/form-data">
      <?= csrfCampo() ?><input type="hidden" name="acao" value="salvar"><input type="hidden" name="chave" value="<?= e($banner['chave']) ?>">
      <?php foreach ($campos as $campo => $label): ?>
        <div class="campo">
          <label for="banner-<?= e($campo) ?>"><?= e($label) ?></label>
          <input id="banner-<?= e($campo) ?>" name="<?= e($campo) ?>" value="<?= e($banner[$campo]) ?>" maxlength="<?= $limites[$campo] ?>" <?= $campo === 'alt' ? '' : 'required' ?>>
        </div>
      <?php endforeach; ?>
      <div class="campo"><label for="imagem">Imagem panorâmica</label><input id="imagem" name="imagem" type="file" accept="image/jpeg,image/png,image/webp" <?= $banner['imagem'] ? '' : 'required' ?>></div>
      <div class="campo"><label for="ordem">Posição na sequência</label><input id="ordem" name="ordem" type="number" min="1" max="999" value="<?= (int) $banner['ordem'] ?>" required></div>
      <label class="check"><input type="checkbox" name="ativo" value="1" <?= $banner['ativo'] ? 'checked' : '' ?>> Exibir na loja</label>
      <button class="btn btn-primario btn-bloco mt-2" type="submit">Salvar banner</button>
    </form>
    <?php if ($banner['chave']): ?>
      <form method="post" class="mt-1" data-confirma="Confirmar esta alteração?">
        <?= csrfCampo() ?><input type="hidden" name="acao" value="restaurar"><input type="hidden" name="chave" value="<?= e($banner['chave']) ?>">
        <button class="btn btn-link btn-bloco" type="submit"><?= isset($padrao[$banner['chave']]) ? 'Restaurar banner padrão' : 'Remover banner' ?></button>
      </form>
    <?php endif; ?>
  </section>
</div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
