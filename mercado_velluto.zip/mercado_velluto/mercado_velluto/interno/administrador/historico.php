<?php
/** Histórico de alterações (auditoria) e de status dos pedidos. */
require __DIR__ . '/../../includes/bootstrap.php';
exigirPerfil('administrador');

$aba = get('aba') === 'pedidos' ? 'pedidos' : 'alteracoes';
$entidade = get('entidade');

if ($aba === 'alteracoes') {
    $params = [];
    $sql = 'SELECT l.*, u.nome, u.perfil FROM logs_alteracoes l LEFT JOIN usuarios u ON u.id = l.usuario_id';
    if ($entidade !== '') {
        $sql .= ' WHERE l.entidade = ?';
        $params[] = $entidade;
    }
    $st = db()->prepare($sql . ' ORDER BY l.criado_em DESC, l.id DESC LIMIT 300');
    $st->execute($params);
    $linhas = $st->fetchAll();
    $entidades = db()->query('SELECT DISTINCT entidade FROM logs_alteracoes ORDER BY entidade')->fetchAll(PDO::FETCH_COLUMN);
} else {
    $linhas = db()->query('SELECT h.*, u.nome FROM historico_pedidos h LEFT JOIN usuarios u ON u.id = h.usuario_id ORDER BY h.criado_em DESC, h.id DESC LIMIT 300')->fetchAll();
}

$titulo = 'Histórico de alterações';
$menuAtivo = 'historico';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Histórico</h1>
<div class="abas-status">
  <a href="?aba=alteracoes" class="<?= $aba === 'alteracoes' ? 'ativo' : '' ?>">Alterações administrativas e acessos</a>
  <a href="?aba=pedidos" class="<?= $aba === 'pedidos' ? 'ativo' : '' ?>">Status dos pedidos</a>
</div>
<?php if ($aba === 'alteracoes'): ?>
  <form class="filtros-linha" method="get"><input type="hidden" name="aba" value="alteracoes">
    <div class="campo"><label for="entidade">Entidade</label><select class="input" id="entidade" name="entidade" data-auto-envio><option value="">Todas</option>
      <?php foreach ($entidades as $en): ?><option <?= $en === $entidade ? 'selected' : '' ?>><?= e($en) ?></option><?php endforeach; ?></select></div>
  </form>
<?php endif; ?>
<div class="cartao"><div class="tabela-wrap"><table class="tabela">
  <?php if ($aba === 'alteracoes'): ?>
    <thead><tr><th>Data</th><th>Usuário</th><th>Entidade</th><th>Ação</th><th>Detalhes</th><th>IP</th></tr></thead>
    <tbody><?php foreach ($linhas as $l): ?>
      <tr><td><small><?= dataBr($l['criado_em']) ?></small></td><td><?= e($l['nome'] ?? 'Sistema') ?><br><small><?= e(PERFIL_ROTULO[$l['perfil']] ?? '') ?></small></td>
        <td><span class="badge"><?= e($l['entidade']) ?><?= $l['entidade_id'] ? ' #' . (int) $l['entidade_id'] : '' ?></span></td>
        <td><span class="badge <?= $l['acao'] === 'acesso_negado' ? 'badge-erro' : '' ?>"><?= e($l['acao']) ?></span></td><td><?= e($l['detalhes']) ?></td><td><small><?= e($l['ip']) ?></small></td></tr>
    <?php endforeach; ?></tbody>
  <?php else: ?>
    <thead><tr><th>Data</th><th>Pedido</th><th>Transição</th><th>Responsável</th><th>Descrição</th></tr></thead>
    <tbody><?php foreach ($linhas as $h): ?>
      <tr><td><small><?= dataBr($h['criado_em']) ?></small></td><td><a href="<?= e(url('interno/administrador/pedido.php?id=' . (int) $h['pedido_id'])) ?>">#<?= (int) $h['pedido_id'] ?></a></td>
        <td><small><?= $h['status_anterior'] && $h['status_anterior'] !== $h['status_novo'] ? e(statusRotulo($h['status_anterior'])) . ' → ' : '' ?></small><?= statusBadge($h['status_novo']) ?></td>
        <td><?= e($h['nome'] ?? 'Sistema') ?><br><small><?= e($h['perfil']) ?></small></td><td><?= e($h['descricao']) ?></td></tr>
    <?php endforeach; ?></tbody>
  <?php endif; ?>
</table></div></div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
