<?php
/** Lista de pedidos com filtros por status, cliente e período. */
require __DIR__ . '/../../includes/bootstrap.php';
exigirPerfil('administrador');

$status = array_key_exists(get('status'), STATUS_PEDIDO) ? get('status') : '';
$q = get('q');
$de = preg_match('/^\d{4}-\d{2}-\d{2}$/', get('de')) ? get('de') : '';
$ate = preg_match('/^\d{4}-\d{2}-\d{2}$/', get('ate')) ? get('ate') : '';

$where = ['1=1'];
$params = [];
if ($status) { $where[] = 'p.status = ?'; $params[] = $status; }
if ($q !== '') {
    if (ctype_digit(ltrim($q, '#'))) { $where[] = 'p.id = ?'; $params[] = (int) ltrim($q, '#'); }
    else { $where[] = '(u.nome LIKE ? OR u.email LIKE ?)'; $params[] = "%$q%"; $params[] = "%$q%"; }
}
if ($de) { $where[] = 'p.criado_em >= ?'; $params[] = $de . ' 00:00:00'; }
if ($ate) { $where[] = 'p.criado_em <= ?'; $params[] = $ate . ' 23:59:59'; }

$st = db()->prepare('SELECT p.*, u.nome AS cliente, s.nome AS separador, en.nome AS entregador, e.status AS entrega_status
                     FROM pedidos p JOIN usuarios u ON u.id = p.usuario_id
                     LEFT JOIN usuarios s ON s.id = p.separador_id
                     LEFT JOIN entregas e ON e.pedido_id = p.id LEFT JOIN usuarios en ON en.id = e.entregador_id
                     WHERE ' . implode(' AND ', $where) . ' ORDER BY p.criado_em DESC, p.id DESC LIMIT 300');
$st->execute($params);
$pedidos = $st->fetchAll();
$contagem = db()->query('SELECT status, COUNT(*) FROM pedidos GROUP BY status')->fetchAll(PDO::FETCH_KEY_PAIR);

$titulo = 'Pedidos';
$menuAtivo = 'pedidos';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Pedidos</h1>
<div class="abas-status">
  <a href="?" class="<?= !$status ? 'ativo' : '' ?>">Todos (<?= array_sum($contagem) ?>)</a>
  <?php foreach (STATUS_PEDIDO as $s => $rot): ?>
    <a href="?status=<?= e($s) ?>" class="<?= $status === $s ? 'ativo' : '' ?>"><?= e($rot) ?> (<?= (int) ($contagem[$s] ?? 0) ?>)</a>
  <?php endforeach; ?>
</div>
<form class="filtros-linha cartao" method="get">
  <?php if ($status): ?><input type="hidden" name="status" value="<?= e($status) ?>"><?php endif; ?>
  <div class="campo"><label for="q">Pedido ou cliente</label><input class="input" id="q" name="q" value="<?= e($q) ?>" placeholder="#12 ou nome/e-mail"></div>
  <div class="campo"><label for="de">De</label><input class="input" type="date" id="de" name="de" value="<?= e($de) ?>"></div>
  <div class="campo"><label for="ate">Até</label><input class="input" type="date" id="ate" name="ate" value="<?= e($ate) ?>"></div>
  <button class="btn btn-neutro" type="submit">Filtrar</button>
</form>
<div class="cartao mt-2"><div class="tabela-wrap"><table class="tabela">
  <thead><tr><th>Pedido</th><th>Cliente</th><th>Status</th><th>Separador</th><th>Entrega</th><th>Pagamento</th><th class="num">Total</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($pedidos as $p): ?>
    <tr>
      <td><b>#<?= (int) $p['id'] ?></b><br><small><?= dataBr($p['criado_em']) ?></small></td>
      <td><?= e($p['cliente']) ?></td>
      <td><?= statusBadge($p['status']) ?></td>
      <td><?= e($p['separador'] ?? '—') ?></td>
      <td><?= $p['entrega_status'] ? '<span class="badge st-' . e($p['entrega_status']) . '">' . e(STATUS_ENTREGA[$p['entrega_status']]) . '</span><br><small>' . e($p['entregador'] ?? '') . '</small>' : '—' ?></td>
      <td><?= e(METODOS_PAGAMENTO[$p['metodo_pagamento']]) ?></td>
      <td class="num"><?= dinheiro($p['total']) ?></td>
      <td><a class="btn btn-neutro btn-sm" href="<?= e(url('interno/administrador/pedido.php?id=' . (int) $p['id'])) ?>">Detalhes</a></td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$pedidos): ?><tr><td colspan="8" class="texto-centro muted">Nenhum pedido encontrado.</td></tr><?php endif; ?>
  </tbody>
</table></div></div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
