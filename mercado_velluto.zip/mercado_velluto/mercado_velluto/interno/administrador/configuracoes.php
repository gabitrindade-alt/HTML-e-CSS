<?php
/** Configurações gerais da loja. */
require __DIR__ . '/../../includes/bootstrap.php';
exigirPerfil('administrador');

$regras = [
    'nome_loja'                 => fn($v) => mb_strlen($v) >= 2,
    'slogan'                    => fn($v) => mb_strlen($v) >= 3,
    'email_contato'             => fn($v) => (bool) filter_var($v, FILTER_VALIDATE_EMAIL),
    'telefone_contato'          => fn($v) => mb_strlen($v) >= 8,
    'valor_minimo_pedido'       => fn($v) => is_numeric($v) && $v >= 0,
    'tolerancia_ajuste_percent' => fn($v) => is_numeric($v) && $v >= 0 && $v <= 50,
    'aviso_topo'                => fn($v) => mb_strlen($v) <= 200,
];
$cfg = db()->query('SELECT * FROM configuracoes ORDER BY chave')->fetchAll();
$cfg = array_values(array_filter($cfg, static fn ($c) => !str_starts_with($c['chave'], 'carrossel_')));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $erros = [];
    $alteradas = [];
    foreach ($cfg as $c) {
        $chave = $c['chave'];
        if (!isset($_POST['cfg'][$chave])) continue;
        $v = trim((string) $_POST['cfg'][$chave]);
        if (in_array($chave, ['valor_minimo_pedido', 'tolerancia_ajuste_percent'], true)) {
            $v = (string) paraNumero($v);
        }
        if (isset($regras[$chave]) && !$regras[$chave]($v)) {
            $erros[] = 'Valor inválido para "' . $c['descricao'] . '".';
            continue;
        }
        if ($v !== $c['valor']) {
            db()->prepare('UPDATE configuracoes SET valor = ? WHERE chave = ?')->execute([mb_substr($v, 0, 500), $chave]);
            $alteradas[] = "$chave: \"{$c['valor']}\" → \"$v\"";
        }
    }
    if ($alteradas) registrarAlteracao('configuracao', null, 'editar', implode('; ', $alteradas));
    $erros ? flash('erro', implode(' ', $erros)) : flash('sucesso', $alteradas ? 'Configurações salvas.' : 'Nenhuma alteração.');
    redirecionar('interno/administrador/configuracoes.php');
}

$titulo = 'Configurações';
$menuAtivo = 'configuracoes';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Configurações gerais</h1>
<div class="grid-2">
  <form class="cartao" method="post">
    <?= csrfCampo() ?>
    <?php foreach ($cfg as $c): ?>
      <div class="campo"><label for="c-<?= e($c['chave']) ?>"><?= e($c['descricao']) ?></label>
        <input id="c-<?= e($c['chave']) ?>" name="cfg[<?= e($c['chave']) ?>]" value="<?= e($c['valor']) ?>"></div>
    <?php endforeach; ?>
    <button class="btn btn-primario" type="submit">Salvar configurações</button>
  </form>
  <div class="cartao">
    <h3>Atalhos de configuração</h3>
    <p><a href="<?= e(url('interno/administrador/carrossel.php')) ?>"><?= icone('grade', 'ico-sm') ?> Carrossel da página inicial</a></p>
    <p><a href="<?= e(url('interno/administrador/areas.php')) ?>"><?= icone('mapa', 'ico-sm') ?> Áreas de entrega e valores de frete</a></p>
    <p><a href="<?= e(url('interno/administrador/funcionarios.php')) ?>"><?= icone('pessoas', 'ico-sm') ?> Funcionários e senhas</a></p>
    <p><a href="<?= e(url('interno/administrador/categorias.php')) ?>"><?= icone('grade', 'ico-sm') ?> Categorias</a></p>
    <hr>
    <h3>Ambiente</h3>
    <dl class="info-lista">
      <dt>PHP</dt><dd><?= e(PHP_VERSION) ?></dd>
      <dt>Banco</dt><dd><?= e(db()->getAttribute(PDO::ATTR_DRIVER_NAME)) ?> <?= e(db()->getAttribute(PDO::ATTR_SERVER_VERSION)) ?></dd>
      <dt>Endereço base</dt><dd><?= e(baseUrl()) ?></dd>
      <dt>Fuso horário</dt><dd><?= e(date_default_timezone_get()) ?></dd>
    </dl>
  </div>
</div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
