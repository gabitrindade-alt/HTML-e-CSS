<?php
/** Administração de produtos: listar, visualizar, excluir/arquivar, ativar. */
require __DIR__ . '/../../includes/bootstrap.php';
exigirPerfil('administrador');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) post('id');
    $st = db()->prepare('SELECT * FROM produtos WHERE id = ?');
    $st->execute([$id]);
    $p = $st->fetch();
    if (!$p) {
        flash('erro', 'Produto não encontrado.');
        redirecionar('interno/administrador/produtos.php');
    }
    if (post('acao') === 'excluir') {
        $usado = db()->prepare('SELECT (SELECT COUNT(*) FROM itens_pedido WHERE produto_id = ?) + (SELECT COUNT(*) FROM substituicoes WHERE produto_original_id = ? OR produto_sugerido_id = ?)');
        $usado->execute([$id, $id, $id]);
        if ((int) $usado->fetchColumn() > 0) {
            // Mantém o histórico dos pedidos: o produto é apenas desativado.
            db()->prepare('UPDATE produtos SET ativo = 0, destaque = 0, atualizado_em = ? WHERE id = ?')->execute([agora(), $id]);
            registrarAlteracao('produto', $id, 'arquivar', 'Produto "' . $p['nome'] . '" desativado (possui pedidos vinculados).');
            flash('aviso', '"' . $p['nome'] . '" possui pedidos vinculados e foi desativado (removido da loja) em vez de excluído.');
        } else {
            db()->prepare('DELETE FROM produtos WHERE id = ?')->execute([$id]);
            if ($p['imagem'] && str_starts_with($p['imagem'], 'uploads/') && is_file(APP_ROOT . '/' . $p['imagem'])) {
                @unlink(APP_ROOT . '/' . $p['imagem']);
            }
            registrarAlteracao('produto', $id, 'excluir', 'Produto "' . $p['nome'] . '" excluído.');
            flash('sucesso', 'Produto "' . $p['nome'] . '" excluído.');
        }
    } elseif (post('acao') === 'alternar') {
        $novo = (int) $p['ativo'] ? 0 : 1;
        db()->prepare('UPDATE produtos SET ativo = ?, atualizado_em = ? WHERE id = ?')->execute([$novo, agora(), $id]);
        registrarAlteracao('produto', $id, $novo ? 'ativar' : 'desativar', 'Produto "' . $p['nome'] . '"');
        flash('sucesso', 'Produto ' . ($novo ? 'ativado' : 'desativado') . '.');
    }
    voltar('interno/administrador/produtos.php');
}

$q = get('q');
$cat = (int) get('categoria');
$situacao = get('situacao');
$where = ['1=1'];
$params = [];
if ($q !== '') {
    $where[] = '(p.nome LIKE ? OR p.marca LIKE ?)';
    $params[] = "%$q%";
    $params[] = "%$q%";
}
if ($cat) {
    $ids = idsCategoriaComFilhas($cat) ?: [$cat];
    $where[] = 'p.categoria_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')';
    array_push($params, ...$ids);
}
if ($situacao === 'ativos') $where[] = 'p.ativo = 1';
if ($situacao === 'inativos') $where[] = 'p.ativo = 0';
if ($situacao === 'promo') $where[] = precoAtualSql() . ' < p.preco';
if ($situacao === 'baixo') $where[] = 'p.estoque <= p.estoque_minimo';

$st = db()->prepare('SELECT p.*, c.nome AS categoria FROM produtos p JOIN categorias c ON c.id = p.categoria_id WHERE ' . implode(' AND ', $where) . ' ORDER BY p.ativo DESC, p.nome');
$st->execute($params);
$produtos = $st->fetchAll();
$categorias = db()->query('SELECT id, nome, pai_id FROM categorias ORDER BY COALESCE(pai_id, id), pai_id IS NOT NULL, ordem, nome')->fetchAll();

$titulo = 'Produtos';
$menuAtivo = 'produtos';
require APP_ROOT . '/includes/header_interno.php';
?>
<div class="flex entre flex-wrap mb-2">
  <h1 class="mb-0">Produtos <small class="muted">(<?= count($produtos) ?>)</small></h1>
  <a class="btn btn-primario" href="<?= e(url('interno/administrador/produto_form.php')) ?>"><?= icone('mais', 'ico-sm') ?> Novo produto</a>
</div>
<form class="filtros-linha cartao" method="get">
  <div class="campo"><label for="q">Buscar</label><input class="input" id="q" name="q" value="<?= e($q) ?>" placeholder="Nome ou marca"></div>
  <div class="campo"><label for="categoria">Categoria</label><select class="input" id="categoria" name="categoria"><option value="">Todas</option>
    <?php foreach ($categorias as $c): ?><option value="<?= (int) $c['id'] ?>" <?= $cat === (int) $c['id'] ? 'selected' : '' ?>><?= $c['pai_id'] ? '— ' : '' ?><?= e($c['nome']) ?></option><?php endforeach; ?></select></div>
  <div class="campo"><label for="situacao">Situação</label><select class="input" id="situacao" name="situacao">
    <?php foreach (['' => 'Todas', 'ativos' => 'Ativos', 'inativos' => 'Inativos', 'promo' => 'Em promoção', 'baixo' => 'Estoque baixo'] as $k => $v): ?>
      <option value="<?= e($k) ?>" <?= $situacao === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?></select></div>
  <button class="btn btn-neutro" type="submit">Filtrar</button>
</form>

<div class="cartao mt-2"><div class="tabela-wrap"><table class="tabela">
  <thead><tr><th></th><th>Produto</th><th>Categoria</th><th class="num">Preço</th><th class="num">Promoção</th><th class="num">Estoque</th><th>Situação</th><th>Ações</th></tr></thead>
  <tbody>
  <?php foreach ($produtos as $p): ?>
    <tr>
      <td><img class="mini" src="<?= e(imagemProduto($p)) ?>" alt=""></td>
      <td><b><?= e($p['nome']) ?></b><br><small><?= e($p['marca']) ?> · <?= e($p['embalagem']) ?><?= $p['vendido_por'] === 'peso' ? ' · por kg' : '' ?></small></td>
      <td><?= e($p['categoria']) ?></td>
      <td class="num"><?= dinheiro($p['preco']) ?></td>
      <td class="num"><?= emPromocao($p) ? dinheiro(precoAtual($p)) : '—' ?></td>
      <td class="num"><span class="badge <?= (float) $p['estoque'] <= 0 ? 'badge-erro' : (estoqueBaixo($p) ? 'badge-alerta' : 'badge-ok') ?>"><?= e(qtdFormatada($p['estoque'], $p['vendido_por'])) ?></span></td>
      <td><?= (int) $p['ativo'] ? '<span class="badge badge-ok">Ativo</span>' : '<span class="badge badge-erro">Inativo</span>' ?><?= (int) $p['destaque'] ? ' <span class="badge">Destaque</span>' : '' ?></td>
      <td><div class="acoes-linha">
        <a class="btn btn-neutro btn-sm" href="<?= e(url('produto.php?id=' . (int) $p['id'])) ?>" target="_blank" title="Visualizar na loja"><?= icone('olho', 'ico-sm') ?></a>
        <a class="btn btn-neutro btn-sm" href="<?= e(url('interno/administrador/produto_form.php?id=' . (int) $p['id'])) ?>" title="Editar"><?= icone('editar', 'ico-sm') ?></a>
        <form method="post"><?= csrfCampo() ?><input type="hidden" name="id" value="<?= (int) $p['id'] ?>"><input type="hidden" name="acao" value="alternar">
          <button class="btn btn-neutro btn-sm" type="submit"><?= (int) $p['ativo'] ? 'Desativar' : 'Ativar' ?></button></form>
        <form method="post" data-confirma="Excluir &quot;<?= e($p['nome']) ?>&quot;? Se houver pedidos vinculados, ele será apenas desativado."><?= csrfCampo() ?>
          <input type="hidden" name="id" value="<?= (int) $p['id'] ?>"><input type="hidden" name="acao" value="excluir">
          <button class="btn btn-perigo btn-sm" type="submit" title="Excluir"><?= icone('lixeira', 'ico-sm') ?></button></form>
      </div></td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$produtos): ?><tr><td colspan="8" class="texto-centro muted">Nenhum produto encontrado.</td></tr><?php endif; ?>
  </tbody>
</table></div></div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
