<?php
/** Cadastro, edição e exclusão de categorias e subcategorias. */
require __DIR__ . '/../../includes/bootstrap.php';
exigirPerfil('administrador');

$editar = null;
if (get('editar')) {
    $st = db()->prepare('SELECT * FROM categorias WHERE id = ?');
    $st->execute([(int) get('editar')]);
    $editar = $st->fetch() ?: null;
}
$erros = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = post('acao');
    $id = (int) post('id');
    if ($acao === 'excluir') {
        $st = db()->prepare('SELECT nome, (SELECT COUNT(*) FROM produtos WHERE categoria_id = c.id) AS prods, (SELECT COUNT(*) FROM categorias f WHERE f.pai_id = c.id) AS filhas FROM categorias c WHERE c.id = ?');
        $st->execute([$id]);
        $c = $st->fetch();
        if (!$c) {
            flash('erro', 'Categoria não encontrada.');
        } elseif ($c['prods'] || $c['filhas']) {
            flash('erro', 'Não é possível excluir "' . $c['nome'] . '": há ' . $c['prods'] . ' produto(s) e ' . $c['filhas'] . ' subcategoria(s) vinculados. Mova-os ou desative a categoria.');
        } else {
            db()->prepare('DELETE FROM categorias WHERE id = ?')->execute([$id]);
            registrarAlteracao('categoria', $id, 'excluir', 'Categoria "' . $c['nome'] . '" excluída.');
            flash('sucesso', 'Categoria excluída.');
        }
        redirecionar('interno/administrador/categorias.php');
    }
    if ($acao === 'salvar') {
        $nome = mb_substr(post('nome'), 0, 80);
        $pai = (int) post('pai_id') ?: null;
        $icone = mb_substr(post('icone'), 0, 8);
        $cor = preg_match('/^#[0-9A-Fa-f]{6}$/', post('cor')) ? strtoupper(post('cor')) : '#EADFD3';
        $descricao = mb_substr(post('descricao'), 0, 255);
        $ordem = (int) post('ordem');
        $ativo = post('ativo') ? 1 : 0;
        if (mb_strlen($nome) < 2) $erros[] = 'Informe o nome da categoria.';
        if ($pai && $pai === $id) $erros[] = 'Uma categoria não pode ser subcategoria dela mesma.';
        if ($pai) {
            $st = db()->prepare('SELECT pai_id FROM categorias WHERE id = ?');
            $st->execute([$pai]);
            $r = $st->fetch();
            if (!$r) $erros[] = 'Categoria pai inválida.';
            elseif ($r['pai_id']) $erros[] = 'Use apenas dois níveis (categoria → subcategoria).';
        }
        if ($id && $pai) {
            $st = db()->prepare('SELECT COUNT(*) FROM categorias WHERE pai_id = ?');
            $st->execute([$id]);
            if ($st->fetchColumn()) $erros[] = 'Esta categoria possui subcategorias e não pode virar subcategoria.';
        }
        $slug = slugify($nome);
        $st = db()->prepare('SELECT COUNT(*) FROM categorias WHERE slug = ? AND id <> ?');
        $st->execute([$slug, $id]);
        if ($st->fetchColumn()) $erros[] = 'Já existe uma categoria com esse nome.';
        if (!$erros) {
            if ($id) {
                db()->prepare('UPDATE categorias SET nome=?, slug=?, pai_id=?, icone=?, cor=?, descricao=?, ordem=?, ativo=? WHERE id=?')
                    ->execute([$nome, $slug, $pai, $icone, $cor, $descricao, $ordem, $ativo, $id]);
                registrarAlteracao('categoria', $id, 'editar', 'Categoria "' . $nome . '" editada.');
            } else {
                db()->prepare('INSERT INTO categorias (nome, slug, pai_id, icone, cor, descricao, ordem, ativo, criado_em) VALUES (?,?,?,?,?,?,?,?,?)')
                    ->execute([$nome, $slug, $pai, $icone, $cor, $descricao, $ordem, $ativo, agora()]);
                $id = (int) db()->lastInsertId();
                registrarAlteracao('categoria', $id, 'criar', 'Categoria "' . $nome . '" criada.');
            }
            flash('sucesso', 'Categoria salva.');
            redirecionar('interno/administrador/categorias.php');
        }
        $editar = ['id' => $id, 'nome' => $nome, 'pai_id' => $pai, 'icone' => $icone, 'cor' => $cor, 'descricao' => $descricao, 'ordem' => $ordem, 'ativo' => $ativo];
    }
}

$cats = db()->query('SELECT c.*, (SELECT COUNT(*) FROM produtos p WHERE p.categoria_id = c.id) AS prods, pai.nome AS pai_nome
                     FROM categorias c LEFT JOIN categorias pai ON pai.id = c.pai_id
                     ORDER BY COALESCE(c.pai_id, c.id), c.pai_id IS NOT NULL, c.ordem, c.nome')->fetchAll();
$principais = array_filter($cats, fn($c) => !$c['pai_id']);
$f = $editar ?: ['id' => 0, 'nome' => '', 'pai_id' => null, 'icone' => '🛒', 'cor' => '#EADFD3', 'descricao' => '', 'ordem' => 0, 'ativo' => 1];

$titulo = 'Categorias';
$menuAtivo = 'categorias';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Categorias</h1>
<?php if ($erros): ?><div class="aviso aviso-vermelho mb-2"><?= implode('<br>', array_map('e', $erros)) ?></div><?php endif; ?>
<div class="layout-resumo" style="grid-template-columns: 1fr 340px">
  <div class="cartao"><div class="tabela-wrap"><table class="tabela">
    <thead><tr><th></th><th>Categoria</th><th class="num">Produtos</th><th>Situação</th><th>Ações</th></tr></thead>
    <tbody><?php foreach ($cats as $c): ?>
      <tr>
        <td><span class="categoria-icone" style="width:38px;height:38px;font-size:1.2rem;background:<?= e($c['cor']) ?>"><?= e($c['icone']) ?></span></td>
        <td><?= $c['pai_id'] ? '<span class="muted">— </span>' : '' ?><b><?= e($c['nome']) ?></b><br><small><?= e($c['descricao']) ?></small></td>
        
        <td class="num"><?= (int) $c['prods'] ?></td>
        <td><?= (int) $c['ativo'] ? '<span class="badge badge-ok">Ativa</span>' : '<span class="badge badge-erro">Inativa</span>' ?></td>
        <td><div class="acoes-linha">
          <a class="btn btn-neutro btn-sm" href="?editar=<?= (int) $c['id'] ?>"><?= icone('editar', 'ico-sm') ?></a>
          <form method="post" data-confirma="Excluir a categoria &quot;<?= e($c['nome']) ?>&quot;?"><?= csrfCampo() ?><input type="hidden" name="acao" value="excluir"><input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
            <button class="btn btn-perigo btn-sm" type="submit"><?= icone('lixeira', 'ico-sm') ?></button></form>
        </div></td>
      </tr>
    <?php endforeach; ?></tbody>
  </table></div></div>

  <form class="cartao resumo" method="post">
    <?= csrfCampo() ?><input type="hidden" name="acao" value="salvar"><input type="hidden" name="id" value="<?= (int) $f['id'] ?>">
    <h3><?= $f['id'] ? 'Editar categoria' : 'Nova categoria' ?></h3>
    <div class="campo"><label for="nome">Nome *</label><input id="nome" name="nome" value="<?= e($f['nome']) ?>" required maxlength="80"></div>
    <div class="campo"><label for="pai_id">Subcategoria de</label><select id="pai_id" name="pai_id"><option value="">— (categoria principal)</option>
      <?php foreach ($principais as $p): if ((int) $p['id'] === (int) $f['id']) continue; ?><option value="<?= (int) $p['id'] ?>" <?= (int) $f['pai_id'] === (int) $p['id'] ? 'selected' : '' ?>><?= e($p['nome']) ?></option><?php endforeach; ?></select></div>
    <div class="grid-2">
      <div class="campo"><label for="icone">Ícone (emoji)</label><input id="icone" name="icone" value="<?= e($f['icone']) ?>" maxlength="8"></div>
      <div class="campo"><label for="cor">Cor</label><input id="cor" type="color" name="cor" value="<?= e($f['cor']) ?>" style="height:42px;padding:4px"></div>
    </div>
    <div class="campo"><label for="descricao">Descrição</label><input id="descricao" name="descricao" value="<?= e($f['descricao']) ?>" maxlength="255"></div>
    <div class="campo"><label for="ordem">Ordem de exibição</label><input id="ordem" type="number" name="ordem" value="<?= (int) $f['ordem'] ?>"></div>
    <label class="check"><input type="checkbox" name="ativo" value="1" <?= (int) $f['ativo'] ? 'checked' : '' ?>> Ativa</label>
    <button class="btn btn-primario btn-bloco mt-2" type="submit">Salvar categoria</button>
    <?php if ($f['id']): ?><a class="btn btn-link btn-bloco mt-1" href="<?= e(url('interno/administrador/categorias.php')) ?>">Nova categoria</a><?php endif; ?>
  </form>
</div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
