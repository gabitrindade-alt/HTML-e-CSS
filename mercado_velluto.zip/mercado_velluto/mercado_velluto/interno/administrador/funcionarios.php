<?php
/** Gestão de funcionários (administradores, separadores e entregadores). */
require __DIR__ . '/../../includes/bootstrap.php';
$eu = exigirPerfil('administrador');

$editar = null;
if (get('editar')) {
    $st = db()->prepare("SELECT * FROM usuarios WHERE id = ? AND perfil <> 'cliente'");
    $st->execute([(int) get('editar')]);
    $editar = $st->fetch() ?: null;
}
$erros = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = post('acao');
    $id = (int) post('id');
    if ($acao === 'alternar') {
        if ($id === (int) $eu['id']) {
            flash('erro', 'Você não pode desativar a própria conta.');
        } else {
            $st = db()->prepare("SELECT nome, ativo FROM usuarios WHERE id = ? AND perfil <> 'cliente'");
            $st->execute([$id]);
            if ($f = $st->fetch()) {
                $novo = (int) $f['ativo'] ? 0 : 1;
                db()->prepare('UPDATE usuarios SET ativo = ?, atualizado_em = ? WHERE id = ?')->execute([$novo, agora(), $id]);
                registrarAlteracao('funcionario', $id, $novo ? 'ativar' : 'desativar', $f['nome']);
                flash('sucesso', 'Funcionário ' . ($novo ? 'reativado' : 'desativado') . '.');
            }
        }
        redirecionar('interno/administrador/funcionarios.php');
    }
    if ($acao === 'salvar') {
        $nome = mb_substr(post('nome'), 0, 120);
        $email = mb_strtolower(post('email'));
        $perfil = post('perfil');
        $tel = mb_substr(post('telefone'), 0, 20);
        $senha = (string) ($_POST['senha'] ?? '');
        if (mb_strlen($nome) < 3) $erros[] = 'Informe o nome.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $erros[] = 'E-mail inválido.';
        elseif (!str_ends_with($email, '@velluto.com')) $erros[] = 'Funcionários devem usar e-mail corporativo @velluto.com.';
        if (!in_array($perfil, PERFIS_INTERNOS, true)) $erros[] = 'Perfil inválido.';
        if ($id && $id === (int) $eu['id'] && $perfil !== 'administrador') $erros[] = 'Você não pode remover o próprio perfil de administrador.';
        if ((!$id && $senha === '') || ($senha !== '' && (strlen($senha) < 8 || strlen($senha) > 72 || str_contains($senha, "\0") || !preg_match('/[A-Za-z]/', $senha) || !preg_match('/\d/', $senha)))) {
            $erros[] = 'Senha: de 8 a 72 bytes, com letras e números' . ($id ? ' (deixe em branco para manter).' : '.');
        }
        $st = db()->prepare('SELECT COUNT(*) FROM usuarios WHERE email = ? AND id <> ?');
        $st->execute([$email, $id]);
        if ($st->fetchColumn()) $erros[] = 'E-mail já cadastrado.';
        if (!$erros) {
            if ($id) {
                $sql = 'UPDATE usuarios SET nome=?, email=?, perfil=?, telefone=?, atualizado_em=?' . ($senha !== '' ? ', senha_hash=?' : '') . " WHERE id=? AND perfil <> 'cliente'";
                $v = [$nome, $email, $perfil, $tel ?: null, agora()];
                if ($senha !== '') $v[] = password_hash($senha, PASSWORD_DEFAULT);
                $v[] = $id;
                db()->prepare($sql)->execute($v);
                registrarAlteracao('funcionario', $id, 'editar', "$nome ($perfil)" . ($senha !== '' ? ' — senha redefinida' : ''));
            } else {
                db()->prepare('INSERT INTO usuarios (nome, email, senha_hash, perfil, telefone, criado_em) VALUES (?,?,?,?,?,?)')
                    ->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT), $perfil, $tel ?: null, agora()]);
                $id = (int) db()->lastInsertId();
                registrarAlteracao('funcionario', $id, 'criar', "$nome ($perfil)");
            }
            flash('sucesso', 'Funcionário salvo.');
            redirecionar('interno/administrador/funcionarios.php');
        }
        $editar = ['id' => $id, 'nome' => $nome, 'email' => $email, 'perfil' => $perfil, 'telefone' => $tel];
    }
}

$func = db()->query("SELECT u.*,
    (SELECT COUNT(*) FROM pedidos p WHERE p.separador_id = u.id AND p.separacao_concluida_em IS NOT NULL) AS separados,
    (SELECT COUNT(*) FROM entregas e WHERE e.entregador_id = u.id AND e.status = 'entregue') AS entregues
    FROM usuarios u WHERE u.perfil <> 'cliente' ORDER BY u.perfil, u.nome")->fetchAll();
$f = $editar ?: ['id' => 0, 'nome' => '', 'email' => '', 'perfil' => 'separador', 'telefone' => ''];

$titulo = 'Funcionários';
$menuAtivo = 'funcionarios';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Funcionários</h1>
<?php if ($erros): ?><div class="aviso aviso-vermelho mb-2"><?= implode('<br>', array_map('e', $erros)) ?></div><?php endif; ?>
<div class="layout-resumo">
  <div class="cartao"><div class="tabela-wrap"><table class="tabela">
    <thead><tr><th>Nome</th><th>Perfil</th><th class="num">Produtividade</th><th>Último login</th><th>Situação</th><th></th></tr></thead>
    <tbody><?php foreach ($func as $x): ?>
      <tr><td><b><?= e($x['nome']) ?></b><br><small><?= e($x['email']) ?></small></td>
        <td><span class="badge"><?= e(PERFIL_ROTULO[$x['perfil']]) ?></span></td>
        <td class="num"><small><?= $x['perfil'] === 'separador' ? (int) $x['separados'] . ' separações' : ($x['perfil'] === 'entregador' ? (int) $x['entregues'] . ' entregas' : '—') ?></small></td>
        <td><small><?= dataBr($x['ultimo_login']) ?><?= $x['senha_hash'] ? '' : '<br><span class="badge badge-alerta">sem senha</span>' ?></small></td>
        <td><?= (int) $x['ativo'] ? '<span class="badge badge-ok">Ativo</span>' : '<span class="badge badge-erro">Inativo</span>' ?></td>
        <td><div class="acoes-linha"><a class="btn btn-neutro btn-sm" href="?editar=<?= (int) $x['id'] ?>"><?= icone('editar', 'ico-sm') ?></a>
          <?php if ((int) $x['id'] !== (int) $eu['id']): ?>
          <form method="post" data-confirma="Alterar a situação de <?= e($x['nome']) ?>?"><?= csrfCampo() ?><input type="hidden" name="acao" value="alternar"><input type="hidden" name="id" value="<?= (int) $x['id'] ?>">
            <button class="btn btn-neutro btn-sm" type="submit"><?= (int) $x['ativo'] ? 'Desativar' : 'Ativar' ?></button></form>
          <?php endif; ?></div></td></tr>
    <?php endforeach; ?></tbody>
  </table></div></div>
  <form class="cartao resumo" id="cadastro-funcionario" method="post" autocomplete="off">
    <?= csrfCampo() ?><input type="hidden" name="acao" value="salvar"><input type="hidden" name="id" value="<?= (int) $f['id'] ?>">
    <h3><?= $f['id'] ? 'Editar funcionário' : 'Novo funcionário' ?></h3>
    <div class="campo"><label for="nome">Nome *</label><input id="nome" name="nome" value="<?= e($f['nome']) ?>" required></div>
    <div class="campo"><label for="email">E-mail corporativo *</label><input id="email" type="email" name="email" value="<?= e($f['email']) ?>" placeholder="nome@velluto.com" required></div>
    <div class="campo"><label for="perfil">Perfil *</label><select id="perfil" name="perfil">
      <?php foreach (PERFIS_INTERNOS as $p): ?><option value="<?= $p ?>" <?= $f['perfil'] === $p ? 'selected' : '' ?>><?= e(PERFIL_ROTULO[$p]) ?></option><?php endforeach; ?></select></div>
    <div class="campo"><label for="telefone">Telefone</label><input id="telefone" name="telefone" value="<?= e($f['telefone']) ?>" data-mascara="telefone"></div>
    <div class="campo"><label for="senha"><?= $f['id'] ? 'Nova senha (opcional)' : 'Senha *' ?></label><input id="senha" type="password" name="senha" autocomplete="new-password" minlength="8" maxlength="72" <?= $f['id'] ? '' : 'required' ?>></div>
    <button class="btn btn-primario btn-bloco" type="submit"><?= $f['id'] ? 'Salvar alterações' : 'Cadastrar funcionário' ?></button>
    <?php if ($f['id']): ?><a class="btn btn-link btn-bloco mt-1" href="<?= e(url('interno/administrador/funcionarios.php')) ?>">Novo funcionário</a><?php endif; ?>
  </form>
</div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
