<?php
/** Dashboard administrativo — dados reais do banco. */
require __DIR__ . '/../../includes/bootstrap.php';
require APP_ROOT . '/includes/graficos.php';
exigirPerfil('administrador');

$validos = "status NOT IN ('cancelado','aguardando_pagamento')";
$kpi = [
    'pedidos'      => (int) db()->query('SELECT COUNT(*) FROM pedidos')->fetchColumn(),
    'vendas'       => (float) db()->query("SELECT COALESCE(SUM(total),0) FROM pedidos WHERE $validos")->fetchColumn(),
    'produtos'     => (int) db()->query('SELECT COUNT(*) FROM produtos WHERE ativo = 1')->fetchColumn(),
    'clientes'     => (int) db()->query("SELECT COUNT(*) FROM usuarios WHERE perfil = 'cliente'")->fetchColumn(),
    'estoque'      => (int) db()->query('SELECT COUNT(*) FROM produtos WHERE ativo = 1 AND estoque <= estoque_minimo')->fetchColumn(),
    'andamento'    => (int) db()->query("SELECT COUNT(*) FROM pedidos WHERE status NOT IN ('concluido','cancelado')")->fetchColumn(),
    'ocorrencias'  => (int) db()->query("SELECT COUNT(*) FROM ocorrencias WHERE status = 'aberta'")->fetchColumn(),
];
$concluidos = (int) db()->query("SELECT COUNT(*) FROM pedidos WHERE status = 'concluido'")->fetchColumn();
$ticket = $concluidos ? (float) db()->query("SELECT AVG(total) FROM pedidos WHERE status = 'concluido'")->fetchColumn() : 0;

// Histórico demonstrativo mensal separado dos pedidos reais.
$ano = (int) date('Y');
$qtdAno = (int) db()->query("SELECT COUNT(*) FROM pedidos WHERE YEAR(criado_em) = $ano")->fetchColumn();
$meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
$dataInicioHistorico = db()->query('SELECT MIN(periodo) FROM vendas_demo_mensais')->fetchColumn();
if (!$dataInicioHistorico) {
    throw new RuntimeException('Importe database/vendas_demo.sql para carregar o histórico demonstrativo do gráfico.');
}
$inicioHistorico = new DateTimeImmutable($dataInicioHistorico);
$anoInicialHistorico = (int) $inicioHistorico->format('Y');
$anoFinalHistorico = max($anoInicialHistorico, (int) date('Y'));
$anosHistorico = range($anoInicialHistorico, $anoFinalHistorico);
$anoSelecionado = filter_var(get('ano'), FILTER_VALIDATE_INT);
if ($anoSelecionado === false || !in_array($anoSelecionado, $anosHistorico, true)) {
    $anoSelecionado = $anoFinalHistorico;
}
$inicioAno = new DateTimeImmutable($anoSelecionado . '-01-01');
$fimAno = $inicioAno->modify('+1 year');
$st = db()->prepare("SELECT MONTH(periodo) AS mes, SUM(valor) AS vendas
    FROM vendas_demo_mensais
    WHERE periodo >= ? AND periodo < ?
    GROUP BY MONTH(periodo)");
$st->execute([$inicioAno->format('Y-m-d'), $fimAno->format('Y-m-d')]);
$porMes = [];
foreach ($st as $linha) $porMes[(int) $linha['mes']] = (float) $linha['vendas'];
$rotulos = $valores = [];
for ($mes = 1; $mes <= 12; $mes++) {
    $rotulos[] = $meses[$mes - 1];
    $vendas = $porMes[$mes] ?? 0.0;
    $valores[] = $vendas;
}
$totalVendasAno = array_sum($valores);
$porStatus = db()->query('SELECT status, COUNT(*) AS n FROM pedidos GROUP BY status')->fetchAll(PDO::FETCH_KEY_PAIR);
$aguardandoRetirada = (int) db()->query("SELECT COUNT(*) FROM entregas e JOIN pedidos p ON p.id = e.pedido_id
    WHERE p.status = 'aguardando_entrega' AND e.status = 'atribuida'")->fetchColumn();
$baixo = db()->query('SELECT id, nome, estoque, estoque_minimo, vendido_por FROM produtos WHERE ativo = 1 AND estoque <= estoque_minimo ORDER BY estoque ASC LIMIT 6')->fetchAll();
$recentes = db()->query('SELECT p.id, p.total, p.status, p.criado_em, u.nome FROM pedidos p JOIN usuarios u ON u.id = p.usuario_id ORDER BY p.criado_em DESC, p.id DESC LIMIT 6')->fetchAll();

$titulo = 'Dashboard';
$menuAtivo = 'dashboard';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Dashboard</h1>
<div class="kpis">
  <div class="kpi"><div class="kpi-topo">Pedidos <?= icone('carrinho') ?></div><div class="kpi-valor"><?= numeroBr($kpi['pedidos'], 0) ?></div><div class="kpi-sub"><?= $qtdAno ?> no ano <?= $ano ?></div></div>
  <div class="kpi"><div class="kpi-topo">Total de vendas <?= icone('grafico') ?></div><div class="kpi-valor"><?= dinheiro($kpi['vendas']) ?></div><div class="kpi-sub">Ticket médio (concluídos): <?= dinheiro($ticket) ?></div></div>
  <div class="kpi"><div class="kpi-topo">Produtos ativos <?= icone('etiqueta') ?></div><div class="kpi-valor"><?= $kpi['produtos'] ?></div><div class="kpi-sub"><a href="<?= e(url('interno/administrador/produtos.php')) ?>">Gerenciar</a></div></div>
  <div class="kpi"><div class="kpi-topo">Clientes <?= icone('usuario') ?></div><div class="kpi-valor"><?= $kpi['clientes'] ?></div><div class="kpi-sub"><a href="<?= e(url('interno/administrador/clientes.php')) ?>">Ver clientes</a></div></div>
  <div class="kpi <?= $kpi['estoque'] ? 'alerta' : '' ?>"><div class="kpi-topo">Estoque baixo <?= icone('alerta') ?></div><div class="kpi-valor"><?= $kpi['estoque'] ?></div><div class="kpi-sub"><a href="<?= e(url('interno/administrador/estoque.php?filtro=baixo')) ?>">Repor estoque</a></div></div>
  <div class="kpi"><div class="kpi-topo">Em andamento <?= icone('relogio') ?></div><div class="kpi-valor"><?= $kpi['andamento'] ?></div><div class="kpi-sub"><?= $kpi['ocorrencias'] ?> ocorrência(s) aberta(s)</div></div>
</div>

<section class="cartao mb-2">
  <h2>Operação de pedidos</h2>
  <div class="kpis mb-0">
    <div class="kpi"><div class="kpi-topo">Fila de separação</div><div class="kpi-valor"><?= (int) ($porStatus['aguardando_separacao'] ?? 0) ?></div><a href="<?= e(url('interno/administrador/pedidos.php?status=aguardando_separacao')) ?>">Ver pedidos na fila</a></div>
    <div class="kpi"><div class="kpi-topo">Prontos para entrega</div><div class="kpi-valor"><?= (int) ($porStatus['aguardando_entrega'] ?? 0) ?></div><div class="kpi-sub"><?= $aguardandoRetirada ?> com entregador designado</div><a href="<?= e(url('interno/administrador/pedidos.php?status=aguardando_entrega')) ?>">Ver pedidos prontos</a></div>
    <div class="kpi"><div class="kpi-topo">Em rota</div><div class="kpi-valor"><?= (int) ($porStatus['saiu_para_entrega'] ?? 0) ?></div><a href="<?= e(url('interno/administrador/pedidos.php?status=saiu_para_entrega')) ?>">Acompanhar entregas</a></div>
  </div>
</section>

<div class="layout-resumo">
  <section class="cartao grafico">
    <div class="cartao-titulo"><h3>Vendas mensais · <?= $anoSelecionado ?></h3><span class="badge">Dados fictícios</span></div>
    <div class="grafico-historico" data-grafico-rolagem tabindex="0" aria-label="Gráfico mensal de vendas"><?= graficoLinha($rotulos, $valores, 'R$', true) ?></div>
    <nav class="historico-anos" aria-label="Escolher ano do gráfico">
      <?php foreach ($anosHistorico as $opcaoAno): ?>
        <a class="historico-ano <?= $opcaoAno === $anoSelecionado ? 'ativo' : '' ?>" href="<?= e(url('interno/administrador/index.php?ano=' . $opcaoAno)) ?>" <?= $opcaoAno === $anoSelecionado ? 'aria-current="page"' : '' ?>><?= $opcaoAno ?></a>
      <?php endforeach; ?>
    </nav>
    <p class="pequeno mb-0"><b>Total do ano: <?= dinheiro($totalVendasAno) ?>.</b> Valores fictícios; não alteram pedidos, faturamento real ou relatórios.</p>
  </section>
  <section class="cartao">
    <h3>Pedidos por status</h3>
    <?php foreach (STATUS_PEDIDO as $s => $rot): ?>
      <div class="linha-resumo"><span><span class="badge st-<?= e($s) ?>"><?= e($rot) ?></span></span>
        <a href="<?= e(url('interno/administrador/pedidos.php?status=' . $s)) ?>"><b><?= (int) ($porStatus[$s] ?? 0) ?></b></a></div>
    <?php endforeach; ?>
  </section>
</div>

<div class="grid-2 mt-2">
  <section class="cartao">
    <div class="cartao-titulo"><h3>Pedidos recentes</h3><a href="<?= e(url('interno/administrador/pedidos.php')) ?>">Ver todos</a></div>
    <div class="tabela-wrap"><table class="tabela">
      <thead><tr><th>Pedido</th><th>Cliente</th><th>Status</th><th class="num">Total</th></tr></thead>
      <tbody><?php foreach ($recentes as $r): ?>
        <tr><td><a href="<?= e(url('interno/administrador/pedido.php?id=' . (int) $r['id'])) ?>">#<?= (int) $r['id'] ?></a><br><small><?= dataBr($r['criado_em']) ?></small></td>
          <td><?= e($r['nome']) ?></td><td><?= statusBadge($r['status']) ?></td><td class="num"><?= dinheiro($r['total']) ?></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
  </section>
  <section class="cartao">
    <div class="cartao-titulo"><h3>Estoque baixo</h3><a href="<?= e(url('interno/administrador/estoque.php?filtro=baixo')) ?>">Ver todos</a></div>
    <?php if (!$baixo): ?><p class="muted">Nenhum produto abaixo do mínimo.</p><?php endif; ?>
    <div class="tabela-wrap"><table class="tabela">
      <tbody><?php foreach ($baixo as $b): ?>
        <tr><td><?= e($b['nome']) ?></td>
          <td class="num"><span class="badge <?= (float) $b['estoque'] <= 0 ? 'badge-erro' : 'badge-alerta' ?>"><?= e(qtdFormatada($b['estoque'], $b['vendido_por'])) ?></span><br><small>mín. <?= e(qtdFormatada($b['estoque_minimo'], $b['vendido_por'])) ?></small></td>
          <td class="num"><a class="btn btn-neutro btn-sm" href="<?= e(url('interno/administrador/estoque.php?produto=' . (int) $b['id'])) ?>">Repor</a></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
  </section>
</div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
