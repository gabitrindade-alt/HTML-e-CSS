<?php
/** Dashboard administrativo — dados reais do banco. */
require __DIR__ . '/../../includes/bootstrap.php';
require APP_ROOT . '/includes/graficos.php';
exigirPerfil('administrador');

$validos = "status NOT IN ('cancelado','aguardando_pagamento')";
$kpi = [
    'pedidos'      => (int) db()->query('SELECT COUNT(*) FROM pedidos')->fetchColumn(),
    'vendas'       => (float) db()->query("SELECT COALESCE(SUM(total),0) FROM pedidos WHERE $validos")->fetchColumn(),
    'produtos'     => (int) db()->query('SELECT COUNT(*) FROM produtos WHERE ativo = 1')->fetchColumn(),
    'clientes'     => (int) db()->query("SELECT COUNT(*) FROM usuarios WHERE perfil = 'cliente'")->fetchColumn(),
    'estoque'      => (int) db()->query('SELECT COUNT(*) FROM produtos WHERE ativo = 1 AND estoque <= estoque_minimo')->fetchColumn(),
    'andamento'    => (int) db()->query("SELECT COUNT(*) FROM pedidos WHERE status NOT IN ('concluido','cancelado')")->fetchColumn(),
    'ocorrencias'  => (int) db()->query("SELECT COUNT(*) FROM ocorrencias WHERE status = 'aberta'")->fetchColumn(),
];
$concluidos = (int) db()->query("SELECT COUNT(*) FROM pedidos WHERE status = 'concluido'")->fetchColumn();
$ticket = $concluidos ? (float) db()->query("SELECT AVG(total) FROM pedidos WHERE status = 'concluido'")->fetchColumn() : 0;

// Vendas dos últimos 7 dias (inclui hoje)
$inicio = date('Y-m-d', strtotime('-6 days'));
$st = db()->prepare("SELECT DATE(criado_em) AS dia, COUNT(*) AS qtd, SUM(total) AS valor FROM pedidos
                     WHERE criado_em >= ? AND $validos GROUP BY DATE(criado_em)");
$st->execute([$inicio . ' 00:00:00']);
$porDia = [];
foreach ($st as $l) {
    $porDia[$l['dia']] = $l;
}
$rotulos = $valores = [];
$total7 = 0;
$qtd7 = 0;
$dias = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $rotulos[] = $dias[(int) date('w', strtotime($d))] . ' ' . date('d/m', strtotime($d));
    $v = (float) ($porDia[$d]['valor'] ?? 0);
    $valores[] = $v;
    $total7 += $v;
    $qtd7 += (int) ($porDia[$d]['qtd'] ?? 0);
}

$porStatus = db()->query('SELECT status, COUNT(*) AS n FROM pedidos GROUP BY status')->fetchAll(PDO::FETCH_KEY_PAIR);
$aguardandoRetirada = (int) db()->query("SELECT COUNT(*) FROM entregas e JOIN pedidos p ON p.id = e.pedido_id
    WHERE p.status = 'aguardando_entrega' AND e.status = 'atribuida'")->fetchColumn();
$baixo = db()->query('SELECT id, nome, estoque, estoque_minimo, vendido_por FROM produtos WHERE ativo = 1 AND estoque <= estoque_minimo ORDER BY estoque ASC LIMIT 6')->fetchAll();
$recentes = db()->query('SELECT p.id, p.total, p.status, p.criado_em, u.nome FROM pedidos p JOIN usuarios u ON u.id = p.usuario_id ORDER BY p.criado_em DESC, p.id DESC LIMIT 6')->fetchAll();

$titulo = 'Dashboard';
$menuAtivo = 'dashboard';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Dashboard</h1>
<div class="kpis">
  <div class="kpi"><div class="kpi-topo">Pedidos <?= icone('carrinho') ?></div><div class="kpi-valor"><?= numeroBr($kpi['pedidos'], 0) ?></div><div class="kpi-sub"><?= $qtd7 ?> nos últimos 7 dias</div></div>
  <div class="kpi"><div class="kpi-topo">Total de vendas <?= icone('grafico') ?></div><div class="kpi-valor"><?= dinheiro($kpi['vendas']) ?></div><div class="kpi-sub">Ticket médio (concluídos): <?= dinheiro($ticket) ?></div></div>
  <div class="kpi"><div class="kpi-topo">Produtos ativos <?= icone('etiqueta') ?></div><div class="kpi-valor"><?= $kpi['produtos'] ?></div><div class="kpi-sub"><a href="<?= e(url('interno/administrador/produtos.php')) ?>">Gerenciar</a></div></div>
  <div class="kpi"><div class="kpi-topo">Clientes <?= icone('usuario') ?></div><div class="kpi-valor"><?= $kpi['clientes'] ?></div><div class="kpi-sub"><a href="<?= e(url('interno/administrador/clientes.php')) ?>">Ver clientes</a></div></div>
  <div class="kpi <?= $kpi['estoque'] ? 'alerta' : '' ?>"><div class="kpi-topo">Estoque baixo <?= icone('alerta') ?></div><div class="kpi-valor"><?= $kpi['estoque'] ?></div><div class="kpi-sub"><a href="<?= e(url('interno/administrador/estoque.php?filtro=baixo')) ?>">Repor estoque</a></div></div>
  <div class="kpi"><div class="kpi-topo">Em andamento <?= icone('relogio') ?></div><div class="kpi-valor"><?= $kpi['andamento'] ?></div><div class="kpi-sub"><?= $kpi['ocorrencias'] ?> ocorrência(s) aberta(s)</div></div>
</div>

<section class="cartao mb-2">
  <h2>Operação de pedidos</h2>
  <div class="kpis mb-0">
    <div class="kpi"><div class="kpi-topo">Fila de separação</div><div class="kpi-valor"><?= (int) ($porStatus['aguardando_separacao'] ?? 0) ?></div><a href="<?= e(url('interno/administrador/pedidos.php?status=aguardando_separacao')) ?>">Ver pedidos na fila</a></div>
    <div class="kpi"><div class="kpi-topo">Prontos para entrega</div><div class="kpi-valor"><?= (int) ($porStatus['aguardando_entrega'] ?? 0) ?></div><div class="kpi-sub"><?= $aguardandoRetirada ?> com entregador designado</div><a href="<?= e(url('interno/administrador/pedidos.php?status=aguardando_entrega')) ?>">Ver pedidos prontos</a></div>
    <div class="kpi"><div class="kpi-topo">Em rota</div><div class="kpi-valor"><?= (int) ($porStatus['saiu_para_entrega'] ?? 0) ?></div><a href="<?= e(url('interno/administrador/pedidos.php?status=saiu_para_entrega')) ?>">Acompanhar entregas</a></div>
  </div>
</section>

<div class="layout-resumo">
  <section class="cartao grafico">
    <div class="cartao-titulo"><h3>Vendas dos últimos 7 dias</h3><span class="badge"><?= dinheiro($total7) ?></span></div>
    <?= graficoLinha($rotulos, $valores) ?>
    <p class="pequeno mb-0">Soma do total dos pedidos pagos por dia de criação (exclui cancelados e aguardando pagamento).</p>
  </section>
  <section class="cartao">
    <h3>Pedidos por status</h3>
    <?php foreach (STATUS_PEDIDO as $s => $rot): ?>
      <div class="linha-resumo"><span><span class="badge st-<?= e($s) ?>"><?= e($rot) ?></span></span>
        <a href="<?= e(url('interno/administrador/pedidos.php?status=' . $s)) ?>"><b><?= (int) ($porStatus[$s] ?? 0) ?></b></a></div>
    <?php endforeach; ?>
  </section>
</div>

<div class="grid-2 mt-2">
  <section class="cartao">
    <div class="cartao-titulo"><h3>Pedidos recentes</h3><a href="<?= e(url('interno/administrador/pedidos.php')) ?>">Ver todos</a></div>
    <div class="tabela-wrap"><table class="tabela">
      <thead><tr><th>Pedido</th><th>Cliente</th><th>Status</th><th class="num">Total</th></tr></thead>
      <tbody><?php foreach ($recentes as $r): ?>
        <tr><td><a href="<?= e(url('interno/administrador/pedido.php?id=' . (int) $r['id'])) ?>">#<?= (int) $r['id'] ?></a><br><small><?= dataBr($r['criado_em']) ?></small></td>
          <td><?= e($r['nome']) ?></td><td><?= statusBadge($r['status']) ?></td><td class="num"><?= dinheiro($r['total']) ?></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
  </section>
  <section class="cartao">
    <div class="cartao-titulo"><h3>Estoque baixo</h3><a href="<?= e(url('interno/administrador/estoque.php?filtro=baixo')) ?>">Ver todos</a></div>
    <?php if (!$baixo): ?><p class="muted">Nenhum produto abaixo do mínimo.</p><?php endif; ?>
    <div class="tabela-wrap"><table class="tabela">
      <tbody><?php foreach ($baixo as $b): ?>
        <tr><td><?= e($b['nome']) ?></td>
          <td class="num"><span class="badge <?= (float) $b['estoque'] <= 0 ? 'badge-erro' : 'badge-alerta' ?>"><?= e(qtdFormatada($b['estoque'], $b['vendido_por'])) ?></span><br><small>mín. <?= e(qtdFormatada($b['estoque_minimo'], $b['vendido_por'])) ?></small></td>
          <td class="num"><a class="btn btn-neutro btn-sm" href="<?= e(url('interno/administrador/estoque.php?produto=' . (int) $b['id'])) ?>">Repor</a></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
  </section>
</div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
