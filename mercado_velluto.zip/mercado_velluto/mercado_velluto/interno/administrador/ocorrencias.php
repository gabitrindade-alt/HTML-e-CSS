<?php
/** Consulta e tratamento de ocorrências (separação, entrega, estoque, atendimento). */
require __DIR__ . '/../../includes/bootstrap.php';
$eu = exigirPerfil('administrador');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && post('acao') === 'resolver') {
    $id = (int) post('id');
    $res = mb_substr(post('resolucao'), 0, 1000);
    if (mb_strlen($res) < 3) {
        flash('erro', 'Descreva a resolução.');
    } else {
        $st = db()->prepare("UPDATE ocorrencias SET status = 'resolvida', resolucao = ?, resolvido_por = ?, resolvido_em = ? WHERE id = ? AND status = 'aberta'");
        $st->execute([$res, $eu['id'], agora(), $id]);
        if ($st->rowCount()) {
            registrarAlteracao('ocorrencia', $id, 'resolver', $res);
            flash('sucesso', 'Ocorrência #' . $id . ' resolvida.');
        }
    }
    redirecionar('interno/administrador/ocorrencias.php');
}

$status = in_array(get('status'), ['aberta', 'resolvida'], true) ? get('status') : '';
$sql = 'SELECT o.*, u.nome, u.perfil, r.nome AS resolvedor FROM ocorrencias o LEFT JOIN usuarios u ON u.id = o.usuario_id LEFT JOIN usuarios r ON r.id = o.resolvido_por';
$params = [];
if ($status) {
    $sql .= ' WHERE o.status = ?';
    $params[] = $status;
}
$st = db()->prepare($sql . " ORDER BY o.status = 'aberta' DESC, o.criado_em DESC LIMIT 200");
$st->execute($params);
$ocorrencias = $st->fetchAll();

$titulo = 'Ocorrências';
$menuAtivo = 'ocorrencias';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Ocorrências</h1>
<div class="abas-status">
  <a href="?" class="<?= !$status ? 'ativo' : '' ?>">Todas</a>
  <a href="?status=aberta" class="<?= $status === 'aberta' ? 'ativo' : '' ?>">Abertas</a>
  <a href="?status=resolvida" class="<?= $status === 'resolvida' ? 'ativo' : '' ?>">Resolvidas</a>
</div>
<div class="cartao"><div class="tabela-wrap"><table class="tabela">
  <thead><tr><th>#</th><th>Data</th><th>Tipo</th><th>Gravidade</th><th>Pedido</th><th>Descrição</th><th>Registrado por</th><th>Situação / resolução</th></tr></thead>
  <tbody><?php foreach ($ocorrencias as $o): ?>
    <tr><td><?= (int) $o['id'] ?></td><td><small><?= dataBr($o['criado_em']) ?></small></td><td><b><?= e($o['tipo']) ?></b></td>
      <td><span class="badge <?= $o['gravidade'] === 'alta' ? 'badge-erro' : ($o['gravidade'] === 'media' ? 'badge-alerta' : '') ?>"><?= e($o['gravidade']) ?></span></td>
      <td><?= $o['pedido_id'] ? '<a href="' . e(url('interno/administrador/pedido.php?id=' . (int) $o['pedido_id'])) . '">#' . (int) $o['pedido_id'] . '</a>' : '—' ?></td>
      <td><?= e($o['descricao']) ?></td><td><?= e($o['nome'] ?? '—') ?><br><small><?= e(PERFIL_ROTULO[$o['perfil']] ?? '') ?></small></td>
      <td><?php if ($o['status'] === 'aberta'): ?>
        <form method="post" class="flex"><?= csrfCampo() ?><input type="hidden" name="acao" value="resolver"><input type="hidden" name="id" value="<?= (int) $o['id'] ?>">
          <input class="input" name="resolucao" placeholder="Como foi resolvida?" required style="min-width:160px"><button class="btn btn-sucesso btn-sm" type="submit">Resolver</button></form>
      <?php else: ?><span class="badge badge-ok">Resolvida</span><br><small><?= e($o['resolucao']) ?> · <?= e($o['resolvedor'] ?? '') ?> · <?= dataBr($o['resolvido_em']) ?></small><?php endif; ?></td></tr>
  <?php endforeach; ?>
  <?php if (!$ocorrencias): ?><tr><td colspan="8" class="muted texto-centro">Nenhuma ocorrência.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
