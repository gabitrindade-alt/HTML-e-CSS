<?php
/** Cadastro e edição de produto (preço, promoção, estoque, imagem). */
require __DIR__ . '/../../includes/bootstrap.php';
exigirPerfil('administrador');

$id = (int) get('id', post('id'));
$produto = null;
if ($id) {
    $st = db()->prepare('SELECT * FROM produtos WHERE id = ?');
    $st->execute([$id]);
    $produto = $st->fetch();
    if (!$produto) {
        flash('erro', 'Produto não encontrado.');
        redirecionar('interno/administrador/produtos.php');
    }
}
$f = $produto ?: ['nome' => '', 'marca' => '', 'categoria_id' => '', 'embalagem' => '', 'vendido_por' => 'unidade', 'preco' => '', 'preco_promocional' => '',
    'estoque' => '0', 'estoque_minimo' => '10', 'descricao' => '', 'informacoes' => '', 'destaque' => 0, 'ativo' => 1, 'imagem' => ''];
$erros = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach (['nome' => 140, 'marca' => 80, 'embalagem' => 60, 'descricao' => 5000, 'informacoes' => 5000] as $c => $lim) {
        $f[$c] = mb_substr(post($c), 0, $lim);
    }
    $f['categoria_id'] = (int) post('categoria_id');
    $f['vendido_por'] = post('vendido_por') === 'peso' ? 'peso' : 'unidade';
    $f['preco'] = paraNumero(post('preco'));
    $f['preco_promocional'] = post('preco_promocional') !== '' ? paraNumero(post('preco_promocional')) : null;
    $f['estoque_minimo'] = max(0, paraNumero(post('estoque_minimo')));
    $f['destaque'] = post('destaque') ? 1 : 0;
    $f['ativo'] = post('ativo') ? 1 : 0;
    $estoqueNovo = max(0, paraNumero(post('estoque')));
    $f['estoque'] = $estoqueNovo;

    if (mb_strlen($f['nome']) < 2 || mb_strlen($f['nome']) > 140) $erros[] = 'Informe o nome do produto (até 140 caracteres).';
    $st = db()->prepare('SELECT COUNT(*) FROM categorias WHERE id = ?');
    $st->execute([$f['categoria_id']]);
    if (!$st->fetchColumn()) $erros[] = 'Selecione uma categoria válida.';
    if ($f['preco'] <= 0) $erros[] = 'O preço deve ser maior que zero.';
    if ($f['preco_promocional'] !== null && ($f['preco_promocional'] <= 0 || $f['preco_promocional'] >= $f['preco'])) $erros[] = 'O preço promocional deve ser maior que zero e menor que o preço normal.';
    if ($f['vendido_por'] === 'unidade' && floor($estoqueNovo) != $estoqueNovo) $erros[] = 'Produtos vendidos por unidade devem ter estoque inteiro.';

    // Upload de imagem (opcional) — valida tipo real e tamanho.
    $novaImagem = null;
    if (!empty($_FILES['imagem']['name'])) {
        $arq = $_FILES['imagem'];
        $info = $arq['error'] === UPLOAD_ERR_OK ? @getimagesize($arq['tmp_name']) : false;
        $tipos = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp', IMAGETYPE_GIF => 'gif'];
        if ($arq['error'] !== UPLOAD_ERR_OK) $erros[] = 'Falha no envio da imagem.';
        elseif ($arq['size'] > UPLOAD_MAX_BYTES) $erros[] = 'A imagem deve ter no máximo 2 MB.';
        elseif (!$info || !isset($tipos[$info[2]])) $erros[] = 'Envie uma imagem JPG, PNG, WEBP ou GIF.';
        else {
            if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0775, true);
            $nomeArq = bin2hex(random_bytes(12)) . '.' . $tipos[$info[2]];
            if (move_uploaded_file($arq['tmp_name'], UPLOAD_DIR . '/' . $nomeArq)) {
                $novaImagem = 'uploads/produtos/' . $nomeArq;
            } else {
                $erros[] = 'Não foi possível salvar a imagem (verifique permissões da pasta uploads/).';
            }
        }
    }

    if (!$erros) {
        $slug = slugify($f['nome']);
        $st = db()->prepare('SELECT COUNT(*) FROM produtos WHERE slug = ? AND id <> ?');
        $st->execute([$slug, $id]);
        if ($st->fetchColumn()) $slug .= '-' . substr(bin2hex(random_bytes(3)), 0, 5);
        $promo = $f['preco_promocional'] !== null ? numSql($f['preco_promocional'], 2) : null;

        transacao(function () use (&$id, $produto, $f, $slug, $promo, $novaImagem, $estoqueNovo) {
            if ($produto) {
                $sql = 'UPDATE produtos SET categoria_id=?, nome=?, slug=?, marca=?, descricao=?, informacoes=?, embalagem=?, vendido_por=?, preco=?, preco_promocional=?,
                        estoque_minimo=?, destaque=?, ativo=?, atualizado_em=?' . ($novaImagem ? ', imagem=?' : '') . ' WHERE id=?';
                $v = [$f['categoria_id'], $f['nome'], $slug, $f['marca'] ?: null, $f['descricao'], $f['informacoes'], $f['embalagem'], $f['vendido_por'],
                    numSql($f['preco'], 2), $promo, numSql($f['estoque_minimo']), $f['destaque'], $f['ativo'], agora()];
                if ($novaImagem) $v[] = $novaImagem;
                $v[] = $id;
                db()->prepare($sql)->execute($v);
                $mud = [];
                $deltaEstoque = $estoqueNovo - (float) $produto['estoque'];
                if (abs($deltaEstoque) >= 0.0005) {
                    movimentarEstoque($id, $deltaEstoque, $deltaEstoque > 0 ? 'entrada' : 'saida', null, 'Quantidade atualizada no cadastro do produto');
                    $mud[] = 'estoque ' . qtdFormatada($produto['estoque'], $produto['vendido_por']) . ' -> ' . qtdFormatada($estoqueNovo, $f['vendido_por']);
                }
                if ((float) $produto['preco'] !== (float) $f['preco']) $mud[] = 'preço ' . dinheiro($produto['preco']) . ' → ' . dinheiro($f['preco']);
                if ((string) $produto['preco_promocional'] !== (string) $promo && ((float) $produto['preco_promocional'] !== (float) $promo)) $mud[] = 'promoção ' . ($produto['preco_promocional'] ? dinheiro($produto['preco_promocional']) : '—') . ' → ' . ($promo ? dinheiro($promo) : '—');
                if ((int) $produto['ativo'] !== $f['ativo']) $mud[] = $f['ativo'] ? 'ativado' : 'desativado';
                registrarAlteracao('produto', $id, 'editar', 'Produto "' . $f['nome'] . '" editado' . ($mud ? ': ' . implode('; ', $mud) : '.'));
            } else {
                db()->prepare('INSERT INTO produtos (categoria_id, nome, slug, marca, descricao, informacoes, embalagem, vendido_por, preco, preco_promocional, estoque, estoque_minimo, imagem, destaque, ativo, criado_em, atualizado_em)
                               VALUES (?,?,?,?,?,?,?,?,?,?,0,?,?,?,?,?,?)')
                    ->execute([$f['categoria_id'], $f['nome'], $slug, $f['marca'] ?: null, $f['descricao'], $f['informacoes'], $f['embalagem'], $f['vendido_por'],
                        numSql($f['preco'], 2), $promo, numSql($f['estoque_minimo']), $novaImagem, $f['destaque'], $f['ativo'], agora(), agora()]);
                $id = (int) db()->lastInsertId();
                if ($estoqueNovo > 0) {
                    movimentarEstoque($id, $estoqueNovo, 'entrada', null, 'Estoque inicial do cadastro');
                }
                registrarAlteracao('produto', $id, 'criar', 'Produto "' . $f['nome'] . '" cadastrado por ' . dinheiro($f['preco']) . '.');
            }
        });
        flash('sucesso', 'Produto salvo com sucesso.');
        redirecionar('interno/administrador/produtos.php');
    }
}

$categorias = db()->query('SELECT id, nome, pai_id FROM categorias ORDER BY COALESCE(pai_id, id), pai_id IS NOT NULL, ordem, nome')->fetchAll();
$titulo = $produto ? 'Editar produto' : 'Novo produto';
$menuAtivo = 'produtos';
require APP_ROOT . '/includes/header_interno.php';
?>
<nav class="migalhas"><a href="<?= e(url('interno/administrador/produtos.php')) ?>">Produtos</a> › <span><?= e($titulo) ?></span></nav>
<h1><?= e($titulo) ?></h1>
<?php if ($erros): ?><div class="aviso aviso-vermelho mb-2"><?= implode('<br>', array_map('e', $erros)) ?></div><?php endif; ?>
<form class="layout-resumo" method="post" enctype="multipart/form-data" style="grid-template-columns: 1fr 300px">
  <?= csrfCampo() ?><input type="hidden" name="id" value="<?= (int) $id ?>">
  <div class="cartao">
    <div class="grid-form">
      <div class="campo col-8"><label for="nome">Nome *</label><input id="nome" name="nome" value="<?= e($f['nome']) ?>" required maxlength="140"></div>
      <div class="campo col-4"><label for="marca">Marca</label><input id="marca" name="marca" value="<?= e($f['marca']) ?>" maxlength="80"></div>
      <div class="campo col-6"><label for="categoria_id">Categoria *</label><select id="categoria_id" name="categoria_id" required><option value="">Selecione…</option>
        <?php foreach ($categorias as $c): ?><option value="<?= (int) $c['id'] ?>" <?= (int) $f['categoria_id'] === (int) $c['id'] ? 'selected' : '' ?>><?= $c['pai_id'] ? '— ' : '' ?><?= e($c['nome']) ?></option><?php endforeach; ?></select></div>
      <div class="campo col-6"><label for="embalagem">Embalagem / apresentação</label><input id="embalagem" name="embalagem" value="<?= e($f['embalagem']) ?>" placeholder="Pacote 5 kg, Caixa 1 L…" maxlength="60"></div>
      <div class="campo col-4"><label for="vendido_por">Forma de venda</label><select id="vendido_por" name="vendido_por">
        <option value="unidade" <?= $f['vendido_por'] === 'unidade' ? 'selected' : '' ?>>Por unidade</option>
        <option value="peso" <?= $f['vendido_por'] === 'peso' ? 'selected' : '' ?>>Por peso (kg)</option></select></div>
      <div class="campo col-4"><label for="preco">Preço (R$) *</label><input id="preco" name="preco" value="<?= e($f['preco'] !== '' ? number_format((float) $f['preco'], 2, ',', '') : '') ?>" required inputmode="decimal"></div>
      <div class="campo col-4"><label for="preco_promocional">Preço promocional (R$)</label><input id="preco_promocional" name="preco_promocional" value="<?= e($f['preco_promocional'] ? number_format((float) $f['preco_promocional'], 2, ',', '') : '') ?>" inputmode="decimal" placeholder="Vazio = sem promoção"></div>
      <div class="campo col-6"><label for="estoque"><?= $produto ? 'Estoque atual / novo saldo' : 'Estoque inicial' ?></label><input class="input" id="estoque" name="estoque" type="number" min="0" step="<?= $f['vendido_por'] === 'peso' ? '0.001' : '1' ?>" value="<?= e(number_format((float) $f['estoque'], $f['vendido_por'] === 'peso' ? 3 : 0, '.', '')) ?>" required>
        <?php if ($produto): ?><small>A alteração ficará registrada no histórico de estoque.</small><?php endif; ?></div>
      <div class="campo col-6"><label for="estoque_minimo">Estoque mínimo (alerta)</label><input id="estoque_minimo" name="estoque_minimo" value="<?= e(numeroBr($f['estoque_minimo'], $f['vendido_por'] === 'peso' ? 3 : 0)) ?>" inputmode="decimal"></div>
      <div class="campo col-12"><label for="descricao">Descrição</label><textarea id="descricao" name="descricao"><?= e($f['descricao']) ?></textarea></div>
      <div class="campo col-12"><label for="informacoes">Informações técnicas</label><textarea id="informacoes" name="informacoes"><?= e($f['informacoes']) ?></textarea></div>
    </div>
  </div>
  <aside class="cartao">
    <h3>Imagem</h3>
    <img id="prev" src="<?= e(imagemProduto($f)) ?>" alt="" style="border-radius:12px;border:1px solid var(--linha);margin-bottom:10px">
    <div class="campo"><input type="file" name="imagem" accept="image/jpeg,image/png,image/webp,image/gif" data-preview="#prev"><small>JPG, PNG, WEBP ou GIF até 2 MB</small></div>
    <label class="check"><input type="checkbox" name="ativo" value="1" <?= (int) $f['ativo'] ? 'checked' : '' ?>> Ativo na loja</label>
    <label class="check"><input type="checkbox" name="destaque" value="1" <?= (int) $f['destaque'] ? 'checked' : '' ?>> Destaque na página inicial</label>
    <button class="btn btn-primario btn-bloco mt-2" type="submit">Salvar produto</button>
    <a class="btn btn-link btn-bloco mt-1" href="<?= e(url('interno/administrador/produtos.php')) ?>">Cancelar</a>
  </aside>
</form>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
