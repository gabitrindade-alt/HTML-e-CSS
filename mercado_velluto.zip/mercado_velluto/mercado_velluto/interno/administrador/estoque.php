<?php
/** Gestão de estoque: entradas, ajustes e consulta das movimentações. */
require __DIR__ . '/../../includes/bootstrap.php';
exigirPerfil('administrador');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) post('produto_id');
    $tipo = post('tipo');
    $qtd = paraNumero(post('quantidade'));
    $obs = mb_substr(post('observacao'), 0, 200);
    $st = db()->prepare('SELECT * FROM produtos WHERE id = ?');
    $st->execute([$id]);
    $p = $st->fetch();
    try {
        if (!$p) throw new RegraNegocioException('Produto não encontrado.');
        if ($qtd <= 0) throw new RegraNegocioException('Informe uma quantidade maior que zero.');
        if ($p['vendido_por'] === 'unidade' && floor($qtd) != $qtd) throw new RegraNegocioException('Produto vendido por unidade: use quantidade inteira.');
        if (!in_array($tipo, ['entrada', 'saida', 'definir'], true)) throw new RegraNegocioException('Tipo de movimentação inválido.');
        if ($tipo !== 'entrada' && $obs === '') throw new RegraNegocioException('Informe o motivo do ajuste (perda, inventário, avaria…).');
        transacao(function () use ($p, $tipo, $qtd, $obs) {
            $delta = match ($tipo) {
                'entrada' => $qtd,
                'saida'   => -$qtd,
                'definir' => $qtd - (float) $p['estoque'],
            };
            movimentarEstoque((int) $p['id'], $delta, $tipo === 'entrada' ? 'entrada' : 'ajuste', null, ($obs ?: 'Entrada de mercadoria'));
            registrarAlteracao('estoque', (int) $p['id'], $tipo, '"' . $p['nome'] . '": ' . ($delta >= 0 ? '+' : '') . numeroBr($delta, 3) . ' — ' . ($obs ?: 'entrada'));
        });
        flash('sucesso', 'Estoque de "' . $p['nome'] . '" atualizado.');
    } catch (RegraNegocioException $e) {
        flash('erro', $e->getMessage() === 'Estoque insuficiente para "' . ($p['nome'] ?? '') . '".' ? 'A saída deixaria o estoque negativo. Operação bloqueada.' : $e->getMessage());
    }
    redirecionar('interno/administrador/estoque.php?produto=' . $id);
}

$filtro = get('filtro');
$sel = (int) get('produto');
$sql = 'SELECT p.*, c.nome AS categoria FROM produtos p JOIN categorias c ON c.id = p.categoria_id';
if ($filtro === 'baixo') $sql .= ' WHERE p.ativo = 1 AND p.estoque <= p.estoque_minimo';
if ($filtro === 'zerado') $sql .= ' WHERE p.estoque <= 0';
$produtos = db()->query($sql . ' ORDER BY (p.estoque <= p.estoque_minimo) DESC, p.nome')->fetchAll();

$produtoSel = null;
$movs = [];
if ($sel) {
    $st = db()->prepare('SELECT * FROM produtos WHERE id = ?');
    $st->execute([$sel]);
    $produtoSel = $st->fetch() ?: null;
    $st = db()->prepare('SELECT m.*, u.nome AS usuario FROM movimentacoes_estoque m LEFT JOIN usuarios u ON u.id = m.usuario_id WHERE m.produto_id = ? ORDER BY m.criado_em DESC, m.id DESC LIMIT 40');
    $st->execute([$sel]);
    $movs = $st->fetchAll();
} else {
    $movs = db()->query('SELECT m.*, u.nome AS usuario, p.nome AS produto, p.vendido_por FROM movimentacoes_estoque m JOIN produtos p ON p.id = m.produto_id
                         LEFT JOIN usuarios u ON u.id = m.usuario_id ORDER BY m.criado_em DESC, m.id DESC LIMIT 30')->fetchAll();
}
$valorEstoque = (float) db()->query('SELECT COALESCE(SUM(estoque * preco), 0) FROM produtos WHERE ativo = 1')->fetchColumn();

$titulo = 'Estoque';
$menuAtivo = 'estoque';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Estoque</h1>
<div class="kpis">
  <div class="kpi"><div class="kpi-topo">Valor em estoque (preço de venda)</div><div class="kpi-valor"><?= dinheiro($valorEstoque) ?></div></div>
  <div class="kpi alerta"><div class="kpi-topo">Abaixo do mínimo</div><div class="kpi-valor"><?= count(array_filter($produtos, 'estoqueBaixo')) ?></div></div>
  <div class="kpi"><div class="kpi-topo">Zerados</div><div class="kpi-valor"><?= count(array_filter($produtos, fn($p) => (float) $p['estoque'] <= 0)) ?></div></div>
</div>

<?php if ($produtoSel): ?>
  <section class="cartao mb-2">
    <div class="cartao-titulo"><h2><?= e($produtoSel['nome']) ?></h2><a href="<?= e(url('interno/administrador/estoque.php')) ?>">← todos os produtos</a></div>
    <p>Estoque atual: <b><?= e(qtdFormatada($produtoSel['estoque'], $produtoSel['vendido_por'])) ?></b> · mínimo <?= e(qtdFormatada($produtoSel['estoque_minimo'], $produtoSel['vendido_por'])) ?></p>
    <form class="filtros-linha" method="post">
      <?= csrfCampo() ?><input type="hidden" name="produto_id" value="<?= (int) $produtoSel['id'] ?>">
      <div class="campo"><label for="tipo">Movimentação</label><select class="input" id="tipo" name="tipo">
        <option value="entrada">Entrada (compra/reposição)</option><option value="saida">Saída (perda/avaria)</option><option value="definir">Definir saldo (inventário)</option></select></div>
      <div class="campo"><label for="quantidade">Quantidade<?= $produtoSel['vendido_por'] === 'peso' ? ' (kg)' : '' ?></label><input class="input" id="quantidade" name="quantidade" inputmode="decimal" required></div>
      <div class="campo" style="flex:1"><label for="observacao">Motivo / observação</label><input class="input" id="observacao" name="observacao" maxlength="200" placeholder="NF 1234, inventário mensal, avaria…"></div>
      <button class="btn btn-primario" type="submit">Registrar</button>
    </form>
  </section>
<?php endif; ?>

<div class="grid-2">
  <section class="cartao">
    <div class="abas-status">
      <a href="?" class="<?= !$filtro ? 'ativo' : '' ?>">Todos</a>
      <a href="?filtro=baixo" class="<?= $filtro === 'baixo' ? 'ativo' : '' ?>">Abaixo do mínimo</a>
      <a href="?filtro=zerado" class="<?= $filtro === 'zerado' ? 'ativo' : '' ?>">Zerados</a>
    </div>
    <div class="tabela-wrap" style="max-height:620px;overflow:auto"><table class="tabela">
      <thead><tr><th>Produto</th><th class="num">Estoque</th><th class="num">Mínimo</th><th></th></tr></thead>
      <tbody><?php foreach ($produtos as $p): ?>
        <tr><td><?= e($p['nome']) ?><br><small><?= e($p['categoria']) ?><?= (int) $p['ativo'] ? '' : ' · inativo' ?></small></td>
          <td class="num"><span class="badge <?= (float) $p['estoque'] <= 0 ? 'badge-erro' : (estoqueBaixo($p) ? 'badge-alerta' : 'badge-ok') ?>"><?= e(qtdFormatada($p['estoque'], $p['vendido_por'])) ?></span></td>
          <td class="num"><?= e(qtdFormatada($p['estoque_minimo'], $p['vendido_por'])) ?></td>
          <td class="num"><a class="btn btn-neutro btn-sm" href="?produto=<?= (int) $p['id'] ?><?= $filtro ? '&filtro=' . e($filtro) : '' ?>">Movimentar</a></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
  </section>
  <section class="cartao">
    <h3>Movimentações <?= $produtoSel ? 'do produto' : 'recentes' ?></h3>
    <div class="tabela-wrap" style="max-height:620px;overflow:auto"><table class="tabela">
      <thead><tr><th>Data</th><?= $produtoSel ? '' : '<th>Produto</th>' ?><th>Tipo</th><th class="num">Qtd.</th><th class="num">Saldo</th><th>Origem</th></tr></thead>
      <tbody><?php foreach ($movs as $m): ?>
        <tr><td><small><?= dataBr($m['criado_em']) ?></small></td>
          <?= $produtoSel ? '' : '<td>' . e($m['produto']) . '</td>' ?>
          <td><span class="badge"><?= e($m['tipo']) ?></span></td>
          <td class="num" style="color:<?= (float) $m['quantidade'] < 0 ? 'var(--vermelho)' : 'var(--verde)' ?>"><?= ((float) $m['quantidade'] > 0 ? '+' : '') . numeroBr($m['quantidade'], 3) ?></td>
          <td class="num"><?= numeroBr($m['estoque_posterior'], 3) ?></td>
          <td><small><?= $m['pedido_id'] ? '<a href="' . e(url('interno/administrador/pedido.php?id=' . (int) $m['pedido_id'])) . '">Pedido #' . (int) $m['pedido_id'] . '</a><br>' : '' ?><?= e($m['observacao']) ?><?= $m['usuario'] ? ' · ' . e($m['usuario']) : '' ?></small></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
  </section>
</div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
