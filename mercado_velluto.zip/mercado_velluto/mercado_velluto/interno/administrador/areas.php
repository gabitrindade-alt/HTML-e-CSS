<?php
/** Áreas de entrega (faixas de CEP) e configuração de valores de frete. */
require __DIR__ . '/../../includes/bootstrap.php';
exigirPerfil('administrador');

$editar = null;
if (get('editar')) {
    $st = db()->prepare('SELECT * FROM areas_entrega WHERE id = ?');
    $st->execute([(int) get('editar')]);
    $editar = $st->fetch() ?: null;
}
$erros = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = post('acao');
    $id = (int) post('id');
    if ($acao === 'excluir') {
        $st = db()->prepare('SELECT COUNT(*) FROM pedidos WHERE area_entrega_id = ?');
        $st->execute([$id]);
        if ($st->fetchColumn()) {
            db()->prepare('UPDATE areas_entrega SET ativo = 0 WHERE id = ?')->execute([$id]);
            flash('aviso', 'A área possui pedidos vinculados e foi desativada (não aceita novos pedidos).');
        } else {
            db()->prepare('DELETE FROM areas_entrega WHERE id = ?')->execute([$id]);
            flash('sucesso', 'Área excluída.');
        }
        registrarAlteracao('area_entrega', $id, 'excluir', 'Área de entrega removida/desativada.');
        redirecionar('interno/administrador/areas.php');
    }
    if ($acao === 'salvar') {
        $horasPadrao = filter_var(post('prazo_padrao'), FILTER_VALIDATE_INT);
        $horasExpresso = filter_var(post('prazo_expresso'), FILTER_VALIDATE_INT);
        $d = [
            'nome' => mb_substr(post('nome'), 0, 80), 'cidade' => mb_substr(post('cidade'), 0, 80), 'uf' => strtoupper(post('uf')),
            'cep_inicio' => apenasDigitos(post('cep_inicio')), 'cep_fim' => apenasDigitos(post('cep_fim')),
            'valor_frete' => paraNumero(post('valor_frete')),
            'valor_expresso' => post('valor_expresso') !== '' ? paraNumero(post('valor_expresso')) : null,
            'frete_gratis_acima' => post('frete_gratis_acima') !== '' ? paraNumero(post('frete_gratis_acima')) : null,
            'prazo_padrao' => (($horasPadrao && $horasPadrao <= 48) ? 'até ' . $horasPadrao . ' horas' : 'até 4 horas'), 'prazo_expresso' => (($horasExpresso && $horasExpresso <= 48) ? 'até ' . $horasExpresso . ' horas' : 'até 2 horas'),
            'ativo' => post('ativo') ? 1 : 0,
        ];
        if (mb_strlen($d['nome']) < 2) $erros[] = 'Informe o nome da área.';
        if (mb_strlen($d['cidade']) < 2 || !preg_match('/^[A-Z]{2}$/', $d['uf'])) $erros[] = 'Informe cidade e UF.';
        if (strlen($d['cep_inicio']) !== 8 || strlen($d['cep_fim']) !== 8) $erros[] = 'CEPs inicial e final devem ter 8 dígitos.';
        elseif ($d['cep_inicio'] > $d['cep_fim']) $erros[] = 'O CEP inicial deve ser menor ou igual ao final.';
        if ($d['valor_frete'] < 0 || ($d['valor_expresso'] !== null && $d['valor_expresso'] < 0)) $erros[] = 'Valores de frete não podem ser negativos.';
        if (!$horasPadrao || $horasPadrao > 48 || !$horasExpresso || $horasExpresso > 48) $erros[] = 'Informe prazos entre 1 e 48 horas para as duas opcoes.';
        elseif ($horasExpresso >= $horasPadrao) $erros[] = 'O prazo expresso precisa ser menor que o padrao.';
        if ($d['valor_expresso'] === null || $d['valor_expresso'] <= $d['valor_frete']) $erros[] = 'O frete expresso precisa custar mais que o padrao.';
        if (!$erros) {
            $v = [$d['nome'], $d['cidade'], $d['uf'], $d['cep_inicio'], $d['cep_fim'], numSql($d['valor_frete'], 2),
                $d['valor_expresso'] !== null ? numSql($d['valor_expresso'], 2) : null,
                $d['frete_gratis_acima'] !== null ? numSql($d['frete_gratis_acima'], 2) : null,
                $d['prazo_padrao'], $d['prazo_expresso'], $d['ativo']];
            if ($id) {
                $v[] = $id;
                db()->prepare('UPDATE areas_entrega SET nome=?, cidade=?, uf=?, cep_inicio=?, cep_fim=?, valor_frete=?, valor_expresso=?, frete_gratis_acima=?, prazo_padrao=?, prazo_expresso=?, ativo=? WHERE id=?')->execute($v);
            } else {
                $v[] = agora();
                db()->prepare('INSERT INTO areas_entrega (nome, cidade, uf, cep_inicio, cep_fim, valor_frete, valor_expresso, frete_gratis_acima, prazo_padrao, prazo_expresso, ativo, criado_em) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')->execute($v);
                $id = (int) db()->lastInsertId();
            }
            registrarAlteracao('area_entrega', $id, 'salvar', $d['nome'] . ': CEP ' . cepFormatado($d['cep_inicio']) . '–' . cepFormatado($d['cep_fim']) . ', frete ' . dinheiro($d['valor_frete']));
            flash('sucesso', 'Área de entrega salva.');
            redirecionar('interno/administrador/areas.php');
        }
        $editar = array_merge(['id' => $id], $d);
    }
}

$areas = db()->query('SELECT a.*, (SELECT COUNT(*) FROM pedidos p WHERE p.area_entrega_id = a.id) AS pedidos FROM areas_entrega a ORDER BY a.cep_inicio')->fetchAll();
$f = $editar ?: ['id' => 0, 'nome' => '', 'cidade' => 'São Paulo', 'uf' => 'SP', 'cep_inicio' => '', 'cep_fim' => '', 'valor_frete' => '1.00', 'valor_expresso' => '2.00', 'frete_gratis_acima' => '', 'prazo_padrao' => 'até 4 horas', 'prazo_expresso' => 'até 2 horas', 'ativo' => 1];
$horasDaString = static fn($v, $fallback) => preg_match('/[0-9]+/', (string) $v, $m) ? (int) $m[0] : $fallback;
$fmt = fn($v) => $v === null || $v === '' ? '' : number_format((float) $v, 2, ',', '');

$titulo = 'Áreas de entrega e frete';
$menuAtivo = 'areas';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Áreas de entrega e frete</h1>
<p class="muted">Pedidos só podem ser finalizados para CEPs dentro de uma área <b>ativa</b>. O frete padrão fica grátis quando o subtotal atinge o valor configurado.</p>
<?php if ($erros): ?><div class="aviso aviso-vermelho mb-2"><?= implode('<br>', array_map('e', $erros)) ?></div><?php endif; ?>
<div class="layout-resumo" style="grid-template-columns: 1fr 340px">
  <div class="cartao"><div class="tabela-wrap"><table class="tabela">
    <thead><tr><th>Área</th><th>Faixa de CEP</th><th class="num">Padrão</th><th class="num">Expresso</th><th class="num">Grátis acima</th><th class="num">Pedidos</th><th>Situação</th><th></th></tr></thead>
    <tbody><?php foreach ($areas as $a): ?>
      <tr><td><b><?= e($a['nome']) ?></b><br><small><?= e($a['cidade']) ?>/<?= e($a['uf']) ?></small></td>
        <td><?= e(cepFormatado($a['cep_inicio'])) ?> a <?= e(cepFormatado($a['cep_fim'])) ?></td>
        <td class="num"><?= dinheiro($a['valor_frete']) ?><br><small><?= e($a['prazo_padrao']) ?></small></td>
        <td class="num"><?= $a['valor_expresso'] !== null ? dinheiro($a['valor_expresso']) . '<br><small>' . e($a['prazo_expresso']) . '</small>' : '—' ?></td>
        <td class="num"><?= $a['frete_gratis_acima'] !== null ? dinheiro($a['frete_gratis_acima']) : '—' ?></td>
        <td class="num"><?= (int) $a['pedidos'] ?></td>
        <td><?= (int) $a['ativo'] ? '<span class="badge badge-ok">Ativa</span>' : '<span class="badge badge-erro">Inativa</span>' ?></td>
        <td><div class="acoes-linha"><a class="btn btn-neutro btn-sm" href="?editar=<?= (int) $a['id'] ?>"><?= icone('editar', 'ico-sm') ?></a>
          <form method="post" data-confirma="Excluir/desativar esta área?"><?= csrfCampo() ?><input type="hidden" name="acao" value="excluir"><input type="hidden" name="id" value="<?= (int) $a['id'] ?>">
            <button class="btn btn-perigo btn-sm" type="submit"><?= icone('lixeira', 'ico-sm') ?></button></form></div></td></tr>
    <?php endforeach; ?></tbody>
  </table></div></div>
  <form class="cartao resumo" method="post">
    <?= csrfCampo() ?><input type="hidden" name="acao" value="salvar"><input type="hidden" name="id" value="<?= (int) $f['id'] ?>">
    <h3><?= $f['id'] ? 'Editar área' : 'Nova área' ?></h3>
    <div class="campo"><label for="nome">Nome *</label><input id="nome" name="nome" value="<?= e($f['nome']) ?>" required></div>
    <div class="grid-form">
      <div class="campo col-8"><label for="cidade">Cidade *</label><input id="cidade" name="cidade" value="<?= e($f['cidade']) ?>" required></div>
      <div class="campo col-4"><label for="uf">UF *</label><input id="uf" name="uf" value="<?= e($f['uf']) ?>" maxlength="2" required></div>
      <div class="campo col-6"><label for="cep_inicio">CEP inicial *</label><input id="cep_inicio" name="cep_inicio" value="<?= e(cepFormatado($f['cep_inicio'])) ?>" data-mascara="cep" required></div>
      <div class="campo col-6"><label for="cep_fim">CEP final *</label><input id="cep_fim" name="cep_fim" value="<?= e(cepFormatado($f['cep_fim'])) ?>" data-mascara="cep" required></div>
      <div class="campo col-6"><label for="valor_frete">Frete padrão (R$)</label><input id="valor_frete" name="valor_frete" value="<?= e($fmt($f['valor_frete'])) ?>" inputmode="decimal"></div>
<div class="campo col-6"><label for="prazo_padrao">Prazo padrão (horas)</label><input id="prazo_padrao" name="prazo_padrao" type="number" min="1" max="48" step="1" required value="<?= e($horasDaString($f['prazo_padrao'], 4)) ?>"></div>
      <div class="campo col-6"><label for="valor_expresso">Frete expresso (R$)</label><input id="valor_expresso" name="valor_expresso" value="<?= e($fmt($f['valor_expresso'])) ?>" inputmode="decimal" placeholder="Taxa simbolica"></div>
<div class="campo col-6"><label for="prazo_expresso">Prazo expresso (horas)</label><input id="prazo_expresso" name="prazo_expresso" type="number" min="1" max="48" step="1" required value="<?= e($horasDaString($f['prazo_expresso'], 2)) ?>"></div>
      <div class="campo col-12"><label for="frete_gratis_acima">Frete padrão grátis acima de (R$)</label><input id="frete_gratis_acima" name="frete_gratis_acima" value="<?= e($fmt($f['frete_gratis_acima'])) ?>" inputmode="decimal" placeholder="Vazio = nunca grátis"></div>
    </div>
    <label class="check"><input type="checkbox" name="ativo" value="1" <?= (int) $f['ativo'] ? 'checked' : '' ?>> Área ativa</label>
    <button class="btn btn-primario btn-bloco mt-2" type="submit">Salvar área</button>
    <?php if ($f['id']): ?><a class="btn btn-link btn-bloco mt-1" href="<?= e(url('interno/administrador/areas.php')) ?>">Nova área</a><?php endif; ?>
  </form>
</div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
