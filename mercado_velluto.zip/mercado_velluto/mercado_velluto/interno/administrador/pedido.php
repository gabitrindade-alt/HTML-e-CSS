<?php
/** Detalhe completo do pedido para o administrador: acompanha todas as etapas. */
require __DIR__ . '/../../includes/bootstrap.php';
exigirPerfil('administrador');

$id = (int) get('id', post('id'));
$pedido = buscarPedido($id);
if (!$pedido) {
    flash('erro', 'Pedido não encontrado.');
    redirecionar('interno/administrador/pedidos.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        switch (post('acao')) {
            case 'cancelar':
                $motivo = mb_substr(post('motivo'), 0, 300);
                if (mb_strlen($motivo) < 5) throw new RegraNegocioException('Descreva o motivo do cancelamento.');
                cancelarPedido($id, 'Administração: ' . $motivo, false);
                registrarAlteracao('pedido', $id, 'cancelar', $motivo);
                flash('sucesso', 'Pedido cancelado, estoque devolvido e valor estornado (simulação).');
                break;
            case 'confirmar_pagamento':
                transacao(function () use ($id) {
                    $p = buscarPedido($id, true);
                    if ($p['status'] !== 'aguardando_pagamento') throw new RegraNegocioException('Pedido não está aguardando pagamento.');
                    db()->prepare("UPDATE pagamentos SET status = 'aprovado', confirmado_em = ?, observacao = 'Confirmado manualmente pela administração (simulação)' WHERE pedido_id = ? AND status = 'pendente'")
                        ->execute([agora(), $id]);
                    alterarStatus($id, 'confirmado', 'Pagamento confirmado manualmente pela administração.', ['total_pago' => $p['total']]);
                    alterarStatus($id, 'aguardando_separacao', 'Pedido liberado para separação.');
                });
                registrarAlteracao('pedido', $id, 'confirmar_pagamento', 'Pagamento confirmado manualmente.');
                flash('sucesso', 'Pagamento confirmado.');
                break;
            case 'ocorrencia':
                $desc = mb_substr(post('descricao'), 0, 1000);
                $gravidade = in_array(post('gravidade'), ['baixa', 'media', 'alta'], true) ? post('gravidade') : 'media';
                if (mb_strlen($desc) < 5) throw new RegraNegocioException('Descreva a ocorrência.');
                $oid = registrarOcorrencia($id, null, mb_substr(post('tipo') ?: 'administrativa', 0, 40), $gravidade, $desc);
                registrarHistorico($id, $pedido['status'], $pedido['status'], 'Ocorrência #' . $oid . ' registrada pela administração.');
                flash('sucesso', 'Ocorrência registrada.');
                break;
            default:
                throw new RegraNegocioException('Ação inválida.');
        }
    } catch (RegraNegocioException $e) {
        flash('erro', $e->getMessage());
    }
    redirecionar('interno/administrador/pedido.php?id=' . $id);
}

$st = db()->prepare('SELECT u.* FROM usuarios u WHERE u.id = ?');
$st->execute([$pedido['usuario_id']]);
$cliente = $st->fetch();
$itens = itensDoPedido($id);
$st = db()->prepare('SELECT s.*, po.nome AS original, ps.nome AS sugerido, us.nome AS separador FROM substituicoes s
                     JOIN produtos po ON po.id = s.produto_original_id JOIN produtos ps ON ps.id = s.produto_sugerido_id
                     LEFT JOIN usuarios us ON us.id = s.sugerido_por WHERE s.pedido_id = ? ORDER BY s.id');
$st->execute([$id]);
$subs = $st->fetchAll();
$st = db()->prepare('SELECT * FROM pagamentos WHERE pedido_id = ? ORDER BY id');
$st->execute([$id]);
$pags = $st->fetchAll();
$st = db()->prepare('SELECT h.*, u.nome FROM historico_pedidos h LEFT JOIN usuarios u ON u.id = h.usuario_id WHERE h.pedido_id = ? ORDER BY h.criado_em, h.id');
$st->execute([$id]);
$hist = $st->fetchAll();
$st = db()->prepare('SELECT e.*, u.nome AS entregador FROM entregas e LEFT JOIN usuarios u ON u.id = e.entregador_id WHERE e.pedido_id = ?');
$st->execute([$id]);
$entrega = $st->fetch();
$st = db()->prepare('SELECT o.*, u.nome FROM ocorrencias o LEFT JOIN usuarios u ON u.id = o.usuario_id WHERE o.pedido_id = ? ORDER BY o.id');
$st->execute([$id]);
$ocorrs = $st->fetchAll();
$separador = null;
if ($pedido['separador_id']) {
    $st = db()->prepare('SELECT nome FROM usuarios WHERE id = ?');
    $st->execute([$pedido['separador_id']]);
    $separador = $st->fetchColumn();
}

$titulo = 'Pedido #' . $id;
$menuAtivo = 'pedidos';
require APP_ROOT . '/includes/header_interno.php';
?>
<nav class="migalhas"><a href="<?= e(url('interno/administrador/pedidos.php')) ?>">Pedidos</a> › <span>#<?= $id ?></span></nav>
<div class="flex entre flex-wrap mb-2">
  <h1 class="mb-0">Pedido #<?= $id ?> <?= statusBadge($pedido['status']) ?></h1>
  <span class="pequeno">Criado em <?= dataBr($pedido['criado_em']) ?> · Atualizado em <?= dataBr($pedido['atualizado_em']) ?></span>
</div>

<div class="layout-resumo" style="grid-template-columns: 1fr 340px">
  <div>
    <section class="cartao">
      <h3>Itens</h3>
      <div class="tabela-wrap"><table class="tabela">
        <thead><tr><th>Produto</th><th class="num">Pedido</th><th class="num">Separado</th><th class="num">Unit.</th><th>Situação</th><th class="num">Subtotal</th></tr></thead>
        <tbody><?php foreach ($itens as $i): ?>
          <tr><td><?= e($i['nome_produto']) ?><?= $i['item_origem_id'] ? '<br><small class="muted">' . e($i['observacao']) . '</small>' : '' ?></td>
            <td class="num"><?= e(qtdFormatada($i['quantidade'], $i['vendido_por'])) ?></td>
            <td class="num"><?= $i['quantidade_separada'] !== null ? e(qtdFormatada($i['quantidade_separada'], $i['vendido_por'])) : '—' ?></td>
            <td class="num"><?= dinheiro($i['preco_unitario']) ?></td>
            <td><span class="badge st-<?= e($i['status']) ?>"><?= e(STATUS_ITEM[$i['status']]) ?></span></td>
            <td class="num"><?= dinheiro($i['subtotal']) ?></td></tr>
        <?php endforeach; ?></tbody>
      </table></div>
      <div style="max-width:320px;margin-left:auto" class="mt-1">
        <div class="linha-resumo"><span>Subtotal</span><span><?= dinheiro($pedido['subtotal']) ?></span></div>
        <div class="linha-resumo"><span>Frete (<?= e(freteRotulo($pedido['tipo_frete'])) ?>)</span><span><?= dinheiro($pedido['valor_frete']) ?></span></div>
        <div class="linha-resumo total"><span>Total</span><span><?= dinheiro($pedido['total']) ?></span></div>
        <div class="linha-resumo"><span>Valor pago (líquido)</span><span><?= dinheiro($pedido['total_pago']) ?></span></div>
      </div>
    </section>

    <?php if ($subs): ?>
    <section class="cartao">
      <h3>Substituições</h3>
      <div class="tabela-wrap"><table class="tabela">
        <thead><tr><th>Original → Sugerido</th><th class="num">Diferença</th><th>Status</th><th>Separador</th><th>Resposta</th></tr></thead>
        <tbody><?php foreach ($subs as $s): ?>
          <tr><td><?= e($s['original']) ?> → <b><?= e($s['sugerido']) ?></b></td><td class="num"><?= dinheiro($s['diferenca']) ?></td>
            <td><span class="badge st-<?= e($s['status']) ?>"><?= e(ucfirst($s['status'])) ?></span></td><td><?= e($s['separador']) ?></td><td><small><?= dataBr($s['respondido_em']) ?></small></td></tr>
        <?php endforeach; ?></tbody>
      </table></div>
    </section>
    <?php endif; ?>

    <section class="cartao">
      <h3>Histórico completo</h3>
      <div class="tabela-wrap"><table class="tabela">
        <thead><tr><th>Data</th><th>Transição</th><th>Responsável</th><th>Descrição</th></tr></thead>
        <tbody><?php foreach ($hist as $h): ?>
          <tr><td><small><?= dataBr($h['criado_em']) ?></small></td>
            <td><small><?= $h['status_anterior'] && $h['status_anterior'] !== $h['status_novo'] ? e(statusRotulo($h['status_anterior'])) . ' → ' : '' ?><b><?= e(statusRotulo($h['status_novo'])) ?></b></small></td>
            <td><small><?= e($h['nome'] ?? 'Sistema') ?><br><?= e($h['perfil']) ?></small></td>
            <td><?= e($h['descricao']) ?></td></tr>
        <?php endforeach; ?></tbody>
      </table></div>
    </section>
  </div>

  <aside>
    <section class="cartao">
      <h3>Cliente</h3>
      <dl class="info-lista">
        <dt>Nome</dt><dd><?= e($cliente['nome']) ?></dd>
        <dt>E-mail</dt><dd><?= e($cliente['email']) ?></dd>
        <dt>Telefone</dt><dd><?= e($cliente['telefone'] ?? '—') ?></dd>
        <dt>Endereço</dt><dd><?= e($pedido['endereco_entrega']) ?> · CEP <?= e(cepFormatado($pedido['cep_entrega'])) ?></dd>
        <?php if ($pedido['observacoes']): ?><dt>Obs.</dt><dd><?= e($pedido['observacoes']) ?></dd><?php endif; ?>
      </dl>
    </section>
    <section class="cartao">
      <h3>Operação</h3>
      <dl class="info-lista">
        <dt>Separador</dt><dd><?= e($separador ?: '—') ?></dd>
        <dt>Volumes</dt><dd><?= $pedido['volumes'] ? (int) $pedido['volumes'] : '—' ?></dd>
        <dt>Entrega</dt><dd><?= $entrega ? '<span class="badge st-' . e($entrega['status']) . '">' . e(STATUS_ENTREGA[$entrega['status']]) . '</span>' : '—' ?></dd>
        <dt>Entregador</dt><dd><?= e($entrega['entregador'] ?? '—') ?></dd>
        <?php if ($entrega && $entrega['recebedor']): ?><dt>Recebido por</dt><dd><?= e($entrega['recebedor']) ?></dd><?php endif; ?>
        <?php if ($pedido['motivo_cancelamento']): ?><dt>Cancelamento</dt><dd><?= e($pedido['motivo_cancelamento']) ?></dd><?php endif; ?>
      </dl>
    </section>
    <section class="cartao">
      <h3>Pagamentos (simulados)</h3>
      <?php foreach ($pags as $pg): ?>
        <div class="linha-resumo"><span><?= e(ucfirst($pg['tipo'])) ?> · <?= e(METODOS_PAGAMENTO[$pg['metodo']]) ?><br><small><?= e($pg['codigo_transacao']) ?></small></span>
          <span class="texto-dir"><?= dinheiro($pg['valor']) ?><br><span class="badge st-<?= e($pg['status']) ?>"><?= e($pg['status']) ?></span></span></div>
      <?php endforeach; ?>
      <?php if ($pedido['status'] === 'aguardando_pagamento'): ?>
        <form method="post" class="mt-1"><?= csrfCampo() ?><input type="hidden" name="acao" value="confirmar_pagamento"><input type="hidden" name="id" value="<?= $id ?>">
          <button class="btn btn-secundario btn-sm btn-bloco" type="submit">Confirmar pagamento</button></form>
      <?php endif; ?>
    </section>
    <section class="cartao">
      <h3>Ocorrências (<?= count($ocorrs) ?>)</h3>
      <?php foreach ($ocorrs as $o): ?>
        <p class="pequeno"><span class="badge st-<?= e($o['status']) ?>"><?= e($o['status']) ?></span> <b><?= e($o['tipo']) ?></b> — <?= e($o['descricao']) ?><br><small><?= e($o['nome']) ?> · <?= dataBr($o['criado_em']) ?></small></p>
      <?php endforeach; ?>
      <form method="post"><?= csrfCampo() ?><input type="hidden" name="acao" value="ocorrencia"><input type="hidden" name="id" value="<?= $id ?>">
        <div class="campo"><select name="tipo"><option value="administrativa">Administrativa</option><option value="atendimento">Atendimento</option><option value="pagamento">Pagamento</option><option value="qualidade">Qualidade</option></select></div>
        <div class="campo"><select name="gravidade"><option value="baixa">Gravidade baixa</option><option value="media" selected>Gravidade média</option><option value="alta">Gravidade alta</option></select></div>
        <div class="campo"><textarea name="descricao" placeholder="Descreva a ocorrência" required></textarea></div>
        <button class="btn btn-neutro btn-sm btn-bloco" type="submit">Registrar ocorrência</button></form>
    </section>
    <?php if (!in_array($pedido['status'], ['concluido', 'cancelado'], true)): ?>
    <section class="cartao">
      <h3>Cancelar pedido</h3>
      <form method="post" data-confirma="Cancelar o pedido #<?= $id ?>? O estoque será devolvido e o valor estornado."><?= csrfCampo() ?>
        <input type="hidden" name="acao" value="cancelar"><input type="hidden" name="id" value="<?= $id ?>">
        <div class="campo"><textarea name="motivo" placeholder="Motivo do cancelamento" required></textarea></div>
        <button class="btn btn-perigo btn-bloco" type="submit">Cancelar pedido</button></form>
    </section>
    <?php endif; ?>
  </aside>
</div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
