<?php
/** Relatórios gerenciais por período (com exportação CSV). */
require __DIR__ . '/../../includes/bootstrap.php';
require APP_ROOT . '/includes/graficos.php';
exigirPerfil('administrador');

$de = preg_match('/^\d{4}-\d{2}-\d{2}$/', get('de')) ? get('de') : date('Y-m-d', strtotime('-29 days'));
$ate = preg_match('/^\d{4}-\d{2}-\d{2}$/', get('ate')) ? get('ate') : date('Y-m-d');
$ini = $de . ' 00:00:00';
$fim = $ate . ' 23:59:59';

$st = db()->prepare('SELECT p.*, u.nome AS cliente FROM pedidos p JOIN usuarios u ON u.id = p.usuario_id WHERE p.criado_em BETWEEN ? AND ? ORDER BY p.criado_em');
$st->execute([$ini, $fim]);
$pedidos = $st->fetchAll();

if (get('exportar') === 'csv') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="velluto-pedidos-' . $de . '-a-' . $ate . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Pedido', 'Data', 'Cliente', 'Status', 'Pagamento', 'Subtotal', 'Frete', 'Total', 'Motivo cancelamento'], ';');
    foreach ($pedidos as $p) {
        fputcsv($out, [$p['id'], dataBr($p['criado_em']), $p['cliente'], statusRotulo($p['status']), METODOS_PAGAMENTO[$p['metodo_pagamento']],
            numeroBr($p['subtotal']), numeroBr($p['valor_frete']), numeroBr($p['total']), $p['motivo_cancelamento']], ';');
    }
    fclose($out);
    exit;
}

$validos = array_filter($pedidos, fn($p) => !in_array($p['status'], ['cancelado', 'aguardando_pagamento'], true));
$cancelados = array_filter($pedidos, fn($p) => $p['status'] === 'cancelado');
$concluidos = array_filter($pedidos, fn($p) => $p['status'] === 'concluido');
$faturamento = array_sum(array_column($validos, 'total'));
$frete = array_sum(array_column($validos, 'valor_frete'));
$ticket = $validos ? $faturamento / count($validos) : 0;
$taxaCanc = $pedidos ? count($cancelados) / count($pedidos) * 100 : 0;

// Tempos operacionais (calculados em PHP para independência do banco)
$tSep = $tTotal = [];
foreach ($pedidos as $p) {
    if ($p['separacao_iniciada_em'] && $p['separacao_concluida_em']) {
        $tSep[] = (strtotime($p['separacao_concluida_em']) - strtotime($p['separacao_iniciada_em'])) / 60;
    }
    if ($p['concluido_em']) {
        $tTotal[] = (strtotime($p['concluido_em']) - strtotime($p['criado_em'])) / 3600;
    }
}
$media = fn(array $a) => $a ? array_sum($a) / count($a) : 0;

$st = db()->prepare("SELECT COALESCE(cp.nome, c.nome) AS categoria, SUM(i.subtotal) AS valor
                     FROM itens_pedido i JOIN pedidos p ON p.id = i.pedido_id JOIN produtos pr ON pr.id = i.produto_id
                     JOIN categorias c ON c.id = pr.categoria_id LEFT JOIN categorias cp ON cp.id = c.pai_id
                     WHERE p.criado_em BETWEEN ? AND ? AND p.status NOT IN ('cancelado','aguardando_pagamento') AND i.status IN ('pendente','separado')
                     GROUP BY COALESCE(cp.nome, c.nome) ORDER BY valor DESC");
$st->execute([$ini, $fim]);
$porCategoria = [];
foreach ($st as $l) {
    $porCategoria[$l['categoria']] = (float) $l['valor'];
}

$st = db()->prepare("SELECT i.produto_id, i.nome_produto, i.vendido_por, SUM(COALESCE(i.quantidade_separada, i.quantidade)) AS qtd, SUM(i.subtotal) AS valor
                     FROM itens_pedido i JOIN pedidos p ON p.id = i.pedido_id
                     WHERE p.criado_em BETWEEN ? AND ? AND p.status NOT IN ('cancelado','aguardando_pagamento') AND i.status IN ('pendente','separado')
                     GROUP BY i.produto_id, i.nome_produto, i.vendido_por ORDER BY valor DESC LIMIT 10");
$st->execute([$ini, $fim]);
$top = $st->fetchAll();

$motivos = [];
foreach ($cancelados as $c) {
    $m = trim(explode(' — ', (string) $c['motivo_cancelamento'])[0]) ?: 'Não informado';
    $motivos[$m] = ($motivos[$m] ?? 0) + 1;
}
arsort($motivos);

$st = db()->prepare("SELECT status, COUNT(*) AS n FROM substituicoes WHERE criado_em BETWEEN ? AND ? GROUP BY status");
$st->execute([$ini, $fim]);
$subs = $st->fetchAll(PDO::FETCH_KEY_PAIR);
$respondidas = (int) ($subs['aceita'] ?? 0) + (int) ($subs['rejeitada'] ?? 0);

$st = db()->prepare('SELECT tipo, COUNT(*) AS n FROM ocorrencias WHERE criado_em BETWEEN ? AND ? GROUP BY tipo ORDER BY n DESC');
$st->execute([$ini, $fim]);
$ocorr = array_map('intval', $st->fetchAll(PDO::FETCH_KEY_PAIR));

$porMetodo = [];
foreach ($validos as $p) {
    $k = METODOS_PAGAMENTO[$p['metodo_pagamento']];
    $porMetodo[$k] = ($porMetodo[$k] ?? 0) + (float) $p['total'];
}

$titulo = 'Relatórios';
$menuAtivo = 'relatorios';
require APP_ROOT . '/includes/header_interno.php';
?>
<div class="flex entre flex-wrap mb-2 relatorios-acoes">
  <h1 class="mb-0">Relatórios</h1>
  <button class="btn btn-neutro" type="button" onclick="window.print()">Imprimir relatórios</button>
  <a class="btn btn-secundario" href="?de=<?= e($de) ?>&ate=<?= e($ate) ?>&exportar=csv"><?= icone('documento', 'ico-sm') ?> Exportar pedidos (CSV)</a>
</div>
<p class="relatorios-periodo-impressao">Período do relatório: <?= e(dataBr($de, false)) ?> a <?= e(dataBr($ate, false)) ?></p>
<form class="filtros-linha cartao relatorios-filtros" method="get">
  <div class="campo"><label for="de">De</label><input class="input" type="date" id="de" name="de" value="<?= e($de) ?>"></div>
  <div class="campo"><label for="ate">Até</label><input class="input" type="date" id="ate" name="ate" value="<?= e($ate) ?>"></div>
  <button class="btn btn-neutro" type="submit">Aplicar período</button>
</form>

<div class="kpis mt-2">
  <div class="kpi"><div class="kpi-topo">Pedidos no período</div><div class="kpi-valor"><?= count($pedidos) ?></div><div class="kpi-sub"><?= count($concluidos) ?> concluídos</div></div>
  <div class="kpi"><div class="kpi-topo">Faturamento</div><div class="kpi-valor"><?= dinheiro($faturamento) ?></div><div class="kpi-sub">Frete: <?= dinheiro($frete) ?></div></div>
  <div class="kpi"><div class="kpi-topo">Ticket médio</div><div class="kpi-valor"><?= dinheiro($ticket) ?></div></div>
  <div class="kpi <?= $taxaCanc > 10 ? 'alerta' : '' ?>"><div class="kpi-topo">Cancelamentos</div><div class="kpi-valor"><?= count($cancelados) ?></div><div class="kpi-sub"><?= numeroBr($taxaCanc, 1) ?>% dos pedidos</div></div>
  <div class="kpi"><div class="kpi-topo">Tempo médio de separação</div><div class="kpi-valor"><?= numeroBr($media($tSep), 0) ?> min</div><div class="kpi-sub"><?= count($tSep) ?> separações</div></div>
  <div class="kpi"><div class="kpi-topo">Pedido → entrega</div><div class="kpi-valor"><?= numeroBr($media($tTotal), 1) ?> h</div><div class="kpi-sub">média dos concluídos</div></div>
</div>

<div class="grid-2">
  <section class="cartao"><h3>Vendas por categoria</h3><?= barrasHorizontais($porCategoria, 'dinheiro') ?></section>
  <section class="cartao"><h3>Faturamento por forma de pagamento</h3><?= barrasHorizontais($porMetodo, 'dinheiro') ?></section>
  <section class="cartao">
    <h3>Top 10 produtos (valor)</h3>
    <div class="tabela-wrap"><table class="tabela"><thead><tr><th>Produto</th><th class="num">Qtd.</th><th class="num">Valor</th></tr></thead>
      <tbody><?php foreach ($top as $t): ?><tr><td><?= e($t['nome_produto']) ?></td><td class="num"><?= e(qtdFormatada($t['qtd'], $t['vendido_por'])) ?></td><td class="num"><?= dinheiro($t['valor']) ?></td></tr><?php endforeach; ?>
      <?php if (!$top): ?><tr><td colspan="3" class="muted">Sem vendas no período.</td></tr><?php endif; ?></tbody></table></div>
  </section>
  <section class="cartao">
    <h3>Cancelamentos por motivo</h3><?= barrasHorizontais($motivos, fn($v) => $v . ' pedido(s)') ?>
    <h3 class="mt-3">Substituições</h3>
    <p class="mb-1">Sugeridas: <b><?= array_sum($subs) ?></b> · Aceitas: <b><?= (int) ($subs['aceita'] ?? 0) ?></b> · Recusadas: <b><?= (int) ($subs['rejeitada'] ?? 0) ?></b> · Pendentes: <b><?= (int) ($subs['pendente'] ?? 0) ?></b></p>
    <p class="pequeno">Taxa de aceitação: <b><?= $respondidas ? numeroBr(($subs['aceita'] ?? 0) / $respondidas * 100, 0) : 0 ?>%</b></p>
    <h3 class="mt-3">Ocorrências por tipo</h3><?= barrasHorizontais($ocorr, fn($v) => $v . ' registro(s)') ?>
  </section>
</div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
