<?php
/** Histórico de entregas do entregador logado. */
require __DIR__ . '/../../includes/bootstrap.php';
$eu = exigirPerfil('entregador');

$st = db()->prepare("SELECT e.*, p.total, p.endereco_entrega FROM entregas e JOIN pedidos p ON p.id = e.pedido_id
                     WHERE e.entregador_id = ? AND e.status IN ('entregue','cancelada') ORDER BY e.entregue_em DESC, e.id DESC LIMIT 200");
$st->execute([$eu['id']]);
$lista = $st->fetchAll();
$tempos = [];
foreach ($lista as $l) {
    if ($l['retirada_em'] && $l['entregue_em']) {
        $tempos[] = (strtotime($l['entregue_em']) - strtotime($l['retirada_em'])) / 60;
    }
}

$titulo = 'Histórico de entregas';
$menuAtivo = 'historico';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Histórico de entregas</h1>
<div class="kpis">
  <div class="kpi"><div class="kpi-topo">Entregas concluídas</div><div class="kpi-valor"><?= count(array_filter($lista, fn($l) => $l['status'] === 'entregue')) ?></div></div>
  <div class="kpi"><div class="kpi-topo">Tempo médio em rota</div><div class="kpi-valor"><?= $tempos ? numeroBr(array_sum($tempos) / count($tempos), 0) : 0 ?> min</div></div>
</div>
<div class="cartao"><div class="tabela-wrap"><table class="tabela">
  <thead><tr><th>Pedido</th><th>Endereço</th><th>Retirada</th><th>Entrega</th><th>Recebedor</th><th>Situação</th></tr></thead>
  <tbody><?php foreach ($lista as $l): ?>
    <tr><td><a href="<?= e(url('interno/entregador/entrega.php?id=' . (int) $l['id'])) ?>">#<?= (int) $l['pedido_id'] ?></a></td><td><small><?= e(explode(' · ', $l['endereco_entrega'])[0]) ?></small></td>
      <td><small><?= dataBr($l['retirada_em']) ?></small></td><td><small><?= dataBr($l['entregue_em']) ?></small></td><td><?= e($l['recebedor'] ?? '—') ?></td>
      <td><span class="badge st-<?= e($l['status']) ?>"><?= e(STATUS_ENTREGA[$l['status']]) ?></span></td></tr>
  <?php endforeach; ?>
  <?php if (!$lista): ?><tr><td colspan="6" class="muted texto-centro">Nenhuma entrega no histórico.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
