<?php
/** Entregas disponíveis para assumir. */
require __DIR__ . '/../../includes/bootstrap.php';
$eu = exigirPerfil('entregador');

$lista = db()->query("SELECT e.id, e.tentativas, p.id AS pedido_id, p.total, p.volumes, p.tipo_frete, p.prazo_entrega, p.endereco_entrega, p.cep_entrega,
                      p.separacao_concluida_em, a.nome AS area
                      FROM entregas e JOIN pedidos p ON p.id = e.pedido_id JOIN areas_entrega a ON a.id = p.area_entrega_id
                      WHERE e.status = 'disponivel' AND p.status = 'aguardando_entrega' AND (e.tentativas = 0 OR e.retirada_em <= NOW())
                      ORDER BY p.tipo_frete = 'expresso' DESC, p.separacao_concluida_em ASC")->fetchAll();
$st = db()->prepare("SELECT
    COUNT(CASE WHEN status = 'atribuida' THEN 1 END) AS para_retirar,
    COUNT(CASE WHEN status = 'em_rota' THEN 1 END) AS em_rota,
    COUNT(CASE WHEN status = 'entregue' AND entregue_em >= ? THEN 1 END) AS entregues_hoje
    FROM entregas WHERE entregador_id = ?");
$st->execute([date('Y-m-d') . ' 00:00:00', $eu['id']]);
$resumo = $st->fetch();
$expressas = count(array_filter($lista, static fn ($entrega) => $entrega['tipo_frete'] === 'expresso'));

$titulo = 'Entregas disponíveis';
$menuAtivo = 'disponiveis';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Entregas disponíveis (<?= count($lista) ?>)</h1>
<div class="kpis">
  <div class="kpi"><div class="kpi-topo">Expressas disponíveis</div><div class="kpi-valor"><?= $expressas ?></div></div>
  <div class="kpi"><div class="kpi-topo">Para eu retirar</div><div class="kpi-valor"><?= (int) $resumo['para_retirar'] ?></div><a href="<?= e(url('interno/entregador/minhas.php')) ?>">Minhas entregas</a></div>
  <div class="kpi"><div class="kpi-topo">Comigo em rota</div><div class="kpi-valor"><?= (int) $resumo['em_rota'] ?></div></div>
  <div class="kpi"><div class="kpi-topo">Entregues por mim hoje</div><div class="kpi-valor"><?= (int) $resumo['entregues_hoje'] ?></div><a href="<?= e(url('interno/entregador/historico.php')) ?>">Meu histórico</a></div>
</div>
<div class="cartao">
  <?php if (!$lista): ?><div class="vazio"><?= icone('caminhao', 'ico-lg') ?><h3>Nenhuma entrega disponível</h3><p>Novos pedidos aparecem aqui assim que a separação é concluída.</p></div><?php endif; ?>
  <?php foreach ($lista as $l): $bairro = trim(explode(',', explode(' — ', $l['endereco_entrega'])[1] ?? '')[0]); ?>
    <div class="flex entre flex-wrap" style="padding:14px 0;border-bottom:1px solid var(--linha)">
      <div class="flex"><?= icone('local') ?><div><b>#<?= (int) $l['pedido_id'] ?></b> <?= $l['tipo_frete'] === 'expresso' ? '<span class="badge badge-erro">Expresso</span>' : '' ?>
        <?= (int) $l['tentativas'] ? '<span class="badge badge-alerta">' . (int) $l['tentativas'] . 'ª nova tentativa</span>' : '' ?><br>
        <small><?= e($bairro ?: $l['area']) ?> · <?= e($l['area']) ?> · CEP <?= e(cepFormatado($l['cep_entrega'])) ?> · <?= (int) $l['volumes'] ?> volume(s)</small><br>
        <small>Prazo <?= e($l['prazo_entrega'] ?: 'a confirmar') ?> · Pronto desde <?= e(dataBr($l['separacao_concluida_em'])) ?></small></div></div>
      <div class="flex">
        <b><?= dinheiro($l['total']) ?></b>
        <form method="post" action="<?= e(url('acoes/entregador.php')) ?>"><?= csrfCampo() ?>
          <input type="hidden" name="acao" value="assumir"><input type="hidden" name="entrega_id" value="<?= (int) $l['id'] ?>">
          <button class="btn btn-primario btn-sm" type="submit">Assumir <?= icone('seta', 'ico-sm') ?></button></form>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
