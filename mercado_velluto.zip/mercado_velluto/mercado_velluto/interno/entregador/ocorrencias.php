<?php
/** Ocorrências registradas pelo entregador logado. */
require __DIR__ . '/../../includes/bootstrap.php';
$eu = exigirPerfil('entregador');

$st = db()->prepare('SELECT o.* FROM ocorrencias o WHERE o.usuario_id = ? ORDER BY o.criado_em DESC LIMIT 200');
$st->execute([$eu['id']]);
$lista = $st->fetchAll();

$titulo = 'Minhas ocorrências';
$menuAtivo = 'ocorrencias';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Minhas ocorrências</h1>
<p class="muted">Para registrar um problema, abra a entrega em <a href="<?= e(url('interno/entregador/minhas.php')) ?>">Minhas entregas</a>.</p>
<div class="cartao"><div class="tabela-wrap"><table class="tabela">
  <thead><tr><th>Data</th><th>Pedido</th><th>Tipo</th><th>Gravidade</th><th>Descrição</th><th>Situação</th></tr></thead>
  <tbody><?php foreach ($lista as $o): ?>
    <tr><td><small><?= dataBr($o['criado_em']) ?></small></td><td><?= $o['pedido_id'] ? '#' . (int) $o['pedido_id'] : '—' ?></td><td><?= e($o['tipo']) ?></td>
      <td><span class="badge"><?= e($o['gravidade']) ?></span></td><td><?= e($o['descricao']) ?></td>
      <td><span class="badge st-<?= e($o['status']) ?>"><?= e($o['status']) ?></span><?= $o['resolucao'] ? '<br><small>' . e($o['resolucao']) . '</small>' : '' ?></td></tr>
  <?php endforeach; ?>
  <?php if (!$lista): ?><tr><td colspan="6" class="muted texto-centro">Nenhuma ocorrência registrada.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
