<?php
/** Detalhe da entrega: dados necessários, endereço, retirada, conclusão e ocorrências. */
require __DIR__ . '/../../includes/bootstrap.php';
$eu = exigirPerfil('entregador');

$id = (int) get('id');
$st = db()->prepare('SELECT e.*, p.id AS pid, p.status AS pedido_status, p.total, p.volumes, p.endereco_entrega, p.cep_entrega, p.observacoes, p.tipo_frete, p.prazo_entrega,
                     u.nome AS cliente, u.telefone FROM entregas e JOIN pedidos p ON p.id = e.pedido_id JOIN usuarios u ON u.id = p.usuario_id WHERE e.id = ?');
$st->execute([$id]);
$e = $st->fetch();
// O entregador vê apenas entregas suas (ou disponíveis, para decidir se assume).
if (!$e || ($e['status'] !== 'disponivel' && (int) $e['entregador_id'] !== (int) $eu['id'])) {
    flash('erro', 'Entrega não encontrada ou atribuída a outro entregador.');
    redirecionar('interno/entregador/index.php');
}
$minha = (int) $e['entregador_id'] === (int) $eu['id'];
$st = db()->prepare("SELECT COUNT(*) FROM itens_pedido WHERE pedido_id = ? AND status = 'separado'");
$st->execute([$e['pid']]);
$qtdItens = (int) $st->fetchColumn();
$st = db()->prepare('SELECT * FROM ocorrencias WHERE entrega_id = ? ORDER BY id DESC');
$st->execute([$id]);
$ocorr = $st->fetchAll();
$mapa = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode(explode(' · ', $e['endereco_entrega'])[0] . ', ' . cepFormatado($e['cep_entrega']));

$titulo = 'Entrega do pedido #' . $e['pid'];
$menuAtivo = 'rota';
require APP_ROOT . '/includes/header_interno.php';
?>
<div class="flex entre flex-wrap mb-2">
  <h1 class="mb-0">Pedido #<?= (int) $e['pid'] ?> <span class="badge st-<?= e($e['status']) ?>"><?= e(STATUS_ENTREGA[$e['status']]) ?></span></h1>
  <?= statusBadge($e['pedido_status']) ?>
</div>
<div class="grid-2">
  <section class="cartao">
    <h3>Dados da entrega</h3>
    <dl class="info-lista">
      <dt>Destinatário</dt><dd><?= e(explode(' · Destinatário: ', $e['endereco_entrega'])[1] ?? $e['cliente']) ?></dd>
      <dt>Endereço</dt><dd><?= e(explode(' · ', $e['endereco_entrega'])[0]) ?></dd>
      <dt>CEP</dt><dd><?= e(cepFormatado($e['cep_entrega'])) ?></dd>
      <?php if ($minha): ?><dt>Telefone</dt><dd><?= e($e['telefone'] ?? '—') ?></dd><?php endif; ?>
      <dt>Volumes</dt><dd><?= (int) $e['volumes'] ?> (<?= $qtdItens ?> itens)</dd>
      <dt>Frete</dt><dd><?= e(freteRotulo($e['tipo_frete'])) ?> · <?= e($e['prazo_entrega']) ?></dd>
      <dt>Tentativas</dt><dd><?= (int) $e['tentativas'] ?></dd>
      <?php if ($e['observacoes']): ?><dt>Observações</dt><dd><b><?= e($e['observacoes']) ?></b></dd><?php endif; ?>
      <dt>Pagamento</dt><dd>Já pago (simulado) — não cobrar na entrega</dd>
    </dl>
    <a class="mapa-simulado mt-2" href="<?= e($mapa) ?>" target="_blank" rel="noopener"><span><?= icone('mapa', 'ico-lg') ?><br>Abrir rota no mapa</span></a>
  </section>

  <section class="cartao">
    <h3>Ações</h3>
    <?php if ($e['status'] === 'disponivel'): ?>
      <form method="post" action="<?= e(url('acoes/entregador.php')) ?>"><?= csrfCampo() ?><input type="hidden" name="acao" value="assumir"><input type="hidden" name="entrega_id" value="<?= $id ?>">
        <button class="btn btn-primario btn-bloco" type="submit">Assumir esta entrega</button></form>
    <?php elseif ($e['status'] === 'atribuida' && $minha): ?>
      <p>1. Retire os <?= (int) $e['volumes'] ?> volume(s) na expedição e confirme:</p>
      <form method="post" action="<?= e(url('acoes/entregador.php')) ?>"><?= csrfCampo() ?><input type="hidden" name="acao" value="retirar"><input type="hidden" name="entrega_id" value="<?= $id ?>">
        <button class="btn btn-primario btn-bloco" type="submit"><?= icone('caixa', 'ico-sm') ?> Confirmar retirada — sair para entrega</button></form>
      <form method="post" action="<?= e(url('acoes/entregador.php')) ?>" class="mt-1" data-confirma="Liberar esta entrega para outro entregador?"><?= csrfCampo() ?>
        <input type="hidden" name="acao" value="liberar"><input type="hidden" name="entrega_id" value="<?= $id ?>">
        <button class="btn btn-link btn-bloco" type="submit">Não vou conseguir entregar — liberar</button></form>
    <?php elseif ($e['status'] === 'em_rota' && $minha): ?>
      <p>Retirado em <?= dataBr($e['retirada_em']) ?>. Ao entregar, confirme:</p>
      <form method="post" action="<?= e(url('acoes/entregador.php')) ?>" data-confirma="Confirmar a entrega do pedido #<?= (int) $e['pid'] ?>?"><?= csrfCampo() ?>
        <input type="hidden" name="acao" value="concluir"><input type="hidden" name="entrega_id" value="<?= $id ?>">
        <div class="campo"><label for="recebedor">Recebido por *</label><input id="recebedor" name="recebedor" required maxlength="120" placeholder="Nome de quem recebeu"></div>
        <div class="campo"><label for="observacao">Observação</label><input id="observacao" name="observacao" maxlength="255" placeholder="Ex.: entregue na portaria"></div>
        <button class="btn btn-sucesso btn-bloco" type="submit"><?= icone('check', 'ico-sm') ?> Confirmar entrega concluída</button>
      </form>
    <?php else: ?>
      <p class="aviso aviso-verde">Entrega <?= e(mb_strtolower(STATUS_ENTREGA[$e['status']])) ?><?= $e['entregue_em'] ? ' em ' . dataBr($e['entregue_em']) . ' · recebido por ' . e($e['recebedor']) : '' ?>.</p>
    <?php endif; ?>

    <?php if ($minha && in_array($e['status'], ['atribuida', 'em_rota'], true)): ?>
      <hr>
      <h3>Registrar problema / ocorrência</h3>
      <form method="post" action="<?= e(url('acoes/entregador.php')) ?>"><?= csrfCampo() ?>
        <input type="hidden" name="acao" value="ocorrencia"><input type="hidden" name="entrega_id" value="<?= $id ?>">
        <div class="grid-2">
          <div class="campo"><label for="tipo">Tipo</label><select id="tipo" name="tipo">
            <option value="cliente_ausente">Cliente ausente</option><option value="endereco_nao_localizado">Endereço não localizado</option>
            <option value="recusa_recebimento">Recusa no recebimento</option><option value="avaria">Avaria / produto danificado</option>
            <option value="atraso">Atraso</option><option value="veiculo">Problema com veículo</option><option value="outro">Outro</option></select></div>
          <div class="campo"><label for="gravidade">Gravidade</label><select id="gravidade" name="gravidade"><option value="baixa">Baixa</option><option value="media" selected>Média</option><option value="alta">Alta</option></select></div>
        </div>
        <div class="campo"><label for="descricao">Descrição *</label><textarea id="descricao" name="descricao" required></textarea></div>
        <label class="check"><input type="checkbox" name="devolver" value="1"> Não foi possível entregar — devolver o pedido à loja para nova tentativa</label>
        <button class="btn btn-perigo mt-1" type="submit"><?= icone('alerta', 'ico-sm') ?> Registrar ocorrência</button>
      </form>
    <?php endif; ?>
    <?php if ($ocorr): ?><h4 class="mt-2">Ocorrências desta entrega</h4>
      <?php foreach ($ocorr as $o): ?><p class="pequeno"><span class="badge st-<?= e($o['status']) ?>"><?= e($o['status']) ?></span> <?= e($o['tipo']) ?> — <?= e($o['descricao']) ?> <small>(<?= dataBr($o['criado_em']) ?>)</small></p><?php endforeach; ?>
    <?php endif; ?>
  </section>
</div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
