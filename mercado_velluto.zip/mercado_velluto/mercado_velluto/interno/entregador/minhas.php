<?php
/** Entregas atribuídas ao entregador logado (em andamento). */
require __DIR__ . '/../../includes/bootstrap.php';
$eu = exigirPerfil('entregador');

$st = db()->prepare("SELECT e.*, p.total, p.volumes, p.endereco_entrega, p.cep_entrega, p.tipo_frete FROM entregas e JOIN pedidos p ON p.id = e.pedido_id
                     WHERE e.entregador_id = ? AND e.status IN ('atribuida','em_rota') ORDER BY e.status = 'em_rota' DESC, e.assumida_em");
$st->execute([$eu['id']]);
$lista = $st->fetchAll();

$titulo = 'Minhas entregas';
$menuAtivo = 'rota';
require APP_ROOT . '/includes/header_interno.php';
?>
<h1>Minhas entregas em andamento</h1>
<div class="cartao">
  <?php if (!$lista): ?><div class="vazio"><?= icone('caminhao', 'ico-lg') ?><h3>Nenhuma entrega em andamento</h3>
    <a class="btn btn-primario" href="<?= e(url('interno/entregador/index.php')) ?>">Ver entregas disponíveis</a></div><?php endif; ?>
  <?php foreach ($lista as $l): ?>
    <div class="flex entre flex-wrap" style="padding:14px 0;border-bottom:1px solid var(--linha)">
      <div><b>Pedido #<?= (int) $l['pedido_id'] ?></b> <span class="badge st-<?= e($l['status']) ?>"><?= e(STATUS_ENTREGA[$l['status']]) ?></span><br>
        <small><?= e($l['endereco_entrega']) ?> · <?= (int) $l['volumes'] ?> volume(s)</small></div>
      <a class="btn btn-primario btn-sm" href="<?= e(url('interno/entregador/entrega.php?id=' . (int) $l['id'])) ?>">Abrir <?= icone('seta', 'ico-sm') ?></a>
    </div>
  <?php endforeach; ?>
</div>
<?php require APP_ROOT . '/includes/footer_interno.php'; ?>
