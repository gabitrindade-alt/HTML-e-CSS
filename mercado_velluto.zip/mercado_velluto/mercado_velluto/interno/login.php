<?php
/** Login específico de cada perfil interno. */
require __DIR__ . '/../includes/bootstrap.php';

$perfil = get('perfil', post('perfil'));
if (!in_array($perfil, PERFIS_INTERNOS, true)) {
    redirecionar('interno/index.php');
}
$u = usuarioLogado();
$cadastro = $perfil === 'administrador' && get('cadastro', post('cadastro')) === '1';
$destino = $cadastro ? 'interno/administrador/funcionarios.php#cadastro-funcionario' : painelDoPerfil($perfil);
$primeiroAdmin = $perfil === 'administrador' && ehRequisicaoLocal() && !(int) db()->query("SELECT COUNT(*) FROM usuarios WHERE perfil = 'administrador' AND ativo = 1 AND senha_hash IS NOT NULL")->fetchColumn();
if ($u && $u['perfil'] === $perfil) {
    redirecionar($destino);
}
$erro = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = mb_strtolower(post('email'));
    $senha = (string) ($_POST['senha'] ?? '');
    if (loginBloqueado()) {
        $erro = 'Muitas tentativas. Aguarde 1 minuto.';
    } else {
        $conta = autenticar($email, $senha);
        // A conta precisa existir, estar ativa e ter exatamente o perfil escolhido.
        if (!$conta || $conta['perfil'] !== $perfil) {
            registrarFalhaLogin();
            $erro = 'Credenciais inválidas para o perfil ' . PERFIL_ROTULO[$perfil] . '.';
        } else {
            limparFalhasLogin();
            iniciarSessaoUsuario($conta);
            registrarAlteracao('sessao', (int) $conta['id'], 'login', 'Login no painel ' . PERFIL_ROTULO[$perfil]);
            flash('sucesso', 'Olá, ' . explode(' ', $conta['nome'])[0] . '!');
            redirecionar($destino);
        }
    }
}
$icones = ['administrador' => 'engrenagem', 'separador' => 'caixa', 'entregador' => 'caminhao'];
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>Login <?= e(PERFIL_ROTULO[$perfil]) ?> · Velluto</title>
<link rel="icon" href="<?= e(asset('img/marca-velluto.svg')) ?>" type="image/svg+xml">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<script>try{document.documentElement.dataset.theme=localStorage.getItem("velluto-theme")||"light";}catch(e){}</script>
<link rel="stylesheet" href="<?= e(asset('css/velluto.css')) ?>">
</head>
<body data-url-interno="<?= e(url('interno/index.php')) ?>" style="background:linear-gradient(140deg,#FFF8F2,#F8E9E2 60%,#F7DCE4)">
<?= mostrarFlash() ?>
<div class="container-estreito pagina" style="max-width:440px">
  <div class="cartao mt-3">
    <div class="texto-centro">
      <span class="categoria-icone" style="background:var(--rosa-suave);margin:0 auto 10px"><?= icone($icones[$perfil], 'ico-lg') ?></span>
      <h1 class="mb-0">Painel do <?= e(PERFIL_ROTULO[$perfil]) ?></h1>
      <p class="muted"><?= $cadastro ? 'Entre como administrador para cadastrar um funcionário.' : 'Acesso restrito à equipe Velluto' ?></p>
    </div>
    <?php if ($u && $u['perfil'] !== $perfil): ?>
      <p class="aviso">Você está conectado como <?= e(PERFIL_ROTULO[$u['perfil']]) ?>. Entrar aqui encerrará a sessão atual.</p>
    <?php endif; ?>
    <?php if ($erro): ?><div class="aviso aviso-vermelho mb-2"><?= e($erro) ?></div><?php endif; ?>
    <form method="post" action="<?= e(url('interno/login.php')) ?>">
      <?= csrfCampo() ?><input type="hidden" name="perfil" value="<?= e($perfil) ?>">
      <?php if ($cadastro): ?><input type="hidden" name="cadastro" value="1"><?php endif; ?>
      <div class="campo"><label for="email">E-mail corporativo</label>
        <input id="email" type="email" name="email" value="<?= e($email) ?>" required autocomplete="username" placeholder="nome@velluto.com"></div>
      <div class="campo"><label for="senha">Senha</label>
        <div class="senha-wrap"><input id="senha" type="password" name="senha" required autocomplete="current-password">
          <button type="button" data-ver-senha aria-label="Mostrar senha"><?= icone('olho', 'ico-sm') ?></button></div></div>
      <button class="btn btn-primario btn-bloco" type="submit">Entrar</button>
    </form>
    <?php if ($primeiroAdmin): ?>
      <p class="texto-centro mt-2"><a class="btn btn-secundario btn-bloco" href="<?= e(url('interno/instalar.php')) ?>">Cadastrar primeiro administrador</a></p>
    <?php endif; ?>
    <?php if (permiteCadastroInternoLocal($perfil)): ?>
      <p class="mt-2"><a class="btn btn-secundario btn-bloco" href="<?= e(url('interno/cadastro.php?perfil=' . $perfil)) ?>">Criar conta de <?= e(mb_strtolower(PERFIL_ROTULO[$perfil])) ?></a></p>
    <?php endif; ?>
    <p class="texto-centro pequeno mt-2 mb-0"><a href="<?= e(url('interno/index.php')) ?>">← Trocar de perfil</a></p>
  </div>
</div>
<script src="<?= e(asset('js/velluto.js')) ?>"></script>
<script src="<?= e(asset('js/preferencias.js')) ?>"></script>
</body>
</html>
