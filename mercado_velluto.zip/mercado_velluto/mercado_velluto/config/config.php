<?php
/**
 * VELLUTO — Configurações gerais da aplicação.
 * Ajuste os dados de acesso ao MySQL conforme o seu XAMPP.
 * (Padrão do XAMPP: usuário "root" e senha vazia.)
 */

define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'velluto');
define('DB_USER', 'root');
define('DB_PASS', '');

/*
 * Caminho público do projeto. Deixe vazio ('') para detecção automática.
 * Exemplo manual: '/velluto' quando o projeto está em C:\xampp\htdocs\velluto
 */
define('BASE_URL_MANUAL', '');

define('APP_NOME', 'Velluto');
define('APP_TIMEZONE', 'America/Sao_Paulo');

/* Mostra detalhes de erros na tela (use false fora do ambiente acadêmico). */
define('APP_DEBUG', true);

/* Itens por página no catálogo */
define('ITENS_POR_PAGINA', 12);

/* Pasta de upload de imagens de produtos */
define('UPLOAD_DIR', dirname(__DIR__) . '/uploads/produtos');
define('UPLOAD_MAX_BYTES', 2 * 1024 * 1024);
