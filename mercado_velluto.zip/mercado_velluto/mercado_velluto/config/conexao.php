<?php
/**
 * VELLUTO — Conexão reutilizável com o banco de dados (PDO).
 * Todas as consultas do sistema usam consultas preparadas.
 */

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $opcoes = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    // Permite apontar para outro banco via variável de ambiente (usado em testes automatizados).
    $dsnAlternativo = getenv('VELLUTO_DSN');

    try {
        if ($dsnAlternativo) {
            $pdo = new PDO($dsnAlternativo, null, null, $opcoes);
            if (str_starts_with($dsnAlternativo, 'sqlite:')) {
                $pdo->exec('PRAGMA foreign_keys = ON');
                $pdo->exec('PRAGMA busy_timeout = 5000');
            }
        } else {
            $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $opcoes);
            $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
        }
    } catch (PDOException $e) {
        http_response_code(500);
        $msg = APP_DEBUG ? htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') : 'Erro de conexão.';
        exit('<div style="font-family:sans-serif;max-width:640px;margin:60px auto;padding:24px;border:1px solid #e5c6cf;border-radius:12px;background:#fff7f9;color:#3b2a24">'
            . '<h2 style="margin-top:0">Velluto — não foi possível conectar ao banco de dados</h2>'
            . '<p>Verifique se o MySQL está iniciado no XAMPP e se o banco <b>velluto</b> foi importado '
            . '(arquivo <code>database/velluto.sql</code>). Confira também <code>config/config.php</code>.</p>'
            . '<p style="color:#a8355a"><small>' . $msg . '</small></p></div>');
    }
    return $pdo;
}

/** Retorna true quando a conexão atual é MySQL/MariaDB. */
function dbEhMysql(): bool
{
    return db()->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql';
}
