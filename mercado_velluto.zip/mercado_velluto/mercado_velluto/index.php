<?php
require __DIR__ . '/includes/bootstrap.php';

$categorias = categoriasMenu();
$campanha = temporadaAtual();
$slugsCampanha = array_keys($campanha['descontos']);
$slotsCampanha = implode(',', array_fill(0, count($slugsCampanha), '?'));
$st = db()->prepare("SELECT p.*, c.slug AS categoria_slug FROM produtos p JOIN categorias c ON c.id = p.categoria_id
    WHERE p.ativo = 1 AND c.ativo = 1 AND p.slug IN ($slotsCampanha) ORDER BY p.estoque > 0 DESC, p.nome");
$st->execute($slugsCampanha);
$tematicos = $st->fetchAll();
$st = db()->prepare("SELECT p.* FROM produtos p WHERE ativo = 1 AND preco_promocional > 0
    AND preco_promocional < preco AND p.slug NOT IN ($slotsCampanha)
    ORDER BY destaque DESC, (preco - preco_promocional) / preco DESC LIMIT 8");
$st->execute($slugsCampanha);
$ofertas = $st->fetchAll();
$destaques = db()->query('SELECT * FROM produtos WHERE ativo = 1 AND destaque = 1 AND estoque > 0 ORDER BY nome LIMIT 8')->fetchAll();
$st = db()->prepare("SELECT p.* FROM produtos p WHERE ativo = 1 AND slug NOT IN ($slotsCampanha)
    AND slug NOT IN ('panetone-frutas', 'chocotone-gotas', 'suco-maca-espumante', 'mix-castanhas-ceia',
        'ovo-pascoa-chocolate', 'pacoca-junina', 'canjica-branca', 'gomas-halloween')
    ORDER BY criado_em DESC, id DESC LIMIT 4");
$st->execute($slugsCampanha);
$novidades = $st->fetchAll();
$natal = $campanha['chave'] === 'natal';
$maiorDesconto = 0;
foreach ($tematicos as $produto) {
    if ((float) $produto['estoque'] > 0 && emPromocao($produto)) {
        $maiorDesconto = max($maiorDesconto, (int) round((1 - precoAtual($produto) / (float) $produto['preco']) * 100));
    }
}
$slides = array_values(array_filter(bannersCarrossel(), static fn ($banner) => (bool) $banner['ativo']));
$opcoes = opcoesCarrossel();
$gruposTematicos = [$campanha['titulo'] => $tematicos];
if ($natal) {
    $decoracao = array_filter($tematicos, static fn ($produto) => $produto['categoria_slug'] === 'casa-decoracao');
    $gruposTematicos = ['Ofertas para a ceia' => array_diff_key($tematicos, $decoracao), 'Decoração de Natal' => $decoracao];
}

$titulo = 'Hipermercado online';
require APP_ROOT . '/includes/header.php';
?>
<div class="container">
  <?php if ($slides): ?>
  <section class="carrossel" data-carrossel data-autoplay="<?= $opcoes['automatico'] ? '1' : '0' ?>"
           data-intervalo="<?= $opcoes['segundos'] * 1000 ?>" data-efeito="<?= e($opcoes['efeito']) ?>" aria-label="Destaques da loja">
    <div id="slides-loja" aria-live="polite">
      <?php foreach ($slides as $i => $slide):
          ['titulo' => $chamada, 'texto' => $texto, 'botao' => $botao, 'destino' => $link, 'imagem' => $foto, 'alt' => $alt] = $slide;
          $slideTemporada = $slide['chave'] === 'temporada';
          $slideNatal = $slideTemporada && $natal;
          if ($link === '#ofertas-temporada' && !$tematicos) $link = 'catalogo.php?temporada=1';
      ?>
      <div class="hero<?= $slideTemporada ? ($slideNatal ? ' hero-natal' : ' hero-sazonal') : '' ?>" data-slide role="group"
           aria-label="<?= e($chamada) ?>" <?= $i ? 'hidden' : '' ?>>
        <div class="hero-texto">
          <?php if ($slideNatal): ?><span class="hero-etiqueta">Natal Velluto</span><?php endif; ?>
          <?php if ($i === 0): ?><h1><?= e($chamada) ?></h1><?php else: ?><h2><?= e($chamada) ?></h2><?php endif; ?>
          <p><?= e($texto) ?></p>
          <div class="flex flex-wrap">
            <a class="btn btn-primario" href="<?= e(url($link)) ?>"><?= e($botao) ?> <?= icone('seta', 'ico-sm') ?></a>
            <?php if ($slide['chave'] === 'loja'): ?>
              <a class="btn btn-secundario" href="<?= e(url('ajuda.php#area')) ?>">Consultar entrega</a>
            <?php endif; ?>
          </div>
          <?php if ($slideNatal && $maiorDesconto): ?>
            <p class="hero-desconto">Até <strong><?= $maiorDesconto ?>% de desconto</strong> em produtos selecionados</p>
          <?php endif; ?>
        </div>
        <picture class="hero-img">
          <?php if ($slideNatal && $foto === 'assets/img/ceia-velluto.jpg'): ?>
            <source media="(max-width: 760px)" srcset="<?= e(asset('img/hero-natal.jpg')) ?>">
          <?php endif; ?>
          <img src="<?= e(fotoBanner($foto)) ?>" alt="<?= e($alt) ?>" <?= $i ? 'loading="lazy"' : 'fetchpriority="high"' ?>>
        </picture>
      </div>
      <?php endforeach; ?>
    </div>
    <?php if (count($slides) > 1): ?>
    <div class="carrossel-controles" data-controles hidden>
      <div class="carrossel-opcoes" role="group" aria-label="Escolher destaque">
        <?php foreach ($slides as $i => $slide): ?>
          <button class="carrossel-opcao" type="button" data-ir="<?= $i ?>" aria-controls="slides-loja" aria-pressed="<?= $i ? 'false' : 'true' ?>"><?= e($slide['rotulo']) ?></button>
        <?php endforeach; ?>
      </div>
      <div class="carrossel-setas" role="group" aria-label="Navegar pelos destaques">
        <button class="carrossel-reproducao" type="button" data-reproducao aria-controls="slides-loja">Pausar</button>
        <button class="carrossel-seta" type="button" data-passo="-1" aria-label="Imagem anterior" aria-controls="slides-loja">←</button>
        <button class="carrossel-seta" type="button" data-passo="1" aria-label="Próxima imagem" aria-controls="slides-loja">→</button>
      </div>
    </div>
    <?php endif; ?>
  </section>
  <?php else: ?><h1 class="sr-only">Hipermercado online</h1><?php endif; ?>

  <?php if ($tematicos): ?>
  <section class="secao vitrine-temporada" id="ofertas-temporada">
    <?php foreach ($gruposTematicos as $nome => $itens): if (!$itens) continue; ?>
      <div class="secao-titulo">
        <h2><?= e($nome) ?></h2>
        <a href="<?= e(url('catalogo.php?temporada=1' . ($nome === 'Decoração de Natal' ? '&categoria=' . (int) reset($itens)['categoria_id'] : ''))) ?>">Ver ofertas →</a>
      </div>
      <div class="grade-produtos">
        <?php foreach ($itens as $p) { echo cartaoProduto($p); } ?>
      </div>
    <?php endforeach; ?>
  </section>
  <?php endif; ?>

  <div class="beneficios">
    <div class="beneficio"><?= icone('caminhao') ?><div><b>Entrega rápida</b>Padrão ou expressa</div></div>
    <div class="beneficio"><?= icone('balanca') ?><div><b>Peso justo</b>Cobrança pelo peso real</div></div>
    <div class="beneficio"><?= icone('troca') ?><div><b>Você decide</b>Aprova cada substituição</div></div>
    <div class="beneficio"><?= icone('cadeado') ?><div><b>Compra segura</b>Pagamento simulado</div></div>
  </div>

  <section class="secao" id="categorias-loja">
    <div class="secao-titulo"><h2>Categorias</h2><a href="<?= e(url('catalogo.php')) ?>">Ver todas →</a></div>
    <div class="grade-categorias">
      <?php foreach ($categorias as $c): ?>
        <a class="categoria-card" href="<?= e(url('catalogo.php?categoria=' . (int) $c['id'])) ?>">
          <?= visualCategoria($c) ?>
          <?= e($c['nome']) ?>
        </a>
      <?php endforeach; ?>
    </div>
  </section>

  <?php if ($ofertas): ?>
  <section class="secao">
    <div class="secao-titulo"><h2>Ofertas da semana</h2><a href="<?= e(url('catalogo.php?ofertas=1')) ?>">Ver ofertas →</a></div>
    <div class="grade-produtos">
      <?php foreach ($ofertas as $p) { echo cartaoProduto($p); } ?>
    </div>
  </section>
  <?php endif; ?>

  <section class="secao">
    <div class="secao-titulo"><h2>Escolhas Velluto</h2><a href="<?= e(url('catalogo.php')) ?>">Ver catálogo →</a></div>
    <div class="grade-produtos">
      <?php foreach ($destaques as $p) { echo cartaoProduto($p); } ?>
    </div>
  </section>

  <section class="secao">
    <div class="secao-titulo"><h2>Novidades</h2><a href="<?= e(url('catalogo.php?ordem=novidades')) ?>">Ver novidades →</a></div>
    <div class="grade-produtos">
      <?php foreach ($novidades as $p) { echo cartaoProduto($p); } ?>
    </div>
  </section>
</div>
<?php require APP_ROOT . '/includes/footer.php'; ?>
