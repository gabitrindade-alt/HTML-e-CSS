<?php
require __DIR__ . '/includes/bootstrap.php';

$id = (int) get('id');
$st = db()->prepare('SELECT p.*, c.nome AS categoria_nome, c.pai_id, c.id AS cat_id FROM produtos p
                     JOIN categorias c ON c.id = p.categoria_id WHERE p.id = ? AND p.ativo = 1');
$st->execute([$id]);
$p = $st->fetch();
if (!$p) {
    http_response_code(404);
    $titulo = 'Produto não encontrado';
    require APP_ROOT . '/includes/header.php';
    echo '<div class="container pagina"><div class="cartao vazio">' . icone('busca', 'ico-lg') .
        '<h2>Produto não encontrado</h2><p>Ele pode ter sido removido do catálogo.</p><a class="btn btn-primario" href="' . e(url('catalogo.php')) . '">Ver catálogo</a></div></div>';
    require APP_ROOT . '/includes/footer.php';
    exit;
}
$pai = null;
if ($p['pai_id']) {
    $s = db()->prepare('SELECT id, nome FROM categorias WHERE id = ?');
    $s->execute([$p['pai_id']]);
    $pai = $s->fetch();
}

$av = db()->prepare('SELECT a.*, u.nome FROM avaliacoes a JOIN usuarios u ON u.id = a.usuario_id WHERE a.produto_id = ? ORDER BY a.criado_em DESC');
$av->execute([$id]);
$avaliacoes = $av->fetchAll();
$media = $avaliacoes ? array_sum(array_column($avaliacoes, 'nota')) / count($avaliacoes) : 0;

// O cliente pode avaliar se já recebeu este produto em um pedido concluído.
$podeAvaliar = false;
$u = usuarioLogado();
if ($u && $u['perfil'] === 'cliente') {
    $s = db()->prepare("SELECT COUNT(*) FROM itens_pedido i JOIN pedidos pe ON pe.id = i.pedido_id
                        WHERE pe.usuario_id = ? AND pe.status = 'concluido' AND i.produto_id = ? AND i.status = 'separado'");
    $s->execute([$u['id'], $id]);
    $jaAvaliou = in_array((int) $u['id'], array_map('intval', array_column($avaliacoes, 'usuario_id')), true);
    $podeAvaliar = (int) $s->fetchColumn() > 0 && !$jaAvaliou;
}

$rel = db()->prepare('SELECT * FROM produtos WHERE categoria_id = ? AND id <> ? AND ativo = 1 ORDER BY estoque > 0 DESC, destaque DESC LIMIT 4');
$rel->execute([$p['categoria_id'], $id]);
$relacionados = $rel->fetchAll();

$passo = passoQtd($p);
$noCarrinho = carrinho()[$id] ?? 0;
$maxQtd = max(0, (float) $p['estoque'] - (float) $noCarrinho);
$fav = in_array($id, idsFavoritos(), true);
$titulo = $p['nome'];
$ativo = 'categorias';
require APP_ROOT . '/includes/header.php';
?>
<div class="container pagina">
  <nav class="migalhas" aria-label="Você está em">
    <a href="<?= e(url('index.php')) ?>">Home</a> ›
    <?php if ($pai): ?><a href="<?= e(url('catalogo.php?categoria=' . (int) $pai['id'])) ?>"><?= e($pai['nome']) ?></a> ›<?php endif; ?>
    <a href="<?= e(url('catalogo.php?categoria=' . (int) $p['cat_id'])) ?>"><?= e($p['categoria_nome']) ?></a> ›
    <span><?= e($p['nome']) ?></span>
  </nav>

  <div class="produto-detalhe">
    <div class="foto-principal"><img src="<?= e(imagemProduto($p)) ?>" alt="<?= e($p['nome']) ?>"></div>
    <div>
      <small class="muted"><?= e($p['marca']) ?></small>
      <h1 class="mb-1"><?= e($p['nome']) ?></h1>
      <p class="muted mb-1"><?= e($p['embalagem']) ?></p>
      <?php if ($avaliacoes): ?><p class="mb-1"><span class="estrelas"><?= str_repeat('★', (int) round($media)) . str_repeat('☆', 5 - (int) round($media)) ?></span> <small><?= numeroBr($media, 1) ?> (<?= count($avaliacoes) ?>)</small></p><?php endif; ?>
      <div class="preco">
        <?php if (emPromocao($p)): ?><span class="preco-antigo"><?= dinheiro($p['preco']) ?></span><?php endif; ?>
        <?= dinheiro(precoAtual($p)) ?><small><?= unidadePreco($p) ?></small>
      </div>
      <?php if ($p['vendido_por'] === 'peso'): ?>
        <p class="aviso aviso-rosa mt-1"><?= icone('balanca', 'ico-sm') ?> Produto vendido por peso. O valor final é ajustado pelo <b>peso real</b> conferido na separação.</p>
      <?php endif; ?>
      <p class="mt-1">
        <?php if ((float) $p['estoque'] <= 0): ?><span class="disponibilidade sem">Indisponível no momento</span>
        <?php elseif (estoqueBaixo($p)): ?><span class="disponibilidade baixo">Últimas unidades (<?= e(qtdFormatada($p['estoque'], $p['vendido_por'])) ?>)</span>
        <?php else: ?><span class="disponibilidade">Em estoque</span><?php endif; ?>
      </p>

      <?php if ((float) $p['estoque'] > 0): ?>
      <form method="post" action="<?= e(url('acoes/carrinho.php')) ?>" class="flex flex-wrap mt-2">
        <?= csrfCampo() ?>
        <input type="hidden" name="acao" value="adicionar">
        <input type="hidden" name="produto_id" value="<?= $id ?>">
        <div class="qtd">
          <button type="button" data-qtd="-1" aria-label="Diminuir"><?= icone('menos', 'ico-sm') ?></button>
          <input type="number" name="qtd" value="<?= e($p['vendido_por'] === 'peso' ? number_format(qtdPadrao($p), 2, '.', '') : 1) ?>" min="<?= e($passo['min']) ?>" max="<?= e($maxQtd) ?>" step="<?= e($passo['passo']) ?>" aria-label="Quantidade<?= $p['vendido_por'] === 'peso' ? ' em kg' : '' ?>">
          <button type="button" data-qtd="1" aria-label="Aumentar"><?= icone('mais', 'ico-sm') ?></button>
        </div>
        <?php if ($p['vendido_por'] === 'peso'): ?><small>kg</small><?php endif; ?>
        <button class="btn btn-primario" type="submit" <?= $maxQtd < $passo['min'] ? 'disabled' : '' ?>><?= icone('carrinho', 'ico-sm') ?> Adicionar ao carrinho</button>
      </form>
      <?php if ($noCarrinho): ?><p class="pequeno mt-1">Você já tem <?= e(qtdFormatada($noCarrinho, $p['vendido_por'])) ?> no carrinho.</p><?php endif; ?>
      <?php endif; ?>
      <form method="post" action="<?= e(url('acoes/favorito.php')) ?>" class="mt-1">
        <?= csrfCampo() ?><input type="hidden" name="produto_id" value="<?= $id ?>">
        <button class="btn btn-secundario btn-sm" type="submit"><?= icone('coracao', 'ico-sm') ?> <?= $fav ? 'Remover dos favoritos' : 'Adicionar aos favoritos' ?></button>
      </form>
    </div>
  </div>

  <div data-abas>
    <div class="abas" role="tablist">
      <button class="aba ativa" type="button" data-aba="aba-desc">Descrição</button>
      <button class="aba" type="button" data-aba="aba-info">Informações</button>
      <button class="aba" type="button" data-aba="aba-aval">Avaliações (<?= count($avaliacoes) ?>)</button>
    </div>
    <div class="aba-conteudo ativa" id="aba-desc"><p><?= nl2br(e($p['descricao'])) ?></p></div>
    <div class="aba-conteudo" id="aba-info"><p><?= nl2br(e(trim(str_replace('Produto fictício para fins acadêmicos.', '', $p['informacoes'] ?? '')))) ?></p></div>
    <div class="aba-conteudo" id="aba-aval">
      <?php foreach ($avaliacoes as $a): ?>
        <div class="cartao">
          <span class="estrelas"><?= str_repeat('★', (int) $a['nota']) . str_repeat('☆', 5 - (int) $a['nota']) ?></span>
          <b><?= e(explode(' ', $a['nome'])[0]) ?></b> <small><?= dataBr($a['criado_em'], false) ?></small>
          <p class="mb-0 mt-1"><?= e($a['comentario']) ?></p>
        </div>
      <?php endforeach; ?>
      <?php if (!$avaliacoes): ?><p class="muted">Este produto ainda não tem avaliações.</p><?php endif; ?>
      <?php if ($podeAvaliar): ?>
        <form class="cartao mt-2" method="post" action="<?= e(url('acoes/avaliacao.php')) ?>">
          <?= csrfCampo() ?><input type="hidden" name="produto_id" value="<?= $id ?>">
          <h3>Avalie este produto</h3>
          <div class="campo"><label for="nota">Nota</label>
            <select id="nota" name="nota" required><?php for ($n = 5; $n >= 1; $n--): ?><option value="<?= $n ?>"><?= str_repeat('★', $n) ?> (<?= $n ?>)</option><?php endfor; ?></select></div>
          <div class="campo"><label for="comentario">Comentário</label><textarea id="comentario" name="comentario" maxlength="500"></textarea></div>
          <button class="btn btn-primario" type="submit">Enviar avaliação</button>
        </form>
      <?php elseif (!$u): ?>
        <p class="pequeno">Clientes que receberam este produto podem avaliá-lo. <a href="<?= e(url('cliente/login.php?voltar=' . urlencode('produto.php?id=' . $id))) ?>">Entrar</a></p>
      <?php endif; ?>
    </div>
  </div>

  <?php if ($relacionados): ?>
  <section class="secao">
    <div class="secao-titulo"><h2>Você também pode gostar</h2></div>
    <div class="grade-produtos"><?php foreach ($relacionados as $r) { echo cartaoProduto($r); } ?></div>
  </section>
  <?php endif; ?>
</div>
<?php require APP_ROOT . '/includes/footer.php'; ?>
