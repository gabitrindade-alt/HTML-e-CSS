(function () {
  'use strict';

  function readPreference(key, fallback) {
    try {
      return localStorage.getItem(key) || fallback;
    } catch (_) {
      return fallback;
    }
  }

  function savePreference(key, value) {
    try {
      localStorage.setItem(key, value);
    } catch (_) {}
  }

  function init() {
    var theme = readPreference('velluto-theme', 'light');
    if (theme !== 'dark') theme = 'light';
    document.documentElement.dataset.theme = theme;

    var widget = document.createElement('div');
    widget.className = 'preferencias-ui';
    widget.setAttribute('aria-label', 'Preferências de aparência');
    widget.innerHTML = '<button type="button" class="preferencia-tema" data-theme-toggle></button>';
    document.body.appendChild(widget);

    var themeButton = widget.querySelector('[data-theme-toggle]');
    function paintThemeButton() {
      var dark = document.documentElement.dataset.theme === 'dark';
      themeButton.textContent = (dark ? '\u2600 ' : '\u263E ') + (dark ? 'Tema claro' : 'Tema escuro');
      themeButton.setAttribute('aria-label', themeButton.textContent.trim());
    }

    themeButton.addEventListener('click', function () {
      var next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
      document.documentElement.dataset.theme = next;
      savePreference('velluto-theme', next);
      paintThemeButton();
    });

    paintThemeButton();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
