/* =====================================================================
   VELLUTO — Interações da interface
   (Toda regra importante é validada também no servidor, em PHP.)
   ===================================================================== */
(function () {
  'use strict';
  var body = document.body;

  document.querySelectorAll('[data-carrossel]').forEach(function (carrossel) {
    var slides = Array.from(carrossel.querySelectorAll('[data-slide]'));
    var pontos = Array.from(carrossel.querySelectorAll('[data-ir]'));
    var controles = carrossel.querySelector('[data-controles]');
    if (!controles) return;
    var regiao = carrossel.querySelector('[aria-live]');
    var reproducao = controles.querySelector('[data-reproducao]');
    var movimentoReduzido = window.matchMedia('(prefers-reduced-motion: reduce)');
    var rodando = carrossel.dataset.autoplay === '1' && !movimentoReduzido.matches;
    var intervalo = Number(carrossel.dataset.intervalo);
    var efeito = carrossel.dataset.efeito;
    var ponteiroSobre = false;
    var temporizador;
    var atual = 0;

    function mostrar(indice) {
      var anterior = atual;
      atual = (indice + slides.length) % slides.length;
      if (atual === anterior) return;
      slides.forEach(function (slide, i) { slide.hidden = i !== atual; });
      pontos.forEach(function (ponto, i) { ponto.setAttribute('aria-pressed', String(i === atual)); });
      if (movimentoReduzido.matches || efeito === 'nenhum' || !slides[atual].animate) return;
      var slide = slides[atual];
      var transicao = { duration: 650, easing: 'cubic-bezier(.22,.61,.36,1)' };
      if (efeito === 'dissolver') {
        slide.animate([{ opacity: .25 }, { opacity: 1 }], transicao);
      } else {
        var sentido = indice < anterior ? -1 : 1;
        slide.querySelector('.hero-img').animate([
          { transform: 'translateX(' + (sentido * 8) + '%) scale(1.08)', opacity: .45 },
          { transform: 'translateX(0) scale(1)', opacity: 1 }
        ], transicao);
        slide.querySelector('.hero-texto').animate([
          { transform: 'translateX(' + (sentido * 18) + 'px)', opacity: 0 },
          { transform: 'translateX(0)', opacity: 1 }
        ], transicao);
      }
    }

    function atualizarReproducao() {
      clearTimeout(temporizador);
      reproducao.textContent = rodando ? 'Pausar' : 'Reproduzir';
      reproducao.setAttribute('aria-label', rodando ? 'Pausar carrossel' : 'Reproduzir carrossel');
      var podeAvancar = rodando && !ponteiroSobre && !document.hidden;
      regiao.setAttribute('aria-live', podeAvancar ? 'off' : 'polite');
      if (podeAvancar) {
        temporizador = setTimeout(function () {
          mostrar(atual + 1);
          atualizarReproducao();
        }, intervalo);
      }
    }

    function navegar(indice) {
      rodando = false;
      atualizarReproducao();
      mostrar(indice);
    }

    pontos.forEach(function (ponto, i) {
      ponto.addEventListener('click', function () { navegar(i); });
    });
    controles.querySelectorAll('[data-passo]').forEach(function (botao) {
      botao.addEventListener('click', function () { navegar(atual + Number(botao.dataset.passo)); });
    });
    controles.addEventListener('keydown', function (evento) {
      if (evento.key === 'ArrowLeft' || evento.key === 'ArrowRight') {
        evento.preventDefault();
        navegar(atual + (evento.key === 'ArrowLeft' ? -1 : 1));
      }
    });
    reproducao.addEventListener('click', function () {
      rodando = !rodando;
      atualizarReproducao();
    });
    carrossel.addEventListener('pointerenter', function (evento) {
      if (evento.pointerType === 'mouse') {
        ponteiroSobre = true;
        atualizarReproducao();
      }
    });
    carrossel.addEventListener('pointerleave', function (evento) {
      if (evento.pointerType === 'mouse') {
        ponteiroSobre = false;
        atualizarReproducao();
      }
    });
    carrossel.addEventListener('focusin', function (evento) {
      if (evento.target.matches(':focus-visible')) {
        rodando = false;
        atualizarReproducao();
      }
    });
    movimentoReduzido.addEventListener('change', function () {
      if (movimentoReduzido.matches) {
        rodando = false;
        atualizarReproducao();
      }
    });
    document.addEventListener('visibilitychange', atualizarReproducao);
    controles.hidden = false;
    atualizarReproducao();
  });

  /* ---------- Atalho Ctrl + A → seleção de painéis internos ---------- */
  function estaEditando(el) {
    if (!el) return false;
    var tag = (el.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select') return true;
    if (el.isContentEditable) return true;
    return !!(el.closest && el.closest('[contenteditable=""], [contenteditable="true"]'));
  }
  document.addEventListener('keydown', function (ev) {
    var tecla = (ev.key || '').toLowerCase();
    if (ev.ctrlKey && !ev.altKey && !ev.shiftKey && !ev.metaKey && tecla === 'a') {
      if (estaEditando(ev.target) || estaEditando(document.activeElement)) return; // mantém "selecionar tudo" nos campos
      var destino = body.getAttribute('data-url-interno');
      if (!destino) return;
      ev.preventDefault();
      window.location.href = destino;
    }
  });

  /* ---------- Mensagens ---------- */
  document.addEventListener('click', function (ev) {
    var b = ev.target.closest('.flash-fechar');
    if (b) b.parentElement.remove();
  });

  /* ---------- Dropdowns ---------- */
  document.querySelectorAll('[data-dropdown]').forEach(function (btn) {
    btn.addEventListener('click', function (ev) {
      ev.preventDefault();
      var dd = btn.closest('.dropdown');
      var aberto = dd.classList.toggle('aberto');
      btn.setAttribute('aria-expanded', aberto ? 'true' : 'false');
      if (aberto) { var i = dd.querySelector('input:not([type=hidden])'); if (i) i.focus(); }
    });
  });
  document.addEventListener('click', function (ev) {
    document.querySelectorAll('.dropdown.aberto').forEach(function (dd) {
      if (!dd.contains(ev.target)) dd.classList.remove('aberto');
    });
  });

  /* ---------- Alternadores (menu mobile, filtros, sidebar) ---------- */
  document.querySelectorAll('[data-alternar]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var alvo = document.querySelector(btn.getAttribute('data-alternar'));
      if (alvo) alvo.classList.toggle('aberto');
    });
  });

  /* ---------- Quantidade (+/-) ---------- */
  document.querySelectorAll('.qtd').forEach(function (box) {
    var input = box.querySelector('input');
    if (!input) return;
    var passo = parseFloat(input.getAttribute('step')) || 1;
    var min = parseFloat(input.getAttribute('min'));
    var max = parseFloat(input.getAttribute('max'));
    function ajustar(d) {
      var v = parseFloat(String(input.value).replace(',', '.')) || 0;
      v = Math.round((v + d) / passo) * passo;
      if (!isNaN(min) && v < min) v = min;
      if (!isNaN(max) && v > max) v = max;
      input.value = passo < 1 ? v.toFixed(2) : String(Math.round(v));
      input.dispatchEvent(new Event('change', { bubbles: true }));
    }
    box.querySelectorAll('[data-qtd]').forEach(function (b) {
      b.addEventListener('click', function () { ajustar(parseFloat(b.getAttribute('data-qtd')) * passo); });
    });
  });
  document.querySelectorAll('[data-auto-envio]').forEach(function (el) {
    el.addEventListener('change', function () { if (el.form) el.form.requestSubmit ? el.form.requestSubmit() : el.form.submit(); });
  });

  /* ---------- Confirmações ---------- */
  document.addEventListener('submit', function (ev) {
    var f = ev.target;
    var msg = f.getAttribute('data-confirma');
    if (msg && !window.confirm(msg)) { ev.preventDefault(); return; }
    var botoes = f.querySelectorAll('button[type=submit]');
    setTimeout(function () { botoes.forEach(function (b) { b.disabled = true; }); }, 0); // evita duplo envio
  });

  /* ---------- Mostrar/ocultar senha ---------- */
  document.querySelectorAll('[data-ver-senha]').forEach(function (b) {
    b.addEventListener('click', function () {
      var i = b.parentElement.querySelector('input');
      i.type = i.type === 'password' ? 'text' : 'password';
    });
  });

  /* ---------- Abas ---------- */
  document.querySelectorAll('[data-aba]').forEach(function (aba) {
    aba.addEventListener('click', function () {
      var grupo = aba.closest('[data-abas]');
      grupo.querySelectorAll('[data-aba]').forEach(function (a) { a.classList.remove('ativa'); });
      grupo.querySelectorAll('.aba-conteudo').forEach(function (c) { c.classList.remove('ativa'); });
      aba.classList.add('ativa');
      var c = grupo.querySelector('#' + aba.getAttribute('data-aba'));
      if (c) c.classList.add('ativa');
    });
  });

  /* ---------- Forma de pagamento ---------- */
  function atualizarPagamento() {
    var sel = document.querySelector('input[name=metodo]:checked');
    document.querySelectorAll('.pagamento-detalhe').forEach(function (d) {
      var ativo = sel && d.getAttribute('data-metodo') === sel.value;
      d.classList.toggle('ativo', ativo);
      d.querySelectorAll('input, select').forEach(function (i) { i.disabled = !ativo; });
    });
  }
  document.querySelectorAll('input[name=metodo]').forEach(function (r) { r.addEventListener('change', atualizarPagamento); });
  atualizarPagamento();

  /* ---------- Máscaras ---------- */
  function mascara(el, fn) { el.addEventListener('input', function () { var p = el.selectionStart; el.value = fn(el.value); }); }
  document.querySelectorAll('[data-mascara=cep]').forEach(function (el) {
    mascara(el, function (v) { v = v.replace(/\D/g, '').slice(0, 8); return v.length > 5 ? v.slice(0, 5) + '-' + v.slice(5) : v; });
  });
  document.querySelectorAll('[data-mascara=cpf]').forEach(function (el) {
    mascara(el, function (v) {
      v = v.replace(/\D/g, '').slice(0, 11);
      return v.replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    });
  });
  document.querySelectorAll('[data-mascara=telefone]').forEach(function (el) {
    mascara(el, function (v) {
      v = v.replace(/\D/g, '').slice(0, 11);
      if (v.length <= 10) return v.replace(/(\d{2})(\d)/, '($1) $2').replace(/(\d{4})(\d)/, '$1-$2');
      return v.replace(/(\d{2})(\d)/, '($1) $2').replace(/(\d{5})(\d)/, '$1-$2');
    });
  });
  document.querySelectorAll('[data-mascara=cartao]').forEach(function (el) {
    mascara(el, function (v) { return v.replace(/\D/g, '').slice(0, 19).replace(/(\d{4})(?=\d)/g, '$1 '); });
  });
  document.querySelectorAll('[data-mascara=validade]').forEach(function (el) {
    mascara(el, function (v) { v = v.replace(/\D/g, '').slice(0, 4); return v.length > 2 ? v.slice(0, 2) + '/' + v.slice(2) : v; });
  });

  /* ---------- Busca de CEP (ViaCEP) — opcional, requer internet ---------- */
  document.querySelectorAll('[data-busca-cep]').forEach(function (el) {
    el.addEventListener('blur', function () {
      var cep = el.value.replace(/\D/g, '');
      if (cep.length !== 8 || !window.fetch) return;
      var f = el.form;
      fetch('https://viacep.com.br/ws/' + cep + '/json/').then(function (r) { return r.json(); }).then(function (d) {
        if (!d || d.erro) return;
        var mapa = { logradouro: d.logradouro, bairro: d.bairro, cidade: d.localidade, uf: d.uf };
        Object.keys(mapa).forEach(function (k) { var i = f.querySelector('[name=' + k + ']'); if (i && !i.value) i.value = mapa[k] || ''; });
      }).catch(function () { /* sem internet: preenchimento manual */ });
    });
  });

  /* ---------- Faixa de preço ---------- */
  document.querySelectorAll('[data-faixa]').forEach(function (r) {
    var alvo = document.querySelector(r.getAttribute('data-faixa'));
    r.addEventListener('input', function () { if (alvo) alvo.value = r.value; });
    if (alvo) alvo.addEventListener('input', function () { r.value = alvo.value; });
  });

  /* ---------- Pré-visualização de imagem (admin) ---------- */
  document.querySelectorAll('[data-preview]').forEach(function (inp) {
    inp.addEventListener('change', function () {
      var img = document.querySelector(inp.getAttribute('data-preview'));
      if (img && inp.files && inp.files[0]) img.src = URL.createObjectURL(inp.files[0]);
    });
  });
})();
