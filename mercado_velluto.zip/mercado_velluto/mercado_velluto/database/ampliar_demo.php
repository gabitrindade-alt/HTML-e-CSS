<?php
/** Adiciona um lote de catálogo e pedidos ao banco local sem recriar tabelas. */
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
require __DIR__ . '/../includes/bootstrap.php';

$catalogo = [
    ['abacaxi-perola', 'Abacaxi Pérola', 'hortifruti', 'Unidade', 'unidade', 9.49, 'Abacaxi de polpa clara, doce e suculenta.'],
    ['brocolis-ninja', 'Brócolis Ninja', 'hortifruti', 'Unidade', 'unidade', 7.99, 'Brócolis fresco de floretes compactos.'],
    ['mirtilo-fresco', 'Mirtilo Fresco', 'hortifruti', 'Bandeja 125 g', 'unidade', 14.90, 'Mirtilos frescos para lanches, cereais e sobremesas.'],
    ['pao-de-fermentacao-natural', 'Pão de Fermentação Natural', 'padaria', 'Vendido por kg', 'peso', 39.90, 'Pão rústico de crosta firme e miolo macio.'],
    ['rolinho-de-canela', 'Rolinho de Canela', 'padaria', 'Unidade', 'unidade', 8.90, 'Massa macia enrolada com canela e cobertura açucarada.'],
    ['aveia-em-flocos', 'Aveia em Flocos', 'mercearia', 'Pacote 500 g', 'unidade', 13.90, 'Flocos de aveia para mingaus, vitaminas e receitas.'],
    ['mel-silvestre', 'Mel Silvestre', 'mercearia', 'Pote 300 g', 'unidade', 24.90, 'Mel de flores silvestres para acompanhar frutas, pães e iogurtes.'],
    ['cha-de-camomila', 'Chá de Camomila', 'bebidas', 'Pacote 40 g', 'unidade', 10.90, 'Flores secas de camomila para preparo por infusão.'],
    ['framboesa-congelada', 'Framboesa Congelada', 'congelados', 'Pacote 300 g', 'unidade', 27.90, 'Framboesas congeladas para caldas, bebidas e sobremesas.'],
    ['geleia-de-morango', 'Geleia de Morango', 'mercearia', 'Vidro 230 g', 'unidade', 16.50, 'Geleia de morango para torradas, bolos e tábuas de queijos.'],
    ['massa-penne', 'Massa Penne', 'mercearia', 'Pacote 500 g', 'unidade', 7.90, 'Massa curta e estriada para molhos encorpados e saladas.'],
    ['granola-castanhas', 'Granola com Castanhas', 'mercearia', 'Pacote 300 g', 'unidade', 19.90, 'Mistura crocante de cereais e castanhas para iogurte e frutas.'],
    ['queijo-minas-frescal', 'Queijo Minas Frescal', 'laticinios', 'Peça 350 g', 'unidade', 23.90, 'Queijo fresco de textura macia. Manter refrigerado.'],
    ['iogurte-grego-morango', 'Iogurte Grego de Morango', 'laticinios', 'Pote 100 g', 'unidade', 4.99, 'Iogurte cremoso com morango para servir gelado.'],
    ['polpa-de-acai', 'Polpa de Açaí', 'congelados', 'Pacote 400 g', 'unidade', 19.90, 'Polpa congelada para tigelas, vitaminas e sobremesas.'],
    ['pao-de-queijo-congelado', 'Pão de Queijo Congelado', 'congelados', 'Pacote 500 g', 'unidade', 17.90, 'Pães de queijo porcionados para assar conforme a embalagem.'],
    ['grao-de-bico-em-conserva', 'Grão-de-bico em Conserva', 'enlatados', 'Lata 240 g', 'unidade', 9.49, 'Grão-de-bico cozido para saladas, pastas e pratos quentes.'],
    ['palmito-em-conserva', 'Palmito em Conserva', 'enlatados', 'Vidro 300 g', 'unidade', 22.90, 'Palmito em salmoura para saladas e recheios.'],
    ['agua-com-gas', 'Água Mineral com Gás', 'bebidas', 'Garrafa 500 ml', 'unidade', 2.99, 'Água mineral gaseificada em garrafa individual.'],
    ['suco-de-laranja', 'Suco de Laranja', 'bebidas', 'Garrafa 1 L', 'unidade', 14.90, 'Suco de laranja para servir gelado.'],
    ['manga-palmer', 'Manga Palmer', 'hortifruti', 'Vendido por kg', 'peso', 8.90, 'Manga de polpa firme, indicada para cortes e vitaminas.'],
    ['cenoura', 'Cenoura', 'hortifruti', 'Vendido por kg', 'peso', 5.49, 'Cenoura fresca para saladas, sopas e assados.'],
    ['coxao-mole', 'Coxão Mole em Bifes', 'carnes', 'Vendido por kg', 'peso', 46.90, 'Corte bovino fatiado para grelhar ou preparar à milanesa.'],
    ['salmao-em-posta', 'Salmão em Posta', 'carnes', 'Vendido por kg', 'peso', 91.90, 'Postas de salmão para forno ou grelha. Manter refrigerado.'],
    ['baguete-rustica', 'Baguete Rústica', 'padaria', 'Unidade 250 g', 'unidade', 11.90, 'Baguete de crosta crocante para sanduíches e bruschettas.'],
    ['bolo-de-laranja', 'Bolo de Laranja', 'padaria', 'Unidade 450 g', 'unidade', 21.90, 'Bolo de laranja de miolo macio para o café.'],
    ['limpador-multiuso-citrico', 'Limpador Multiuso Cítrico', 'limpeza', 'Frasco 500 ml', 'unidade', 8.90, 'Limpador em spray para as superfícies indicadas no rótulo.'],
    ['sabao-em-po', 'Sabão em Pó para Roupas', 'limpeza', 'Pacote 800 g', 'unidade', 15.90, 'Sabão para lavagem de roupas. Siga a dosagem da embalagem.'],
    ['fio-dental', 'Fio Dental Encerado', 'higiene', 'Estojo 50 m', 'unidade', 7.90, 'Fio dental encerado em estojo compacto.'],
    ['condicionador-hidratante', 'Condicionador Hidratante', 'higiene', 'Frasco 300 ml', 'unidade', 18.90, 'Condicionador para usar após a lavagem e enxaguar.'],
    ['serum-facial', 'Sérum Facial Hidratante', 'beleza', 'Frasco 30 ml', 'unidade', 42.90, 'Sérum de textura leve com aplicador conta-gotas.'],
    ['protetor-solar-facial', 'Protetor Solar Facial FPS 50', 'beleza', 'Tubo 40 g', 'unidade', 49.90, 'Protetor solar facial de uso diário. Siga as instruções do rótulo.'],
    ['mouse-sem-fio', 'Mouse sem Fio', 'eletronicos', 'Unidade', 'unidade', 69.90, 'Mouse compacto com receptor USB para computadores compatíveis.'],
    ['cabo-usb-c-trancado', 'Cabo USB-C Trançado', 'eletronicos', 'Unidade 1 m', 'unidade', 29.90, 'Cabo de um metro com revestimento trançado e conectores USB-C.'],
    ['sanduicheira-eletrica', 'Sanduicheira Elétrica', 'eletrodomesticos', 'Unidade 127 V', 'unidade', 129.90, 'Sanduicheira compacta com placas antiaderentes.'],
    ['chaleira-eletrica', 'Chaleira Elétrica Inox', 'eletrodomesticos', 'Unidade 1,7 L · 127 V', 'unidade', 139.90, 'Chaleira de aço inox com base removível.'],
    ['bermuda-moletom', 'Bermuda de Moletom', 'roupas', 'Tamanho M', 'unidade', 59.90, 'Bermuda cinza de moletom com cintura ajustável.'],
    ['camiseta-infantil', 'Camiseta Infantil de Algodão', 'roupas', 'Tamanho 8', 'unidade', 34.90, 'Camiseta amarela de algodão com manga curta.'],
    ['almofada-de-linho', 'Almofada com Capa de Linho', 'casa-decoracao', 'Unidade 45 × 45 cm', 'unidade', 79.90, 'Almofada em tom areia com capa texturizada.'],
    ['organizador-de-bambu', 'Organizador de Bambu', 'casa-decoracao', 'Unidade 30 × 20 cm', 'unidade', 59.90, 'Cesto retangular para organizar objetos em prateleiras.'],
    ['comedouro-inox', 'Comedouro Pet de Inox', 'pet', 'Unidade 500 ml', 'unidade', 25.90, 'Tigela de aço inox para água ou ração.'],
    ['brinquedo-corda-para-caes', 'Brinquedo de Corda para Cães', 'pet', 'Unidade 25 cm', 'unidade', 19.90, 'Corda trançada com nós para brincadeiras supervisionadas.'],
    ['sabonete-liquido-infantil', 'Sabonete Líquido Infantil', 'bebes', 'Frasco 200 ml', 'unidade', 18.90, 'Sabonete líquido com válvula dosadora para o banho.'],
    ['copo-de-transicao', 'Copo de Transição Infantil', 'bebes', 'Unidade 200 ml', 'unidade', 32.90, 'Copo infantil com duas alças e bico para transição.'],
    ['arroz-integral', 'Arroz Integral', 'mercearia', 'Pacote 1 kg', 'unidade', 9.90, 'Arroz integral para acompanhamentos e refeições do dia a dia.'],
    ['lentilha-seca', 'Lentilha Seca', 'mercearia', 'Pacote 500 g', 'unidade', 12.90, 'Lentilhas secas para caldos, saladas e acompanhamentos.'],
    ['panetone-frutas', 'Panetone de Frutas Cristalizadas', 'padaria', 'Unidade 500 g', 'unidade', 34.90, 'Panetone de massa macia com frutas cristalizadas e uvas-passas.'],
    ['chocotone-gotas', 'Chocotone com Gotas de Chocolate', 'padaria', 'Unidade 500 g', 'unidade', 39.90, 'Panetone de chocolate com gotas na massa.'],
    ['suco-maca-espumante', 'Suco de Maçã Gaseificado', 'bebidas', 'Garrafa 750 ml', 'unidade', 26.90, 'Suco de maçã com gás, sem álcool, para servir bem gelado.'],
    ['mix-castanhas-ceia', 'Mix de Castanhas para Ceia', 'mercearia', 'Pacote 250 g', 'unidade', 32.90, 'Mistura de castanhas para servir na ceia ou acrescentar às receitas.'],
    ['ovo-pascoa-chocolate', 'Ovo de Páscoa ao Leite', 'mercearia', 'Unidade 200 g', 'unidade', 49.90, 'Ovo de chocolate ao leite com bombons.'],
    ['pacoca-junina', 'Paçoca de Amendoim', 'mercearia', 'Pacote 180 g', 'unidade', 13.90, 'Doce tradicional de amendoim em porções individuais.'],
    ['canjica-branca', 'Milho Branco para Canjica', 'mercearia', 'Pacote 500 g', 'unidade', 8.90, 'Milho branco em grãos para preparo de canjica doce.'],
    ['gomas-halloween', 'Gomas Sortidas de Halloween', 'mercearia', 'Pacote 150 g', 'unidade', 15.90, 'Balas de goma em formatos variados para festas e lembrancinhas.'],
    ['peru-temperado-natal', 'Peru Temperado para Assar', 'carnes', 'Vendido por kg', 'peso', 39.90, 'Peru inteiro temperado e congelado. Descongele sob refrigeração e asse conforme a embalagem.'],
    ['lombo-suino-natal', 'Lombo Suíno Temperado', 'carnes', 'Vendido por kg', 'peso', 36.90, 'Lombo temperado para assar e servir fatiado. A imagem apresenta uma sugestão de preparo.'],
    ['farofa-natalina', 'Farofa Natalina com Passas', 'mercearia', 'Pacote 300 g', 'unidade', 15.90, 'Farofa de mandioca torrada com uvas-passas para servir como acompanhamento.'],
    ['ameixa-seca', 'Ameixa Seca sem Caroço', 'mercearia', 'Pacote 200 g', 'unidade', 15.90, 'Ameixas secas para molhos, recheios e tábuas.'],
    ['cerejas-frescas', 'Cerejas Frescas', 'hortifruti', 'Bandeja 200 g', 'unidade', 29.90, 'Cerejas frescas para servir à mesa ou decorar sobremesas.'],
    ['azeitonas-verdes-ceia', 'Azeitonas Verdes sem Caroço', 'enlatados', 'Vidro 200 g', 'unidade', 14.90, 'Azeitonas verdes em salmoura para entradas, assados e recheios.'],
    ['guirlanda-natal', 'Guirlanda de Natal com Laço', 'casa-decoracao', 'Unidade 35 cm', 'unidade', 79.90, 'Guirlanda verde com laço bordô para porta ou parede em ambiente protegido.'],
    ['bolas-natal', 'Conjunto de Bolas de Natal', 'casa-decoracao', 'Caixa com 6', 'unidade', 24.90, 'Bolas decorativas em vermelho e dourado para pendurar na árvore.'],
    ['pisca-led-natal', 'Pisca-pisca de LED Branco Quente', 'casa-decoracao', 'Cordão 5 m', 'unidade', 39.90, 'Cordão de luzes em tom quente para decorar ambientes internos.'],
    ['vela-canela-natal', 'Vela Aromática de Canela', 'casa-decoracao', 'Pote 150 g', 'unidade', 29.90, 'Vela aromática em pote de vidro âmbar para decorar a mesa ou a sala.'],
    ['toalha-mesa-natal', 'Toalha de Mesa Natalina Bordô', 'casa-decoracao', 'Unidade 140 × 180 cm', 'unidade', 64.90, 'Toalha retangular bordô com detalhes dourados para a mesa da ceia.'],
    ['mini-arvore-natal', 'Miniárvore de Natal', 'casa-decoracao', 'Unidade 40 cm', 'unidade', 69.90, 'Árvore decorativa de mesa com base revestida e ramos verdes.'],
];

$conexao = db();
$conexao->exec(file_get_contents(__DIR__ . '/carrossel.sql'));
$chave = "CONCAT(LEFT(DATABASE(), 45), ':ampliar-demo-v1')";
if (!(int) $conexao->query("SELECT GET_LOCK($chave, 10)")->fetchColumn()) {
    throw new RuntimeException('Outro processo está adicionando os dados de demonstração.');
}

try {
    [$novosProdutos, $novosPedidos, $novasAreas] = transacao(function () use ($conexao, $catalogo) {
        $novasAreas = $conexao->exec("INSERT INTO areas_entrega (nome, cidade, uf, cep_inicio, cep_fim,
            valor_frete, valor_expresso, frete_gratis_acima, prazo_padrao, prazo_expresso)
            SELECT 'Zona Leste', 'São Paulo', 'SP', '08000000', '08499999', 1.00, 2.00, 249.00, 'até 4 horas', 'até 2 horas'
            WHERE NOT EXISTS (SELECT 1 FROM areas_entrega WHERE cep_inicio = '08000000' AND cep_fim = '08499999')");
        $insProduto = $conexao->prepare("INSERT INTO produtos
            (categoria_id, slug, nome, marca, embalagem, vendido_por, preco, estoque, imagem, descricao, criado_em)
            SELECT id, ?, ?, 'Velluto Seleção', ?, ?, ?, 96, ?, ?, ?
            FROM categorias WHERE slug = ?
            ON DUPLICATE KEY UPDATE produtos.id = produtos.id");
        $produtos = [];
        $novosProdutos = 0;
        $buscarProduto = $conexao->prepare('SELECT * FROM produtos WHERE slug = ? AND ativo = 1 FOR UPDATE');
        foreach ($catalogo as [$slug, $nome, $categoria, $embalagem, $unidade, $preco, $descricao]) {
            $imagem = "assets/img/produtos/$slug.jpg";
            if (!is_file(APP_ROOT . '/' . $imagem)) {
                throw new RuntimeException("Imagem ausente: $imagem");
            }
            $insProduto->execute([$slug, $nome, $embalagem, $unidade, $preco, $imagem, $descricao, agora(), $categoria]);
            $novosProdutos += $insProduto->rowCount();
            $buscarProduto->execute([$slug]);
            $produtos[] = $buscarProduto->fetch();
        }

        $modelos = $conexao->query("SELECT p.usuario_id, p.endereco_id, p.area_entrega_id, p.endereco_entrega, p.cep_entrega, a.*
            FROM pedidos p JOIN areas_entrega a ON a.id = p.area_entrega_id
            JOIN usuarios u ON u.id = p.usuario_id AND u.perfil = 'cliente'
            WHERE p.id IN (12, 13, 14) ORDER BY p.id")->fetchAll();
        $separador = $conexao->query("SELECT id FROM usuarios WHERE perfil = 'separador' AND ativo = 1 ORDER BY id LIMIT 1")->fetchColumn();
        $jaCriado = $conexao->prepare('SELECT 1 FROM pagamentos WHERE codigo_transacao = ? LIMIT 1');
        $insPedido = $conexao->prepare("INSERT INTO pedidos (usuario_id, endereco_id, area_entrega_id, endereco_entrega,
            cep_entrega, tipo_frete, prazo_entrega, valor_frete, subtotal, total, metodo_pagamento, criado_em)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pix', ?)");
        $insItem = $conexao->prepare('INSERT INTO itens_pedido (pedido_id, produto_id, nome_produto, vendido_por,
            quantidade, quantidade_separada, preco_unitario, subtotal, status, criado_em) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $insPagamento = $conexao->prepare("INSERT INTO pagamentos (pedido_id, tipo, metodo, valor, status,
            codigo_transacao, criado_em, confirmado_em) VALUES (?, 'cobranca', 'pix', ?, 'aprovado', ?, ?, ?)");

        $novosPedidos = 0;
        for ($i = 0; $i < 16; $i++) {
            $codigo = sprintf('SIM-VELLUTO-AMPLIACAO-%02d', $i + 1);
            $jaCriado->execute([$codigo]);
            if ($jaCriado->fetchColumn()) continue;
            if (!$modelos || !$separador || in_array(false, $produtos, true)) {
                throw new RuntimeException('O lote inicial de clientes, categorias e funcionários precisa estar disponível.');
            }

            $modelo = $modelos[$i % count($modelos)];
            $pronto = $i >= 8;
            $subtotal = 0.0;
            $itens = [];
            foreach ([$produtos[$i % 10], $produtos[($i + 3) % 10]] as $produto) {
                $quantidade = $produto['vendido_por'] === 'peso' ? 0.650 : 1 + $i % 3;
                $preco = precoAtual($produto);
                $valor = round($quantidade * $preco, 2);
                $itens[] = [$produto, $quantidade, $preco, $valor];
                $subtotal += $valor;
            }
            $fretes = opcoesFrete($modelo, $subtotal);
            $tipo = $i % 3 === 0 && isset($fretes['expresso']) ? 'expresso' : 'padrao';
            $frete = $fretes[$tipo];
            $total = numSql($subtotal + $frete['valor'], 2);
            $data = agora();
            $insPedido->execute([$modelo['usuario_id'], $modelo['endereco_id'], $modelo['area_entrega_id'],
                $modelo['endereco_entrega'], $modelo['cep_entrega'], $tipo, $frete['prazo'], numSql($frete['valor'], 2),
                numSql($subtotal, 2), $total, $data]);
            $id = (int) $conexao->lastInsertId();
            registrarHistorico($id, null, 'aguardando_pagamento', 'Pedido registrado.');
            foreach ($itens as [$produto, $quantidade, $preco, $valor]) {
                movimentarEstoque((int) $produto['id'], -$quantidade, 'venda', $id, "Venda — pedido #$id");
                $insItem->execute([$id, $produto['id'], $produto['nome'], $produto['vendido_por'], numSql($quantidade),
                    $pronto ? numSql($quantidade) : null, numSql($preco, 2), numSql($valor, 2), $pronto ? 'separado' : 'pendente', $data]);
            }
            $insPagamento->execute([$id, $total, $codigo, $data, $data]);
            alterarStatus($id, 'confirmado', 'Pagamento PIX aprovado.', ['total_pago' => $total]);
            alterarStatus($id, 'aguardando_separacao', 'Pedido liberado para separação.');
            if ($pronto) {
                alterarStatus($id, 'em_separacao', 'Separação iniciada.', [
                    'separador_id' => (int) $separador, 'separacao_iniciada_em' => $data, 'volumes' => 1 + $i % 2,
                ]);
                liberarParaEntrega($id, 'Separação concluída. Pedido embalado e pronto para retirada.');
            }
            $novosPedidos++;
        }
        return [$novosProdutos, $novosPedidos, $novasAreas];
    });
    printf("Produtos adicionados: %d. Pedidos adicionados: %d. Áreas adicionadas: %d.\n", $novosProdutos, $novosPedidos, $novasAreas);
} finally {
    $conexao->query("SELECT RELEASE_LOCK($chave)");
}
