-- Define taxas simbolicas e prazos distintos nas areas com entrega expressa.
UPDATE areas_entrega
SET valor_frete = 1.00,
    valor_expresso = 2.00,
    prazo_padrao = 'até 4 horas',
    prazo_expresso = 'até 2 horas'
WHERE valor_expresso IS NOT NULL;

ALTER TABLE movimentacoes_estoque
MODIFY tipo ENUM('entrada','saida','venda','estorno','ajuste','substituicao','ajuste_peso') NOT NULL;