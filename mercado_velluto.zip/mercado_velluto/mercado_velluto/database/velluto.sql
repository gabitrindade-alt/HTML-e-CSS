-- =====================================================================
-- VELLUTO — Hipermercado Online (projeto acadêmico)
-- Banco de dados MySQL/MariaDB · InnoDB · utf8mb4
-- Importe este arquivo pelo phpMyAdmin (aba "Importar").
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP DATABASE IF EXISTS velluto;
CREATE DATABASE velluto CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE velluto;

-- ---------------------------------------------------------------------
-- 1. Usuários (clientes e funcionários)
-- ---------------------------------------------------------------------
CREATE TABLE usuarios (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL,
  senha_hash VARCHAR(255) NULL,
  perfil ENUM('cliente','administrador','separador','entregador') NOT NULL DEFAULT 'cliente',
  cpf VARCHAR(11) NULL,
  telefone VARCHAR(20) NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  ultimo_login DATETIME NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL,
  CONSTRAINT uq_usuarios_email UNIQUE (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 2. Endereços dos clientes
-- ---------------------------------------------------------------------
CREATE TABLE enderecos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT UNSIGNED NOT NULL,
  apelido VARCHAR(40) NOT NULL DEFAULT 'Casa',
  destinatario VARCHAR(120) NOT NULL,
  cep CHAR(8) NOT NULL,
  logradouro VARCHAR(160) NOT NULL,
  numero VARCHAR(10) NOT NULL,
  complemento VARCHAR(80) NULL,
  bairro VARCHAR(80) NOT NULL,
  cidade VARCHAR(80) NOT NULL,
  uf CHAR(2) NOT NULL,
  referencia VARCHAR(160) NULL,
  principal TINYINT(1) NOT NULL DEFAULT 0,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_enderecos_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 3. Categorias (com subcategorias)
-- ---------------------------------------------------------------------
CREATE TABLE categorias (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pai_id INT UNSIGNED NULL,
  nome VARCHAR(80) NOT NULL,
  slug VARCHAR(90) NOT NULL,
  icone VARCHAR(16) NULL,
  cor CHAR(7) NOT NULL DEFAULT '#EADFD3',
  descricao VARCHAR(255) NULL,
  ordem INT NOT NULL DEFAULT 0,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_categorias_slug UNIQUE (slug),
  CONSTRAINT fk_categorias_pai FOREIGN KEY (pai_id) REFERENCES categorias (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 4. Produtos
-- ---------------------------------------------------------------------
CREATE TABLE produtos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  categoria_id INT UNSIGNED NOT NULL,
  nome VARCHAR(140) NOT NULL,
  slug VARCHAR(160) NOT NULL,
  marca VARCHAR(80) NULL,
  descricao TEXT NULL,
  informacoes TEXT NULL,
  embalagem VARCHAR(60) NULL,
  vendido_por ENUM('unidade','peso') NOT NULL DEFAULT 'unidade',
  preco DECIMAL(10,2) NOT NULL,
  preco_promocional DECIMAL(10,2) NULL,
  estoque DECIMAL(10,3) NOT NULL DEFAULT 0,
  estoque_minimo DECIMAL(10,3) NOT NULL DEFAULT 10,
  imagem VARCHAR(255) NULL,
  destaque TINYINT(1) NOT NULL DEFAULT 0,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL,
  CONSTRAINT uq_produtos_slug UNIQUE (slug),
  CONSTRAINT ck_produtos_estoque CHECK (estoque >= 0),
  CONSTRAINT ck_produtos_preco CHECK (preco >= 0),
  CONSTRAINT fk_produtos_categoria FOREIGN KEY (categoria_id) REFERENCES categorias (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 5. Áreas de entrega (faixas de CEP) e frete
-- ---------------------------------------------------------------------
CREATE TABLE areas_entrega (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(80) NOT NULL,
  cidade VARCHAR(80) NOT NULL,
  uf CHAR(2) NOT NULL,
  cep_inicio CHAR(8) NOT NULL,
  cep_fim CHAR(8) NOT NULL,
  valor_frete DECIMAL(10,2) NOT NULL DEFAULT 0,
  valor_expresso DECIMAL(10,2) NULL,
  frete_gratis_acima DECIMAL(10,2) NULL,
  prazo_padrao VARCHAR(40) NOT NULL DEFAULT 'até 2 dias',
  prazo_expresso VARCHAR(40) NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 6. Pedidos
-- ---------------------------------------------------------------------
CREATE TABLE pedidos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT UNSIGNED NOT NULL,
  endereco_id INT UNSIGNED NOT NULL,
  area_entrega_id INT UNSIGNED NOT NULL,
  endereco_entrega VARCHAR(400) NOT NULL,
  cep_entrega CHAR(8) NOT NULL,
  tipo_frete ENUM('padrao','expresso') NOT NULL DEFAULT 'padrao',
  prazo_entrega VARCHAR(40) NULL,
  valor_frete DECIMAL(10,2) NOT NULL DEFAULT 0,
  subtotal DECIMAL(10,2) NOT NULL DEFAULT 0,
  total DECIMAL(10,2) NOT NULL DEFAULT 0,
  total_pago DECIMAL(10,2) NOT NULL DEFAULT 0,
  metodo_pagamento ENUM('pix','cartao','boleto') NOT NULL,
  status ENUM('aguardando_pagamento','confirmado','aguardando_separacao','em_separacao','aguardando_aprovacao',
              'aguardando_entrega','saiu_para_entrega','concluido','cancelado') NOT NULL DEFAULT 'aguardando_pagamento',
  ajuste_pendente TINYINT(1) NOT NULL DEFAULT 0,
  separador_id INT UNSIGNED NULL,
  volumes INT NULL,
  observacoes VARCHAR(500) NULL,
  motivo_cancelamento VARCHAR(500) NULL,
  cancelado_por INT UNSIGNED NULL,
  cancelado_em DATETIME NULL,
  separacao_iniciada_em DATETIME NULL,
  separacao_concluida_em DATETIME NULL,
  concluido_em DATETIME NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL,
  CONSTRAINT ck_pedidos_total CHECK (total >= 0),
  CONSTRAINT fk_pedidos_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE RESTRICT,
  CONSTRAINT fk_pedidos_endereco FOREIGN KEY (endereco_id) REFERENCES enderecos (id) ON DELETE RESTRICT,
  CONSTRAINT fk_pedidos_area FOREIGN KEY (area_entrega_id) REFERENCES areas_entrega (id) ON DELETE RESTRICT,
  CONSTRAINT fk_pedidos_separador FOREIGN KEY (separador_id) REFERENCES usuarios (id) ON DELETE SET NULL,
  CONSTRAINT fk_pedidos_cancelado_por FOREIGN KEY (cancelado_por) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 7. Itens do pedido
-- ---------------------------------------------------------------------
CREATE TABLE itens_pedido (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pedido_id INT UNSIGNED NOT NULL,
  produto_id INT UNSIGNED NOT NULL,
  nome_produto VARCHAR(140) NOT NULL,
  vendido_por ENUM('unidade','peso') NOT NULL DEFAULT 'unidade',
  quantidade DECIMAL(10,3) NOT NULL,
  quantidade_separada DECIMAL(10,3) NULL,
  preco_unitario DECIMAL(10,2) NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  status ENUM('pendente','separado','indisponivel','substituido','removido') NOT NULL DEFAULT 'pendente',
  item_origem_id INT UNSIGNED NULL,
  observacao VARCHAR(255) NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT ck_itens_quantidade CHECK (quantidade > 0),
  CONSTRAINT fk_itens_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos (id) ON DELETE CASCADE,
  CONSTRAINT fk_itens_produto FOREIGN KEY (produto_id) REFERENCES produtos (id) ON DELETE RESTRICT,
  CONSTRAINT fk_itens_origem FOREIGN KEY (item_origem_id) REFERENCES itens_pedido (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 8. Substituições de produtos
-- ---------------------------------------------------------------------
CREATE TABLE substituicoes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pedido_id INT UNSIGNED NOT NULL,
  item_id INT UNSIGNED NOT NULL,
  produto_original_id INT UNSIGNED NOT NULL,
  produto_sugerido_id INT UNSIGNED NOT NULL,
  quantidade DECIMAL(10,3) NOT NULL,
  preco_original DECIMAL(10,2) NOT NULL,
  preco_sugerido DECIMAL(10,2) NOT NULL,
  diferenca DECIMAL(10,2) NOT NULL DEFAULT 0,
  status ENUM('pendente','aceita','rejeitada','cancelada') NOT NULL DEFAULT 'pendente',
  mensagem VARCHAR(255) NULL,
  sugerido_por INT UNSIGNED NULL,
  respondido_por INT UNSIGNED NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  respondido_em DATETIME NULL,
  CONSTRAINT fk_subst_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos (id) ON DELETE CASCADE,
  CONSTRAINT fk_subst_item FOREIGN KEY (item_id) REFERENCES itens_pedido (id) ON DELETE CASCADE,
  CONSTRAINT fk_subst_original FOREIGN KEY (produto_original_id) REFERENCES produtos (id) ON DELETE RESTRICT,
  CONSTRAINT fk_subst_sugerido FOREIGN KEY (produto_sugerido_id) REFERENCES produtos (id) ON DELETE RESTRICT,
  CONSTRAINT fk_subst_sugerido_por FOREIGN KEY (sugerido_por) REFERENCES usuarios (id) ON DELETE SET NULL,
  CONSTRAINT fk_subst_respondido_por FOREIGN KEY (respondido_por) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 9. Entregas
-- ---------------------------------------------------------------------
CREATE TABLE entregas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pedido_id INT UNSIGNED NOT NULL,
  entregador_id INT UNSIGNED NULL,
  status ENUM('disponivel','atribuida','em_rota','entregue','cancelada') NOT NULL DEFAULT 'disponivel',
  tentativas INT NOT NULL DEFAULT 0,
  assumida_em DATETIME NULL,
  retirada_em DATETIME NULL,
  entregue_em DATETIME NULL,
  recebedor VARCHAR(120) NULL,
  observacao VARCHAR(255) NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_entregas_pedido UNIQUE (pedido_id),
  CONSTRAINT fk_entregas_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos (id) ON DELETE CASCADE,
  CONSTRAINT fk_entregas_entregador FOREIGN KEY (entregador_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 10. Ocorrências (separação, entrega, estoque etc.)
-- ---------------------------------------------------------------------
CREATE TABLE ocorrencias (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pedido_id INT UNSIGNED NULL,
  entrega_id INT UNSIGNED NULL,
  usuario_id INT UNSIGNED NULL,
  tipo VARCHAR(40) NOT NULL,
  gravidade ENUM('baixa','media','alta') NOT NULL DEFAULT 'media',
  descricao VARCHAR(1000) NOT NULL,
  status ENUM('aberta','resolvida') NOT NULL DEFAULT 'aberta',
  resolucao VARCHAR(1000) NULL,
  resolvido_por INT UNSIGNED NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  resolvido_em DATETIME NULL,
  CONSTRAINT fk_ocorr_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos (id) ON DELETE CASCADE,
  CONSTRAINT fk_ocorr_entrega FOREIGN KEY (entrega_id) REFERENCES entregas (id) ON DELETE SET NULL,
  CONSTRAINT fk_ocorr_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE SET NULL,
  CONSTRAINT fk_ocorr_resolvido_por FOREIGN KEY (resolvido_por) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 11. Pagamentos (simulados)
-- ---------------------------------------------------------------------
CREATE TABLE pagamentos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pedido_id INT UNSIGNED NOT NULL,
  tipo ENUM('cobranca','complemento','estorno') NOT NULL DEFAULT 'cobranca',
  metodo ENUM('pix','cartao','boleto') NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  status ENUM('pendente','aprovado','recusado') NOT NULL DEFAULT 'pendente',
  codigo_transacao VARCHAR(40) NOT NULL,
  cartao_final CHAR(4) NULL,
  parcelas INT NULL,
  observacao VARCHAR(255) NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  confirmado_em DATETIME NULL,
  CONSTRAINT fk_pagamentos_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 12. Histórico de status dos pedidos
-- ---------------------------------------------------------------------
CREATE TABLE historico_pedidos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pedido_id INT UNSIGNED NOT NULL,
  status_anterior VARCHAR(30) NULL,
  status_novo VARCHAR(30) NOT NULL,
  usuario_id INT UNSIGNED NULL,
  perfil VARCHAR(20) NULL,
  descricao VARCHAR(500) NOT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_hist_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos (id) ON DELETE CASCADE,
  CONSTRAINT fk_hist_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 13. Movimentações de estoque
-- ---------------------------------------------------------------------
CREATE TABLE movimentacoes_estoque (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  produto_id INT UNSIGNED NOT NULL,
  tipo ENUM('entrada','venda','estorno','ajuste','substituicao','ajuste_peso') NOT NULL,
  quantidade DECIMAL(10,3) NOT NULL,
  estoque_anterior DECIMAL(10,3) NOT NULL,
  estoque_posterior DECIMAL(10,3) NOT NULL,
  pedido_id INT UNSIGNED NULL,
  usuario_id INT UNSIGNED NULL,
  observacao VARCHAR(255) NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_mov_produto FOREIGN KEY (produto_id) REFERENCES produtos (id) ON DELETE CASCADE,
  CONSTRAINT fk_mov_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos (id) ON DELETE SET NULL,
  CONSTRAINT fk_mov_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 14. Recuperação de senhas (token armazenado como hash SHA-256)
-- ---------------------------------------------------------------------
CREATE TABLE recuperacao_senhas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL,
  expira_em DATETIME NOT NULL,
  usado_em DATETIME NULL,
  ip VARCHAR(45) NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_recuperacao_token UNIQUE (token_hash),
  CONSTRAINT fk_recuperacao_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Tabelas complementares
-- ---------------------------------------------------------------------
CREATE TABLE favoritos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT UNSIGNED NOT NULL,
  produto_id INT UNSIGNED NOT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_favoritos UNIQUE (usuario_id, produto_id),
  CONSTRAINT fk_fav_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE,
  CONSTRAINT fk_fav_produto FOREIGN KEY (produto_id) REFERENCES produtos (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE avaliacoes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  produto_id INT UNSIGNED NOT NULL,
  usuario_id INT UNSIGNED NOT NULL,
  nota TINYINT NOT NULL,
  comentario VARCHAR(500) NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_avaliacoes UNIQUE (produto_id, usuario_id),
  CONSTRAINT ck_avaliacoes_nota CHECK (nota BETWEEN 1 AND 5),
  CONSTRAINT fk_aval_produto FOREIGN KEY (produto_id) REFERENCES produtos (id) ON DELETE CASCADE,
  CONSTRAINT fk_aval_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE configuracoes (
  chave VARCHAR(60) NOT NULL PRIMARY KEY,
  valor VARCHAR(500) NOT NULL,
  descricao VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE carrossel_banners (
  chave VARCHAR(32) PRIMARY KEY,
  rotulo VARCHAR(32) NOT NULL,
  titulo VARCHAR(100) NOT NULL,
  texto VARCHAR(220) NOT NULL,
  botao VARCHAR(40) NOT NULL,
  destino VARCHAR(230) NOT NULL,
  imagem VARCHAR(230) NOT NULL,
  alt VARCHAR(150) NOT NULL,
  ordem SMALLINT UNSIGNED NOT NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE logs_alteracoes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT UNSIGNED NULL,
  entidade VARCHAR(40) NOT NULL,
  entidade_id INT UNSIGNED NULL,
  acao VARCHAR(40) NOT NULL,
  detalhes VARCHAR(2000) NULL,
  ip VARCHAR(45) NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_logs_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Índices
-- ---------------------------------------------------------------------
CREATE INDEX idx_usuarios_perfil ON usuarios (perfil);
CREATE INDEX idx_enderecos_cep ON enderecos (cep);
CREATE INDEX idx_produtos_nome ON produtos (nome);
CREATE INDEX idx_produtos_ativo_cat ON produtos (ativo, categoria_id);
CREATE INDEX idx_produtos_marca ON produtos (marca);
CREATE INDEX idx_areas_cep ON areas_entrega (cep_inicio, cep_fim);
CREATE INDEX idx_pedidos_status ON pedidos (status);
CREATE INDEX idx_pedidos_criado ON pedidos (criado_em);
CREATE INDEX idx_itens_status ON itens_pedido (pedido_id, status);
CREATE INDEX idx_subst_status ON substituicoes (pedido_id, status);
CREATE INDEX idx_entregas_status ON entregas (status);
CREATE INDEX idx_ocorr_status ON ocorrencias (status);
CREATE INDEX idx_hist_pedido_data ON historico_pedidos (pedido_id, criado_em);
CREATE INDEX idx_mov_produto_data ON movimentacoes_estoque (produto_id, criado_em);
CREATE INDEX idx_logs_data ON logs_alteracoes (criado_em);

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- DADOS FICTÍCIOS INICIAIS
-- =====================================================================

-- As contas internas são criadas SEM senha (senha_hash NULL).
-- Defina as senhas iniciais em: http://localhost/velluto/interno/instalar.php
-- (a página só funciona a partir do próprio computador e se desativa após o uso).
-- Clientes de demonstração: senha "Cliente@123" (armazenada com password_hash).

INSERT INTO usuarios (id, nome, email, senha_hash, perfil, cpf, telefone, criado_em) VALUES
  (1, 'Administrador Velluto', 'admin@velluto.com', NULL, 'administrador', NULL, '(11) 4000-1000', DATE_SUB(NOW(), INTERVAL 720 HOUR)),
  (2, 'Separador Velluto', 'separador@velluto.com', NULL, 'separador', NULL, '(11) 4000-1001', DATE_SUB(NOW(), INTERVAL 720 HOUR)),
  (3, 'Entregador Velluto', 'entregador@velluto.com', NULL, 'entregador', NULL, '(11) 4000-1002', DATE_SUB(NOW(), INTERVAL 720 HOUR)),
  (4, 'Bruno Lima', 'separador2@velluto.com', NULL, 'separador', NULL, '(11) 4000-1003', DATE_SUB(NOW(), INTERVAL 720 HOUR)),
  (5, 'Carla Mendes', 'entregador2@velluto.com', NULL, 'entregador', NULL, '(11) 4000-1004', DATE_SUB(NOW(), INTERVAL 720 HOUR)),
  (6, 'Maria Oliveira', 'cliente@velluto.com', '$2y$10$VVmbsMRwB4RgTr5rODKTsueOgf2O0Wq6xwNVy5jnFj42yeNhGOITi', 'cliente', '52998224725', '(11) 98888-1234', DATE_SUB(NOW(), INTERVAL 720 HOUR)),
  (7, 'João Pereira', 'joao@velluto.com', '$2y$10$VVmbsMRwB4RgTr5rODKTsueOgf2O0Wq6xwNVy5jnFj42yeNhGOITi', 'cliente', '11144477735', '(11) 97777-4321', DATE_SUB(NOW(), INTERVAL 720 HOUR));

INSERT INTO enderecos (id, usuario_id, apelido, destinatario, cep, logradouro, numero, complemento, bairro, cidade, uf, referencia, principal) VALUES
  (1, 6, 'Casa', 'Maria Oliveira', '01234567', 'Rua das Flores', '123', 'Apto 42', 'Jardim Bela Vista', 'São Paulo', 'SP', 'Próximo à praça', 1),
  (2, 6, 'Trabalho', 'Maria Oliveira', '04538133', 'Avenida das Magnólias', '1500', '8º andar', 'Vila Olímpia', 'São Paulo', 'SP', NULL, 0),
  (3, 7, 'Casa', 'João Pereira', '05422010', 'Rua dos Ipês', '77', NULL, 'Pinheiros', 'São Paulo', 'SP', NULL, 1);

INSERT INTO categorias (id, nome, slug, icone, cor, pai_id, ordem, descricao) VALUES
  (1, 'Alimentos', 'alimentos', '🥖', '#EAD2B0', NULL, 1, 'Mercearia, laticínios, congelados e enlatados para o dia a dia.'),
  (2, 'Bebidas', 'bebidas', '🧃', '#F2BFCB', NULL, 2, 'Águas, sucos, refrigerantes, vinhos e cervejas.'),
  (3, 'Hortifruti', 'hortifruti', '🥬', '#CFE0BC', NULL, 3, 'Frutas, legumes e verduras selecionados.'),
  (4, 'Carnes', 'carnes', '🥩', '#E9B0A8', NULL, 4, 'Carnes bovinas, suínas, aves e peixes.'),
  (5, 'Padaria', 'padaria', '🥐', '#F0D9AE', NULL, 5, 'Pães, bolos e torradas.'),
  (6, 'Limpeza', 'limpeza', '🧴', '#C5DDD6', NULL, 6, 'Tudo para deixar a casa impecável.'),
  (7, 'Higiene', 'higiene', '🧼', '#DCCDE8', NULL, 7, 'Cuidados pessoais e higiene diária.'),
  (8, 'Beleza', 'beleza', '💄', '#F2C6D6', NULL, 8, 'Maquiagem, perfumaria e cuidados.'),
  (9, 'Eletrônicos', 'eletronicos', '🎧', '#CDD0DC', NULL, 9, 'Áudio, acessórios e tecnologia.'),
  (10, 'Eletrodomésticos', 'eletrodomesticos', '🍳', '#DDD3C6', NULL, 10, 'Praticidade para a cozinha e a casa.'),
  (11, 'Roupas', 'roupas', '👕', '#E8C7B6', NULL, 11, 'Básicos confortáveis para toda a família.'),
  (12, 'Casa & Decoração', 'casa-decoracao', '🕯️', '#E6D9BD', NULL, 12, 'Aconchego e estilo para o lar.'),
  (13, 'Pet', 'pet', '🐾', '#EAD5AE', NULL, 13, 'Alimentação e cuidados para pets.'),
  (14, 'Bebês', 'bebes', '🍼', '#F7D9DF', NULL, 14, 'Cuidado e carinho para os pequenos.'),
  (15, 'Mercearia', 'mercearia', '🌾', '#EAD2B0', 1, 1, 'Grãos, massas, óleos e básicos.'),
  (16, 'Laticínios', 'laticinios', '🧀', '#F3E6C8', 1, 2, 'Leites, queijos, iogurtes e manteigas.'),
  (17, 'Congelados', 'congelados', '🧊', '#C9DCE6', 1, 3, 'Pratos prontos, sorvetes e congelados.'),
  (18, 'Enlatados', 'enlatados', '🥫', '#E8C4A8', 1, 4, 'Conservas e enlatados.');

INSERT INTO produtos (id, categoria_id, nome, slug, marca, descricao, informacoes, embalagem, vendido_por, preco, preco_promocional, estoque, estoque_minimo, imagem, destaque, criado_em) VALUES
  (1, 15, 'Arroz Tipo 1', 'arroz-tipo-1', 'Velluto Seleção', 'Arroz Tipo 1 Velluto Seleção — pacote 5 kg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Velluto Seleção
Apresentação: Pacote 5 kg
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote 5 kg', 'unidade', 24.90, NULL, 80, 10, 'assets/img/produtos/arroz-tipo-1.jpg', 1, DATE_SUB(NOW(), INTERVAL 936 HOUR)),
  (2, 15, 'Feijão Carioca', 'feijao-carioca', 'Campo Doce', 'Feijão Carioca Campo Doce — pacote 1 kg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Campo Doce
Apresentação: Pacote 1 kg
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote 1 kg', 'unidade', 8.49, NULL, 120, 10, 'assets/img/produtos/feijao-carioca.jpg', 0, DATE_SUB(NOW(), INTERVAL 912 HOUR)),
  (3, 15, 'Óleo de Soja', 'oleo-de-soja', 'Aurora', 'Óleo de Soja Aurora — garrafa 900 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Aurora
Apresentação: Garrafa 900 ml
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Garrafa 900 ml', 'unidade', 6.99, NULL, 90, 10, 'assets/img/produtos/oleo-de-soja.jpg', 0, DATE_SUB(NOW(), INTERVAL 888 HOUR)),
  (4, 15, 'Açúcar Refinado', 'acucar-refinado', 'Doce Lar', 'Açúcar Refinado Doce Lar — pacote 1 kg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Doce Lar
Apresentação: Pacote 1 kg
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote 1 kg', 'unidade', 4.79, NULL, 100, 10, 'assets/img/produtos/acucar-refinado.jpg', 0, DATE_SUB(NOW(), INTERVAL 864 HOUR)),
  (5, 15, 'Café Torrado e Moído', 'cafe-torrado-e-moido', 'Grão Nobre', 'Café Torrado e Moído Grão Nobre — pacote 500 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Grão Nobre
Apresentação: Pacote 500 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote 500 g', 'unidade', 18.90, 16.90, 60, 10, 'assets/img/produtos/cafe-torrado-e-moido.jpg', 1, DATE_SUB(NOW(), INTERVAL 840 HOUR)),
  (6, 15, 'Macarrão Espaguete', 'macarrao-espaguete', 'Bella Pasta', 'Macarrão Espaguete Bella Pasta — pacote 500 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Bella Pasta
Apresentação: Pacote 500 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote 500 g', 'unidade', 4.29, NULL, 140, 10, 'assets/img/produtos/macarrao-espaguete.jpg', 0, DATE_SUB(NOW(), INTERVAL 816 HOUR)),
  (7, 15, 'Farinha de Trigo', 'farinha-de-trigo', 'Campo Doce', 'Farinha de Trigo Campo Doce — pacote 1 kg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Campo Doce
Apresentação: Pacote 1 kg
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote 1 kg', 'unidade', 5.49, NULL, 70, 10, 'assets/img/produtos/farinha-de-trigo.jpg', 0, DATE_SUB(NOW(), INTERVAL 792 HOUR)),
  (8, 15, 'Azeite Extravirgem', 'azeite-extravirgem', 'Oliva Rara', 'Azeite Extravirgem Oliva Rara — vidro 500 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Oliva Rara
Apresentação: Vidro 500 ml
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Vidro 500 ml', 'unidade', 32.90, 28.90, 35, 10, 'assets/img/produtos/azeite-extravirgem.jpg', 1, DATE_SUB(NOW(), INTERVAL 768 HOUR)),
  (9, 16, 'Leite Integral', 'leite-integral', 'Nuvem', 'Leite Integral Nuvem — caixa 1 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Nuvem
Apresentação: Caixa 1 L
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Caixa 1 L', 'unidade', 5.49, NULL, 150, 10, 'assets/img/produtos/leite-integral.jpg', 0, DATE_SUB(NOW(), INTERVAL 744 HOUR)),
  (10, 16, 'Leite Semidesnatado', 'leite-semidesnatado', 'Nuvem', 'Leite Semidesnatado Nuvem — caixa 1 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Nuvem
Apresentação: Caixa 1 L
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Caixa 1 L', 'unidade', 5.29, NULL, 0, 10, 'assets/img/produtos/leite-semidesnatado.jpg', 0, DATE_SUB(NOW(), INTERVAL 720 HOUR)),
  (11, 16, 'Queijo Muçarela Fatiado', 'queijo-mucarela-fatiado', 'Serra Branca', 'Queijo Muçarela Fatiado Serra Branca — bandeja 200 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Serra Branca
Apresentação: Bandeja 200 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Bandeja 200 g', 'unidade', 11.90, NULL, 45, 10, 'assets/img/produtos/queijo-mucarela-fatiado.jpg', 0, DATE_SUB(NOW(), INTERVAL 696 HOUR)),
  (12, 16, 'Iogurte Natural', 'iogurte-natural', 'Nuvem', 'Iogurte Natural Nuvem — pote 170 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Nuvem
Apresentação: Pote 170 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pote 170 g', 'unidade', 3.29, NULL, 80, 10, 'assets/img/produtos/iogurte-natural.jpg', 0, DATE_SUB(NOW(), INTERVAL 672 HOUR)),
  (13, 16, 'Manteiga com Sal', 'manteiga-com-sal', 'Serra Branca', 'Manteiga com Sal Serra Branca — pote 200 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Serra Branca
Apresentação: Pote 200 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pote 200 g', 'unidade', 12.49, NULL, 40, 10, 'assets/img/produtos/manteiga-com-sal.jpg', 0, DATE_SUB(NOW(), INTERVAL 648 HOUR)),
  (14, 16, 'Requeijão Cremoso', 'requeijao-cremoso', 'Serra Branca', 'Requeijão Cremoso Serra Branca — copo 200 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Serra Branca
Apresentação: Copo 200 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Copo 200 g', 'unidade', 7.99, NULL, 55, 10, 'assets/img/produtos/requeijao-cremoso.jpg', 0, DATE_SUB(NOW(), INTERVAL 624 HOUR)),
  (15, 17, 'Pizza Margherita', 'pizza-margherita', 'Forno de Pedra', 'Pizza Margherita Forno de Pedra — caixa 460 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Forno de Pedra
Apresentação: Caixa 460 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Caixa 460 g', 'unidade', 19.90, 16.90, 30, 10, 'assets/img/produtos/pizza-margherita.jpg', 1, DATE_SUB(NOW(), INTERVAL 600 HOUR)),
  (16, 17, 'Lasanha à Bolonhesa', 'lasanha-a-bolonhesa', 'Forno de Pedra', 'Lasanha à Bolonhesa Forno de Pedra — bandeja 600 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Forno de Pedra
Apresentação: Bandeja 600 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Bandeja 600 g', 'unidade', 21.90, NULL, 25, 10, 'assets/img/produtos/lasanha-a-bolonhesa.jpg', 0, DATE_SUB(NOW(), INTERVAL 576 HOUR)),
  (17, 17, 'Batata Pré-frita', 'batata-pre-frita', 'Campo Doce', 'Batata Pré-frita Campo Doce — pacote 1 kg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Campo Doce
Apresentação: Pacote 1 kg
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote 1 kg', 'unidade', 17.49, NULL, 40, 10, 'assets/img/produtos/batata-pre-frita.jpg', 0, DATE_SUB(NOW(), INTERVAL 552 HOUR)),
  (18, 17, 'Sorvete de Creme', 'sorvete-de-creme', 'Polar Doce', 'Sorvete de Creme Polar Doce — pote 1,5 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Polar Doce
Apresentação: Pote 1,5 L
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pote 1,5 L', 'unidade', 22.90, NULL, 20, 10, 'assets/img/produtos/sorvete-de-creme.jpg', 0, DATE_SUB(NOW(), INTERVAL 528 HOUR)),
  (19, 18, 'Milho Verde', 'milho-verde', 'Horta Viva', 'Milho Verde Horta Viva — lata 170 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Horta Viva
Apresentação: Lata 170 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Lata 170 g', 'unidade', 3.99, NULL, 90, 10, 'assets/img/produtos/milho-verde.jpg', 0, DATE_SUB(NOW(), INTERVAL 504 HOUR)),
  (20, 18, 'Atum Sólido', 'atum-solido', 'Mar Azul', 'Atum Sólido Mar Azul — lata 170 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Mar Azul
Apresentação: Lata 170 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Lata 170 g', 'unidade', 9.49, NULL, 60, 10, 'assets/img/produtos/atum-solido.jpg', 0, DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (21, 18, 'Extrato de Tomate', 'extrato-de-tomate', 'Horta Viva', 'Extrato de Tomate Horta Viva — lata 340 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Horta Viva
Apresentação: Lata 340 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Lata 340 g', 'unidade', 4.59, NULL, 75, 10, 'assets/img/produtos/extrato-de-tomate.jpg', 0, DATE_SUB(NOW(), INTERVAL 456 HOUR)),
  (22, 18, 'Ervilha em Conserva', 'ervilha-em-conserva', 'Horta Viva', 'Ervilha em Conserva Horta Viva — lata 170 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Horta Viva
Apresentação: Lata 170 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Lata 170 g', 'unidade', 3.79, NULL, 65, 10, 'assets/img/produtos/ervilha-em-conserva.jpg', 0, DATE_SUB(NOW(), INTERVAL 432 HOUR)),
  (23, 2, 'Água Mineral sem Gás', 'agua-mineral-sem-gas', 'Fonte Clara', 'Água Mineral sem Gás Fonte Clara — garrafa 1,5 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Fonte Clara
Apresentação: Garrafa 1,5 L
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Garrafa 1,5 L', 'unidade', 2.49, NULL, 200, 10, 'assets/img/produtos/agua-mineral-sem-gas.jpg', 0, DATE_SUB(NOW(), INTERVAL 408 HOUR)),
  (24, 2, 'Suco de Uva Integral', 'suco-de-uva-integral', 'Vinha Serena', 'Suco de Uva Integral Vinha Serena — garrafa 1 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Vinha Serena
Apresentação: Garrafa 1 L
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Garrafa 1 L', 'unidade', 13.90, NULL, 50, 10, 'assets/img/produtos/suco-de-uva-integral.jpg', 0, DATE_SUB(NOW(), INTERVAL 384 HOUR)),
  (25, 2, 'Refrigerante de Cola', 'refrigerante-de-cola', 'Bolha', 'Refrigerante de Cola Bolha — garrafa 2 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Bolha
Apresentação: Garrafa 2 L
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Garrafa 2 L', 'unidade', 8.99, NULL, 110, 10, 'assets/img/produtos/refrigerante-de-cola.jpg', 0, DATE_SUB(NOW(), INTERVAL 360 HOUR)),
  (26, 2, 'Vinho Tinto Seco', 'vinho-tinto-seco', 'Vinha Serena', 'Vinho Tinto Seco Vinha Serena — garrafa 750 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Vinha Serena
Apresentação: Garrafa 750 ml
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Garrafa 750 ml', 'unidade', 49.90, 42.90, 30, 10, 'assets/img/produtos/vinho-tinto-seco.jpg', 1, DATE_SUB(NOW(), INTERVAL 336 HOUR)),
  (27, 2, 'Cerveja Artesanal', 'cerveja-artesanal', 'Lúpulo Rosa', 'Cerveja Artesanal Lúpulo Rosa — garrafa 500 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Lúpulo Rosa
Apresentação: Garrafa 500 ml
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Garrafa 500 ml', 'unidade', 12.90, NULL, 70, 10, 'assets/img/produtos/cerveja-artesanal.jpg', 0, DATE_SUB(NOW(), INTERVAL 312 HOUR)),
  (28, 2, 'Chá Gelado de Pêssego', 'cha-gelado-de-pessego', 'Fonte Clara', 'Chá Gelado de Pêssego Fonte Clara — garrafa 1 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Fonte Clara
Apresentação: Garrafa 1 L
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Garrafa 1 L', 'unidade', 6.49, NULL, 60, 10, 'assets/img/produtos/cha-gelado-de-pessego.jpg', 0, DATE_SUB(NOW(), INTERVAL 288 HOUR)),
  (29, 3, 'Banana Prata', 'banana-prata', 'Hortifruti Velluto', 'Banana Prata fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Hortifruti Velluto
Apresentação: Vendido por kg
Venda: por quilo (peso aproximado; cobrança pelo peso real)
Armazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 6.90, NULL, 60, 8, 'assets/img/produtos/banana-prata.jpg', 1, DATE_SUB(NOW(), INTERVAL 264 HOUR)),
  (30, 3, 'Maçã Gala', 'maca-gala', 'Hortifruti Velluto', 'Maçã Gala fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Hortifruti Velluto
Apresentação: Vendido por kg
Venda: por quilo (peso aproximado; cobrança pelo peso real)
Armazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 9.90, NULL, 50, 8, 'assets/img/produtos/maca-gala.jpg', 0, DATE_SUB(NOW(), INTERVAL 240 HOUR)),
  (31, 3, 'Tomate', 'tomate', 'Hortifruti Velluto', 'Tomate fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Hortifruti Velluto
Apresentação: Vendido por kg
Venda: por quilo (peso aproximado; cobrança pelo peso real)
Armazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 7.49, NULL, 40, 8, 'assets/img/produtos/tomate.jpg', 0, DATE_SUB(NOW(), INTERVAL 216 HOUR)),
  (32, 3, 'Batata Inglesa', 'batata-inglesa', 'Hortifruti Velluto', 'Batata Inglesa fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Hortifruti Velluto
Apresentação: Vendido por kg
Venda: por quilo (peso aproximado; cobrança pelo peso real)
Armazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 5.99, NULL, 70, 8, 'assets/img/produtos/batata-inglesa.jpg', 0, DATE_SUB(NOW(), INTERVAL 192 HOUR)),
  (33, 3, 'Alface Crespa', 'alface-crespa', 'Hortifruti Velluto', 'Alface Crespa Hortifruti Velluto — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Hortifruti Velluto
Apresentação: Unidade
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 3.49, NULL, 40, 10, 'assets/img/produtos/alface-crespa.jpg', 0, DATE_SUB(NOW(), INTERVAL 168 HOUR)),
  (34, 3, 'Laranja Pera', 'laranja-pera', 'Hortifruti Velluto', 'Laranja Pera fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Hortifruti Velluto
Apresentação: Vendido por kg
Venda: por quilo (peso aproximado; cobrança pelo peso real)
Armazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 4.99, NULL, 80, 8, 'assets/img/produtos/laranja-pera.jpg', 0, DATE_SUB(NOW(), INTERVAL 144 HOUR)),
  (35, 3, 'Abacate', 'abacate', 'Hortifruti Velluto', 'Abacate fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Hortifruti Velluto
Apresentação: Vendido por kg
Venda: por quilo (peso aproximado; cobrança pelo peso real)
Armazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 8.90, NULL, 30, 8, 'assets/img/produtos/abacate.jpg', 0, DATE_SUB(NOW(), INTERVAL 960 HOUR)),
  (36, 3, 'Morango', 'morango', 'Hortifruti Velluto', 'Morango Hortifruti Velluto — bandeja 250 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Hortifruti Velluto
Apresentação: Bandeja 250 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Bandeja 250 g', 'unidade', 7.90, 5.90, 35, 10, 'assets/img/produtos/morango.jpg', 1, DATE_SUB(NOW(), INTERVAL 936 HOUR)),
  (37, 4, 'Picanha Bovina', 'picanha-bovina', 'Açougue Velluto', 'Picanha Bovina fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Açougue Velluto
Apresentação: Vendido por kg
Venda: por quilo (peso aproximado; cobrança pelo peso real)
Armazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 79.90, NULL, 25, 8, 'assets/img/produtos/picanha-bovina.jpg', 1, DATE_SUB(NOW(), INTERVAL 912 HOUR)),
  (38, 4, 'Filé de Peito de Frango', 'file-de-peito-de-frango', 'Açougue Velluto', 'Filé de Peito de Frango fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Açougue Velluto
Apresentação: Vendido por kg
Venda: por quilo (peso aproximado; cobrança pelo peso real)
Armazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 22.90, NULL, 40, 8, 'assets/img/produtos/file-de-peito-de-frango.jpg', 0, DATE_SUB(NOW(), INTERVAL 888 HOUR)),
  (39, 4, 'Carne Moída de Patinho', 'carne-moida-de-patinho', 'Açougue Velluto', 'Carne Moída de Patinho fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Açougue Velluto
Apresentação: Vendido por kg
Venda: por quilo (peso aproximado; cobrança pelo peso real)
Armazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 39.90, NULL, 30, 8, 'assets/img/produtos/carne-moida-de-patinho.jpg', 0, DATE_SUB(NOW(), INTERVAL 864 HOUR)),
  (40, 4, 'Linguiça Toscana', 'linguica-toscana', 'Açougue Velluto', 'Linguiça Toscana fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Açougue Velluto
Apresentação: Vendido por kg
Venda: por quilo (peso aproximado; cobrança pelo peso real)
Armazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 24.90, NULL, 35, 8, 'assets/img/produtos/linguica-toscana.jpg', 0, DATE_SUB(NOW(), INTERVAL 840 HOUR)),
  (41, 4, 'Filé de Tilápia', 'file-de-tilapia', 'Peixaria Velluto', 'Filé de Tilápia fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Peixaria Velluto
Apresentação: Vendido por kg
Venda: por quilo (peso aproximado; cobrança pelo peso real)
Armazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 44.90, NULL, 20, 8, 'assets/img/produtos/file-de-tilapia.jpg', 0, DATE_SUB(NOW(), INTERVAL 816 HOUR)),
  (42, 4, 'Costela Suína', 'costela-suina', 'Açougue Velluto', 'Costela Suína fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Açougue Velluto
Apresentação: Vendido por kg
Venda: por quilo (peso aproximado; cobrança pelo peso real)
Armazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 29.90, 26.90, 25, 8, 'assets/img/produtos/costela-suina.jpg', 0, DATE_SUB(NOW(), INTERVAL 792 HOUR)),
  (43, 5, 'Pão Francês', 'pao-frances', 'Padaria Velluto', 'Pão Francês fresquinho, escolhido a dedo. Selecionado diariamente pela equipe Velluto. O valor final é calculado pelo peso real conferido na separação.', 'Marca: Padaria Velluto
Apresentação: Vendido por kg
Venda: por quilo (peso aproximado; cobrança pelo peso real)
Armazenamento: conforme orientação da embalagem', 'Vendido por kg', 'peso', 16.90, NULL, 30, 8, 'assets/img/produtos/pao-frances.jpg', 0, DATE_SUB(NOW(), INTERVAL 768 HOUR)),
  (44, 5, 'Pão de Forma Integral', 'pao-de-forma-integral', 'Trigal', 'Pão de Forma Integral Trigal — pacote 500 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Trigal
Apresentação: Pacote 500 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote 500 g', 'unidade', 9.99, NULL, 40, 10, 'assets/img/produtos/pao-de-forma-integral.jpg', 0, DATE_SUB(NOW(), INTERVAL 744 HOUR)),
  (45, 5, 'Bolo de Cenoura', 'bolo-de-cenoura', 'Padaria Velluto', 'Bolo de Cenoura Padaria Velluto — unidade 400 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Padaria Velluto
Apresentação: Unidade 400 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade 400 g', 'unidade', 18.90, NULL, 15, 10, 'assets/img/produtos/bolo-de-cenoura.jpg', 0, DATE_SUB(NOW(), INTERVAL 720 HOUR)),
  (46, 5, 'Croissant de Manteiga', 'croissant-de-manteiga', 'Padaria Velluto', 'Croissant de Manteiga Padaria Velluto — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Padaria Velluto
Apresentação: Unidade
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 6.50, NULL, 40, 10, 'assets/img/produtos/croissant-de-manteiga.jpg', 1, DATE_SUB(NOW(), INTERVAL 696 HOUR)),
  (47, 5, 'Torrada Tradicional', 'torrada-tradicional', 'Trigal', 'Torrada Tradicional Trigal — pacote 160 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Trigal
Apresentação: Pacote 160 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote 160 g', 'unidade', 5.49, NULL, 50, 10, 'assets/img/produtos/torrada-tradicional.jpg', 0, DATE_SUB(NOW(), INTERVAL 672 HOUR)),
  (48, 6, 'Detergente Neutro', 'detergente-neutro', 'Pura Casa', 'Detergente Neutro Pura Casa — frasco 500 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pura Casa
Apresentação: Frasco 500 ml
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Frasco 500 ml', 'unidade', 2.79, NULL, 150, 10, 'assets/img/produtos/detergente-neutro.jpg', 0, DATE_SUB(NOW(), INTERVAL 648 HOUR)),
  (49, 6, 'Sabão Líquido para Roupas', 'sabao-liquido-para-roupas', 'Pura Casa', 'Sabão Líquido para Roupas Pura Casa — galão 3 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pura Casa
Apresentação: Galão 3 L
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Galão 3 L', 'unidade', 39.90, 34.90, 40, 10, 'assets/img/produtos/sabao-liquido-para-roupas.jpg', 1, DATE_SUB(NOW(), INTERVAL 624 HOUR)),
  (50, 6, 'Desinfetante Lavanda', 'desinfetante-lavanda', 'Pura Casa', 'Desinfetante Lavanda Pura Casa — frasco 2 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pura Casa
Apresentação: Frasco 2 L
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Frasco 2 L', 'unidade', 11.90, NULL, 60, 10, 'assets/img/produtos/desinfetante-lavanda.jpg', 0, DATE_SUB(NOW(), INTERVAL 600 HOUR)),
  (51, 6, 'Esponja Multiuso', 'esponja-multiuso', 'Pura Casa', 'Esponja Multiuso Pura Casa — pacote com 3. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pura Casa
Apresentação: Pacote com 3
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote com 3', 'unidade', 4.99, NULL, 90, 10, 'assets/img/produtos/esponja-multiuso.jpg', 0, DATE_SUB(NOW(), INTERVAL 576 HOUR)),
  (52, 6, 'Papel Toalha', 'papel-toalha', 'Suave', 'Papel Toalha Suave — pacote 2 rolos. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Suave
Apresentação: Pacote 2 rolos
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote 2 rolos', 'unidade', 7.49, NULL, 70, 10, 'assets/img/produtos/papel-toalha.jpg', 0, DATE_SUB(NOW(), INTERVAL 552 HOUR)),
  (53, 6, 'Água Sanitária', 'agua-sanitaria', 'Pura Casa', 'Água Sanitária Pura Casa — frasco 2 l. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pura Casa
Apresentação: Frasco 2 L
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Frasco 2 L', 'unidade', 6.99, NULL, 80, 10, 'assets/img/produtos/agua-sanitaria.jpg', 0, DATE_SUB(NOW(), INTERVAL 528 HOUR)),
  (54, 7, 'Sabonete Erva-doce', 'sabonete-erva-doce', 'Flor de Algodão', 'Sabonete Erva-doce Flor de Algodão — barra 90 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Flor de Algodão
Apresentação: Barra 90 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Barra 90 g', 'unidade', 2.99, NULL, 200, 10, 'assets/img/produtos/sabonete-erva-doce.jpg', 0, DATE_SUB(NOW(), INTERVAL 504 HOUR)),
  (55, 7, 'Creme Dental Menta', 'creme-dental-menta', 'Sorriso', 'Creme Dental Menta Sorriso — tubo 90 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Sorriso
Apresentação: Tubo 90 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Tubo 90 g', 'unidade', 5.49, NULL, 120, 10, 'assets/img/produtos/creme-dental-menta.jpg', 0, DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (56, 7, 'Shampoo Nutrição', 'shampoo-nutricao', 'Flor de Algodão', 'Shampoo Nutrição Flor de Algodão — frasco 350 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Flor de Algodão
Apresentação: Frasco 350 ml
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Frasco 350 ml', 'unidade', 19.90, NULL, 50, 10, 'assets/img/produtos/shampoo-nutricao.jpg', 0, DATE_SUB(NOW(), INTERVAL 456 HOUR)),
  (57, 7, 'Papel Higiênico Folha Dupla', 'papel-higienico-folha-dupla', 'Suave', 'Papel Higiênico Folha Dupla Suave — pacote 12 rolos. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Suave
Apresentação: Pacote 12 rolos
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote 12 rolos', 'unidade', 22.90, 19.90, 60, 10, 'assets/img/produtos/papel-higienico-folha-dupla.jpg', 1, DATE_SUB(NOW(), INTERVAL 432 HOUR)),
  (58, 7, 'Desodorante Aerossol', 'desodorante-aerossol', 'Brisa', 'Desodorante Aerossol Brisa — frasco 150 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Brisa
Apresentação: Frasco 150 ml
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Frasco 150 ml', 'unidade', 14.90, NULL, 70, 10, 'assets/img/produtos/desodorante-aerossol.jpg', 0, DATE_SUB(NOW(), INTERVAL 408 HOUR)),
  (59, 8, 'Hidratante Corporal', 'hidratante-corporal', 'Rosé Botânica', 'Hidratante Corporal Rosé Botânica — frasco 400 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Rosé Botânica
Apresentação: Frasco 400 ml
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Frasco 400 ml', 'unidade', 29.90, NULL, 35, 3, 'assets/img/produtos/hidratante-corporal.jpg', 0, DATE_SUB(NOW(), INTERVAL 384 HOUR)),
  (60, 8, 'Batom Matte Rosé', 'batom-matte-rose', 'Rosé Botânica', 'Batom Matte Rosé Rosé Botânica — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Rosé Botânica
Apresentação: Unidade
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 24.90, NULL, 40, 3, 'assets/img/produtos/batom-matte-rose.jpg', 1, DATE_SUB(NOW(), INTERVAL 360 HOUR)),
  (61, 8, 'Esmalte Nude', 'esmalte-nude', 'Rosé Botânica', 'Esmalte Nude Rosé Botânica — frasco 8 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Rosé Botânica
Apresentação: Frasco 8 ml
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Frasco 8 ml', 'unidade', 7.90, NULL, 60, 3, 'assets/img/produtos/esmalte-nude.jpg', 0, DATE_SUB(NOW(), INTERVAL 336 HOUR)),
  (62, 8, 'Perfume Floral', 'perfume-floral', 'Maison Velluto', 'Perfume Floral Maison Velluto — frasco 50 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Maison Velluto
Apresentação: Frasco 50 ml
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Frasco 50 ml', 'unidade', 129.90, 109.90, 15, 3, 'assets/img/produtos/perfume-floral.jpg', 1, DATE_SUB(NOW(), INTERVAL 312 HOUR)),
  (63, 8, 'Máscara Capilar', 'mascara-capilar', 'Rosé Botânica', 'Máscara Capilar Rosé Botânica — pote 300 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Rosé Botânica
Apresentação: Pote 300 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pote 300 g', 'unidade', 34.90, NULL, 30, 3, 'assets/img/produtos/mascara-capilar.jpg', 0, DATE_SUB(NOW(), INTERVAL 288 HOUR)),
  (64, 9, 'Fone de Ouvido Bluetooth', 'fone-de-ouvido-bluetooth', 'Sonora', 'Fone de Ouvido Bluetooth Sonora — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Sonora
Apresentação: Unidade
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 189.90, 159.90, 18, 3, 'assets/img/produtos/fone-de-ouvido-bluetooth.jpg', 1, DATE_SUB(NOW(), INTERVAL 264 HOUR)),
  (65, 9, 'Carregador USB-C 20W', 'carregador-usb-c-20w', 'Volt', 'Carregador USB-C 20W Volt — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Volt
Apresentação: Unidade
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 79.90, NULL, 25, 3, 'assets/img/produtos/carregador-usb-c-20w.jpg', 0, DATE_SUB(NOW(), INTERVAL 240 HOUR)),
  (66, 9, 'Caixa de Som Portátil', 'caixa-de-som-portatil', 'Sonora', 'Caixa de Som Portátil Sonora — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Sonora
Apresentação: Unidade
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 249.90, NULL, 12, 3, 'assets/img/produtos/caixa-de-som-portatil.jpg', 0, DATE_SUB(NOW(), INTERVAL 216 HOUR)),
  (67, 9, 'Smartwatch Fit', 'smartwatch-fit', 'Volt', 'Smartwatch Fit Volt — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Volt
Apresentação: Unidade
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 399.90, NULL, 8, 3, 'assets/img/produtos/smartwatch-fit.jpg', 0, DATE_SUB(NOW(), INTERVAL 192 HOUR)),
  (68, 9, 'Pilhas Alcalinas AA', 'pilhas-alcalinas-aa', 'Volt', 'Pilhas Alcalinas AA Volt — cartela com 4. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Volt
Apresentação: Cartela com 4
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Cartela com 4', 'unidade', 18.90, NULL, 3, 3, 'assets/img/produtos/pilhas-alcalinas-aa.jpg', 0, DATE_SUB(NOW(), INTERVAL 168 HOUR)),
  (69, 10, 'Air Fryer 4 L', 'air-fryer-4-l', 'Casa Prática', 'Air Fryer 4 L Casa Prática — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Casa Prática
Apresentação: Unidade
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 449.90, 399.90, 10, 3, 'assets/img/produtos/air-fryer-4-l.jpg', 1, DATE_SUB(NOW(), INTERVAL 144 HOUR)),
  (70, 10, 'Liquidificador 3 Velocidades', 'liquidificador-3-velocidades', 'Casa Prática', 'Liquidificador 3 Velocidades Casa Prática — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Casa Prática
Apresentação: Unidade
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 189.90, NULL, 12, 3, 'assets/img/produtos/liquidificador-3-velocidades.jpg', 0, DATE_SUB(NOW(), INTERVAL 960 HOUR)),
  (71, 10, 'Cafeteira Elétrica', 'cafeteira-eletrica', 'Casa Prática', 'Cafeteira Elétrica Casa Prática — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Casa Prática
Apresentação: Unidade
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 159.90, NULL, 9, 3, 'assets/img/produtos/cafeteira-eletrica.jpg', 0, DATE_SUB(NOW(), INTERVAL 936 HOUR)),
  (72, 10, 'Ferro a Vapor', 'ferro-a-vapor', 'Casa Prática', 'Ferro a Vapor Casa Prática — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Casa Prática
Apresentação: Unidade
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 129.90, NULL, 11, 3, 'assets/img/produtos/ferro-a-vapor.jpg', 0, DATE_SUB(NOW(), INTERVAL 912 HOUR)),
  (73, 10, 'Micro-ondas 20 L', 'micro-ondas-20-l', 'Casa Prática', 'Micro-ondas 20 L Casa Prática — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Casa Prática
Apresentação: Unidade
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 699.90, NULL, 4, 3, 'assets/img/produtos/micro-ondas-20-l.jpg', 0, DATE_SUB(NOW(), INTERVAL 888 HOUR)),
  (74, 11, 'Camiseta Básica de Algodão', 'camiseta-basica-de-algodao', 'Linho & Co.', 'Camiseta Básica de Algodão Linho & Co. — tamanhos p ao gg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Linho & Co.
Apresentação: Tamanhos P ao GG
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Tamanhos P ao GG', 'unidade', 49.90, NULL, 40, 3, 'assets/img/produtos/camiseta-basica-de-algodao.jpg', 0, DATE_SUB(NOW(), INTERVAL 864 HOUR)),
  (75, 11, 'Pijama Feminino', 'pijama-feminino', 'Linho & Co.', 'Pijama Feminino Linho & Co. — tamanhos p ao g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Linho & Co.
Apresentação: Tamanhos P ao G
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Tamanhos P ao G', 'unidade', 89.90, NULL, 20, 3, 'assets/img/produtos/pijama-feminino.jpg', 0, DATE_SUB(NOW(), INTERVAL 840 HOUR)),
  (76, 11, 'Kit de Meias', 'kit-de-meias', 'Linho & Co.', 'Kit de Meias Linho & Co. — pacote com 3 pares. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Linho & Co.
Apresentação: Pacote com 3 pares
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote com 3 pares', 'unidade', 29.90, NULL, 50, 3, 'assets/img/produtos/kit-de-meias.jpg', 0, DATE_SUB(NOW(), INTERVAL 816 HOUR)),
  (77, 11, 'Moletom Confort', 'moletom-confort', 'Linho & Co.', 'Moletom Confort Linho & Co. — tamanhos p ao gg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Linho & Co.
Apresentação: Tamanhos P ao GG
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Tamanhos P ao GG', 'unidade', 139.90, 119.90, 15, 3, 'assets/img/produtos/moletom-confort.jpg', 0, DATE_SUB(NOW(), INTERVAL 792 HOUR)),
  (78, 12, 'Vela Aromática Baunilha', 'vela-aromatica-baunilha', 'Maison Velluto', 'Vela Aromática Baunilha Maison Velluto — pote 200 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Maison Velluto
Apresentação: Pote 200 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pote 200 g', 'unidade', 39.90, NULL, 25, 3, 'assets/img/produtos/vela-aromatica-baunilha.jpg', 1, DATE_SUB(NOW(), INTERVAL 768 HOUR)),
  (79, 12, 'Jogo de Toalhas', 'jogo-de-toalhas', 'Maison Velluto', 'Jogo de Toalhas Maison Velluto — 4 peças. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Maison Velluto
Apresentação: 4 peças
Venda: por unidade
Armazenamento: conforme orientação da embalagem', '4 peças', 'unidade', 99.90, NULL, 15, 3, 'assets/img/produtos/jogo-de-toalhas.jpg', 0, DATE_SUB(NOW(), INTERVAL 744 HOUR)),
  (80, 12, 'Caneca de Cerâmica', 'caneca-de-ceramica', 'Maison Velluto', 'Caneca de Cerâmica Maison Velluto — unidade 350 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Maison Velluto
Apresentação: Unidade 350 ml
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade 350 ml', 'unidade', 34.90, NULL, 30, 3, 'assets/img/produtos/caneca-de-ceramica.jpg', 0, DATE_SUB(NOW(), INTERVAL 720 HOUR)),
  (81, 12, 'Manta Decorativa', 'manta-decorativa', 'Maison Velluto', 'Manta Decorativa Maison Velluto — unidade 1,2 x 1,6 m. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Maison Velluto
Apresentação: Unidade 1,2 x 1,6 m
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade 1,2 x 1,6 m', 'unidade', 119.90, NULL, 10, 3, 'assets/img/produtos/manta-decorativa.jpg', 0, DATE_SUB(NOW(), INTERVAL 696 HOUR)),
  (82, 12, 'Vaso de Cerâmica', 'vaso-de-ceramica', 'Maison Velluto', 'Vaso de Cerâmica Maison Velluto — unidade. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Maison Velluto
Apresentação: Unidade
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade', 'unidade', 59.90, NULL, 14, 3, 'assets/img/produtos/vaso-de-ceramica.jpg', 0, DATE_SUB(NOW(), INTERVAL 672 HOUR)),
  (83, 13, 'Ração para Cães Adultos', 'racao-para-caes-adultos', 'Patas Felizes', 'Ração para Cães Adultos Patas Felizes — saco 10 kg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Patas Felizes
Apresentação: Saco 10 kg
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Saco 10 kg', 'unidade', 149.90, NULL, 20, 10, 'assets/img/produtos/racao-para-caes-adultos.jpg', 0, DATE_SUB(NOW(), INTERVAL 648 HOUR)),
  (84, 13, 'Ração para Gatos', 'racao-para-gatos', 'Patas Felizes', 'Ração para Gatos Patas Felizes — saco 3 kg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Patas Felizes
Apresentação: Saco 3 kg
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Saco 3 kg', 'unidade', 69.90, NULL, 25, 10, 'assets/img/produtos/racao-para-gatos.jpg', 0, DATE_SUB(NOW(), INTERVAL 624 HOUR)),
  (85, 13, 'Petisco Bifinho', 'petisco-bifinho', 'Patas Felizes', 'Petisco Bifinho Patas Felizes — pacote 65 g. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Patas Felizes
Apresentação: Pacote 65 g
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote 65 g', 'unidade', 8.90, NULL, 60, 10, 'assets/img/produtos/petisco-bifinho.jpg', 0, DATE_SUB(NOW(), INTERVAL 600 HOUR)),
  (86, 13, 'Areia Higiênica', 'areia-higienica', 'Patas Felizes', 'Areia Higiênica Patas Felizes — pacote 4 kg. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Patas Felizes
Apresentação: Pacote 4 kg
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote 4 kg', 'unidade', 24.90, NULL, 30, 10, 'assets/img/produtos/areia-higienica.jpg', 0, DATE_SUB(NOW(), INTERVAL 576 HOUR)),
  (87, 14, 'Fralda Tamanho M', 'fralda-tamanho-m', 'Pequeno Abraço', 'Fralda Tamanho M Pequeno Abraço — pacote 40 unidades. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pequeno Abraço
Apresentação: Pacote 40 unidades
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote 40 unidades', 'unidade', 69.90, 59.90, 30, 10, 'assets/img/produtos/fralda-tamanho-m.jpg', 1, DATE_SUB(NOW(), INTERVAL 552 HOUR)),
  (88, 14, 'Lenço Umedecido', 'lenco-umedecido', 'Pequeno Abraço', 'Lenço Umedecido Pequeno Abraço — pacote 50 unidades. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pequeno Abraço
Apresentação: Pacote 50 unidades
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Pacote 50 unidades', 'unidade', 9.90, NULL, 60, 10, 'assets/img/produtos/lenco-umedecido.jpg', 0, DATE_SUB(NOW(), INTERVAL 528 HOUR)),
  (89, 14, 'Shampoo Infantil', 'shampoo-infantil', 'Pequeno Abraço', 'Shampoo Infantil Pequeno Abraço — frasco 200 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pequeno Abraço
Apresentação: Frasco 200 ml
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Frasco 200 ml', 'unidade', 16.90, NULL, 35, 10, 'assets/img/produtos/shampoo-infantil.jpg', 0, DATE_SUB(NOW(), INTERVAL 504 HOUR)),
  (90, 14, 'Mamadeira', 'mamadeira', 'Pequeno Abraço', 'Mamadeira Pequeno Abraço — unidade 260 ml. Qualidade selecionada pela curadoria Velluto para o seu dia a dia.', 'Marca: Pequeno Abraço
Apresentação: Unidade 260 ml
Venda: por unidade
Armazenamento: conforme orientação da embalagem', 'Unidade 260 ml', 'unidade', 39.90, NULL, 20, 10, 'assets/img/produtos/mamadeira.jpg', 0, DATE_SUB(NOW(), INTERVAL 480 HOUR));

INSERT INTO movimentacoes_estoque (produto_id, tipo, quantidade, estoque_anterior, estoque_posterior, usuario_id, observacao, criado_em) VALUES
  (1, 'entrada', 80, 0, 80, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (2, 'entrada', 120, 0, 120, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (3, 'entrada', 90, 0, 90, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (4, 'entrada', 100, 0, 100, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (5, 'entrada', 60, 0, 60, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (6, 'entrada', 140, 0, 140, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (7, 'entrada', 70, 0, 70, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (8, 'entrada', 35, 0, 35, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (9, 'entrada', 150, 0, 150, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (11, 'entrada', 45, 0, 45, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (12, 'entrada', 80, 0, 80, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (13, 'entrada', 40, 0, 40, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (14, 'entrada', 55, 0, 55, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (15, 'entrada', 30, 0, 30, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (16, 'entrada', 25, 0, 25, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (17, 'entrada', 40, 0, 40, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (18, 'entrada', 20, 0, 20, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (19, 'entrada', 90, 0, 90, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (20, 'entrada', 60, 0, 60, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (21, 'entrada', 75, 0, 75, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (22, 'entrada', 65, 0, 65, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (23, 'entrada', 200, 0, 200, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (24, 'entrada', 50, 0, 50, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (25, 'entrada', 110, 0, 110, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (26, 'entrada', 30, 0, 30, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (27, 'entrada', 70, 0, 70, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (28, 'entrada', 60, 0, 60, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (29, 'entrada', 60, 0, 60, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (30, 'entrada', 50, 0, 50, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (31, 'entrada', 40, 0, 40, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (32, 'entrada', 70, 0, 70, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (33, 'entrada', 40, 0, 40, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (34, 'entrada', 80, 0, 80, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (35, 'entrada', 30, 0, 30, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (36, 'entrada', 35, 0, 35, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (37, 'entrada', 25, 0, 25, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (38, 'entrada', 40, 0, 40, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (39, 'entrada', 30, 0, 30, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (40, 'entrada', 35, 0, 35, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (41, 'entrada', 20, 0, 20, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (42, 'entrada', 25, 0, 25, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (43, 'entrada', 30, 0, 30, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (44, 'entrada', 40, 0, 40, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (45, 'entrada', 15, 0, 15, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (46, 'entrada', 40, 0, 40, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (47, 'entrada', 50, 0, 50, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (48, 'entrada', 150, 0, 150, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (49, 'entrada', 40, 0, 40, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (50, 'entrada', 60, 0, 60, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (51, 'entrada', 90, 0, 90, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (52, 'entrada', 70, 0, 70, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (53, 'entrada', 80, 0, 80, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (54, 'entrada', 200, 0, 200, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (55, 'entrada', 120, 0, 120, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (56, 'entrada', 50, 0, 50, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (57, 'entrada', 60, 0, 60, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (58, 'entrada', 70, 0, 70, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (59, 'entrada', 35, 0, 35, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (60, 'entrada', 40, 0, 40, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (61, 'entrada', 60, 0, 60, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (62, 'entrada', 15, 0, 15, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (63, 'entrada', 30, 0, 30, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (64, 'entrada', 18, 0, 18, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (65, 'entrada', 25, 0, 25, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (66, 'entrada', 12, 0, 12, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (67, 'entrada', 8, 0, 8, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (68, 'entrada', 3, 0, 3, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (69, 'entrada', 10, 0, 10, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (70, 'entrada', 12, 0, 12, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (71, 'entrada', 9, 0, 9, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (72, 'entrada', 11, 0, 11, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (73, 'entrada', 4, 0, 4, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (74, 'entrada', 40, 0, 40, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (75, 'entrada', 20, 0, 20, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (76, 'entrada', 50, 0, 50, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (77, 'entrada', 15, 0, 15, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (78, 'entrada', 25, 0, 25, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (79, 'entrada', 15, 0, 15, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (80, 'entrada', 30, 0, 30, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (81, 'entrada', 10, 0, 10, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (82, 'entrada', 14, 0, 14, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (83, 'entrada', 20, 0, 20, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (84, 'entrada', 25, 0, 25, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (85, 'entrada', 60, 0, 60, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (86, 'entrada', 30, 0, 30, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (87, 'entrada', 30, 0, 30, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (88, 'entrada', 60, 0, 60, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (89, 'entrada', 35, 0, 35, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR)),
  (90, 'entrada', 20, 0, 20, 1, 'Carga inicial de estoque', DATE_SUB(NOW(), INTERVAL 480 HOUR));

INSERT INTO areas_entrega (id, nome, cidade, uf, cep_inicio, cep_fim, valor_frete, valor_expresso, frete_gratis_acima, prazo_padrao, prazo_expresso) VALUES
  (1, 'Centro e Bela Vista', 'São Paulo', 'SP', '01000000', '01599999', 12.90, 18.90, 199.00, 'até 2 dias', 'até 1 dia'),
  (2, 'Zona Norte', 'São Paulo', 'SP', '02000000', '02999999', 14.90, 24.90, 249.00, 'até 2 dias', 'até 1 dia'),
  (3, 'Zona Sul', 'São Paulo', 'SP', '04000000', '04999999', 12.90, 19.90, 199.00, 'até 2 dias', 'até 1 dia'),
  (4, 'Zona Oeste', 'São Paulo', 'SP', '05000000', '05899999', 13.90, 21.90, 199.00, 'até 2 dias', 'até 1 dia'),
  (5, 'Zona Leste', 'São Paulo', 'SP', '08000000', '08499999', 14.90, 24.90, 249.00, 'até 2 dias', 'até 1 dia');

INSERT INTO configuracoes (chave, valor, descricao) VALUES
  ('nome_loja', 'Velluto', 'Nome exibido na loja'),
  ('slogan', 'Tudo para sua casa, em um só lugar.', 'Frase de destaque da página inicial'),
  ('email_contato', 'contato@velluto.com', 'E-mail de atendimento'),
  ('telefone_contato', '(11) 4000-1000', 'Telefone de atendimento'),
  ('valor_minimo_pedido', '20.00', 'Valor mínimo de produtos para finalizar a compra (R$)'),
  ('tolerancia_ajuste_percent', '10', 'Aumento máximo (%) no total por diferença de peso sem nova aprovação do cliente'),
  ('aviso_topo', 'Frete grátis acima de R$ 199 nas regiões atendidas · Pagamento 100% simulado', 'Faixa de aviso no topo do site');

INSERT INTO pedidos (id, usuario_id, endereco_id, area_entrega_id, endereco_entrega, cep_entrega, tipo_frete, prazo_entrega, valor_frete, subtotal, total, total_pago, metodo_pagamento, status, separador_id, volumes, observacoes, motivo_cancelamento, cancelado_por, cancelado_em, separacao_iniciada_em, separacao_concluida_em, concluido_em, criado_em, atualizado_em) VALUES
  (1, 6, 1, 1, 'Rua das Flores, 123, Apto 42 — Jardim Bela Vista, São Paulo/SP', '01234567', 'padrao', 'até 2 dias', 12.90, 81.72, 94.62, 94.62, 'cartao', 'concluido', 2, 2, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 147 HOUR), DATE_SUB(NOW(), INTERVAL 146 HOUR), DATE_SUB(NOW(), INTERVAL 143 HOUR), DATE_SUB(NOW(), INTERVAL 149 HOUR), DATE_SUB(NOW(), INTERVAL 143 HOUR)),
  (2, 7, 3, 4, 'Rua dos Ipês, 77 — Pinheiros, São Paulo/SP', '05422010', 'padrao', 'até 2 dias', 13.90, 181.73, 195.63, 195.63, 'pix', 'concluido', 2, 2, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 143 HOUR), DATE_SUB(NOW(), INTERVAL 142 HOUR), DATE_SUB(NOW(), INTERVAL 139 HOUR), DATE_SUB(NOW(), INTERVAL 145 HOUR), DATE_SUB(NOW(), INTERVAL 139 HOUR)),
  (3, 6, 1, 1, 'Rua das Flores, 123, Apto 42 — Jardim Bela Vista, São Paulo/SP', '01234567', 'padrao', 'até 2 dias', 12.90, 72.96, 85.86, 85.86, 'cartao', 'concluido', 2, 2, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 121 HOUR), DATE_SUB(NOW(), INTERVAL 120 HOUR), DATE_SUB(NOW(), INTERVAL 117 HOUR), DATE_SUB(NOW(), INTERVAL 123 HOUR), DATE_SUB(NOW(), INTERVAL 117 HOUR)),
  (4, 6, 2, 3, 'Avenida das Magnólias, 1500, 8º andar — Vila Olímpia, São Paulo/SP', '04538133', 'padrao', 'até 2 dias', 12.90, 63.17, 76.07, 76.07, 'pix', 'concluido', 2, 2, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 100 HOUR), DATE_SUB(NOW(), INTERVAL 99 HOUR), DATE_SUB(NOW(), INTERVAL 96 HOUR), DATE_SUB(NOW(), INTERVAL 102 HOUR), DATE_SUB(NOW(), INTERVAL 96 HOUR)),
  (5, 7, 3, 4, 'Rua dos Ipês, 77 — Pinheiros, São Paulo/SP', '05422010', 'padrao', 'até 2 dias', 0.00, 239.80, 239.80, 239.80, 'pix', 'concluido', 2, 2, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 96 HOUR), DATE_SUB(NOW(), INTERVAL 95 HOUR), DATE_SUB(NOW(), INTERVAL 92 HOUR), DATE_SUB(NOW(), INTERVAL 98 HOUR), DATE_SUB(NOW(), INTERVAL 92 HOUR)),
  (6, 6, 1, 1, 'Rua das Flores, 123, Apto 42 — Jardim Bela Vista, São Paulo/SP', '01234567', 'padrao', 'até 2 dias', 12.90, 74.68, 87.58, 87.58, 'cartao', 'concluido', 2, 2, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 74 HOUR), DATE_SUB(NOW(), INTERVAL 73 HOUR), DATE_SUB(NOW(), INTERVAL 70 HOUR), DATE_SUB(NOW(), INTERVAL 76 HOUR), DATE_SUB(NOW(), INTERVAL 70 HOUR)),
  (7, 7, 3, 4, 'Rua dos Ipês, 77 — Pinheiros, São Paulo/SP', '05422010', 'padrao', 'até 2 dias', 13.90, 52.22, 66.12, 66.12, 'pix', 'concluido', 2, 2, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 53 HOUR), DATE_SUB(NOW(), INTERVAL 52 HOUR), DATE_SUB(NOW(), INTERVAL 49 HOUR), DATE_SUB(NOW(), INTERVAL 55 HOUR), DATE_SUB(NOW(), INTERVAL 49 HOUR)),
  (8, 6, 1, 1, 'Rua das Flores, 123, Apto 42 — Jardim Bela Vista, São Paulo/SP', '01234567', 'padrao', 'até 2 dias', 12.90, 139.80, 152.70, 152.70, 'cartao', 'concluido', 2, 2, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 48 HOUR), DATE_SUB(NOW(), INTERVAL 47 HOUR), DATE_SUB(NOW(), INTERVAL 44 HOUR), DATE_SUB(NOW(), INTERVAL 50 HOUR), DATE_SUB(NOW(), INTERVAL 44 HOUR)),
  (9, 7, 3, 4, 'Rua dos Ipês, 77 — Pinheiros, São Paulo/SP', '05422010', 'padrao', 'até 2 dias', 13.90, 119.70, 133.60, 0.00, 'pix', 'cancelado', NULL, NULL, NULL, 'Desistência da compra', 7, DATE_SUB(NOW(), INTERVAL 29 HOUR), NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 30 HOUR), DATE_SUB(NOW(), INTERVAL 24 HOUR)),
  (10, 6, 1, 1, 'Rua das Flores, 123, Apto 42 — Jardim Bela Vista, São Paulo/SP', '01234567', 'padrao', 'até 2 dias', 12.90, 126.60, 139.50, 139.50, 'pix', 'concluido', 2, 2, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 25 HOUR), DATE_SUB(NOW(), INTERVAL 24 HOUR), DATE_SUB(NOW(), INTERVAL 21 HOUR), DATE_SUB(NOW(), INTERVAL 27 HOUR), DATE_SUB(NOW(), INTERVAL 21 HOUR)),
  (11, 7, 3, 4, 'Rua dos Ipês, 77 — Pinheiros, São Paulo/SP', '05422010', 'padrao', 'até 2 dias', 13.90, 149.50, 163.40, 163.40, 'cartao', 'concluido', 2, 2, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 23 HOUR), DATE_SUB(NOW(), INTERVAL 22 HOUR), DATE_SUB(NOW(), INTERVAL 19 HOUR), DATE_SUB(NOW(), INTERVAL 25 HOUR), DATE_SUB(NOW(), INTERVAL 19 HOUR)),
  (12, 6, 2, 3, 'Avenida das Magnólias, 1500, 8º andar — Vila Olímpia, São Paulo/SP', '04538133', 'padrao', 'até 2 dias', 0.00, 399.90, 399.90, 399.90, 'pix', 'aguardando_entrega', 2, 2, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 18 HOUR), DATE_SUB(NOW(), INTERVAL 17 HOUR), NULL, DATE_SUB(NOW(), INTERVAL 20 HOUR), DATE_SUB(NOW(), INTERVAL 14 HOUR)),
  (13, 6, 1, 1, 'Rua das Flores, 123, Apto 42 — Jardim Bela Vista, São Paulo/SP', '01234567', 'padrao', 'até 2 dias', 12.90, 62.73, 75.63, 75.63, 'cartao', 'aguardando_separacao', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 3 HOUR), DATE_SUB(NOW(), INTERVAL 0 HOUR)),
  (14, 7, 3, 4, 'Rua dos Ipês, 77 — Pinheiros, São Paulo/SP', '05422010', 'padrao', 'até 2 dias', 13.90, 44.60, 58.50, 58.50, 'pix', 'aguardando_separacao', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 2 HOUR), DATE_SUB(NOW(), INTERVAL 0 HOUR)),
  (15, 6, 1, 1, 'Rua das Flores, 123, Apto 42 — Jardim Bela Vista, São Paulo/SP', '01234567', 'padrao', 'até 2 dias', 12.90, 149.60, 162.50, 162.50, 'pix', 'aguardando_separacao', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 1 HOUR), DATE_SUB(NOW(), INTERVAL 0 HOUR));

INSERT INTO itens_pedido (id, pedido_id, produto_id, nome_produto, vendido_por, quantidade, quantidade_separada, preco_unitario, subtotal, status, criado_em) VALUES
  (1, 1, 1, 'Arroz Tipo 1', 'unidade', 1, 1, 24.90, 24.90, 'separado', DATE_SUB(NOW(), INTERVAL 149 HOUR)),
  (2, 1, 2, 'Feijão Carioca', 'unidade', 2, 2, 8.49, 16.98, 'separado', DATE_SUB(NOW(), INTERVAL 149 HOUR)),
  (3, 1, 29, 'Banana Prata', 'peso', 1.00, 1.00, 6.90, 6.90, 'separado', DATE_SUB(NOW(), INTERVAL 149 HOUR)),
  (4, 1, 9, 'Leite Integral', 'unidade', 6, 6, 5.49, 32.94, 'separado', DATE_SUB(NOW(), INTERVAL 149 HOUR)),
  (5, 2, 37, 'Picanha Bovina', 'peso', 1.20, 1.20, 79.90, 95.88, 'separado', DATE_SUB(NOW(), INTERVAL 145 HOUR)),
  (6, 2, 27, 'Cerveja Artesanal', 'unidade', 6, 6, 12.90, 77.40, 'separado', DATE_SUB(NOW(), INTERVAL 145 HOUR)),
  (7, 2, 43, 'Pão Francês', 'peso', 0.50, 0.50, 16.90, 8.45, 'separado', DATE_SUB(NOW(), INTERVAL 145 HOUR)),
  (8, 3, 5, 'Café Torrado e Moído', 'unidade', 2, 2, 16.90, 33.80, 'separado', DATE_SUB(NOW(), INTERVAL 123 HOUR)),
  (9, 3, 46, 'Croissant de Manteiga', 'unidade', 4, 4, 6.50, 26.00, 'separado', DATE_SUB(NOW(), INTERVAL 123 HOUR)),
  (10, 3, 12, 'Iogurte Natural', 'unidade', 4, 4, 3.29, 13.16, 'separado', DATE_SUB(NOW(), INTERVAL 123 HOUR)),
  (11, 4, 49, 'Sabão Líquido para Roupas', 'unidade', 1, 1, 34.90, 34.90, 'separado', DATE_SUB(NOW(), INTERVAL 102 HOUR)),
  (12, 4, 48, 'Detergente Neutro', 'unidade', 3, 3, 2.79, 8.37, 'separado', DATE_SUB(NOW(), INTERVAL 102 HOUR)),
  (13, 4, 57, 'Papel Higiênico Folha Dupla', 'unidade', 1, 1, 19.90, 19.90, 'separado', DATE_SUB(NOW(), INTERVAL 102 HOUR)),
  (14, 5, 64, 'Fone de Ouvido Bluetooth', 'unidade', 1, 1, 159.90, 159.90, 'separado', DATE_SUB(NOW(), INTERVAL 98 HOUR)),
  (15, 5, 65, 'Carregador USB-C 20W', 'unidade', 1, 1, 79.90, 79.90, 'separado', DATE_SUB(NOW(), INTERVAL 98 HOUR)),
  (16, 6, 15, 'Pizza Margherita', 'unidade', 2, 2, 16.90, 33.80, 'separado', DATE_SUB(NOW(), INTERVAL 76 HOUR)),
  (17, 6, 25, 'Refrigerante de Cola', 'unidade', 2, 2, 8.99, 17.98, 'separado', DATE_SUB(NOW(), INTERVAL 76 HOUR)),
  (18, 6, 18, 'Sorvete de Creme', 'unidade', 1, 1, 22.90, 22.90, 'separado', DATE_SUB(NOW(), INTERVAL 76 HOUR)),
  (19, 7, 30, 'Maçã Gala', 'peso', 1.50, 1.50, 9.90, 14.85, 'separado', DATE_SUB(NOW(), INTERVAL 55 HOUR)),
  (20, 7, 31, 'Tomate', 'peso', 1.00, 1.00, 7.49, 7.49, 'separado', DATE_SUB(NOW(), INTERVAL 55 HOUR)),
  (21, 7, 33, 'Alface Crespa', 'unidade', 2, 2, 3.49, 6.98, 'separado', DATE_SUB(NOW(), INTERVAL 55 HOUR)),
  (22, 7, 38, 'Filé de Peito de Frango', 'peso', 1.00, 1.00, 22.90, 22.90, 'separado', DATE_SUB(NOW(), INTERVAL 55 HOUR)),
  (23, 8, 62, 'Perfume Floral', 'unidade', 1, 1, 109.90, 109.90, 'separado', DATE_SUB(NOW(), INTERVAL 50 HOUR)),
  (24, 8, 59, 'Hidratante Corporal', 'unidade', 1, 1, 29.90, 29.90, 'separado', DATE_SUB(NOW(), INTERVAL 50 HOUR)),
  (25, 9, 84, 'Ração para Gatos', 'unidade', 1, NULL, 69.90, 69.90, 'pendente', DATE_SUB(NOW(), INTERVAL 30 HOUR)),
  (26, 9, 86, 'Areia Higiênica', 'unidade', 2, NULL, 24.90, 49.80, 'pendente', DATE_SUB(NOW(), INTERVAL 30 HOUR)),
  (27, 10, 26, 'Vinho Tinto Seco', 'unidade', 2, 2, 42.90, 85.80, 'separado', DATE_SUB(NOW(), INTERVAL 27 HOUR)),
  (28, 10, 11, 'Queijo Muçarela Fatiado', 'unidade', 1, 1, 11.90, 11.90, 'separado', DATE_SUB(NOW(), INTERVAL 27 HOUR)),
  (29, 10, 8, 'Azeite Extravirgem', 'unidade', 1, 1, 28.90, 28.90, 'separado', DATE_SUB(NOW(), INTERVAL 27 HOUR)),
  (30, 11, 87, 'Fralda Tamanho M', 'unidade', 2, 2, 59.90, 119.80, 'separado', DATE_SUB(NOW(), INTERVAL 25 HOUR)),
  (31, 11, 88, 'Lenço Umedecido', 'unidade', 3, 3, 9.90, 29.70, 'separado', DATE_SUB(NOW(), INTERVAL 25 HOUR)),
  (32, 12, 69, 'Air Fryer 4 L', 'unidade', 1, 1, 399.90, 399.90, 'separado', DATE_SUB(NOW(), INTERVAL 20 HOUR)),
  (33, 13, 1, 'Arroz Tipo 1', 'unidade', 1, NULL, 24.90, 24.90, 'pendente', DATE_SUB(NOW(), INTERVAL 3 HOUR)),
  (34, 13, 10, 'Leite Semidesnatado', 'unidade', 2, NULL, 5.29, 10.58, 'pendente', DATE_SUB(NOW(), INTERVAL 3 HOUR)),
  (35, 13, 29, 'Banana Prata', 'peso', 1.50, NULL, 6.90, 10.35, 'pendente', DATE_SUB(NOW(), INTERVAL 3 HOUR)),
  (36, 13, 5, 'Café Torrado e Moído', 'unidade', 1, NULL, 16.90, 16.90, 'pendente', DATE_SUB(NOW(), INTERVAL 3 HOUR)),
  (37, 14, 36, 'Morango', 'unidade', 2, NULL, 5.90, 11.80, 'pendente', DATE_SUB(NOW(), INTERVAL 2 HOUR)),
  (38, 14, 45, 'Bolo de Cenoura', 'unidade', 1, NULL, 18.90, 18.90, 'pendente', DATE_SUB(NOW(), INTERVAL 2 HOUR)),
  (39, 14, 24, 'Suco de Uva Integral', 'unidade', 1, NULL, 13.90, 13.90, 'pendente', DATE_SUB(NOW(), INTERVAL 2 HOUR)),
  (40, 15, 78, 'Vela Aromática Baunilha', 'unidade', 2, NULL, 39.90, 79.80, 'pendente', DATE_SUB(NOW(), INTERVAL 1 HOUR)),
  (41, 15, 80, 'Caneca de Cerâmica', 'unidade', 2, NULL, 34.90, 69.80, 'pendente', DATE_SUB(NOW(), INTERVAL 1 HOUR));

INSERT INTO pagamentos (pedido_id, tipo, metodo, valor, status, codigo_transacao, criado_em, confirmado_em) VALUES
  (1, 'cobranca', 'cartao', 94.62, 'aprovado', 'SIM-DEMO0001', DATE_SUB(NOW(), INTERVAL 149 HOUR), DATE_SUB(NOW(), INTERVAL 149 HOUR)),
  (2, 'cobranca', 'pix', 195.63, 'aprovado', 'SIM-DEMO0002', DATE_SUB(NOW(), INTERVAL 145 HOUR), DATE_SUB(NOW(), INTERVAL 145 HOUR)),
  (3, 'cobranca', 'cartao', 85.86, 'aprovado', 'SIM-DEMO0003', DATE_SUB(NOW(), INTERVAL 123 HOUR), DATE_SUB(NOW(), INTERVAL 123 HOUR)),
  (4, 'cobranca', 'pix', 76.07, 'aprovado', 'SIM-DEMO0004', DATE_SUB(NOW(), INTERVAL 102 HOUR), DATE_SUB(NOW(), INTERVAL 102 HOUR)),
  (5, 'cobranca', 'pix', 239.80, 'aprovado', 'SIM-DEMO0005', DATE_SUB(NOW(), INTERVAL 98 HOUR), DATE_SUB(NOW(), INTERVAL 98 HOUR)),
  (6, 'cobranca', 'cartao', 87.58, 'aprovado', 'SIM-DEMO0006', DATE_SUB(NOW(), INTERVAL 76 HOUR), DATE_SUB(NOW(), INTERVAL 76 HOUR)),
  (7, 'cobranca', 'pix', 66.12, 'aprovado', 'SIM-DEMO0007', DATE_SUB(NOW(), INTERVAL 55 HOUR), DATE_SUB(NOW(), INTERVAL 55 HOUR)),
  (8, 'cobranca', 'cartao', 152.70, 'aprovado', 'SIM-DEMO0008', DATE_SUB(NOW(), INTERVAL 50 HOUR), DATE_SUB(NOW(), INTERVAL 50 HOUR)),
  (9, 'cobranca', 'pix', 133.60, 'aprovado', 'SIM-DEMO0009', DATE_SUB(NOW(), INTERVAL 30 HOUR), DATE_SUB(NOW(), INTERVAL 30 HOUR)),
  (9, 'estorno', 'pix', 133.60, 'aprovado', 'SIM-EST0009', DATE_SUB(NOW(), INTERVAL 29 HOUR), DATE_SUB(NOW(), INTERVAL 29 HOUR)),
  (10, 'cobranca', 'pix', 139.50, 'aprovado', 'SIM-DEMO0010', DATE_SUB(NOW(), INTERVAL 27 HOUR), DATE_SUB(NOW(), INTERVAL 27 HOUR)),
  (11, 'cobranca', 'cartao', 163.40, 'aprovado', 'SIM-DEMO0011', DATE_SUB(NOW(), INTERVAL 25 HOUR), DATE_SUB(NOW(), INTERVAL 25 HOUR)),
  (12, 'cobranca', 'pix', 399.90, 'aprovado', 'SIM-DEMO0012', DATE_SUB(NOW(), INTERVAL 20 HOUR), DATE_SUB(NOW(), INTERVAL 20 HOUR)),
  (13, 'cobranca', 'cartao', 75.63, 'aprovado', 'SIM-DEMO0013', DATE_SUB(NOW(), INTERVAL 3 HOUR), DATE_SUB(NOW(), INTERVAL 3 HOUR)),
  (14, 'cobranca', 'pix', 58.50, 'aprovado', 'SIM-DEMO0014', DATE_SUB(NOW(), INTERVAL 2 HOUR), DATE_SUB(NOW(), INTERVAL 2 HOUR)),
  (15, 'cobranca', 'pix', 162.50, 'aprovado', 'SIM-DEMO0015', DATE_SUB(NOW(), INTERVAL 1 HOUR), DATE_SUB(NOW(), INTERVAL 1 HOUR));

INSERT INTO historico_pedidos (pedido_id, status_anterior, status_novo, usuario_id, perfil, descricao, criado_em) VALUES
  (1, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', DATE_SUB(NOW(), INTERVAL 149 HOUR)),
  (1, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', DATE_SUB(NOW(), INTERVAL 149 HOUR)),
  (1, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', DATE_SUB(NOW(), INTERVAL 147 HOUR)),
  (1, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', DATE_SUB(NOW(), INTERVAL 146 HOUR)),
  (1, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', DATE_SUB(NOW(), INTERVAL 145 HOUR)),
  (1, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: Maria', DATE_SUB(NOW(), INTERVAL 143 HOUR)),
  (2, 'aguardando_pagamento', 'confirmado', 7, 'cliente', 'Pagamento simulado aprovado.', DATE_SUB(NOW(), INTERVAL 145 HOUR)),
  (2, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', DATE_SUB(NOW(), INTERVAL 145 HOUR)),
  (2, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', DATE_SUB(NOW(), INTERVAL 143 HOUR)),
  (2, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', DATE_SUB(NOW(), INTERVAL 142 HOUR)),
  (2, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', DATE_SUB(NOW(), INTERVAL 141 HOUR)),
  (2, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: João', DATE_SUB(NOW(), INTERVAL 139 HOUR)),
  (3, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', DATE_SUB(NOW(), INTERVAL 123 HOUR)),
  (3, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', DATE_SUB(NOW(), INTERVAL 123 HOUR)),
  (3, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', DATE_SUB(NOW(), INTERVAL 121 HOUR)),
  (3, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', DATE_SUB(NOW(), INTERVAL 120 HOUR)),
  (3, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', DATE_SUB(NOW(), INTERVAL 119 HOUR)),
  (3, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: Maria', DATE_SUB(NOW(), INTERVAL 117 HOUR)),
  (4, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', DATE_SUB(NOW(), INTERVAL 102 HOUR)),
  (4, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', DATE_SUB(NOW(), INTERVAL 102 HOUR)),
  (4, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', DATE_SUB(NOW(), INTERVAL 100 HOUR)),
  (4, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', DATE_SUB(NOW(), INTERVAL 99 HOUR)),
  (4, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', DATE_SUB(NOW(), INTERVAL 98 HOUR)),
  (4, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: Maria', DATE_SUB(NOW(), INTERVAL 96 HOUR)),
  (5, 'aguardando_pagamento', 'confirmado', 7, 'cliente', 'Pagamento simulado aprovado.', DATE_SUB(NOW(), INTERVAL 98 HOUR)),
  (5, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', DATE_SUB(NOW(), INTERVAL 98 HOUR)),
  (5, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', DATE_SUB(NOW(), INTERVAL 96 HOUR)),
  (5, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', DATE_SUB(NOW(), INTERVAL 95 HOUR)),
  (5, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', DATE_SUB(NOW(), INTERVAL 94 HOUR)),
  (5, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: João', DATE_SUB(NOW(), INTERVAL 92 HOUR)),
  (6, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', DATE_SUB(NOW(), INTERVAL 76 HOUR)),
  (6, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', DATE_SUB(NOW(), INTERVAL 76 HOUR)),
  (6, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', DATE_SUB(NOW(), INTERVAL 74 HOUR)),
  (6, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', DATE_SUB(NOW(), INTERVAL 73 HOUR)),
  (6, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', DATE_SUB(NOW(), INTERVAL 72 HOUR)),
  (6, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: Maria', DATE_SUB(NOW(), INTERVAL 70 HOUR)),
  (7, 'aguardando_pagamento', 'confirmado', 7, 'cliente', 'Pagamento simulado aprovado.', DATE_SUB(NOW(), INTERVAL 55 HOUR)),
  (7, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', DATE_SUB(NOW(), INTERVAL 55 HOUR)),
  (7, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', DATE_SUB(NOW(), INTERVAL 53 HOUR)),
  (7, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', DATE_SUB(NOW(), INTERVAL 52 HOUR)),
  (7, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', DATE_SUB(NOW(), INTERVAL 51 HOUR)),
  (7, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: João', DATE_SUB(NOW(), INTERVAL 49 HOUR)),
  (8, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', DATE_SUB(NOW(), INTERVAL 50 HOUR)),
  (8, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', DATE_SUB(NOW(), INTERVAL 50 HOUR)),
  (8, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', DATE_SUB(NOW(), INTERVAL 48 HOUR)),
  (8, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', DATE_SUB(NOW(), INTERVAL 47 HOUR)),
  (8, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', DATE_SUB(NOW(), INTERVAL 46 HOUR)),
  (8, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: Maria', DATE_SUB(NOW(), INTERVAL 44 HOUR)),
  (9, 'aguardando_pagamento', 'confirmado', 7, 'cliente', 'Pagamento simulado aprovado.', DATE_SUB(NOW(), INTERVAL 30 HOUR)),
  (9, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', DATE_SUB(NOW(), INTERVAL 30 HOUR)),
  (9, 'aguardando_separacao', 'cancelado', 7, 'cliente', 'Pedido cancelado pelo cliente. Motivo: Desistência da compra', DATE_SUB(NOW(), INTERVAL 29 HOUR)),
  (10, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', DATE_SUB(NOW(), INTERVAL 27 HOUR)),
  (10, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', DATE_SUB(NOW(), INTERVAL 27 HOUR)),
  (10, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', DATE_SUB(NOW(), INTERVAL 25 HOUR)),
  (10, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', DATE_SUB(NOW(), INTERVAL 24 HOUR)),
  (10, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', DATE_SUB(NOW(), INTERVAL 23 HOUR)),
  (10, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: Maria', DATE_SUB(NOW(), INTERVAL 21 HOUR)),
  (11, 'aguardando_pagamento', 'confirmado', 7, 'cliente', 'Pagamento simulado aprovado.', DATE_SUB(NOW(), INTERVAL 25 HOUR)),
  (11, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', DATE_SUB(NOW(), INTERVAL 25 HOUR)),
  (11, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', DATE_SUB(NOW(), INTERVAL 23 HOUR)),
  (11, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', DATE_SUB(NOW(), INTERVAL 22 HOUR)),
  (11, 'aguardando_entrega', 'saiu_para_entrega', 3, 'entregador', 'Pedido retirado pelo entregador.', DATE_SUB(NOW(), INTERVAL 21 HOUR)),
  (11, 'saiu_para_entrega', 'concluido', 3, 'entregador', 'Entrega concluída. Recebido por: João', DATE_SUB(NOW(), INTERVAL 19 HOUR)),
  (12, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', DATE_SUB(NOW(), INTERVAL 20 HOUR)),
  (12, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', DATE_SUB(NOW(), INTERVAL 20 HOUR)),
  (12, 'aguardando_separacao', 'em_separacao', 2, 'separador', 'Separação iniciada.', DATE_SUB(NOW(), INTERVAL 18 HOUR)),
  (12, 'em_separacao', 'aguardando_entrega', 2, 'separador', 'Separação concluída — 2 volume(s) embalados.', DATE_SUB(NOW(), INTERVAL 17 HOUR)),
  (13, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', DATE_SUB(NOW(), INTERVAL 3 HOUR)),
  (13, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', DATE_SUB(NOW(), INTERVAL 3 HOUR)),
  (14, 'aguardando_pagamento', 'confirmado', 7, 'cliente', 'Pagamento simulado aprovado.', DATE_SUB(NOW(), INTERVAL 2 HOUR)),
  (14, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', DATE_SUB(NOW(), INTERVAL 2 HOUR)),
  (15, 'aguardando_pagamento', 'confirmado', 6, 'cliente', 'Pagamento simulado aprovado.', DATE_SUB(NOW(), INTERVAL 1 HOUR)),
  (15, 'confirmado', 'aguardando_separacao', NULL, 'sistema', 'Pedido liberado para separação.', DATE_SUB(NOW(), INTERVAL 1 HOUR));

INSERT INTO entregas (pedido_id, entregador_id, status, tentativas, assumida_em, retirada_em, entregue_em, recebedor, criado_em) VALUES
  (1, 3, 'entregue', 1, DATE_SUB(NOW(), INTERVAL 145 HOUR), DATE_SUB(NOW(), INTERVAL 145 HOUR), DATE_SUB(NOW(), INTERVAL 143 HOUR), 'Maria', DATE_SUB(NOW(), INTERVAL 146 HOUR)),
  (2, 3, 'entregue', 1, DATE_SUB(NOW(), INTERVAL 141 HOUR), DATE_SUB(NOW(), INTERVAL 141 HOUR), DATE_SUB(NOW(), INTERVAL 139 HOUR), 'João', DATE_SUB(NOW(), INTERVAL 142 HOUR)),
  (3, 3, 'entregue', 1, DATE_SUB(NOW(), INTERVAL 119 HOUR), DATE_SUB(NOW(), INTERVAL 119 HOUR), DATE_SUB(NOW(), INTERVAL 117 HOUR), 'Maria', DATE_SUB(NOW(), INTERVAL 120 HOUR)),
  (4, 3, 'entregue', 1, DATE_SUB(NOW(), INTERVAL 98 HOUR), DATE_SUB(NOW(), INTERVAL 98 HOUR), DATE_SUB(NOW(), INTERVAL 96 HOUR), 'Maria', DATE_SUB(NOW(), INTERVAL 99 HOUR)),
  (5, 3, 'entregue', 1, DATE_SUB(NOW(), INTERVAL 94 HOUR), DATE_SUB(NOW(), INTERVAL 94 HOUR), DATE_SUB(NOW(), INTERVAL 92 HOUR), 'João', DATE_SUB(NOW(), INTERVAL 95 HOUR)),
  (6, 3, 'entregue', 1, DATE_SUB(NOW(), INTERVAL 72 HOUR), DATE_SUB(NOW(), INTERVAL 72 HOUR), DATE_SUB(NOW(), INTERVAL 70 HOUR), 'Maria', DATE_SUB(NOW(), INTERVAL 73 HOUR)),
  (7, 3, 'entregue', 1, DATE_SUB(NOW(), INTERVAL 51 HOUR), DATE_SUB(NOW(), INTERVAL 51 HOUR), DATE_SUB(NOW(), INTERVAL 49 HOUR), 'João', DATE_SUB(NOW(), INTERVAL 52 HOUR)),
  (8, 3, 'entregue', 1, DATE_SUB(NOW(), INTERVAL 46 HOUR), DATE_SUB(NOW(), INTERVAL 46 HOUR), DATE_SUB(NOW(), INTERVAL 44 HOUR), 'Maria', DATE_SUB(NOW(), INTERVAL 47 HOUR)),
  (10, 3, 'entregue', 1, DATE_SUB(NOW(), INTERVAL 23 HOUR), DATE_SUB(NOW(), INTERVAL 23 HOUR), DATE_SUB(NOW(), INTERVAL 21 HOUR), 'Maria', DATE_SUB(NOW(), INTERVAL 24 HOUR)),
  (11, 3, 'entregue', 1, DATE_SUB(NOW(), INTERVAL 21 HOUR), DATE_SUB(NOW(), INTERVAL 21 HOUR), DATE_SUB(NOW(), INTERVAL 19 HOUR), 'João', DATE_SUB(NOW(), INTERVAL 22 HOUR)),
  (12, NULL, 'disponivel', 0, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 17 HOUR));

INSERT INTO ocorrencias (pedido_id, entrega_id, usuario_id, tipo, gravidade, descricao, status, resolucao, resolvido_por, criado_em, resolvido_em) VALUES
  (7, 7, 3, 'cliente_ausente', 'baixa', 'Cliente ausente na primeira tentativa; porteiro orientou retorno em 20 minutos.', 'resolvida', 'Entrega realizada na segunda passagem.', 1, DATE_SUB(NOW(), INTERVAL 51 HOUR), DATE_SUB(NOW(), INTERVAL 49 HOUR)),
  (NULL, NULL, 1, 'estoque', 'media', 'Leite Semidesnatado zerado no estoque; reposição solicitada ao fornecedor.', 'aberta', NULL, NULL, DATE_SUB(NOW(), INTERVAL 10 HOUR), NULL);

INSERT INTO avaliacoes (produto_id, usuario_id, nota, comentario, criado_em) VALUES
  (1, 6, 5, 'Grão soltinho, ótimo custo-benefício.', DATE_SUB(NOW(), INTERVAL 120 HOUR)),
  (5, 6, 4, 'Aroma excelente. Chegou bem embalado.', DATE_SUB(NOW(), INTERVAL 96 HOUR)),
  (37, 7, 5, 'Corte perfeito, peso bem conferido.', DATE_SUB(NOW(), INTERVAL 120 HOUR));

INSERT INTO logs_alteracoes (usuario_id, entidade, entidade_id, acao, detalhes, criado_em) VALUES
  (1, 'sistema', NULL, 'instalacao', 'Banco de dados criado com dados de demonstração.', NOW());
