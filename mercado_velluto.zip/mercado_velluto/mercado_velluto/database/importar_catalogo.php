<?php
/** Importa somente os produtos do catálogo de demonstração, sem criar pedidos ou áreas. */
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require __DIR__ . '/../config/config.php';
require __DIR__ . '/../config/conexao.php';
date_default_timezone_set(APP_TIMEZONE);

$arquivoCatalogo = file_get_contents(__DIR__ . '/ampliar_demo.php');
if (!preg_match('/\$catalogo\s*=\s*\[(.*?)\n\];/s', $arquivoCatalogo, $trecho)) {
    throw new RuntimeException('Não foi possível localizar os produtos do catálogo.');
}

$catalogo = [];
foreach (explode("\n", $trecho[1]) as $linha) {
    if (!preg_match('/^\s*\[/', $linha)) {
        continue;
    }
    $produto = eval('return ' . rtrim(trim($linha), ',') . ';');
    if (is_array($produto) && count($produto) === 7) {
        $catalogo[] = $produto;
    }
}

if (!$catalogo) {
    throw new RuntimeException('O catálogo está vazio ou em formato inválido.');
}

$pdo = db();
$pdo->beginTransaction();
try {
    $categoriaId = $pdo->prepare('SELECT id FROM categorias WHERE slug = ? AND ativo = 1 LIMIT 1');
    $produtoId = $pdo->prepare('SELECT id FROM produtos WHERE slug = ? LIMIT 1');
    $inserir = $pdo->prepare("INSERT INTO produtos
        (categoria_id, slug, nome, marca, embalagem, vendido_por, preco, estoque, imagem, descricao, criado_em)
        VALUES (?, ?, ?, 'Velluto Seleção', ?, ?, ?, 96, ?, ?, ?)");

    $novos = 0;
    foreach ($catalogo as [$slug, $nome, $categoria, $embalagem, $vendidoPor, $preco, $descricao]) {
        $imagem = "assets/img/produtos/$slug.jpg";
        if (!preg_match('/^[a-z0-9-]+$/', $slug) || !is_file(dirname(__DIR__) . '/' . $imagem)) {
            throw new RuntimeException("Produto ou imagem inválida: $slug");
        }

        $produtoId->execute([$slug]);
        if ($produtoId->fetchColumn()) {
            continue;
        }

        $categoriaId->execute([$categoria]);
        $idCategoria = $categoriaId->fetchColumn();
        if (!$idCategoria) {
            throw new RuntimeException("Categoria não encontrada: $categoria");
        }

        $inserir->execute([$idCategoria, $slug, $nome, $embalagem, $vendidoPor, $preco, $imagem, $descricao, date('Y-m-d H:i:s')]);
        $novos++;
    }

    $pdo->commit();
    printf("Produtos adicionados: %d. Produtos existentes preservados: %d.\n", $novos, count($catalogo) - $novos);
} catch (Throwable $erro) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    throw $erro;
}
