# VELLUTO — Hipermercado Online (projeto acadêmico)

Sistema web completo de hipermercado fictício, em **HTML5, CSS3, JavaScript, PHP e MySQL**, para rodar localmente no **XAMPP**.
Inclui área do cliente, painel administrativo, painel do separador, painel do entregador, fluxo completo de pedidos
(com peso real, substituições e aprovação do cliente), pagamento **simulado**.

> Todos os dados são fictícios. Nenhuma transação financeira real é feita.

---

## Requisitos

- XAMPP com **PHP 8.1 ou superior** (recomendado: XAMPP 8.2) e MariaDB/MySQL.
- Navegador atualizado (Chrome, Edge, Firefox).

---

## 1. Instalar e iniciar o XAMPP

1. Baixe o XAMPP em <https://www.apachefriends.org> e instale (no Windows, o padrão é `C:\xampp`).
2. Abra o **XAMPP Control Panel**.

## 2. Iniciar Apache e MySQL

No XAMPP Control Panel, clique em **Start** nas linhas **Apache** e **MySQL**. As duas devem ficar verdes.

## 3. Colocar a pasta do projeto no diretório correto

Copie a pasta `mercado_velluto` inteira para dentro de `htdocs`:

```
C:\xampp\htdocs\mercado_velluto\        (Windows)
/Applications/XAMPP/htdocs/mercado_velluto/   (macOS)
/opt/lampp/htdocs/mercado_velluto/      (Linux)
```

O arquivo `index.php` deve ficar em `htdocs\mercado_velluto\index.php`.

## 4. Acessar o phpMyAdmin

Abra no navegador: <http://localhost/phpmyadmin>

## 5. Criar/importar o banco `velluto`

1. No phpMyAdmin, clique na aba **Importar** (sem selecionar nenhum banco).
2. Em **Arquivo**, escolha `velluto/database/velluto.sql`.
3. Clique em **Importar** (botão no fim da página).

O script cria o banco `velluto` (InnoDB, `utf8mb4`), as 18 tabelas, os relacionamentos, índices e os dados fictícios
(90 produtos, 18 categorias, 4 áreas de entrega, 15 pedidos de demonstração nos últimos 7 dias, clientes e funcionários).

> Atenção: o script começa com `DROP DATABASE IF EXISTS velluto` — reimportar apaga os dados anteriores.

## 6. Configurar a conexão PHP

Edite `config/config.php` se o seu MySQL não usa o padrão do XAMPP:

```php
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'velluto');
define('DB_USER', 'root');
define('DB_PASS', '');        // XAMPP vem com senha vazia
```

O caminho do site (`/velluto`) é detectado automaticamente. Se você renomear a pasta e algo não funcionar,
preencha `BASE_URL_MANUAL` (ex.: `'/minhaloja'`).

## 7. Configurar as senhas iniciais dos perfis internos

As contas internas são criadas **sem senha** no banco (nenhuma senha administrativa fica exposta no código):

| Perfil | E-mail |
|---|---|
| Administrador | `admin@velluto.com` |
| Separador | `separador@velluto.com` |
| Entregador | `entregador@velluto.com` |
| Separador (2º, para testes de concorrência) | `separador2@velluto.com` |
| Entregador (2º, para testes de permissão) | `entregador2@velluto.com` |

Para definir as senhas, abra **no mesmo computador do XAMPP**:

<http://localhost/mercado_velluto/interno/instalar.php>

- Informe as senhas (mínimo de 8 caracteres, com letras e números) e salve.
- As senhas são gravadas com `password_hash()` e conferidas com `password_verify()`.
- A página só aceita acessos de `localhost` e **se desativa sozinha** quando todas as contas têm senha.
- Depois disso, o administrador redefine senhas em **Painel → Funcionários**.

Alternativa manual (Shell do XAMPP):

```bash
php -r "echo password_hash('MinhaSenha123', PASSWORD_DEFAULT);"
```

e no phpMyAdmin: `UPDATE usuarios SET senha_hash = '<hash gerado>' WHERE email = 'admin@velluto.com';`

**Clientes de demonstração** (já com senha): `cliente@velluto.com` e `joao@velluto.com` — senha `Cliente@123`.

## 8. Endereço para abrir o sistema

<http://localhost/mercado_velluto/>

## 9. Acessar cada painel interno

1. Em qualquer página da loja, pressione **Ctrl + A** (fora de campos de texto).
   - Dentro de campos (busca, formulários, áreas de texto) o Ctrl + A continua selecionando o texto normalmente.
2. Escolha o perfil: **Administrador**, **Separador** ou **Entregador**.
3. Faça login com a conta do perfil. O PHP confere no servidor se a conta tem exatamente aquele perfil.

Acesso direto (sem atalho): <http://localhost/mercado_velluto/interno/>

Cada painel bloqueia os demais perfis (resposta 403 “Acesso negado”), e a tentativa é registrada no histórico.

## 10. Testar o fluxo completo de compra e entrega

1. **Cliente** — entre com `cliente@velluto.com` (ou crie uma conta), adicione produtos ao carrinho
   (inclua um item vendido por peso, ex.: Banana Prata).
2. **Endereço e frete** — use um CEP atendido (ex.: `01234-567`). Teste também um CEP fora da área
   (ex.: `20040-020`): o pedido é bloqueado.
3. **Pagamento simulado** — PIX (aprovado na hora), cartão de teste `4111 1111 1111 1111` (validade futura, CVV 123)
   ou boleto (use “Simular pagamento do boleto” na tela do pedido). O cartão `4000 0000 0000 0002` simula recusa.
4. **Separador** — Ctrl + A → Separador → **Separar** um pedido da fila. Informe quantidades e **pesos reais**.
   Marque um item como **Indisponível** e **sugira um substituto** (o pedido de demonstração #13 contém
   “Leite Semidesnatado”, que está sem estoque — ótimo para testar).
5. **Cliente** — em *Meus pedidos*, **aceite ou recuse** a substituição. Se aceitar um item mais caro,
   a diferença é cobrada (simulação); itens removidos são estornados ao final.
6. **Separador** — finalize informando os volumes. Se o total subir mais que a tolerância (10% por padrão, por peso),
   o cliente precisa **aprovar o novo valor** (ou cancelar).
7. **Entregador** — assuma a entrega, **confirme a retirada** (status “Saiu para entrega”), registre uma
   **ocorrência** (opcional: devolver à loja) e **confirme a entrega** com o nome do recebedor.
8. **Administrador** — acompanhe tudo no **Dashboard**, em **Pedidos → Detalhes** (histórico completo),
   **Ocorrências**, **Relatórios** e **Histórico de alterações**.

---

## Funcionalidades

**Área do cliente:** página inicial, cadastro, login (visível no topo), recuperação de senha, catálogo com categorias e
subcategorias, pesquisa, filtros (categoria, preço, marca, disponibilidade, ofertas), ordenação, detalhes do produto,
favoritos, avaliações, carrinho (alterar/remover), endereços (cadastro, seleção, principal), verificação da área de entrega,
frete padrão/expresso/grátis, revisão, pagamento simulado, confirmação, histórico e acompanhamento do pedido,
aprovação/recusa de substituições e de ajuste de valor, cancelamento com motivo.

**Administrador:** dashboard com dados reais (pedidos, vendas, produtos, clientes, estoque baixo, em andamento e gráfico
dos últimos 7 dias); produtos (cadastrar, editar, visualizar, excluir/arquivar, preço, promoção, imagem); categorias;
estoque (entradas, saídas, inventário, movimentações); pedidos (filtros, detalhe, confirmar pagamento, cancelar, ocorrências);
clientes (consulta e bloqueio); funcionários (cadastro, perfil, senha, ativação); áreas de entrega e frete; relatórios
(por período, categoria, produtos, pagamento, cancelamentos, substituições, ocorrências, exportação CSV);
histórico de alterações e de status; ocorrências (resolver); configurações gerais.

**Separador:** fila priorizada (expressos primeiro), assumir pedido (sem conflito entre separadores), conferência de
quantidades e pesos reais, indisponibilidade, sugestão de substitutos, remoção de item, bloqueio de finalização sem
resposta do cliente, finalização com volumes, histórico com tempo médio.

**Entregador:** entregas disponíveis, assumir, dados do pedido e endereço (link para mapa), confirmar retirada,
entrega em andamento, ocorrências (com devolução à loja), concluir entrega, histórico. Só o entregador responsável
altera ou conclui a entrega.

## Regras de negócio implementadas

- Estoque nunca negativo: baixa por `UPDATE ... WHERE estoque + ? >= 0` dentro de transação (+ `CHECK` no banco).
- Duas compras não vendem a mesma última unidade (atualização condicional atômica + bloqueio de linha `FOR UPDATE`).
- Transações em todas as operações críticas (compra, separação, substituição, cancelamento, entrega).
- Toda movimentação de estoque é registrada (`movimentacoes_estoque`).
- Peso real dos itens por kg recalcula o valor; total recalculado a cada alteração.
- Substituição sempre exige resposta do cliente; diferença positiva só é cobrada após aceite.
- Aumento acima da tolerância configurável exige aprovação do cliente (ou cancelamento).
- Pedidos fora da área de entrega são bloqueados no servidor.
- Status, ocorrências, cancelamentos e motivos ficam registrados.
- Cada cliente vê e altera apenas os próprios pedidos; cada funcionário só acessa o seu painel.

Estados do pedido: aguardando pagamento → confirmado → aguardando separação → em separação →
(aguardando aprovação do cliente) → aguardando entrega → saiu para entrega → concluído | cancelado.

## Segurança

- Senhas com `password_hash()` / `password_verify()` (rehash automático).
- Sessões PHP com cookie `HttpOnly` e `SameSite=Lax`; `session_regenerate_id()` no login; logout destrói a sessão.
- PDO com consultas preparadas em 100% das consultas (proteção contra SQL Injection).
- Token **CSRF** verificado automaticamente em todo envio POST.
- Saída sempre escapada (`htmlspecialchars`) contra XSS.
- Autorização por perfil verificada no PHP em cada página e ação; verificação de propriedade dos pedidos.
- Limite de tentativas de login por sessão; recuperação de senha com token aleatório (armazenado como hash SHA-256,
  validade de 30 min, uso único). Sem servidor de e-mail no XAMPP, o “e-mail” é exibido na tela apenas para acessos de `localhost`.
- Uploads validados pelo conteúdo real da imagem, tamanho máximo de 2 MB e nome aleatório; `.htaccess` impede execução de scripts em `uploads/`.
- Pastas `config/`, `includes/` e `database/` bloqueadas para acesso direto via `.htaccess`.
- Cartão: apenas os 4 últimos dígitos são armazenados.

## Estrutura de pastas

```
mercado_velluto/
├── index.php, catalogo.php, produto.php, ajuda.php
├── config/        config.php (dados do MySQL) · conexao.php (PDO reutilizável)
├── database/      velluto.sql (importar no phpMyAdmin)
├── includes/      bootstrap, funções, autenticação, regras de pedidos, cabeçalhos/rodapés, gráficos
├── cliente/       login, cadastro, recuperação, conta, endereços, carrinho, checkout, pagamento, pedidos
├── acoes/         processamento de formulários (carrinho, compra, pedido do cliente, separador, entregador…)
├── interno/       seleção de perfil (Ctrl+A), login interno, instalação de senhas
│   ├── administrador/   dashboard e gestão completa
│   ├── separador/       fila, separação, histórico
│   └── entregador/      entregas, ocorrências, histórico
├── assets/        css/ · js/ (atalho Ctrl+A e interações) · img/ (logo e imagens dos produtos) · icons/
├── uploads/       imagens enviadas pelo administrador
└── README.md
```

## Banco de dados (tabelas)

`usuarios`, `enderecos`, `categorias`, `produtos`, `areas_entrega`, `pedidos`, `itens_pedido`, `substituicoes`, `entregas`,
`ocorrencias`, `pagamentos`, `historico_pedidos`, `movimentacoes_estoque`, `recuperacao_senhas` + complementares
`favoritos`, `avaliacoes`, `configuracoes`, `logs_alteracoes`.

## Produtos e filas adicionais

Após a importação inicial, execute `php database/ampliar_demo.php` na pasta do projeto para adicionar 66 produtos, 8 pedidos para separação e 8 entregas disponíveis. O comando também atualiza a estrutura do carrossel e adiciona a faixa da Zona Leste a bancos anteriores. É possível repeti-lo preservando os registros existentes.

No painel administrativo, **Carrossel** controla as imagens, os textos, os links, a ordem e a visibilidade dos banners, além da reprodução automática e do efeito de transição.

A campanha exibida na loja muda automaticamente pelo calendário local. Os produtos e descontos de cada campanha são definidos em `includes/temporadas.php`.

## Solução de problemas

| Problema | Solução |
|---|---|
| “Não foi possível conectar ao banco” | Inicie o MySQL no XAMPP, importe `database/velluto.sql` e confira `config/config.php`. |
| Página de login interna recusa a senha | Defina as senhas em `interno/instalar.php` (passo 7). |
| CSS/links quebrados após renomear a pasta | Preencha `BASE_URL_MANUAL` em `config/config.php`. |
| “Sessão expirada ou formulário inválido” | O formulário ficou aberto após logout/login; recarregue a página. |
| Ícones de produtos aparecem como quadrados | As imagens usam emojis; use um navegador atualizado (Chrome/Edge). |
| Upload de imagem falha | Verifique permissão de escrita na pasta `uploads/produtos/`. |
| Busca automática de CEP não preenche | Usa o serviço ViaCEP e exige internet; sem internet, preencha manualmente. |
