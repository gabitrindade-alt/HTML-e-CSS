<?php
/**
 * Ações do entregador: assumir, liberar, confirmar retirada, concluir entrega, registrar ocorrência.
 * Somente o entregador responsável pode atualizar ou concluir a entrega.
 */
require __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirecionar('interno/entregador/index.php');
}
$eu = exigirPerfil('entregador');
$acao = post('acao');
$entregaId = (int) post('entrega_id');
$destino = 'interno/entregador/entrega.php?id=' . $entregaId;

/** Carrega a entrega com bloqueio e confere o responsável. */
function minhaEntrega(int $entregaId, int $entregadorId, array $estados): array
{
    $st = db()->prepare('SELECT * FROM entregas WHERE id = ?' . lockSql());
    $st->execute([$entregaId]);
    $e = $st->fetch();
    if (!$e) {
        throw new RegraNegocioException('Entrega não encontrada.');
    }
    if ((int) $e['entregador_id'] !== $entregadorId) {
        throw new RegraNegocioException('Esta entrega está atribuída a outro entregador. Somente o responsável pode atualizá-la.');
    }
    if (!in_array($e['status'], $estados, true)) {
        throw new RegraNegocioException('A entrega está "' . STATUS_ENTREGA[$e['status']] . '" e não permite esta ação.');
    }
    return $e;
}

try {
    switch ($acao) {
        case 'assumir':
            transacao(function () use ($entregaId, $eu) {
                $st = db()->prepare("UPDATE entregas SET entregador_id = ?, status = 'atribuida', assumida_em = ?
                                     WHERE id = ? AND status = 'disponivel' AND entregador_id IS NULL");
                $st->execute([$eu['id'], agora(), $entregaId]);
                if ($st->rowCount() !== 1) {
                    throw new RegraNegocioException('Esta entrega já foi assumida por outro entregador.');
                }
                $st = db()->prepare('SELECT pedido_id FROM entregas WHERE id = ?');
                $st->execute([$entregaId]);
                $pid = (int) $st->fetchColumn();
                registrarHistorico($pid, 'aguardando_entrega', 'aguardando_entrega', 'Entrega assumida por ' . $eu['nome'] . '.');
            });
            flash('sucesso', 'Entrega assumida. Retire o pedido na expedição.');
            break;

        case 'liberar':
            transacao(function () use ($entregaId, $eu) {
                $e = minhaEntrega($entregaId, (int) $eu['id'], ['atribuida']);
                db()->prepare("UPDATE entregas SET entregador_id = NULL, status = 'disponivel', assumida_em = NULL WHERE id = ?")->execute([$entregaId]);
                registrarHistorico((int) $e['pedido_id'], 'aguardando_entrega', 'aguardando_entrega', 'Entrega liberada por ' . $eu['nome'] . ' antes da retirada.');
            });
            flash('info', 'Entrega devolvida para a lista de disponíveis.');
            $destino = 'interno/entregador/index.php';
            break;

        case 'retirar':
            transacao(function () use ($entregaId, $eu) {
                $e = minhaEntrega($entregaId, (int) $eu['id'], ['atribuida']);
                db()->prepare("UPDATE entregas SET status = 'em_rota', retirada_em = ? WHERE id = ?")->execute([agora(), $entregaId]);
                alterarStatus((int) $e['pedido_id'], 'saiu_para_entrega', 'Pedido retirado por ' . $eu['nome'] . ' — entrega em andamento.');
            });
            flash('sucesso', 'Retirada confirmada. Status: saiu para entrega.');
            break;

        case 'concluir':
            $recebedor = mb_substr(post('recebedor'), 0, 120);
            if (mb_strlen($recebedor) < 2) {
                throw new RegraNegocioException('Informe o nome de quem recebeu o pedido.');
            }
            transacao(function () use ($entregaId, $eu, $recebedor) {
                $e = minhaEntrega($entregaId, (int) $eu['id'], ['em_rota']);
                db()->prepare("UPDATE entregas SET status = 'entregue', entregue_em = ?, recebedor = ?, tentativas = tentativas + 1, observacao = ? WHERE id = ?")
                    ->execute([agora(), $recebedor, mb_substr(post('observacao'), 0, 255) ?: null, $entregaId]);
                alterarStatus((int) $e['pedido_id'], 'concluido', 'Entrega concluída por ' . $eu['nome'] . '. Recebido por: ' . $recebedor . '.', ['concluido_em' => agora()]);
            });
            flash('sucesso', 'Entrega concluída! Pedido finalizado.');
            $destino = 'interno/entregador/minhas.php';
            break;

        case 'ocorrencia':
            $tipos = ['cliente_ausente', 'endereco_nao_localizado', 'recusa_recebimento', 'avaria', 'atraso', 'veiculo', 'outro'];
            $tipo = in_array(post('tipo'), $tipos, true) ? post('tipo') : 'outro';
            $grav = in_array(post('gravidade'), ['baixa', 'media', 'alta'], true) ? post('gravidade') : 'media';
            $desc = mb_substr(post('descricao'), 0, 1000);
            $devolver = (bool) post('devolver');
            if (mb_strlen($desc) < 5) {
                throw new RegraNegocioException('Descreva a ocorrência.');
            }
            transacao(function () use ($entregaId, $eu, $tipo, $grav, $desc, $devolver) {
                $e = minhaEntrega($entregaId, (int) $eu['id'], ['atribuida', 'em_rota']);
                $pid = (int) $e['pedido_id'];
                $oid = registrarOcorrencia($pid, $entregaId, $tipo, $grav, $desc);
                if ($devolver) {
                    // Tentativa frustrada: pedido volta à expedição e fica disponível para nova entrega.
                    db()->prepare("UPDATE entregas SET status = 'disponivel', entregador_id = NULL, assumida_em = NULL, retirada_em = NULL, tentativas = tentativas + 1 WHERE id = ?")
                        ->execute([$entregaId]);
                    if ($e['status'] === 'em_rota') {
                        alterarStatus($pid, 'aguardando_entrega', 'Tentativa de entrega sem sucesso (ocorrência #' . $oid . ': ' . $tipo . '). Pedido retornou à loja para nova entrega.');
                    } else {
                        registrarHistorico($pid, 'aguardando_entrega', 'aguardando_entrega', 'Ocorrência #' . $oid . ' registrada; entrega liberada.');
                    }
                } else {
                    $p = buscarPedido($pid);
                    registrarHistorico($pid, $p['status'], $p['status'], 'Ocorrência #' . $oid . ' registrada pelo entregador (' . $tipo . ').');
                }
            });
            flash('sucesso', 'Ocorrência registrada' . ($devolver ? ' e pedido devolvido à loja.' : '.'));
            if ($devolver) {
                $destino = 'interno/entregador/minhas.php';
            }
            break;

        default:
            throw new RegraNegocioException('Ação inválida.');
    }
} catch (RegraNegocioException $e) {
    flash('erro', $e->getMessage());
    if ($acao === 'assumir') {
        $destino = 'interno/entregador/index.php';
    }
}
redirecionar($destino);
