<?php
/** Registra a avaliação de um produto já recebido pelo cliente. */
require __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirecionar('index.php');
}
$u = exigirCliente();
$id = (int) post('produto_id');
$nota = (int) post('nota');
$comentario = mb_substr(post('comentario'), 0, 500);

if ($nota < 1 || $nota > 5) {
    flash('erro', 'Escolha uma nota de 1 a 5.');
    redirecionar('produto.php?id=' . $id);
}
$st = db()->prepare("SELECT COUNT(*) FROM itens_pedido i JOIN pedidos pe ON pe.id = i.pedido_id
                     WHERE pe.usuario_id = ? AND pe.status = 'concluido' AND i.produto_id = ? AND i.status = 'separado'");
$st->execute([$u['id'], $id]);
if (!(int) $st->fetchColumn()) {
    flash('erro', 'Somente clientes que receberam o produto podem avaliá-lo.');
    redirecionar('produto.php?id=' . $id);
}
try {
    db()->prepare('INSERT INTO avaliacoes (produto_id, usuario_id, nota, comentario, criado_em) VALUES (?, ?, ?, ?, ?)')
        ->execute([$id, $u['id'], $nota, $comentario, agora()]);
    flash('sucesso', 'Obrigado pela sua avaliação!');
} catch (PDOException $e) {
    flash('aviso', 'Você já avaliou este produto.');
}
redirecionar('produto.php?id=' . $id);
