<?php
/**
 * Finaliza a compra: valida endereço/área/frete, confere estoque com bloqueio,
 * baixa o estoque, registra pedido, itens, pagamento simulado e histórico.
 * Tudo em uma única transação.
 */
require __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirecionar('cliente/carrinho.php');
}
$u = exigirCliente();
$ck = $_SESSION['checkout'] ?? null;
$carrinho = carrinho();
if (!$carrinho || !$ck) {
    flash('erro', 'Sessão de compra expirada. Revise o carrinho.');
    redirecionar('cliente/carrinho.php');
}

/* ---------- Endereço e área de entrega ---------- */
$st = db()->prepare('SELECT * FROM enderecos WHERE id = ? AND usuario_id = ? AND ativo = 1');
$st->execute([(int) $ck['endereco_id'], $u['id']]);
$end = $st->fetch();
$area = $end ? areaPorCep($end['cep']) : null;
if (!$end || !$area) {
    flash('erro', 'Endereço fora da área de entrega. O pedido não pode ser finalizado.');
    redirecionar('cliente/checkout.php');
}

/* ---------- Pagamento (simulado) ---------- */
$metodo = post('metodo');
if (!isset(METODOS_PAGAMENTO[$metodo])) {
    flash('erro', 'Escolha uma forma de pagamento.');
    redirecionar('cliente/pagamento.php');
}
$cartaoFinal = null;
$parcelas = null;
$recusado = false;
if ($metodo === 'cartao') {
    $num = apenasDigitos(post('cartao_numero'));
    $nome = post('cartao_nome');
    $val = post('cartao_validade');
    $cvv = apenasDigitos(post('cartao_cvv'));
    $parcelas = max(1, min(6, (int) post('parcelas', 1)));
    $erro = '';
    if (!validarLuhn($num)) {
        $erro = 'Número de cartão inválido. Use o cartão de teste 4111 1111 1111 1111.';
    } elseif (mb_strlen($nome) < 3) {
        $erro = 'Informe o nome impresso no cartão.';
    } elseif (!preg_match('#^(0[1-9]|1[0-2])/(\d{2})$#', $val, $m) || mktime(0, 0, 0, (int) $m[1] + 1, 1, 2000 + (int) $m[2]) <= time()) {
        $erro = 'Validade do cartão inválida ou vencida.';
    } elseif (strlen($cvv) < 3 || strlen($cvv) > 4) {
        $erro = 'CVV inválido.';
    }
    if ($erro) {
        flash('erro', $erro);
        redirecionar('cliente/pagamento.php');
    }
    $cartaoFinal = substr($num, -4);
    $recusado = $num === '4000000000000002'; // cartão de teste que simula recusa
}
if ($recusado) {
    flash('erro', 'Pagamento recusado pela operadora (simulação). Nenhum pedido foi criado; tente outro cartão ou PIX.');
    redirecionar('cliente/pagamento.php');
}

$observacoes = mb_substr(post('observacoes'), 0, 500);

try {
    $pedidoId = transacao(function () use ($u, $end, $area, $ck, $carrinho, $metodo, $cartaoFinal, $parcelas, $observacoes) {
        // 1) Confere produtos com bloqueio de linha e calcula valores no servidor.
        $itens = [];
        $subtotal = 0.0;
        foreach ($carrinho as $pid => $qtd) {
            $st = db()->prepare('SELECT * FROM produtos WHERE id = ?' . lockSql());
            $st->execute([(int) $pid]);
            $p = $st->fetch();
            if (!$p || !(int) $p['ativo']) {
                throw new RegraNegocioException('Um dos produtos não está mais disponível. Revise o carrinho.');
            }
            $qtd = normalizarQtd($p, $qtd);
            if ($qtd <= 0) {
                continue;
            }
            if ($qtd > (float) $p['estoque']) {
                throw new RegraNegocioException('Estoque insuficiente para "' . $p['nome'] . '" (disponível: ' . qtdFormatada($p['estoque'], $p['vendido_por']) . ').');
            }
            $preco = precoAtual($p);
            $sub = round($preco * $qtd, 2);
            $subtotal += $sub;
            $itens[] = [$p, $qtd, $preco, $sub];
        }
        if (!$itens) {
            throw new RegraNegocioException('Carrinho vazio.');
        }
        $subtotal = round($subtotal, 2);
        if ($subtotal < (float) config('valor_minimo_pedido', 0)) {
            throw new RegraNegocioException('Valor mínimo do pedido não atingido.');
        }
        $fretes = opcoesFrete($area, $subtotal);
        $frete = $fretes[$ck['tipo_frete']] ?? $fretes['padrao'];
        $tipoFrete = isset($fretes[$ck['tipo_frete']]) ? $ck['tipo_frete'] : 'padrao';
        $total = round($subtotal + $frete['valor'], 2);

        $exibido = round(paraNumero(post('total_exibido')), 2);
        if (abs($exibido - $total) >= 0.01) {
            throw new RegraNegocioException('Os valores foram atualizados (' . dinheiro($total) . '). Revise o pedido e confirme novamente.');
        }

        // 2) Registra o pedido.
        $txtEnd = $end['logradouro'] . ', ' . $end['numero'] . ($end['complemento'] ? ', ' . $end['complemento'] : '') .
            ' — ' . $end['bairro'] . ', ' . $end['cidade'] . '/' . $end['uf'] . ' · Destinatário: ' . $end['destinatario'] .
            ($end['referencia'] ? ' · Ref.: ' . $end['referencia'] : '');
        $st = db()->prepare("INSERT INTO pedidos (usuario_id, endereco_id, area_entrega_id, endereco_entrega, cep_entrega, tipo_frete, prazo_entrega,
                             valor_frete, subtotal, total, total_pago, metodo_pagamento, status, observacoes, criado_em, atualizado_em)
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, 'aguardando_pagamento', ?, ?, ?)");
        $st->execute([$u['id'], $end['id'], $area['id'], $txtEnd, $end['cep'], $tipoFrete, $frete['prazo'],
            numSql($frete['valor'], 2), numSql($subtotal, 2), numSql($total, 2), $metodo, $observacoes ?: null, agora(), agora()]);
        $pedidoId = (int) db()->lastInsertId();
        registrarHistorico($pedidoId, null, 'aguardando_pagamento', 'Pedido criado pelo cliente (' . count($itens) . ' itens, ' . dinheiro($total) . ').');

        // 3) Itens + baixa de estoque atômica (impede estoque negativo e venda simultânea da última unidade).
        $insItem = db()->prepare("INSERT INTO itens_pedido (pedido_id, produto_id, nome_produto, vendido_por, quantidade, preco_unitario, subtotal, status, criado_em)
                                  VALUES (?, ?, ?, ?, ?, ?, ?, 'pendente', ?)");
        foreach ($itens as [$p, $qtd, $preco, $sub]) {
            movimentarEstoque((int) $p['id'], -$qtd, 'venda', $pedidoId, 'Venda — pedido #' . $pedidoId);
            $insItem->execute([$pedidoId, $p['id'], $p['nome'], $p['vendido_por'], numSql($qtd), numSql($preco, 2), numSql($sub, 2), agora()]);
        }

        // 4) Pagamento simulado.
        $codigo = 'SIM-' . strtoupper(bin2hex(random_bytes(6)));
        if ($metodo === 'boleto') {
            db()->prepare("INSERT INTO pagamentos (pedido_id, tipo, metodo, valor, status, codigo_transacao, observacao, criado_em)
                           VALUES (?, 'cobranca', 'boleto', ?, 'pendente', ?, 'Boleto emitido (simulado)', ?)")
                ->execute([$pedidoId, numSql($total, 2), $codigo, agora()]);
            registrarHistorico($pedidoId, 'aguardando_pagamento', 'aguardando_pagamento', 'Boleto simulado emitido. Aguardando compensação.');
        } else {
            db()->prepare("INSERT INTO pagamentos (pedido_id, tipo, metodo, valor, status, codigo_transacao, cartao_final, parcelas, observacao, criado_em, confirmado_em)
                           VALUES (?, 'cobranca', ?, ?, 'aprovado', ?, ?, ?, 'Pagamento simulado aprovado', ?, ?)")
                ->execute([$pedidoId, $metodo, numSql($total, 2), $codigo, $cartaoFinal, $parcelas, agora(), agora()]);
            alterarStatus($pedidoId, 'confirmado', 'Pagamento simulado aprovado via ' . METODOS_PAGAMENTO[$metodo] . '.', ['total_pago' => numSql($total, 2)]);
            alterarStatus($pedidoId, 'aguardando_separacao', 'Pedido liberado para separação.');
        }
        return $pedidoId;
    });
} catch (RegraNegocioException $e) {
    flash('erro', $e->getMessage());
    redirecionar('cliente/carrinho.php');
}

$_SESSION['carrinho'] = [];
unset($_SESSION['checkout']);
redirecionar('cliente/confirmacao.php?id=' . $pedidoId);
