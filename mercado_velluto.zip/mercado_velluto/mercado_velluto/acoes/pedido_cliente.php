<?php
/**
 * Ações do cliente sobre o próprio pedido:
 * pagar boleto (simulado), aceitar/recusar substituição, aprovar/recusar ajuste, confirmar entrega e cancelar.
 */
require __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirecionar('cliente/pedidos.php');
}
$u = exigirCliente();
$pedidoId = (int) post('pedido_id');
$acao = post('acao');

// Verificação de propriedade: o cliente só age sobre os próprios pedidos.
$st = db()->prepare('SELECT * FROM pedidos WHERE id = ? AND usuario_id = ?');
$st->execute([$pedidoId, $u['id']]);
if (!$st->fetch()) {
    http_response_code(403);
    flash('erro', 'Pedido não encontrado.');
    redirecionar('cliente/pedidos.php');
}
$voltarPara = 'cliente/pedido.php?id=' . $pedidoId;

try {
    switch ($acao) {
        case 'pagar_boleto':
            transacao(function () use ($pedidoId) {
                $p = buscarPedido($pedidoId, true);
                if ($p['status'] !== 'aguardando_pagamento') {
                    throw new RegraNegocioException('Este pedido não está aguardando pagamento.');
                }
                db()->prepare("UPDATE pagamentos SET status = 'aprovado', confirmado_em = ?, observacao = 'Boleto compensado (simulado)'
                               WHERE pedido_id = ? AND tipo = 'cobranca' AND status = 'pendente'")->execute([agora(), $pedidoId]);
                alterarStatus($pedidoId, 'confirmado', 'Pagamento do boleto compensado (simulação).', ['total_pago' => $p['total']]);
                alterarStatus($pedidoId, 'aguardando_separacao', 'Pedido liberado para separação.');
            });
            flash('sucesso', 'Pagamento confirmado! Seu pedido já está na fila de separação.');
            break;

        case 'aceitar_substituicao':
        case 'recusar_substituicao':
            $sid = (int) post('substituicao_id');
            $aceitar = $acao === 'aceitar_substituicao';
            $resultado = transacao(function () use ($pedidoId, $sid, $aceitar) {
                $p = buscarPedido($pedidoId, true);
                $st = db()->prepare("SELECT * FROM substituicoes WHERE id = ? AND pedido_id = ? AND status = 'pendente'" . lockSql());
                $st->execute([$sid, $pedidoId]);
                $s = $st->fetch();
                if (!$s || $p['status'] !== 'aguardando_aprovacao') {
                    throw new RegraNegocioException('Esta substituição já foi respondida ou não está mais disponível.');
                }
                $st = db()->prepare('SELECT * FROM itens_pedido WHERE id = ? AND pedido_id = ?');
                $st->execute([$s['item_id'], $pedidoId]);
                $item = $st->fetch();
                $st = db()->prepare('SELECT * FROM produtos WHERE id = ?' . lockSql());
                $st->execute([$s['produto_sugerido_id']]);
                $sug = $st->fetch();
                $u = usuarioLogado();

                if ($aceitar) {
                    if (!$sug || !(int) $sug['ativo'] || (float) $sug['estoque'] < (float) $s['quantidade']) {
                        // Substituto esgotou: a sugestão é cancelada e o separador poderá sugerir outro.
                        db()->prepare("UPDATE substituicoes SET status = 'cancelada', respondido_por = ?, respondido_em = ? WHERE id = ?")
                            ->execute([$u['id'], agora(), $sid]);
                        registrarHistorico($pedidoId, $p['status'], $p['status'], 'Substituto "' . ($sug['nome'] ?? '') . '" esgotou antes da aprovação; aguardando nova sugestão.');
                        retomarSeparacaoSePossivel($pedidoId);
                        return 'esgotado';
                    }
                    movimentarEstoque((int) $sug['id'], -(float) $s['quantidade'], 'substituicao', $pedidoId, 'Substituição aceita — pedido #' . $pedidoId);
                    $sub = round((float) $s['preco_sugerido'] * (float) $s['quantidade'], 2);
                    db()->prepare("INSERT INTO itens_pedido (pedido_id, produto_id, nome_produto, vendido_por, quantidade, preco_unitario, subtotal, status, item_origem_id, observacao, criado_em)
                                   VALUES (?, ?, ?, ?, ?, ?, ?, 'pendente', ?, ?, ?)")
                        ->execute([$pedidoId, $sug['id'], $sug['nome'], $sug['vendido_por'], numSql((float) $s['quantidade']), $s['preco_sugerido'], numSql($sub, 2),
                            $item['id'], 'Substitui ' . $item['nome_produto'], agora()]);
                    db()->prepare("UPDATE itens_pedido SET status = 'substituido', subtotal = 0 WHERE id = ?")->execute([$item['id']]);
                    db()->prepare("UPDATE substituicoes SET status = 'aceita', respondido_por = ?, respondido_em = ? WHERE id = ?")->execute([$u['id'], agora(), $sid]);
                    $desc = 'Cliente aceitou substituir "' . $item['nome_produto'] . '" por "' . $sug['nome'] . '".';
                } else {
                    db()->prepare("UPDATE itens_pedido SET status = 'removido', subtotal = 0 WHERE id = ?")->execute([$item['id']]);
                    db()->prepare("UPDATE substituicoes SET status = 'rejeitada', respondido_por = ?, respondido_em = ? WHERE id = ?")->execute([$u['id'], agora(), $sid]);
                    $desc = 'Cliente recusou a substituição; item "' . $item['nome_produto'] . '" removido do pedido.';
                }
                $r = recalcularPedido($pedidoId);
                registrarHistorico($pedidoId, $p['status'], $p['status'], $desc . ' Novo total: ' . dinheiro($r['total']) . '.');
                // Diferença positiva aprovada pelo cliente é cobrada agora; créditos (itens a menos)
                // são estornados ao final da separação, junto com eventuais ajustes de peso.
                if ($aceitar && (float) $s['diferenca'] > 0) {
                    registrarComplemento($pedidoId, (float) $s['diferenca'], 'diferença da substituição aprovada pelo cliente');
                }
                retomarSeparacaoSePossivel($pedidoId);
                return 'ok';
            });
            if ($resultado === 'esgotado') {
                throw new RegraNegocioException('O produto sugerido acabou de esgotar. O separador vai sugerir outra opção ou remover o item.');
            }
            flash('sucesso', $aceitar ? 'Substituição aceita. O total do pedido foi recalculado.' : 'Substituição recusada. O item foi removido; o valor será estornado ao final da separação (simulação).');
            break;

        case 'aprovar_ajuste':
            transacao(function () use ($pedidoId) {
                $p = buscarPedido($pedidoId, true);
                if ($p['status'] !== 'aguardando_aprovacao' || (int) $p['ajuste_pendente'] !== 1) {
                    throw new RegraNegocioException('Não há ajuste de valor pendente neste pedido.');
                }
                registrarHistorico($pedidoId, $p['status'], $p['status'], 'Cliente aprovou o novo total de ' . dinheiro($p['total']) . '.');
                liberarParaEntrega($pedidoId, 'Novo valor aprovado pelo cliente; pedido embalado e liberado para entrega.');
            });
            flash('sucesso', 'Novo valor aprovado. Seu pedido foi liberado para entrega!');
            break;

        case 'recusar_ajuste':
            $p = buscarPedido($pedidoId);
            if ($p['status'] !== 'aguardando_aprovacao' || (int) $p['ajuste_pendente'] !== 1) {
                throw new RegraNegocioException('Não há ajuste de valor pendente neste pedido.');
            }
            cancelarPedido($pedidoId, 'Cliente recusou o novo valor após pesagem', true);
            flash('info', 'Pedido cancelado. O valor pago foi estornado (simulação).');
            break;

        case 'confirmar_entrega':
            transacao(function () use ($pedidoId, $u) {
                $st = db()->prepare('SELECT * FROM entregas WHERE pedido_id = ?' . lockSql());
                $st->execute([$pedidoId]);
                $entrega = $st->fetch();
                if (!$entrega || $entrega['status'] !== 'em_rota') {
                    throw new RegraNegocioException('A entrega não está em rota ou já foi concluída.');
                }

                $p = buscarPedido($pedidoId, true);
                if (!$p || (int) $p['usuario_id'] !== (int) $u['id'] || $p['status'] !== 'saiu_para_entrega') {
                    throw new RegraNegocioException('Este pedido não está aguardando confirmação de recebimento.');
                }

                $confirmadoEm = agora();
                $up = db()->prepare("UPDATE entregas SET status = 'entregue', entregue_em = ?, recebedor = ?, tentativas = tentativas + 1
                                     WHERE id = ? AND status = 'em_rota'");
                $up->execute([$confirmadoEm, $u['nome'], $entrega['id']]);
                if ($up->rowCount() !== 1) {
                    throw new RegraNegocioException('A entrega foi atualizada por outra pessoa. Atualize o pedido.');
                }
                alterarStatus($pedidoId, 'concluido', 'Recebimento confirmado pelo cliente ' . $u['nome'] . '.', ['concluido_em' => $confirmadoEm]);
            });
            flash('sucesso', 'Recebimento confirmado. Obrigado!');
            break;

        case 'cancelar':
            $motivo = mb_substr(post('motivo'), 0, 100);
            if ($motivo === '') {
                throw new RegraNegocioException('Informe o motivo do cancelamento.');
            }
            $detalhe = mb_substr(post('detalhe'), 0, 200);
            cancelarPedido($pedidoId, $motivo . ($detalhe !== '' ? ' — ' . $detalhe : ''), true);
            flash('info', 'Pedido #' . $pedidoId . ' cancelado. O estoque foi liberado e o valor estornado (simulação).');
            break;

        default:
            throw new RegraNegocioException('Ação inválida.');
    }
} catch (RegraNegocioException $e) {
    flash('erro', $e->getMessage());
}
redirecionar($voltarPara);
