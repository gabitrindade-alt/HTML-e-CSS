<?php
/**
 * Ações do separador: assumir pedido, conferir itens (quantidade/peso real),
 * marcar indisponível, sugerir substituto, remover item, finalizar separação.
 */
require __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirecionar('interno/separador/index.php');
}
$eu = exigirPerfil('separador');
$acao = post('acao');
$pedidoId = (int) post('pedido_id');
$destino = 'interno/separador/pedido.php?id=' . $pedidoId;

/** Garante que o pedido está com este separador e em estado editável. */
function pedidoDoSeparador(int $pedidoId, int $separadorId, array $estados = ['em_separacao', 'aguardando_aprovacao']): array
{
    $p = buscarPedido($pedidoId, true);
    if (!$p) {
        throw new RegraNegocioException('Pedido não encontrado.');
    }
    if ((int) $p['separador_id'] !== $separadorId) {
        throw new RegraNegocioException('Este pedido está atribuído a outro separador.');
    }
    if (!in_array($p['status'], $estados, true)) {
        throw new RegraNegocioException('O pedido está "' . statusRotulo($p['status']) . '" e não pode ser alterado agora.');
    }
    return $p;
}

function itemDoPedido(int $itemId, int $pedidoId): array
{
    $st = db()->prepare('SELECT * FROM itens_pedido WHERE id = ? AND pedido_id = ?' . lockSql());
    $st->execute([$itemId, $pedidoId]);
    $i = $st->fetch();
    if (!$i) {
        throw new RegraNegocioException('Item não encontrado neste pedido.');
    }
    return $i;
}

try {
    switch ($acao) {
        case 'assumir':
            transacao(function () use ($pedidoId, $eu) {
                // UPDATE condicional: apenas um separador consegue assumir o mesmo pedido.
                $st = db()->prepare("UPDATE pedidos SET separador_id = ?, status = 'em_separacao', separacao_iniciada_em = ?, atualizado_em = ?
                                     WHERE id = ? AND status = 'aguardando_separacao' AND separador_id IS NULL");
                $st->execute([$eu['id'], agora(), agora(), $pedidoId]);
                if ($st->rowCount() !== 1) {
                    throw new RegraNegocioException('Este pedido já foi assumido por outro separador ou não está mais na fila.');
                }
                registrarHistorico($pedidoId, 'aguardando_separacao', 'em_separacao', 'Separação iniciada por ' . $eu['nome'] . '.');
            });
            flash('sucesso', 'Pedido #' . $pedidoId . ' assumido. Boa separação!');
            break;

        case 'devolver':
            transacao(function () use ($pedidoId, $eu) {
                pedidoDoSeparador($pedidoId, (int) $eu['id'], ['em_separacao']);
                $st = db()->prepare("SELECT COUNT(*) FROM itens_pedido WHERE pedido_id = ? AND status <> 'pendente'");
                $st->execute([$pedidoId]);
                if ((int) $st->fetchColumn() > 0) {
                    throw new RegraNegocioException('Já existem itens conferidos; finalize a separação.');
                }
                alterarStatus($pedidoId, 'aguardando_separacao', 'Pedido devolvido à fila por ' . $eu['nome'] . '.', ['separador_id' => null, 'separacao_iniciada_em' => null]);
            });
            flash('info', 'Pedido devolvido à fila de separação.');
            $destino = 'interno/separador/index.php';
            break;

        case 'separar':
            $itemId = (int) post('item_id');
            transacao(function () use ($pedidoId, $itemId, $eu) {
                pedidoDoSeparador($pedidoId, (int) $eu['id']);
                $i = itemDoPedido($itemId, $pedidoId);
                if ($i['status'] !== 'pendente') {
                    throw new RegraNegocioException('Este item já foi conferido.');
                }
                $solicitado = (float) $i['quantidade'];
                if ($i['vendido_por'] === 'peso') {
                    $real = round(paraNumero(post('quantidade_real')), 3);
                    if ($real <= 0 || $real > $solicitado * 2) {
                        throw new RegraNegocioException('Peso real inválido para "' . $i['nome_produto'] . '" (informe em kg, até o dobro do solicitado).');
                    }
                    // Ajusta o estoque pela diferença entre o peso real e o reservado.
                    movimentarEstoque((int) $i['produto_id'], -($real - $solicitado), 'ajuste_peso', $pedidoId, 'Peso real ' . numeroBr($real, 3) . ' kg (solicitado ' . numeroBr($solicitado, 3) . ' kg)');
                    $obs = 'Peso real: ' . numeroBr($real, 3) . ' kg';
                } else {
                    $real = (float) (int) post('quantidade_real');
                    if ($real < 1 || $real > $solicitado) {
                        throw new RegraNegocioException('Quantidade inválida: informe de 1 a ' . (int) $solicitado . '. Se não houver nenhuma unidade, marque como indisponível.');
                    }
                    $obs = $real < $solicitado ? 'Separado parcialmente: ' . (int) $real . ' de ' . (int) $solicitado : null;
                    if ($real < $solicitado) {
                        registrarOcorrencia($pedidoId, null, 'divergencia_estoque', 'media',
                            '"' . $i['nome_produto'] . '": encontradas ' . (int) $real . ' de ' . (int) $solicitado . ' unidades reservadas no sistema.');
                    }
                }
                $sub = round((float) $i['preco_unitario'] * $real, 2);
                db()->prepare("UPDATE itens_pedido SET status = 'separado', quantidade_separada = ?, subtotal = ?, observacao = COALESCE(?, observacao) WHERE id = ?")
                    ->execute([numSql($real), numSql($sub, 2), $obs, $itemId]);
                $r = recalcularPedido($pedidoId);
                $p = buscarPedido($pedidoId);
                registrarHistorico($pedidoId, $p['status'], $p['status'], '"' . $i['nome_produto'] . '" conferido: ' . qtdFormatada($real, $i['vendido_por']) . ' (' . dinheiro($sub) . '). Total atual ' . dinheiro($r['total']) . '.');
            });
            flash('sucesso', 'Item conferido.');
            break;

        case 'indisponivel':
            $itemId = (int) post('item_id');
            transacao(function () use ($pedidoId, $itemId, $eu) {
                pedidoDoSeparador($pedidoId, (int) $eu['id']);
                $i = itemDoPedido($itemId, $pedidoId);
                if ($i['status'] !== 'pendente') {
                    throw new RegraNegocioException('Somente itens pendentes podem ser marcados como indisponíveis.');
                }
                db()->prepare("UPDATE itens_pedido SET status = 'indisponivel', quantidade_separada = 0, subtotal = 0 WHERE id = ?")->execute([$itemId]);
                recalcularPedido($pedidoId);
                registrarOcorrencia($pedidoId, null, 'divergencia_estoque', 'media',
                    '"' . $i['nome_produto'] . '" não encontrado na separação (reserva de ' . qtdFormatada($i['quantidade'], $i['vendido_por']) . '). Conferir inventário.');
                $p = buscarPedido($pedidoId);
                registrarHistorico($pedidoId, $p['status'], $p['status'], '"' . $i['nome_produto'] . '" indisponível no momento da separação.');
            });
            flash('aviso', 'Item marcado como indisponível. Sugira um substituto ou remova o item.');
            break;

        case 'sugerir':
            $itemId = (int) post('item_id');
            $sugId = (int) post('produto_sugerido_id');
            transacao(function () use ($pedidoId, $itemId, $sugId, $eu) {
                $p = pedidoDoSeparador($pedidoId, (int) $eu['id']);
                $i = itemDoPedido($itemId, $pedidoId);
                if ($i['status'] !== 'indisponivel') {
                    throw new RegraNegocioException('Marque o item como indisponível antes de sugerir um substituto.');
                }
                $st = db()->prepare("SELECT COUNT(*) FROM substituicoes WHERE item_id = ? AND status = 'pendente'");
                $st->execute([$itemId]);
                if ($st->fetchColumn()) {
                    throw new RegraNegocioException('Já existe uma sugestão aguardando o cliente para este item.');
                }
                $st = db()->prepare('SELECT * FROM produtos WHERE id = ? AND ativo = 1');
                $st->execute([$sugId]);
                $sug = $st->fetch();
                if (!$sug || $sugId === (int) $i['produto_id']) {
                    throw new RegraNegocioException('Escolha um produto substituto válido.');
                }
                $qtd = $sug['vendido_por'] === 'peso' ? max(0.25, round(paraNumero(post('quantidade')) * 4) / 4) : max(1, (int) post('quantidade'));
                if ((float) $sug['estoque'] < $qtd) {
                    throw new RegraNegocioException('Estoque insuficiente do substituto (' . qtdFormatada($sug['estoque'], $sug['vendido_por']) . ').');
                }
                $precoSug = precoAtual($sug);
                $dif = round($precoSug * $qtd - (float) $i['preco_unitario'] * (float) $i['quantidade'], 2);
                db()->prepare("INSERT INTO substituicoes (pedido_id, item_id, produto_original_id, produto_sugerido_id, quantidade, preco_original, preco_sugerido, diferenca, status, mensagem, sugerido_por, criado_em)
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pendente', ?, ?, ?)")
                    ->execute([$pedidoId, $itemId, $i['produto_id'], $sugId, numSql($qtd), $i['preco_unitario'], numSql($precoSug, 2), numSql($dif, 2),
                        mb_substr(post('mensagem'), 0, 255) ?: null, $eu['id'], agora()]);
                $desc = 'Substituição sugerida: "' . $i['nome_produto'] . '" → "' . $sug['nome'] . '" (diferença ' . dinheiro($dif) . '). Aguardando resposta do cliente.';
                if ($p['status'] === 'em_separacao') {
                    alterarStatus($pedidoId, 'aguardando_aprovacao', $desc);
                } else {
                    registrarHistorico($pedidoId, $p['status'], $p['status'], $desc);
                }
            });
            flash('sucesso', 'Sugestão enviada ao cliente. Continue separando os demais itens.');
            break;

        case 'remover':
            $itemId = (int) post('item_id');
            transacao(function () use ($pedidoId, $itemId, $eu) {
                pedidoDoSeparador($pedidoId, (int) $eu['id']);
                $i = itemDoPedido($itemId, $pedidoId);
                if ($i['status'] !== 'indisponivel') {
                    throw new RegraNegocioException('Somente itens indisponíveis podem ser removidos.');
                }
                $st = db()->prepare("SELECT COUNT(*) FROM substituicoes WHERE item_id = ? AND status = 'pendente'");
                $st->execute([$itemId]);
                if ($st->fetchColumn()) {
                    throw new RegraNegocioException('Há uma substituição aguardando o cliente para este item.');
                }
                db()->prepare("UPDATE itens_pedido SET status = 'removido', subtotal = 0 WHERE id = ?")->execute([$itemId]);
                $r = recalcularPedido($pedidoId);
                $p = buscarPedido($pedidoId);
                registrarHistorico($pedidoId, $p['status'], $p['status'], '"' . $i['nome_produto'] . '" removido do pedido (indisponível, sem substituto). Novo total ' . dinheiro($r['total']) . '; diferença será estornada.');
            });
            flash('info', 'Item removido. O valor será estornado ao cliente ao finalizar.');
            break;

        case 'finalizar':
            $volumes = (int) post('volumes');
            $resultado = transacao(function () use ($pedidoId, $volumes, $eu) {
                $p = pedidoDoSeparador($pedidoId, (int) $eu['id'], ['em_separacao']);
                if ($volumes < 1 || $volumes > 50) {
                    throw new RegraNegocioException('Informe o número de volumes embalados (1 a 50).');
                }
                $pend = pendenciasSeparacao($pedidoId);
                if ($pend['substituicoes'] > 0) {
                    throw new RegraNegocioException('Há substituições aguardando resposta do cliente. Não é possível finalizar.');
                }
                if ($pend['pendentes'] > 0 || $pend['indisponiveis'] > 0) {
                    throw new RegraNegocioException('Confira todos os itens: há ' . $pend['pendentes'] . ' pendente(s) e ' . $pend['indisponiveis'] . ' indisponível(is) sem decisão.');
                }
                $st = db()->prepare("SELECT COUNT(*) FROM itens_pedido WHERE pedido_id = ? AND status = 'separado'");
                $st->execute([$pedidoId]);
                if (!(int) $st->fetchColumn()) {
                    throw new RegraNegocioException('Nenhum item foi separado. Peça à administração para cancelar o pedido.');
                }
                db()->prepare('UPDATE pedidos SET volumes = ? WHERE id = ?')->execute([$volumes, $pedidoId]);
                $r = recalcularPedido($pedidoId);
                $tol = (float) config('tolerancia_ajuste_percent', 10);
                if ($r['total'] > round($r['total_pago'] * (1 + $tol / 100), 2) + 0.009) {
                    // Aumento acima da tolerância (ex.: diferença de peso): exige aprovação do cliente.
                    alterarStatus($pedidoId, 'aguardando_aprovacao',
                        'Separação concluída com novo total ' . dinheiro($r['total']) . ' (pago ' . dinheiro($r['total_pago']) . '), acima da tolerância de ' . numeroBr($tol, 0) . '%. Aguardando aprovação do cliente.',
                        ['ajuste_pendente' => 1, 'separacao_concluida_em' => agora()]);
                    return 'aprovacao';
                }
                liberarParaEntrega($pedidoId, 'Separação concluída por ' . $eu['nome'] . ' — ' . $volumes . ' volume(s) embalado(s). Pedido pronto para entrega.');
                return 'ok';
            });
            if ($resultado === 'aprovacao') {
                flash('aviso', 'O total aumentou além da tolerância. O pedido aguarda aprovação do cliente antes de seguir para entrega.');
            } else {
                flash('sucesso', 'Separação finalizada! Pedido #' . $pedidoId . ' encaminhado para entrega.');
            }
            $destino = 'interno/separador/index.php';
            break;

        default:
            throw new RegraNegocioException('Ação inválida.');
    }
} catch (RegraNegocioException $e) {
    flash('erro', $e->getMessage());
    if ($acao === 'assumir') {
        $destino = 'interno/separador/index.php';
    }
}
redirecionar($destino);
