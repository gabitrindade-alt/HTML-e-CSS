<?php
/** Ações do carrinho: adicionar, atualizar quantidade, remover e limpar. */
require __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirecionar('cliente/carrinho.php');
}
if (usuarioLogado() && !clienteLogado()) {
    flash('erro', 'Funcionários não podem fazer compras com o perfil interno. Saia e entre como cliente.');
    voltar();
}

$acao = post('acao');
$id = (int) post('produto_id');

if ($acao === 'limpar') {
    $_SESSION['carrinho'] = [];
    flash('info', 'Carrinho esvaziado.');
    redirecionar('cliente/carrinho.php');
}

$st = db()->prepare('SELECT * FROM produtos WHERE id = ?');
$st->execute([$id]);
$p = $st->fetch();
if (!$p) {
    flash('erro', 'Produto não encontrado.');
    voltar('catalogo.php');
}

$atual = (float) ($_SESSION['carrinho'][$id] ?? 0);

switch ($acao) {
    case 'adicionar':
        if (!(int) $p['ativo'] || (float) $p['estoque'] <= 0) {
            flash('erro', '"' . $p['nome'] . '" está indisponível no momento.');
            voltar('catalogo.php');
        }
        $qtd = normalizarQtd($p, post('qtd', 1));
        $min = passoQtd($p)['min'];
        if ($qtd < $min) {
            $qtd = $min;
        }
        $nova = $atual + $qtd;
        if ($nova > (float) $p['estoque']) {
            $nova = $p['vendido_por'] === 'peso' ? floor((float) $p['estoque'] * 4) / 4 : floor((float) $p['estoque']);
            flash('aviso', 'Quantidade ajustada ao estoque disponível de "' . $p['nome'] . '" (' . qtdFormatada($p['estoque'], $p['vendido_por']) . ').');
        } else {
            flash('sucesso', '"' . $p['nome'] . '" adicionado ao carrinho.');
        }
        if ($nova > 0) {
            $_SESSION['carrinho'][$id] = $nova;
        }
        voltar('cliente/carrinho.php');

    case 'atualizar':
        $qtd = normalizarQtd($p, post('qtd', 0));
        if ($qtd <= 0) {
            unset($_SESSION['carrinho'][$id]);
            flash('info', '"' . $p['nome'] . '" removido do carrinho.');
        } else {
            if ($qtd > (float) $p['estoque']) {
                $qtd = $p['vendido_por'] === 'peso' ? floor((float) $p['estoque'] * 4) / 4 : floor((float) $p['estoque']);
                flash('aviso', 'Estoque disponível de "' . $p['nome'] . '": ' . qtdFormatada($p['estoque'], $p['vendido_por']) . '.');
            }
            if ($qtd > 0) {
                $_SESSION['carrinho'][$id] = $qtd;
            } else {
                unset($_SESSION['carrinho'][$id]);
            }
        }
        redirecionar('cliente/carrinho.php');

    case 'remover':
        unset($_SESSION['carrinho'][$id]);
        flash('info', '"' . $p['nome'] . '" removido do carrinho.');
        redirecionar('cliente/carrinho.php');
}

flash('erro', 'Ação inválida.');
redirecionar('cliente/carrinho.php');
