<?php
/** Adiciona/remove um produto dos favoritos do cliente. */
require __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirecionar('cliente/favoritos.php');
}
$u = exigirCliente();
$id = (int) post('produto_id');

$st = db()->prepare('SELECT id, nome FROM produtos WHERE id = ?');
$st->execute([$id]);
$p = $st->fetch();
if (!$p) {
    flash('erro', 'Produto não encontrado.');
    voltar('catalogo.php');
}

$st = db()->prepare('SELECT id FROM favoritos WHERE usuario_id = ? AND produto_id = ?');
$st->execute([$u['id'], $id]);
if ($fav = $st->fetchColumn()) {
    db()->prepare('DELETE FROM favoritos WHERE id = ? AND usuario_id = ?')->execute([$fav, $u['id']]);
    flash('info', '"' . $p['nome'] . '" removido dos favoritos.');
} else {
    db()->prepare('INSERT INTO favoritos (usuario_id, produto_id, criado_em) VALUES (?, ?, ?)')->execute([$u['id'], $id, agora()]);
    flash('sucesso', '"' . $p['nome'] . '" adicionado aos favoritos.');
}
voltar('cliente/favoritos.php');
