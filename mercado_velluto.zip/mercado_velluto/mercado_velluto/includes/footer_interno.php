    </main>
  </div>
</div>
<script src="<?= e(asset('js/velluto.js')) ?>"></script>
<script src="<?= e(asset('js/preferencias.js')) ?>"></script>
</body>
</html>
