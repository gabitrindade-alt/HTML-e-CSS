<?php
/**
 * VELLUTO — Regras de negócio de pedidos, estoque, substituições e entregas.
 * Operações críticas rodam dentro de transações.
 */

const STATUS_PEDIDO = [
    'aguardando_pagamento' => 'Aguardando pagamento',
    'confirmado'           => 'Confirmado',
    'aguardando_separacao' => 'Aguardando separação',
    'em_separacao'         => 'Em separação',
    'aguardando_aprovacao' => 'Aguardando aprovação do cliente',
    'aguardando_entrega'   => 'Pronto — aguardando entrega',
    'saiu_para_entrega'    => 'Saiu para entrega',
    'concluido'            => 'Concluído',
    'cancelado'            => 'Cancelado',
];

/** Transições de status permitidas. */
const TRANSICOES = [
    'aguardando_pagamento' => ['confirmado', 'cancelado'],
    'confirmado'           => ['aguardando_separacao', 'cancelado'],
    'aguardando_separacao' => ['em_separacao', 'cancelado'],
    'em_separacao'         => ['aguardando_aprovacao', 'aguardando_entrega', 'aguardando_separacao', 'cancelado'],
    'aguardando_aprovacao' => ['em_separacao', 'aguardando_entrega', 'cancelado'],
    'aguardando_entrega'   => ['saiu_para_entrega', 'cancelado'],
    'saiu_para_entrega'    => ['concluido', 'aguardando_entrega', 'cancelado'],
    'concluido'            => [],
    'cancelado'            => [],
];

/** Estados em que o próprio cliente pode cancelar. */
const STATUS_CANCELAVEL_CLIENTE = ['aguardando_pagamento', 'confirmado', 'aguardando_separacao', 'aguardando_aprovacao'];

const STATUS_ITEM = [
    'pendente'     => 'Pendente',
    'separado'     => 'Separado',
    'indisponivel' => 'Indisponível',
    'substituido'  => 'Substituído',
    'removido'     => 'Removido',
];

const STATUS_ENTREGA = [
    'disponivel' => 'Disponível',
    'atribuida'  => 'Atribuída',
    'em_rota'    => 'Em rota',
    'entregue'   => 'Entregue',
    'cancelada'  => 'Cancelada',
];

const METODOS_PAGAMENTO = ['pix' => 'PIX', 'cartao' => 'Cartão de crédito', 'boleto' => 'Boleto bancário'];

class RegraNegocioException extends RuntimeException
{
}

function statusRotulo(string $s): string
{
    return STATUS_PEDIDO[$s] ?? $s;
}

function freteRotulo(string $t): string
{
    return $t === 'expresso' ? 'expresso' : 'padrão';
}

function statusBadge(string $s): string
{
    return '<span class="badge st-' . e($s) . '">' . e(statusRotulo($s)) . '</span>';
}

/** Cláusula de bloqueio de linha (MySQL/InnoDB). */
function lockSql(): string
{
    return dbEhMysql() ? ' FOR UPDATE' : '';
}

function numSql(float $v, int $casas = 3): string
{
    return number_format($v, $casas, '.', '');
}

/** Executa uma função dentro de transação, com rollback em caso de erro. */
function transacao(callable $fn)
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $r = $fn($pdo);
        $pdo->commit();
        return $r;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function buscarPedido(int $id, bool $bloquear = false): ?array
{
    $st = db()->prepare('SELECT * FROM pedidos WHERE id = ?' . ($bloquear ? lockSql() : ''));
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

function itensDoPedido(int $pedidoId): array
{
    $st = db()->prepare('SELECT i.*, p.imagem, p.estoque, p.categoria_id, p.embalagem
                         FROM itens_pedido i JOIN produtos p ON p.id = i.produto_id
                         WHERE i.pedido_id = ? ORDER BY i.id');
    $st->execute([$pedidoId]);
    return $st->fetchAll();
}

function registrarHistorico(int $pedidoId, ?string $anterior, string $novo, string $descricao): void
{
    $u = usuarioLogado();
    $st = db()->prepare('INSERT INTO historico_pedidos (pedido_id, status_anterior, status_novo, usuario_id, perfil, descricao, criado_em)
                         VALUES (?, ?, ?, ?, ?, ?, ?)');
    $st->execute([$pedidoId, $anterior, $novo, $u['id'] ?? null, $u['perfil'] ?? 'sistema', mb_substr($descricao, 0, 500), agora()]);
}

/**
 * Altera o status do pedido validando a transição e registrando no histórico.
 * Deve ser chamada dentro de uma transação.
 */
function alterarStatus(int $pedidoId, string $novo, string $descricao, ?array $extras = null): void
{
    $p = buscarPedido($pedidoId, true);
    if (!$p) {
        throw new RegraNegocioException('Pedido não encontrado.');
    }
    $atual = $p['status'];
    if (!in_array($novo, TRANSICOES[$atual] ?? [], true)) {
        throw new RegraNegocioException('Não é possível mudar o pedido de "' . statusRotulo($atual) . '" para "' . statusRotulo($novo) . '".');
    }
    $campos = ['status = ?', 'atualizado_em = ?'];
    $valores = [$novo, agora()];
    foreach (($extras ?? []) as $campo => $valor) {
        $campos[] = $campo . ' = ?';
        $valores[] = $valor;
    }
    $valores[] = $pedidoId;
    $valores[] = $atual;
    $st = db()->prepare('UPDATE pedidos SET ' . implode(', ', $campos) . ' WHERE id = ? AND status = ?');
    $st->execute($valores);
    if ($st->rowCount() !== 1) {
        throw new RegraNegocioException('O pedido foi alterado por outra pessoa. Atualize a página.');
    }
    registrarHistorico($pedidoId, $atual, $novo, $descricao);
}

/**
 * Movimenta o estoque de forma atômica. Delta negativo = saída.
 * Impede estoque negativo (UPDATE condicional) e registra a movimentação.
 */
function movimentarEstoque(int $produtoId, float $delta, string $tipo, ?int $pedidoId, string $obs = ''): void
{
    $delta = round($delta, 3);
    if (abs($delta) < 0.0005) {
        return;
    }
    $st = db()->prepare('UPDATE produtos SET estoque = estoque + ?, atualizado_em = ? WHERE id = ? AND estoque + ? >= 0');
    $st->execute([numSql($delta), agora(), $produtoId, numSql($delta)]);
    if ($st->rowCount() !== 1) {
        $n = db()->prepare('SELECT nome FROM produtos WHERE id = ?');
        $n->execute([$produtoId]);
        throw new RegraNegocioException('Estoque insuficiente para "' . ($n->fetchColumn() ?: 'produto') . '".');
    }
    $s = db()->prepare('SELECT estoque FROM produtos WHERE id = ?');
    $s->execute([$produtoId]);
    $posterior = (float) $s->fetchColumn();
    $u = usuarioLogado();
    $m = db()->prepare('INSERT INTO movimentacoes_estoque (produto_id, tipo, quantidade, estoque_anterior, estoque_posterior, pedido_id, usuario_id, observacao, criado_em)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $m->execute([$produtoId, $tipo, numSql($delta), numSql($posterior - $delta), numSql($posterior), $pedidoId, $u['id'] ?? null, $obs, agora()]);
}

/** Recalcula subtotal e total do pedido a partir dos itens válidos. */
function recalcularPedido(int $pedidoId): array
{
    $st = db()->prepare("SELECT COALESCE(SUM(subtotal), 0) FROM itens_pedido WHERE pedido_id = ? AND status IN ('pendente', 'separado')");
    $st->execute([$pedidoId]);
    $subtotal = round((float) $st->fetchColumn(), 2);
    $p = buscarPedido($pedidoId);
    $total = round($subtotal + (float) $p['valor_frete'], 2);
    $up = db()->prepare('UPDATE pedidos SET subtotal = ?, total = ?, atualizado_em = ? WHERE id = ?');
    $up->execute([numSql($subtotal, 2), numSql($total, 2), agora(), $pedidoId]);
    return ['subtotal' => $subtotal, 'total' => $total, 'total_pago' => (float) $p['total_pago']];
}

/** Gera cobrança complementar ou estorno simulado para igualar o valor pago ao total. */
function liquidarDiferenca(int $pedidoId, string $motivo): void
{
    $p = buscarPedido($pedidoId, true);
    $dif = round((float) $p['total'] - (float) $p['total_pago'], 2);
    if (abs($dif) < 0.01) {
        return;
    }
    $tipo = $dif > 0 ? 'complemento' : 'estorno';
    $st = db()->prepare("INSERT INTO pagamentos (pedido_id, tipo, metodo, valor, status, codigo_transacao, observacao, criado_em, confirmado_em)
                         VALUES (?, ?, ?, ?, 'aprovado', ?, ?, ?, ?)");
    $st->execute([$pedidoId, $tipo, $p['metodo_pagamento'], numSql(abs($dif), 2), 'SIM-' . strtoupper(bin2hex(random_bytes(5))), $motivo, agora(), agora()]);
    $up = db()->prepare('UPDATE pedidos SET total_pago = total WHERE id = ?');
    $up->execute([$pedidoId]);
    registrarHistorico($pedidoId, $p['status'], $p['status'],
        ($tipo === 'complemento' ? 'Cobrança complementar simulada de ' : 'Estorno simulado de ') . dinheiro(abs($dif)) . ' — ' . $motivo);
}

/** Cobrança complementar simulada de um valor aprovado pelo cliente (ex.: substituição mais cara). */
function registrarComplemento(int $pedidoId, float $valor, string $motivo): void
{
    $valor = round($valor, 2);
    if ($valor < 0.01) {
        return;
    }
    $p = buscarPedido($pedidoId, true);
    db()->prepare("INSERT INTO pagamentos (pedido_id, tipo, metodo, valor, status, codigo_transacao, observacao, criado_em, confirmado_em)
                   VALUES (?, 'complemento', ?, ?, 'aprovado', ?, ?, ?, ?)")
        ->execute([$pedidoId, $p['metodo_pagamento'], numSql($valor, 2), 'SIM-' . strtoupper(bin2hex(random_bytes(5))), $motivo, agora(), agora()]);
    db()->prepare('UPDATE pedidos SET total_pago = total_pago + ? WHERE id = ?')->execute([numSql($valor, 2), $pedidoId]);
    registrarHistorico($pedidoId, $p['status'], $p['status'], 'Cobrança complementar simulada de ' . dinheiro($valor) . ' — ' . $motivo . '.');
}

function criarOuReabrirEntrega(int $pedidoId): void
{
    $st = db()->prepare('SELECT id FROM entregas WHERE pedido_id = ?');
    $st->execute([$pedidoId]);
    $id = $st->fetchColumn();
    if ($id) {
        $up = db()->prepare("UPDATE entregas SET status = 'disponivel', entregador_id = NULL, assumida_em = NULL, retirada_em = NULL WHERE id = ?");
        $up->execute([$id]);
    } else {
        $in = db()->prepare("INSERT INTO entregas (pedido_id, status, tentativas, criado_em) VALUES (?, 'disponivel', 0, ?)");
        $in->execute([$pedidoId, agora()]);
    }
}

function registrarOcorrencia(?int $pedidoId, ?int $entregaId, string $tipo, string $gravidade, string $descricao): int
{
    $u = usuarioLogado();
    $st = db()->prepare("INSERT INTO ocorrencias (pedido_id, entrega_id, usuario_id, tipo, gravidade, descricao, status, criado_em)
                         VALUES (?, ?, ?, ?, ?, ?, 'aberta', ?)");
    $st->execute([$pedidoId, $entregaId, $u['id'] ?? null, $tipo, $gravidade, $descricao, agora()]);
    return (int) db()->lastInsertId();
}

/** Cancela o pedido, devolve o estoque reservado e estorna o valor pago (simulado). */
function cancelarPedido(int $pedidoId, string $motivo, bool $peloCliente): void
{
    transacao(function () use ($pedidoId, $motivo, $peloCliente) {
        $p = buscarPedido($pedidoId, true);
        if (!$p) {
            throw new RegraNegocioException('Pedido não encontrado.');
        }
        if ($peloCliente && !in_array($p['status'], STATUS_CANCELAVEL_CLIENTE, true)) {
            throw new RegraNegocioException('Este pedido não pode mais ser cancelado pelo cliente (status: ' . statusRotulo($p['status']) . ').');
        }
        if (in_array($p['status'], ['concluido', 'cancelado'], true)) {
            throw new RegraNegocioException('Pedido já finalizado.');
        }
        // Devolve ao estoque o que estava reservado/separado.
        foreach (itensDoPedido($pedidoId) as $i) {
            if ($i['status'] === 'pendente') {
                movimentarEstoque((int) $i['produto_id'], (float) $i['quantidade'], 'estorno', $pedidoId, 'Cancelamento do pedido #' . $pedidoId);
            } elseif ($i['status'] === 'separado') {
                movimentarEstoque((int) $i['produto_id'], (float) $i['quantidade_separada'], 'estorno', $pedidoId, 'Cancelamento do pedido #' . $pedidoId);
            }
        }
        db()->prepare("UPDATE substituicoes SET status = 'cancelada', respondido_em = ? WHERE pedido_id = ? AND status = 'pendente'")
            ->execute([agora(), $pedidoId]);
        db()->prepare("UPDATE entregas SET status = 'cancelada' WHERE pedido_id = ? AND status <> 'entregue'")->execute([$pedidoId]);

        // Pagamentos: pendentes são cancelados; valor pago é estornado.
        db()->prepare("UPDATE pagamentos SET status = 'recusado', observacao = 'Cancelado com o pedido' WHERE pedido_id = ? AND status = 'pendente'")
            ->execute([$pedidoId]);
        if ((float) $p['total_pago'] > 0) {
            db()->prepare("INSERT INTO pagamentos (pedido_id, tipo, metodo, valor, status, codigo_transacao, observacao, criado_em, confirmado_em)
                           VALUES (?, 'estorno', ?, ?, 'aprovado', ?, 'Estorno por cancelamento', ?, ?)")
                ->execute([$pedidoId, $p['metodo_pagamento'], $p['total_pago'], 'SIM-' . strtoupper(bin2hex(random_bytes(5))), agora(), agora()]);
        }
        $u = usuarioLogado();
        alterarStatus($pedidoId, 'cancelado', 'Pedido cancelado' . ($peloCliente ? ' pelo cliente' : '') . '. Motivo: ' . $motivo, [
            'motivo_cancelamento' => $motivo,
            'cancelado_por'       => $u['id'] ?? null,
            'cancelado_em'        => agora(),
            'total_pago'          => '0.00',
            'ajuste_pendente'     => 0,
        ]);
    });
}

/** Itens finalizados? Substituições pendentes? */
function pendenciasSeparacao(int $pedidoId): array
{
    $st = db()->prepare("SELECT
        SUM(CASE WHEN status = 'pendente' THEN 1 ELSE 0 END) AS pendentes,
        SUM(CASE WHEN status = 'indisponivel' THEN 1 ELSE 0 END) AS indisponiveis
        FROM itens_pedido WHERE pedido_id = ?");
    $st->execute([$pedidoId]);
    $r = $st->fetch();
    $s = db()->prepare("SELECT COUNT(*) FROM substituicoes WHERE pedido_id = ? AND status = 'pendente'");
    $s->execute([$pedidoId]);
    return [
        'pendentes'      => (int) $r['pendentes'],
        'indisponiveis'  => (int) $r['indisponiveis'],
        'substituicoes'  => (int) $s->fetchColumn(),
    ];
}

/** Libera o pedido para entrega (após separação e eventuais aprovações). */
function liberarParaEntrega(int $pedidoId, string $descricao): void
{
    liquidarDiferenca($pedidoId, 'Ajuste após separação');
    alterarStatus($pedidoId, 'aguardando_entrega', $descricao, ['separacao_concluida_em' => agora(), 'ajuste_pendente' => 0]);
    criarOuReabrirEntrega($pedidoId);
}

/** Se não houver mais respostas pendentes do cliente, devolve o pedido ao separador. */
function retomarSeparacaoSePossivel(int $pedidoId): void
{
    $p = buscarPedido($pedidoId, true);
    if ($p['status'] !== 'aguardando_aprovacao' || (int) $p['ajuste_pendente'] === 1) {
        return;
    }
    $pend = pendenciasSeparacao($pedidoId);
    if ($pend['substituicoes'] === 0) {
        alterarStatus($pedidoId, 'em_separacao', 'Respostas do cliente recebidas; separação retomada.');
    }
}

/** Contagem de ações pendentes para o cliente (substituições/ajustes). */
function pendenciasCliente(int $usuarioId): int
{
    $st = db()->prepare("SELECT COUNT(*) FROM pedidos WHERE usuario_id = ? AND status = 'aguardando_aprovacao'");
    $st->execute([$usuarioId]);
    return (int) $st->fetchColumn();
}
