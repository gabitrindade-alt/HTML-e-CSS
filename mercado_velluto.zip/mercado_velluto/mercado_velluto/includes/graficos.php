<?php
/** Gráficos SVG gerados no servidor (sem bibliotecas externas). */

function graficoLinha(array $rotulos, array $valores, string $prefixo = 'R$ '): string
{
    $w = 640; $h = 240; $ml = 56; $mr = 34; $mt = 18; $mb = 34;
    $max = max(1, max($valores ?: [0]));
    $ordem = 10 ** max(0, (int) floor(log10($max)));
    $max = ceil($max / $ordem) * $ordem;
    $n = max(1, count($valores) - 1);
    $px = fn($i) => $ml + ($w - $ml - $mr) * $i / $n;
    $py = fn($v) => $mt + ($h - $mt - $mb) * (1 - $v / $max);

    $svg = '<svg viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="Gráfico de linha">';
    $svg .= '<defs><linearGradient id="ga" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#E58AA5" stop-opacity=".35"/><stop offset="1" stop-color="#E58AA5" stop-opacity="0"/></linearGradient></defs>';
    for ($g = 0; $g <= 4; $g++) {
        $v = $max * $g / 4;
        $y = $py($v);
        $svg .= '<line x1="' . $ml . '" x2="' . ($w - $mr) . '" y1="' . $y . '" y2="' . $y . '" stroke="#EBDFD3" stroke-width="1"/>';
        $svg .= '<text x="' . ($ml - 8) . '" y="' . ($y + 4) . '" font-size="11" text-anchor="end" fill="#9A8A82">' . e(number_format($v, 0, ',', '.')) . '</text>';
    }
    $pts = [];
    foreach ($valores as $i => $v) {
        $pts[] = round($px($i), 1) . ',' . round($py($v), 1);
    }
    if ($pts) {
        $area = 'M' . $ml . ',' . $py(0) . ' L' . implode(' L', $pts) . ' L' . $px(count($valores) - 1) . ',' . $py(0) . ' Z';
        $svg .= '<path d="' . $area . '" fill="url(#ga)"/>';
        $svg .= '<polyline points="' . implode(' ', $pts) . '" fill="none" stroke="#C9476E" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>';
    }
    foreach ($valores as $i => $v) {
        $x = $px($i); $y = $py($v);
        $svg .= '<circle cx="' . $x . '" cy="' . $y . '" r="4" fill="#fff" stroke="#C9476E" stroke-width="2"><title>' . e($rotulos[$i] . ': ' . $prefixo . number_format($v, 2, ',', '.')) . '</title></circle>';
        $svg .= '<text x="' . $x . '" y="' . ($h - 12) . '" font-size="11" text-anchor="middle" fill="#6F5D55">' . e($rotulos[$i]) . '</text>';
    }
    return $svg . '</svg>';
}

/** Barras horizontais simples: [rótulo => valor] */
function barrasHorizontais(array $dados, callable $formatar): string
{
    if (!$dados) {
        return '<p class="muted">Sem dados no período.</p>';
    }
    $max = max(1, max($dados));
    $html = '<div style="display:grid;gap:10px">';
    foreach ($dados as $rot => $v) {
        $html .= '<div><div class="flex entre pequeno"><span>' . e($rot) . '</span><b>' . e($formatar($v)) . '</b></div>'
            . '<div class="barra-h"><span style="width:' . round($v / $max * 100, 1) . '%"></span></div></div>';
    }
    return $html . '</div>';
}
