<?php
/**
 * VELLUTO — Inicialização comum a todas as páginas.
 */
define('APP_ROOT', dirname(__DIR__));

require APP_ROOT . '/config/config.php';
require APP_ROOT . '/config/conexao.php';
require __DIR__ . '/temporadas.php';
require __DIR__ . '/funcoes.php';
require __DIR__ . '/carrossel.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/pedidos.php';

date_default_timezone_set(APP_TIMEZONE);
mb_internal_encoding('UTF-8');

if (APP_DEBUG) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
}

iniciarSessao();

// Proteção CSRF automática para qualquer envio POST.
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    verificarCsrf();
}
