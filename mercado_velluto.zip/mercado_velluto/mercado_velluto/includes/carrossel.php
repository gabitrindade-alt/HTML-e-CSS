<?php

function bannersPadrao(): array
{
    $campanha = temporadaAtual();
    $natal = $campanha['chave'] === 'natal';
    $linhas = [
        'temporada' => [$natal ? 'Natal' : 'Temporada', $natal ? 'Uma ceia para celebrar' : $campanha['titulo'],
            $natal ? 'Panetone, clássicos da ceia e enfeites para receber em casa.' : $campanha['texto'],
            $natal ? 'Ver ofertas de Natal' : 'Ver ofertas da temporada', '#ofertas-temporada',
            $natal ? 'ceia-velluto.jpg' : 'produtos/' . array_key_first($campanha['descontos']) . '.jpg',
            $natal ? 'Mesa da ceia com panetone, castanhas e ramos de pinheiro' : ''],
        'loja' => ['Loja', config('slogan', 'Tudo para sua casa, em um só lugar.'),
            'Alimentos, bebidas, limpeza, beleza, eletrônicos e muito mais.', 'Comprar agora', 'catalogo.php',
            'hero-mercearia.jpg', 'Pães, figos e azeite numa mesa de mercado'],
        'hortifruti' => ['Hortifruti', 'Direto do hortifruti', 'Encontre frutas, legumes e verduras para o dia a dia.',
            'Ver hortifruti', 'catalogo.php?q=hortifruti', 'hero-feira.jpg', 'Frutas e verduras frescas à luz da manhã'],
        'cesta' => ['Cesta', 'Sua cesta da semana', 'Escolha de frutas e pães a itens para cuidar da casa.',
            'Ver categorias', '#categorias-loja', 'hero-velluto.jpg', 'Cesta de feira com pães, verduras e frutas'],
        'padaria' => ['Padaria', 'Da nossa padaria', 'Pão francês, croissants e bolos para o seu café.',
            'Ver padaria', 'catalogo.php?q=padaria', 'hero-padaria.jpg', 'Croissants e pães recém-assados sobre uma bancada'],
    ];
    $banners = [];
    foreach ($linhas as $chave => [$rotulo, $titulo, $texto, $botao, $destino, $imagem, $alt]) {
        $ordem = (count($banners) + 1) * 10;
        $imagem = 'assets/img/' . $imagem;
        $ativo = 1;
        $banners[$chave] = compact('chave', 'rotulo', 'titulo', 'texto', 'botao', 'destino', 'imagem', 'alt', 'ordem', 'ativo');
    }
    return $banners;
}

function bannersCarrossel(): array
{
    $banners = bannersPadrao();
    foreach (db()->query('SELECT * FROM carrossel_banners') as $banner) {
        $banners[$banner['chave']] = $banner;
    }
    uasort($banners, static fn ($a, $b) => [$a['ordem'], $a['chave']] <=> [$b['ordem'], $b['chave']]);
    return $banners;
}

function opcoesCarrossel(): array
{
    $efeito = config('carrossel_efeito', 'deslizar');
    return [
        'automatico' => config('carrossel_auto', '1') === '1',
        'segundos' => max(3, min(30, (int) config('carrossel_segundos', 6))),
        'efeito' => in_array($efeito, ['deslizar', 'dissolver', 'nenhum'], true) ? $efeito : 'deslizar',
    ];
}

function fotoBanner(string $imagem): string
{
    return str_starts_with($imagem, 'assets/') ? asset(substr($imagem, 7)) : url($imagem);
}
