<?php
/** Página exibida quando um perfil tenta acessar a área de outro. */
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Acesso negado · Velluto</title>
<link rel="stylesheet" href="<?= e(asset('css/velluto.css')) ?>">
</head>
<body data-url-interno="<?= e(url('interno/index.php')) ?>">
<div class="container-estreito pagina texto-centro">
  <div class="cartao mt-3">
    <div class="vazio">
      <?= icone('cadeado', 'ico-lg') ?>
      <h1>Acesso negado</h1>
      <p>Seu perfil (<b><?= e(PERFIL_ROTULO[perfilAtual()] ?? '') ?></b>) não tem permissão para acessar esta área.<br>
        A tentativa foi registrada no histórico de alterações.</p>
      <a class="btn btn-primario" href="<?= e(url(painelDoPerfil((string) perfilAtual()))) ?>">Voltar ao meu painel</a>
      <a class="btn btn-neutro" href="<?= e(url('interno/sair.php')) ?>">Sair e trocar de perfil</a>
    </div>
  </div>
</div>
<script src="<?= e(asset('js/velluto.js')) ?>"></script>
<script src="<?= e(asset('js/preferencias.js')) ?>"></script>
</body>
</html>
