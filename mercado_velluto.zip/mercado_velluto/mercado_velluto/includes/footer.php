</main>
<footer class="rodape-site">
  <div class="container">
    <div class="rodape-grade">
      <div>
        <a class="logo" href="<?= e(url('index.php')) ?>"><img src="<?= e(asset('img/marca-velluto.svg')) ?>" alt=""><span class="logo-texto">VELLUTO</span></a>
        <p class="rodape-slogan"><?= e(config('slogan', '')) ?></p>
      </div>
      <div>
        <h4>Comprar</h4>
        <ul>
          <li><a href="<?= e(url('catalogo.php')) ?>">Todas as categorias</a></li>
          <li><a href="<?= e(url('catalogo.php?ofertas=1')) ?>">Ofertas da semana</a></li>
          <li><a href="<?= e(url('catalogo.php?ordem=novidades')) ?>">Novidades</a></li>
        </ul>
      </div>
      <div>
        <h4>Minha conta</h4>
        <ul>
          <li><a href="<?= e(url('cliente/pedidos.php')) ?>">Meus pedidos</a></li>
          <li><a href="<?= e(url('cliente/enderecos.php')) ?>">Endereços</a></li>
          <li><a href="<?= e(url('cliente/carrinho.php')) ?>">Carrinho</a></li>
        </ul>
      </div>
      <div>
        <h4>Atendimento</h4>
        <ul>
          <li><a href="<?= e(url('ajuda.php')) ?>">Central de ajuda</a></li>
          <li><a href="<?= e(url('ajuda.php#area')) ?>">Consultar área de entrega</a></li>
          <?php if ($emailContato = config('email_contato', '')): ?>
            <li><a href="mailto:<?= e($emailContato) ?>"><?= e($emailContato) ?></a></li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
    <div class="rodape-copy">
      <span>© <?= date('Y') ?> Velluto Hipermercado</span>
    </div>
  </div>
</footer>
<script src="<?= e(asset('js/velluto.js')) ?>"></script>
<script src="<?= e(asset('js/preferencias.js')) ?>"></script>
</body>
</html>
