<?php
/** Layout dos painéis internos. Variáveis: $titulo, $menuAtivo */
$u = usuarioLogado();
$perfil = $u['perfil'];
$menuAtivo = $menuAtivo ?? '';

$contagens = [];
if ($perfil === 'administrador') {
    $contagens['pedidos'] = (int) db()->query("SELECT COUNT(*) FROM pedidos WHERE status NOT IN ('concluido','cancelado')")->fetchColumn();
    $contagens['ocorrencias'] = (int) db()->query("SELECT COUNT(*) FROM ocorrencias WHERE status = 'aberta'")->fetchColumn();
    $contagens['estoque'] = (int) db()->query('SELECT COUNT(*) FROM produtos WHERE ativo = 1 AND estoque <= estoque_minimo')->fetchColumn();
} elseif ($perfil === 'separador') {
    $contagens['fila'] = (int) db()->query("SELECT COUNT(*) FROM pedidos WHERE status = 'aguardando_separacao'")->fetchColumn();
    $st = db()->prepare("SELECT COUNT(*) FROM pedidos WHERE separador_id = ? AND status = 'em_separacao'");
    $st->execute([$u['id']]);
    $contagens['meus'] = (int) $st->fetchColumn();
    $st = db()->prepare("SELECT COUNT(*) FROM pedidos WHERE separador_id = ? AND status = 'aguardando_aprovacao'");
    $st->execute([$u['id']]);
    $contagens['aguardando'] = (int) $st->fetchColumn();
} elseif ($perfil === 'entregador') {
    $contagens['disponiveis'] = (int) db()->query("SELECT COUNT(*) FROM entregas WHERE status = 'disponivel'")->fetchColumn();
    $st = db()->prepare("SELECT COUNT(*) FROM entregas WHERE entregador_id = ? AND status IN ('atribuida','em_rota')");
    $st->execute([$u['id']]);
    $contagens['rota'] = (int) $st->fetchColumn();
}

$menus = [
    'administrador' => [
        ['dashboard', 'interno/administrador/index.php', 'grafico', 'Dashboard'],
        ['carrossel', 'interno/administrador/carrossel.php', 'grade', 'Carrossel'],
        ['produtos', 'interno/administrador/produtos.php', 'etiqueta', 'Produtos'],
        ['categorias', 'interno/administrador/categorias.php', 'grade', 'Categorias'],
        ['estoque', 'interno/administrador/estoque.php', 'caixa', 'Estoque', 'estoque'],
        ['pedidos', 'interno/administrador/pedidos.php', 'lista', 'Pedidos', 'pedidos'],
        ['clientes', 'interno/administrador/clientes.php', 'usuario', 'Clientes'],
        ['funcionarios', 'interno/administrador/funcionarios.php', 'pessoas', 'Funcionários'],
        ['areas', 'interno/administrador/areas.php', 'mapa', 'Áreas e frete'],
        ['relatorios', 'interno/administrador/relatorios.php', 'documento', 'Relatórios'],
        ['ocorrencias', 'interno/administrador/ocorrencias.php', 'alerta', 'Ocorrências', 'ocorrencias'],
        ['historico', 'interno/administrador/historico.php', 'historico', 'Histórico de alterações'],
        ['configuracoes', 'interno/administrador/configuracoes.php', 'engrenagem', 'Configurações'],
    ],
    'separador' => [
        ['fila', 'interno/separador/index.php', 'lista', 'Pedidos para separar', 'fila'],
        ['meus', 'interno/separador/meus.php', 'caixa', 'Em separação', 'meus'],
        ['aguardando', 'interno/separador/meus.php?status=aguardando_aprovacao', 'ampulheta', 'Aguardando cliente', 'aguardando'],
        ['historico', 'interno/separador/historico.php', 'historico', 'Histórico'],
    ],
    'entregador' => [
        ['disponiveis', 'interno/entregador/index.php', 'caixa', 'Entregas disponíveis', 'disponiveis'],
        ['rota', 'interno/entregador/minhas.php', 'caminhao', 'Minhas entregas', 'rota'],
        ['ocorrencias', 'interno/entregador/ocorrencias.php', 'alerta', 'Ocorrências'],
        ['historico', 'interno/entregador/historico.php', 'historico', 'Histórico'],
    ],
];
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?= e(csrfToken()) ?>">
<meta name="robots" content="noindex">
<title><?= e($titulo ?? 'Painel') ?> · <?= e(PERFIL_ROTULO[$perfil]) ?> · Velluto</title>
<link rel="icon" href="<?= e(asset('img/marca-velluto.svg')) ?>" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<script>try{document.documentElement.dataset.theme=localStorage.getItem("velluto-theme")||"light";}catch(e){}</script>
<link rel="stylesheet" href="<?= e(asset('css/velluto.css')) ?>">
</head>
<body data-url-interno="<?= e(url('interno/index.php')) ?>">
<div class="painel">
  <aside class="painel-lateral" id="lateral">
    <a class="logo" href="<?= e(url(painelDoPerfil($perfil))) ?>"><img src="<?= e(asset('img/marca-velluto.svg')) ?>" alt=""><span class="logo-texto" style="font-size:1.35rem">VELLUTO</span></a>
    <span class="perfil-tag"><?= e(PERFIL_ROTULO[$perfil]) ?></span>
    <nav class="menu-painel">
      <?php foreach ($menus[$perfil] as $m): $n = isset($m[4]) ? ($contagens[$m[4]] ?? 0) : 0; ?>
        <a href="<?= e(url($m[1])) ?>" class="<?= $menuAtivo === $m[0] ? 'ativo' : '' ?>"><?= icone($m[2]) ?> <?= e($m[3]) ?>
          <?php if ($n): ?><span class="contador-menu"><?= $n ?></span><?php endif; ?></a>
      <?php endforeach; ?>
      <hr>
      <a href="<?= e(url('index.php')) ?>" target="_blank" rel="noopener"><?= icone('loja') ?> Ver loja</a>
      <a href="<?= e(url('interno/sair.php')) ?>"><?= icone('sair') ?> Sair</a>
    </nav>
  </aside>
  <div>
    <header class="painel-topo">
      <button class="btn-icone so-mobile" type="button" data-alternar="#lateral" aria-label="Menu"><?= icone('menu') ?></button>
      <strong><?= e($titulo ?? '') ?></strong>
      <span class="usuario-info"><?= icone('usuario', 'ico-sm') ?> <?= e($u['nome']) ?> · <?= e($u['email']) ?>
        <a class="btn btn-neutro btn-sm" href="<?= e(url('interno/sair.php')) ?>"><?= icone('sair', 'ico-sm') ?> Sair</a></span>
    </header>
    <?= str_replace('flash-area', 'flash-area" style="width:auto;margin:16px 28px 0', mostrarFlash()) ?>
    <main class="painel-conteudo" id="conteudo">
