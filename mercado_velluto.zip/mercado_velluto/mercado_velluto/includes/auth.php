<?php
/**
 * VELLUTO — Autenticação e controle de permissões por perfil.
 * Toda autorização é verificada no servidor (PHP).
 */

const PERFIS_INTERNOS = ['administrador', 'separador', 'entregador'];

function permiteCadastroInternoLocal(string $perfil): bool
{
    return APP_DEBUG && ehRequisicaoLocal() && in_array($perfil, ['separador', 'entregador'], true);
}

const PERFIL_ROTULO = [
    'cliente'       => 'Cliente',
    'administrador' => 'Administrador',
    'separador'     => 'Separador',
    'entregador'    => 'Entregador',
];

function usuarioLogado(): ?array
{
    return $_SESSION['usuario'] ?? null;
}

function perfilAtual(): ?string
{
    return $_SESSION['usuario']['perfil'] ?? null;
}

function clienteLogado(): bool
{
    return perfilAtual() === 'cliente';
}

/** Busca usuário por e-mail e confere a senha (password_verify). */
function autenticar(string $email, string $senha): ?array
{
    $st = db()->prepare('SELECT * FROM usuarios WHERE email = ? LIMIT 1');
    $st->execute([mb_strtolower(trim($email))]);
    $u = $st->fetch();
    if (!$u || !(int) $u['ativo'] || empty($u['senha_hash']) || !password_verify($senha, $u['senha_hash'])) {
        return null;
    }
    if (password_needs_rehash($u['senha_hash'], PASSWORD_DEFAULT)) {
        $up = db()->prepare('UPDATE usuarios SET senha_hash = ? WHERE id = ?');
        $up->execute([password_hash($senha, PASSWORD_DEFAULT), $u['id']]);
    }
    return $u;
}

function iniciarSessaoUsuario(array $u): void
{
    $carrinho = $_SESSION['carrinho'] ?? [];
    session_regenerate_id(true);
    $_SESSION = [];
    $_SESSION['usuario'] = [
        'id'     => (int) $u['id'],
        'nome'   => $u['nome'],
        'email'  => $u['email'],
        'perfil' => $u['perfil'],
    ];
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    $_SESSION['login_em'] = time();
    if ($u['perfil'] === 'cliente') {
        $_SESSION['carrinho'] = $carrinho; // mantém o carrinho do visitante
    }
    $st = db()->prepare('UPDATE usuarios SET ultimo_login = ? WHERE id = ?');
    $st->execute([agora(), $u['id']]);
}

function encerrarSessao(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'] ?? '', (bool) $p['secure'], (bool) $p['httponly']);
    }
    session_destroy();
}

/** Limita tentativas de login por sessão (proteção simples contra força bruta). */
function loginBloqueado(): bool
{
    $t = $_SESSION['tentativas_login'] ?? ['n' => 0, 'ate' => 0];
    return $t['ate'] > time();
}

function registrarFalhaLogin(): void
{
    $t = $_SESSION['tentativas_login'] ?? ['n' => 0, 'ate' => 0];
    $t['n']++;
    if ($t['n'] >= 5) {
        $t = ['n' => 0, 'ate' => time() + 60];
    }
    $_SESSION['tentativas_login'] = $t;
}

function limparFalhasLogin(): void
{
    unset($_SESSION['tentativas_login']);
}

/** Exige cliente autenticado; caso contrário envia ao login e retorna depois. */
function exigirCliente(): array
{
    $u = usuarioLogado();
    if (!$u || $u['perfil'] !== 'cliente') {
        if ($u && in_array($u['perfil'], PERFIS_INTERNOS, true)) {
            flash('erro', 'Esta área é exclusiva para clientes. Você está conectado como ' . PERFIL_ROTULO[$u['perfil']] . '.');
            redirecionar(painelDoPerfil($u['perfil']));
        }
        $destino = ltrim(substr($_SERVER['REQUEST_URI'] ?? '', strlen(baseUrl())), '/');
        flash('info', 'Entre na sua conta para continuar.');
        redirecionar('cliente/login.php?voltar=' . urlencode($destino));
    }
    return $u;
}

/** Exige um perfil interno específico. Bloqueia acesso cruzado entre perfis. */
function exigirPerfil(string $perfil): array
{
    $u = usuarioLogado();
    if (!$u) {
        flash('info', 'Faça login como ' . PERFIL_ROTULO[$perfil] . ' para acessar este painel.');
        redirecionar('interno/login.php?perfil=' . $perfil);
    }
    if ($u['perfil'] !== $perfil) {
        http_response_code(403);
        registrarTentativaAcessoNegado($u, $perfil);
        require APP_ROOT . '/includes/acesso_negado.php';
        exit;
    }
    // Confere no banco se o usuário continua ativo e com o mesmo perfil.
    $st = db()->prepare('SELECT ativo, perfil FROM usuarios WHERE id = ?');
    $st->execute([$u['id']]);
    $r = $st->fetch();
    if (!$r || !(int) $r['ativo'] || $r['perfil'] !== $perfil) {
        encerrarSessao();
        iniciarSessao();
        flash('erro', 'Seu acesso foi alterado. Entre novamente.');
        redirecionar('interno/login.php?perfil=' . $perfil);
    }
    return $u;
}

function registrarTentativaAcessoNegado(array $u, string $perfilExigido): void
{
    try {
        $st = db()->prepare('INSERT INTO logs_alteracoes (usuario_id, entidade, entidade_id, acao, detalhes, ip, criado_em) VALUES (?,?,?,?,?,?,?)');
        $st->execute([$u['id'], 'acesso', null, 'acesso_negado',
            'Perfil ' . $u['perfil'] . ' tentou acessar área de ' . $perfilExigido . ' (' . ($_SERVER['REQUEST_URI'] ?? '') . ')',
            $_SERVER['REMOTE_ADDR'] ?? null, agora()]);
    } catch (Throwable $e) {
        // registro de auditoria não deve interromper a resposta
    }
}

function painelDoPerfil(string $perfil): string
{
    return match ($perfil) {
        'administrador' => 'interno/administrador/index.php',
        'separador'     => 'interno/separador/index.php',
        'entregador'    => 'interno/entregador/index.php',
        default         => 'index.php',
    };
}
