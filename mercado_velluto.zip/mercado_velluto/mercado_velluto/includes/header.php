<?php
/** Cabeçalho das páginas públicas e do cliente. Variáveis: $titulo, $ativo */
$titulo = $titulo ?? APP_NOME;
$ativo = $ativo ?? '';
$u = usuarioLogado();
$qtdCarrinho = carrinhoQuantidadeItens();
$pendencias = ($u && $u['perfil'] === 'cliente') ? pendenciasCliente((int) $u['id']) : 0;
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?= e(csrfToken()) ?>">
<title><?= e($titulo) ?> · <?= e(config('nome_loja', APP_NOME)) ?></title>
<meta name="description" content="Velluto — hipermercado online: alimentos, bebidas, limpeza, beleza, eletrônicos e muito mais.">
<link rel="icon" href="<?= e(asset('img/marca-velluto.svg')) ?>" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<script>try{document.documentElement.dataset.theme=localStorage.getItem("velluto-theme")||"light";}catch(e){}</script>
<link rel="stylesheet" href="<?= e(asset('css/velluto.css')) ?>">
</head>
<body data-url-interno="<?= e(url('interno/index.php')) ?>">
<a class="sr-only" href="#conteudo">Pular para o conteúdo</a>
<div class="faixa-topo"><?= e(config('aviso_topo', '')) ?></div>

<div class="topo-login">
  <div class="container">
    <?php if ($u && $u['perfil'] === 'cliente'): ?>
      <span>Olá, <b><?= e(explode(' ', $u['nome'])[0]) ?></b>! Que bom ter você aqui.</span>
      <span class="flex">
        <?php if ($pendencias): ?><a href="<?= e(url('cliente/pedidos.php')) ?>" class="badge st-aguardando_aprovacao"><?= $pendencias ?> pedido(s) aguardando sua aprovação</a><?php endif; ?>
        <a href="<?= e(url('cliente/pedidos.php')) ?>">Meus pedidos</a> ·
        <a href="<?= e(url('cliente/sair.php')) ?>">Sair</a>
      </span>
    <?php elseif ($u): ?>
      <span>Conectado como <b><?= e(PERFIL_ROTULO[$u['perfil']]) ?></b>.</span>
      <a href="<?= e(url(painelDoPerfil($u['perfil']))) ?>">Ir para o painel →</a>
    <?php else: ?>
      <span>Bem-vindo(a) ao Velluto! Entre para comprar e acompanhar seus pedidos.</span>
      <span><a href="<?= e(url('cliente/login.php')) ?>">Entrar</a> · <a href="<?= e(url('cliente/cadastro.php')) ?>">Criar conta</a></span>
    <?php endif; ?>
  </div>
</div>

<header class="cabecalho">
  <div class="container">
    <button class="btn-icone menu-mobile-btn" type="button" data-alternar="#nav-principal" aria-label="Menu"><?= icone('menu') ?></button>
    <a class="logo" href="<?= e(url('index.php')) ?>" aria-label="Velluto — página inicial">
      <img src="<?= e(asset('img/marca-velluto.svg')) ?>" alt="">
      <span class="logo-texto">VELLUTO<small>hipermercado</small></span>
    </a>
    <nav class="nav-principal" id="nav-principal" aria-label="Principal">
      <a href="<?= e(url('catalogo.php')) ?>" class="<?= $ativo === 'categorias' ? 'ativo' : '' ?>">Categorias</a>
      <a href="<?= e(url('catalogo.php?ofertas=1')) ?>" class="<?= $ativo === 'ofertas' ? 'ativo' : '' ?>">Ofertas</a>
      <a href="<?= e(url('catalogo.php?ordem=novidades')) ?>" class="<?= $ativo === 'novidades' ? 'ativo' : '' ?>">Novidades</a>
      <a href="<?= e(url('ajuda.php')) ?>" class="<?= $ativo === 'ajuda' ? 'ativo' : '' ?>">Ajuda</a>
    </nav>
    <form class="busca" action="<?= e(url('catalogo.php')) ?>" method="get" role="search">
      <label class="sr-only" for="busca-topo">Buscar produtos</label>
      <input id="busca-topo" type="search" name="q" placeholder="Buscar produtos, marcas…" value="<?= e(get('q')) ?>">
      <button type="submit" aria-label="Buscar"><?= icone('busca') ?></button>
    </form>
    <div class="acoes-topo">
      <?php if ($u && $u['perfil'] === 'cliente'): ?>
        <div class="dropdown">
          <button class="btn-icone" type="button" data-dropdown aria-label="Minha conta" aria-expanded="false"><?= icone('usuario') ?>
            <?php if ($pendencias): ?><span class="contador alerta"><?= $pendencias ?></span><?php endif; ?></button>
          <div class="dropdown-painel">
            <h4><?= e($u['nome']) ?></h4>
            <nav class="menu-conta">
              <a href="<?= e(url('cliente/pedidos.php')) ?>"><?= icone('caixa') ?> Meus pedidos</a>
              <a href="<?= e(url('cliente/conta.php')) ?>"><?= icone('usuario') ?> Meus dados</a>
              <a href="<?= e(url('cliente/enderecos.php')) ?>"><?= icone('local') ?> Endereços</a>
              <a href="<?= e(url('cliente/favoritos.php')) ?>"><?= icone('coracao') ?> Favoritos</a>
              <a href="<?= e(url('cliente/sair.php')) ?>"><?= icone('sair') ?> Sair</a>
            </nav>
          </div>
        </div>
      <?php elseif (!$u): ?>
        <div class="dropdown">
          <button class="btn-icone" type="button" data-dropdown aria-label="Entrar" aria-expanded="false"><?= icone('usuario') ?></button>
          <div class="dropdown-painel">
            <h4>Acesse sua conta</h4>
            <form method="post" action="<?= e(url('cliente/login.php')) ?>">
              <?= csrfCampo() ?>
              <div class="campo"><label for="dd-email">E-mail</label><input id="dd-email" type="email" name="email" required autocomplete="email"></div>
              <div class="campo"><label for="dd-senha">Senha</label><input id="dd-senha" type="password" name="senha" required autocomplete="current-password"></div>
              <button class="btn btn-primario btn-bloco" type="submit">Entrar</button>
            </form>
            <p class="pequeno mt-1 mb-0"><a href="<?= e(url('cliente/recuperar.php')) ?>">Esqueci minha senha</a> · <a href="<?= e(url('cliente/cadastro.php')) ?>">Cadastre-se</a></p>
          </div>
        </div>
      <?php endif; ?>
      <a class="btn-icone" href="<?= e(url('cliente/favoritos.php')) ?>" aria-label="Favoritos"><?= icone('coracao') ?></a>
      <a class="btn-icone" href="<?= e(url('cliente/carrinho.php')) ?>" aria-label="Carrinho"><?= icone('carrinho') ?>
        <?php if ($qtdCarrinho): ?><span class="contador"><?= $qtdCarrinho ?></span><?php endif; ?></a>
    </div>
  </div>
</header>
<?= mostrarFlash() ?>
<main id="conteudo">
