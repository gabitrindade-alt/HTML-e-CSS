    </div>
    <div class="auth-img"><img src="<?= e(url('assets/img/hero-velluto.jpg')) ?>" alt=""></div>
  </div>
</div>
