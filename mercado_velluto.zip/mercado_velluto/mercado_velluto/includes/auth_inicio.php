<?php /** Abertura do layout das telas de Login / Cadastro / Recuperar senha. Variável: $aba */ ?>
<div class="container pagina">
  <div class="auth">
    <div class="auth-form">
      <nav class="auth-abas">
        <a href="<?= e(url('cliente/login.php')) ?>" class="<?= $aba === 'login' ? 'ativa' : '' ?>">Login</a>
        <a href="<?= e(url('cliente/cadastro.php')) ?>" class="<?= $aba === 'cadastro' ? 'ativa' : '' ?>">Cadastro</a>
        <a href="<?= e(url('cliente/recuperar.php')) ?>" class="<?= $aba === 'recuperar' ? 'ativa' : '' ?>">Recuperar senha</a>
      </nav>
