<?php
/**
 * VELLUTO — Funções utilitárias reutilizáveis.
 */

/* ---------------------------------------------------------------
 * Sessão, URLs e redirecionamentos
 * ------------------------------------------------------------- */

function iniciarSessao(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    session_name('VELLUTOSESS');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    session_start();
}

function baseUrl(): string
{
    static $base = null;
    if ($base !== null) {
        return $base;
    }
    if (BASE_URL_MANUAL !== '') {
        return $base = rtrim(BASE_URL_MANUAL, '/');
    }
    $raiz    = str_replace('\\', '/', (string) realpath(APP_ROOT));
    $docRoot = str_replace('\\', '/', (string) realpath($_SERVER['DOCUMENT_ROOT'] ?? ''));
    if ($docRoot !== '' && stripos($raiz, $docRoot) === 0) {
        $base = substr($raiz, strlen($docRoot));
    } else {
        $base = '/velluto';
    }
    return $base = rtrim($base, '/');
}

function url(string $caminho = ''): string
{
    return baseUrl() . '/' . ltrim($caminho, '/');
}

function asset(string $caminho): string
{
    $arquivo = APP_ROOT . '/assets/' . ltrim($caminho, '/');
    $versao  = is_file($arquivo) ? filemtime($arquivo) : '1';
    return url('assets/' . ltrim($caminho, '/')) . '?v=' . $versao;
}

function redirecionar(string $caminho): never
{
    if (!preg_match('#^https?://#', $caminho) && !str_starts_with($caminho, baseUrl() . '/')) {
        $caminho = url($caminho);
    }
    header('Location: ' . $caminho);
    exit;
}

/** Volta para a página anterior (somente se for do próprio site). */
function voltar(string $padrao = 'index.php'): never
{
    $ref = $_SERVER['HTTP_REFERER'] ?? '';
    $host = $_SERVER['HTTP_HOST'] ?? '';
    if ($ref !== '' && parse_url($ref, PHP_URL_HOST) === parse_url('http://' . $host, PHP_URL_HOST)) {
        header('Location: ' . $ref);
        exit;
    }
    redirecionar($padrao);
}

/** Aceita apenas caminhos internos relativos para redirecionamento pós-login. */
function destinoSeguro(?string $destino, string $padrao): string
{
    $destino = (string) $destino;
    if ($destino === '' || preg_match('#^(https?:)?//#i', $destino) || str_contains($destino, '..') || str_contains($destino, "\n")) {
        return $padrao;
    }
    return ltrim($destino, '/');
}

/* ---------------------------------------------------------------
 * Escape, entrada e mensagens
 * ------------------------------------------------------------- */

function e($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function post(string $chave, $padrao = '')
{
    $v = $_POST[$chave] ?? $padrao;
    return is_string($v) ? trim($v) : $v;
}

function get(string $chave, $padrao = '')
{
    $v = $_GET[$chave] ?? $padrao;
    return is_string($v) ? trim($v) : $v;
}

function apenasDigitos(?string $v): string
{
    return preg_replace('/\D+/', '', (string) $v);
}

function flash(string $tipo, string $mensagem): void
{
    $_SESSION['flash'][] = ['tipo' => $tipo, 'msg' => $mensagem];
}

function mostrarFlash(): string
{
    if (empty($_SESSION['flash'])) {
        return '';
    }
    $html = '<div class="flash-area">';
    foreach ($_SESSION['flash'] as $f) {
        $html .= '<div class="flash flash-' . e($f['tipo']) . '" role="status">' . e($f['msg']) .
            '<button type="button" class="flash-fechar" aria-label="Fechar">×</button></div>';
    }
    unset($_SESSION['flash']);
    return $html . '</div>';
}

/* ---------------------------------------------------------------
 * CSRF
 * ------------------------------------------------------------- */

function csrfToken(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrfCampo(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrfToken()) . '">';
}

function verificarCsrf(): void
{
    $enviado = $_POST['csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!is_string($enviado) || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $enviado)) {
        http_response_code(419);
        exit('<p style="font-family:sans-serif;padding:40px">Sessão expirada ou formulário inválido. '
            . '<a href="javascript:history.back()">Volte</a> e tente novamente.</p>');
    }
}

/* ---------------------------------------------------------------
 * Formatação
 * ------------------------------------------------------------- */

function dinheiro($valor): string
{
    return 'R$ ' . number_format((float) $valor, 2, ',', '.');
}

function numeroBr($valor, int $casas = 2): string
{
    return number_format((float) $valor, $casas, ',', '.');
}

/** Converte "1.234,56" ou "1234.56" em float. */
function paraNumero($valor): float
{
    $v = trim((string) $valor);
    if ($v === '') {
        return 0.0;
    }
    if (str_contains($v, ',')) {
        $v = str_replace('.', '', $v);
        $v = str_replace(',', '.', $v);
    }
    return is_numeric($v) ? (float) $v : 0.0;
}

function qtdFormatada($qtd, string $vendidoPor): string
{
    $q = (float) $qtd;
    if ($vendidoPor === 'peso') {
        return rtrim(rtrim(number_format($q, 3, ',', '.'), '0'), ',') . ' kg';
    }
    return (string) (int) round($q) . ' un';
}

function dataBr(?string $data, bool $comHora = true): string
{
    if (!$data) {
        return '—';
    }
    $t = strtotime($data);
    return $t ? date($comHora ? 'd/m/Y H:i' : 'd/m/Y', $t) : '—';
}

function agora(): string
{
    return date('Y-m-d H:i:s');
}

function cepFormatado(?string $cep): string
{
    $c = apenasDigitos($cep);
    return strlen($c) === 8 ? substr($c, 0, 5) . '-' . substr($c, 5) : $c;
}

function slugify(string $texto): string
{
    $t = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $texto);
    $t = strtolower((string) $t);
    $t = preg_replace('/[^a-z0-9]+/', '-', $t);
    return trim((string) $t, '-') ?: 'item';
}

function validarCpf(string $cpf): bool
{
    $cpf = apenasDigitos($cpf);
    if (strlen($cpf) !== 11 || preg_match('/^(\d)\1{10}$/', $cpf)) {
        return false;
    }
    for ($t = 9; $t < 11; $t++) {
        $soma = 0;
        for ($c = 0; $c < $t; $c++) {
            $soma += (int) $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $soma) % 11) % 10;
        if ((int) $cpf[$t] !== $d) {
            return false;
        }
    }
    return true;
}

/** Valida número de cartão (algoritmo de Luhn) — usado apenas na simulação. */
function validarLuhn(string $numero): bool
{
    $n = apenasDigitos($numero);
    if (strlen($n) < 13 || strlen($n) > 19) {
        return false;
    }
    $soma = 0;
    $alternar = false;
    for ($i = strlen($n) - 1; $i >= 0; $i--) {
        $d = (int) $n[$i];
        if ($alternar) {
            $d *= 2;
            if ($d > 9) {
                $d -= 9;
            }
        }
        $soma += $d;
        $alternar = !$alternar;
    }
    return $soma % 10 === 0;
}

/* ---------------------------------------------------------------
 * Configurações e registros
 * ------------------------------------------------------------- */

function config(string $chave, $padrao = null)
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (db()->query('SELECT chave, valor FROM configuracoes') as $l) {
            $cache[$l['chave']] = $l['valor'];
        }
    }
    return $cache[$chave] ?? $padrao;
}

/** Histórico de alterações administrativas (auditoria). */
function registrarAlteracao(string $entidade, ?int $entidadeId, string $acao, string $detalhes = ''): void
{
    $u = usuarioLogado();
    $st = db()->prepare('INSERT INTO logs_alteracoes (usuario_id, entidade, entidade_id, acao, detalhes, ip, criado_em)
                         VALUES (?, ?, ?, ?, ?, ?, ?)');
    $st->execute([
        $u['id'] ?? null, $entidade, $entidadeId, $acao, mb_substr($detalhes, 0, 2000),
        $_SERVER['REMOTE_ADDR'] ?? null, agora(),
    ]);
}

/* ---------------------------------------------------------------
 * Produtos
 * ------------------------------------------------------------- */

function precoAtual(array $p): float
{
    $normal = (float) $p['preco'];
    $promo = (float) ($p['preco_promocional'] ?? 0);
    $desconto = temporadaAtual()['descontos'][$p['slug'] ?? ''] ?? 0;
    $sazonal = round($normal * (100 - $desconto) / 100, 2);
    return min($promo > 0 ? $promo : $normal, $sazonal);
}

function emPromocao(array $p): bool
{
    return precoAtual($p) < (float) $p['preco'];
}

function imagemProduto(array $p): string
{
    $img = (string) ($p['imagem'] ?? '');
    if (preg_match('~^assets/img/produtos/[a-z0-9-]+\.svg$~D', $img)) {
        $foto = substr($img, 0, -4) . '.jpg';
        if (is_file(APP_ROOT . '/' . $foto)) {
            return url($foto);
        }
    }
    if ($img !== '' && is_file(APP_ROOT . '/' . $img)) {
        return url($img);
    }
    return url('assets/img/hero-velluto.jpg');
}

function visualCategoria(array $categoria): string
{
    $produto = match ($categoria['slug']) {
        'alimentos', 'mercearia' => 'arroz-tipo-1',
        'bebidas' => 'suco-de-uva-integral',
        'hortifruti' => 'morango',
        'carnes' => 'picanha-bovina',
        'padaria' => 'croissant-de-manteiga',
        'limpeza' => 'sabao-liquido-para-roupas',
        'higiene' => 'sabonete-erva-doce',
        'beleza' => 'batom-matte-rose',
        'eletronicos' => 'fone-de-ouvido-bluetooth',
        'eletrodomesticos' => 'air-fryer-4-l',
        'roupas' => 'camiseta-basica-de-algodao',
        'casa-decoracao' => 'caneca-de-ceramica',
        'pet' => 'racao-para-caes-adultos',
        'bebes' => 'mamadeira',
        'laticinios' => 'queijo-mucarela-fatiado',
        'congelados' => 'pizza-margherita',
        'enlatados' => 'milho-verde',
        default => null,
    };
    if ($produto === null) {
        return '<span class="categoria-icone" aria-hidden="true">' . e($categoria['icone']) . '</span>';
    }
    return '<span class="categoria-icone foto-categoria"><img src="' .
        e(url('assets/img/produtos/' . $produto . '.jpg')) . '" alt="" loading="lazy"></span>';
}

function unidadePreco(array $p): string
{
    return ($p['vendido_por'] ?? 'unidade') === 'peso' ? '/kg' : '';
}

function estoqueBaixo(array $p): bool
{
    return (float) $p['estoque'] <= (float) $p['estoque_minimo'];
}

/** Passo e mínimo de quantidade conforme forma de venda. */
function passoQtd(array $p): array
{
    return ($p['vendido_por'] ?? 'unidade') === 'peso' ? ['min' => 0.25, 'passo' => 0.25] : ['min' => 1, 'passo' => 1];
}

/** Quantidade sugerida ao adicionar: 1 unidade ou 1 kg (limitado ao estoque). */
function qtdPadrao(array $p): float
{
    if (($p['vendido_por'] ?? 'unidade') === 'peso') {
        return max(0.25, min(1.0, floor((float) $p['estoque'] * 4) / 4));
    }
    return 1.0;
}

function normalizarQtd(array $p, $qtd): float
{
    $q = paraNumero($qtd);
    if (($p['vendido_por'] ?? 'unidade') === 'peso') {
        $q = round($q * 4) / 4; // múltiplos de 250 g
        return max(0.0, min($q, 50.0));
    }
    return (float) max(0, min((int) floor($q), 99));
}

/* ---------------------------------------------------------------
 * Ícones (sprite SVG)
 * ------------------------------------------------------------- */

function icone(string $nome, string $classe = 'ico'): string
{
    return '<svg class="' . e($classe) . '" aria-hidden="true"><use href="' . e(url('assets/icons/icones.svg')) . '#' . e($nome) . '"></use></svg>';
}

/* ---------------------------------------------------------------
 * Paginação
 * ------------------------------------------------------------- */

function paginacao(int $total, int $pagina, int $porPagina, array $params): string
{
    $paginas = (int) ceil($total / max(1, $porPagina));
    if ($paginas <= 1) {
        return '';
    }
    $html = '<nav class="paginacao" aria-label="Paginação">';
    for ($i = 1; $i <= $paginas; $i++) {
        $params['pagina'] = $i;
        $href = '?' . http_build_query($params);
        $html .= $i === $pagina
            ? '<span class="pag atual">' . $i . '</span>'
            : '<a class="pag" href="' . e($href) . '">' . $i . '</a>';
    }
    return $html . '</nav>';
}

/* ---------------------------------------------------------------
 * Carrinho (armazenado na sessão)
 * ------------------------------------------------------------- */

function carrinho(): array
{
    return $_SESSION['carrinho'] ?? [];
}

function carrinhoQuantidadeItens(): int
{
    return count(carrinho());
}

/**
 * Retorna os itens do carrinho com dados atualizados do banco.
 * Cada item: produto, qtd, preco, subtotal, disponivel(bool), aviso
 */
function carrinhoDetalhado(): array
{
    $c = carrinho();
    if (!$c) {
        return ['itens' => [], 'subtotal' => 0.0, 'problemas' => 0];
    }
    $ids = array_map('intval', array_keys($c));
    $marc = implode(',', array_fill(0, count($ids), '?'));
    $st = db()->prepare("SELECT p.*, c.nome AS categoria_nome FROM produtos p
                         JOIN categorias c ON c.id = p.categoria_id WHERE p.id IN ($marc)");
    $st->execute($ids);
    $produtos = [];
    foreach ($st as $p) {
        $produtos[(int) $p['id']] = $p;
    }
    $itens = [];
    $subtotal = 0.0;
    $problemas = 0;
    foreach ($c as $id => $qtd) {
        $id = (int) $id;
        if (!isset($produtos[$id])) {
            unset($_SESSION['carrinho'][$id]);
            continue;
        }
        $p = $produtos[$id];
        $preco = precoAtual($p);
        $sub = round($preco * (float) $qtd, 2);
        $aviso = '';
        $ok = true;
        if (!(int) $p['ativo']) {
            $ok = false;
            $aviso = 'Produto indisponível no momento.';
        } elseif ((float) $p['estoque'] <= 0) {
            $ok = false;
            $aviso = 'Sem estoque.';
        } elseif ((float) $qtd > (float) $p['estoque']) {
            $ok = false;
            $aviso = 'Disponível apenas ' . qtdFormatada($p['estoque'], $p['vendido_por']) . '.';
        }
        if (!$ok) {
            $problemas++;
        } else {
            $subtotal += $sub;
        }
        $itens[] = ['produto' => $p, 'qtd' => (float) $qtd, 'preco' => $preco, 'subtotal' => $sub, 'disponivel' => $ok, 'aviso' => $aviso];
    }
    return ['itens' => $itens, 'subtotal' => round($subtotal, 2), 'problemas' => $problemas];
}

/* ---------------------------------------------------------------
 * Área de entrega e frete
 * ------------------------------------------------------------- */

function areaPorCep(string $cep): ?array
{
    $cep = apenasDigitos($cep);
    if (strlen($cep) !== 8) {
        return null;
    }
    $st = db()->prepare('SELECT * FROM areas_entrega WHERE ativo = 1 AND ? BETWEEN cep_inicio AND cep_fim ORDER BY valor_frete ASC LIMIT 1');
    $st->execute([$cep]);
    return $st->fetch() ?: null;
}

/** Opções de frete calculadas a partir da área e do subtotal. */
function opcoesFrete(array $area, float $subtotal): array
{
    $gratisAcima = $area['frete_gratis_acima'] !== null ? (float) $area['frete_gratis_acima'] : null;
    $padrao = (float) $area['valor_frete'];
    $gratis = $gratisAcima !== null && $gratisAcima > 0 && $subtotal >= $gratisAcima;
    $opcoes = [
        'padrao' => [
            'rotulo' => 'Padrão',
            'prazo'  => $area['prazo_padrao'],
            'valor'  => $gratis ? 0.0 : $padrao,
            'obs'    => $gratis ? 'Frete grátis (compras acima de ' . dinheiro($gratisAcima) . ')'
                : ($gratisAcima ? 'Grátis em compras acima de ' . dinheiro($gratisAcima) : ''),
        ],
    ];
    if ($area['valor_expresso'] !== null && (float) $area['valor_expresso'] > 0) {
        $opcoes['expresso'] = [
            'rotulo' => 'Expresso',
            'prazo'  => $area['prazo_expresso'],
            'valor'  => (float) $area['valor_expresso'],
            'obs'    => '',
        ];
    }
    return $opcoes;
}

/* ---------------------------------------------------------------
 * Diversos
 * ------------------------------------------------------------- */

function categoriasMenu(): array
{
    static $cats = null;
    if ($cats === null) {
        $cats = db()->query('SELECT * FROM categorias WHERE ativo = 1 AND pai_id IS NULL ORDER BY ordem, nome')->fetchAll();
    }
    return $cats;
}

/** IDs da categoria e de suas subcategorias. */
function idsCategoriaComFilhas(int $categoriaId): array
{
    $st = db()->prepare('SELECT id FROM categorias WHERE (id = ? OR pai_id = ?) AND ativo = 1');
    $st->execute([$categoriaId, $categoriaId]);
    return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
}

/** IDs dos produtos favoritos do cliente logado. */
function idsFavoritos(): array
{
    static $ids = null;
    if ($ids !== null) {
        return $ids;
    }
    $u = usuarioLogado();
    if (!$u || $u['perfil'] !== 'cliente') {
        return $ids = [];
    }
    $st = db()->prepare('SELECT produto_id FROM favoritos WHERE usuario_id = ?');
    $st->execute([$u['id']]);
    return $ids = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
}

/** Renderiza o cartão de produto (reutilizado em várias telas). */
function cartaoProduto(array $p): string
{
    ob_start();
    include APP_ROOT . '/includes/produto_card.php';
    return (string) ob_get_clean();
}

/** Indicador de etapas do checkout (1 Carrinho, 2 Endereço e frete, 3 Pagamento, 4 Confirmação). */
function passosCheckout(int $atual): string
{
    $nomes = [1 => 'Carrinho', 2 => 'Endereço e frete', 3 => 'Pagamento', 4 => 'Confirmação'];
    $html = '<ol class="passos" style="list-style:none;padding:0">';
    foreach ($nomes as $n => $nome) {
        $cls = $n < $atual ? 'feito' : ($n === $atual ? 'atual' : '');
        $html .= '<li class="passo ' . $cls . '"><span class="bola">' . ($n < $atual ? icone('check') : '') . '</span>' . e($nome) . '</li>';
    }
    return $html . '</ol>';
}

function ehRequisicaoLocal(): bool
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    return in_array($ip, ['127.0.0.1', '::1'], true);
}
