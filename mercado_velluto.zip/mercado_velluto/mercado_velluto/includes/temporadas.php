<?php
/** Campanhas recorrentes pelo calendário local da loja. */

function temporadaEm(DateTimeImmutable $dia): array
{
    $mes = (int) $dia->format('n');
    $ano = (int) $dia->format('Y');
    $chave = match (true) {
        $dia->format('m-d') >= '11-15' => 'natal',
        $mes <= 2 => 'verao',
        $mes === 6 => 'junina',
        $mes === 10 => 'halloween',
        $mes <= 5 => 'outono',
        $mes <= 8 => 'inverno',
        default => 'primavera',
    };
    if ($mes >= 2 && $mes <= 4) {
        $pascoa = $dia->setDate($ano, 3, 21)->setTime(0, 0)
            ->modify('+' . easter_days($ano, CAL_EASTER_ALWAYS_GREGORIAN) . ' days');
        $data = $dia->setTime(0, 0);
        if ($data >= $pascoa->modify('-28 days') && $data <= $pascoa) {
            $chave = 'pascoa';
        }
    }
    [$titulo, $texto, $descontos] = match ($chave) {
        'natal' => ['Natal Velluto', 'Alimentos para a ceia e enfeites para receber em casa.', [
            'panetone-frutas' => 20, 'chocotone-gotas' => 20, 'suco-maca-espumante' => 15, 'mix-castanhas-ceia' => 15,
            'peru-temperado-natal' => 15, 'lombo-suino-natal' => 12, 'farofa-natalina' => 15,
            'ameixa-seca' => 10, 'cerejas-frescas' => 12, 'azeitonas-verdes-ceia' => 10,
            'guirlanda-natal' => 20, 'bolas-natal' => 15, 'pisca-led-natal' => 15,
            'vela-canela-natal' => 12, 'toalha-mesa-natal' => 15, 'mini-arvore-natal' => 20,
        ]],
        'verao' => ['Ofertas de verão', 'Frutas e bebidas para os dias quentes.', [
            'abacaxi-perola' => 15, 'agua-com-gas' => 10, 'polpa-de-acai' => 15, 'suco-de-laranja' => 12,
        ]],
        'pascoa' => ['Páscoa Velluto', 'Chocolate para presentear e ingredientes para a mesa.', [
            'ovo-pascoa-chocolate' => 20, 'salmao-em-posta' => 12, 'azeite-extravirgem' => 15, 'geleia-de-morango' => 10,
        ]],
        'outono' => ['Ofertas de outono', 'Ingredientes para sopas e para o café da tarde.', [
            'lentilha-seca' => 12, 'cha-de-camomila' => 15, 'cenoura' => 10, 'pao-de-fermentacao-natural' => 12,
        ]],
        'junina' => ['Arraiá Velluto', 'Paçoca, canjica e mais sabores de festa junina.', [
            'pacoca-junina' => 20, 'canjica-branca' => 15, 'milho-verde' => 10, 'bolo-de-laranja' => 12,
        ]],
        'inverno' => ['Ofertas de inverno', 'Chá, pão e ingredientes para refeições quentes.', [
            'cha-de-camomila' => 18, 'mel-silvestre' => 15, 'massa-penne' => 10, 'pao-de-queijo-congelado' => 15,
        ]],
        'primavera' => ['Ofertas de primavera', 'Frutas frescas e acompanhamentos para a estação.', [
            'mirtilo-fresco' => 15, 'manga-palmer' => 10, 'iogurte-grego-morango' => 12, 'granola-castanhas' => 15,
        ]],
        'halloween' => ['Halloween Velluto', 'Guloseimas e opções para a mesa da festa.', [
            'gomas-halloween' => 20, 'sorvete-de-creme' => 12, 'rolinho-de-canela' => 10, 'refrigerante-de-cola' => 12,
        ]],
    };
    return ['chave' => $chave, 'titulo' => $titulo, 'texto' => $texto, 'descontos' => $descontos];
}

function temporadaAtual(): array
{
    static $campanha;
    return $campanha ??= temporadaEm(new DateTimeImmutable('today'));
}

/** Mantém os filtros e a ordenação SQL coerentes com o preço do carrinho. */
function precoAtualSql(): string
{
    $regular = '(CASE WHEN p.preco_promocional > 0 AND p.preco_promocional < p.preco THEN p.preco_promocional ELSE p.preco END)';
    $casos = [];
    foreach (temporadaAtual()['descontos'] as $slug => $desconto) {
        $fator = sprintf('0.%02d', 100 - $desconto);
        $valor = "ROUND(p.preco * $fator, 2)";
        $casos[] = 'WHEN p.slug = ' . db()->quote($slug) . " AND $valor < $regular THEN $valor";
    }
    return '(CASE ' . implode(' ', $casos) . " ELSE $regular END)";
}
