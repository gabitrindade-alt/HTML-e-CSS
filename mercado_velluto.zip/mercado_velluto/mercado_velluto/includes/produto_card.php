<?php
/** Cartão de produto. Recebe $p (linha da tabela produtos). */
$fav = in_array((int) $p['id'], idsFavoritos(), true);
$passo = passoQtd($p);
$semEstoque = (float) $p['estoque'] <= 0;
$link = url('produto.php?id=' . (int) $p['id']);
?>
<article class="produto-card">
  <?php if (emPromocao($p)): ?><span class="selo-promo">-<?= (int) round((1 - precoAtual($p) / (float) $p['preco']) * 100) ?>%</span><?php endif; ?>
  <form method="post" action="<?= e(url('acoes/favorito.php')) ?>">
    <?= csrfCampo() ?><input type="hidden" name="produto_id" value="<?= (int) $p['id'] ?>">
    <button class="btn-fav <?= $fav ? 'ativo' : '' ?>" type="submit" aria-label="<?= $fav ? 'Remover dos favoritos' : 'Adicionar aos favoritos' ?>" title="Favoritar"><?= icone('coracao') ?></button>
  </form>
  <a class="foto" href="<?= e($link) ?>"><img src="<?= e(imagemProduto($p)) ?>" alt="<?= e($p['nome']) ?>" loading="lazy"></a>
  <div class="info">
    <a class="nome" href="<?= e($link) ?>"><?= e($p['nome']) ?></a>
    <span class="emb"><?= e($p['embalagem'] ?? '') ?></span>
    <div class="preco">
      <?php if (emPromocao($p)): ?><span class="preco-antigo"><?= dinheiro($p['preco']) ?></span><?php endif; ?>
      <?= dinheiro(precoAtual($p)) ?><small><?= unidadePreco($p) ?></small>
    </div>
    <?php if ($semEstoque): ?>
      <span class="disponibilidade sem">Indisponível</span>
    <?php elseif (estoqueBaixo($p)): ?>
      <span class="disponibilidade baixo">Últimas unidades</span>
    <?php else: ?>
      <span class="disponibilidade">Em estoque</span>
    <?php endif; ?>
    <div class="rodape">
      <form class="form-add" method="post" action="<?= e(url('acoes/carrinho.php')) ?>">
        <?= csrfCampo() ?>
        <input type="hidden" name="acao" value="adicionar">
        <input type="hidden" name="produto_id" value="<?= (int) $p['id'] ?>">
        <input type="hidden" name="qtd" value="<?= e(qtdPadrao($p)) ?>">
        <button class="btn btn-primario btn-sm" type="submit" <?= $semEstoque ? 'disabled' : '' ?>>
          <?= icone('carrinho', 'ico-sm') ?> <?= $semEstoque ? 'Esgotado' : 'Adicionar' ?>
        </button>
      </form>
    </div>
  </div>
</article>
